# Gossenheld – Version 0.9.2

Offline-Fantasy-RPG für Android-Tablets (Querformat). Pixelgrafik wird vom Spiel selbst erzeugt – keine Internetverbindung nötig.

## APK über GitHub bauen
1. Neues Repository auf github.com anlegen.
2. „Add file → Upload files“: die Datei `gossenheld.zip` hochladen, „Commit changes“.
3. „Add file → Create new file“, Dateiname: `.github/workflows/build.yml`, Inhalt aus der Datei `build.yml` einfügen, „Commit changes“.
4. Reiter „Actions“ öffnen → Lauf „Gossenheld APK bauen“ abwarten (ca. 5 Minuten).
5. Unten bei „Artifacts“ `Gossenheld-APK` herunterladen, entpacken, `app-debug.apk` auf dem Tablet öffnen und installieren
   (Installation aus unbekannten Quellen erlauben).

Für ein Update einfach eine neue `gossenheld.zip` hochladen (alte ersetzen) – der Build startet automatisch.

## Dateien
- `www/` – das Spiel (HTML/JavaScript)
- `capacitor.config.json`, `package.json` – verpacken das Spiel als Android-App
