'use strict';
// ---------- Pixel-Grafik (prozedural erzeugt) ----------
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function paint(ctx, pat, pal, ox, oy) {
  for (let y = 0; y < pat.length; y++) { const row = pat[y];
    for (let x = 0; x < row.length; x++) { const col = pal[row[x]]; if (!col) continue; ctx.fillStyle = col; ctx.fillRect((ox || 0) + x, (oy || 0) + y, 1, 1); } }
}
function addOutline(c, col) {
  const ctx = c.getContext('2d'), w = c.width, h = c.height;
  const img = ctx.getImageData(0, 0, w, h), d = img.data, src = new Uint8ClampedArray(d);
  const r = parseInt(col.slice(1, 3), 16), g = parseInt(col.slice(3, 5), 16), b = parseInt(col.slice(5, 7), 16);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4; if (src[i + 3] > 0) continue;
    if ((x > 0 && src[i - 1] > 0) || (x < w - 1 && src[i + 7] > 0) || (y > 0 && src[i - w * 4 + 3] > 0) || (y < h - 1 && src[i + w * 4 + 3] > 0)) {
      d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 220;
    }
  }
  ctx.putImageData(img, 0, 0); return c;
}
function circ(ctx, cx, cy, r, col) {
  ctx.fillStyle = col;
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
    const dx = x + 0.5 - cx, dy = y + 0.5 - cy; if (dx * dx + dy * dy <= r * r) ctx.fillRect(x, y, 1, 1);
  }
}
function speck(ctx, w, h, base, cols, dens, seed) {
  ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (hash2(x, y, seed) < dens) {
    ctx.fillStyle = cols[Math.floor(hash2(x + 31, y + 17, seed) * cols.length)]; ctx.fillRect(x, y, 1, 1);
  }
}
// --- Figuren ---
const HUM = [
'................','.....hhhhhh.....','....hhhhhhhh....','....hhsssshh....','....hsessesh....','....ssssssss....','.....ssssss.....','......kkkk......',
'....oooooooo....','...soooooooos...','...soOooooOos...','....bbbbbbbb....','....pppppppp....','.....pp..pp.....','.....pp..pp.....','.....ff..ff.....'];
const SPR_CACHE = {};
function makeHumanoid(o) {
  const key = 'h' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {h:o.hair, s:o.skin, e:o.eye || '#1a1a2a', k:shade(o.skin, -0.2), o:o.outfit, O:shade(o.outfit, -0.28), b:o.belt || '#4a3018', p:o.pants || shade(o.outfit, -0.45), f:o.feet || '#2a1c10'};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = HUM.map(r => r.split(''));
    if (f === 1) { g[13] = '....pp....pp....'.split(''); g[14] = g[13].slice(); g[15] = '....ff....ff....'.split(''); }
    if (o.bald) for (let y = 1; y < 5; y++) for (let x = 0; x < 16; x++) if (g[y][x] === 'h') g[y][x] = 's';
    if (o.longHair) for (let y = 3; y < 9; y++) { g[y][3] = 'h'; g[y][12] = 'h'; }
    if (o.ears) { g[3][3] = 'k'; g[4][3] = 'k'; g[3][12] = 'k'; g[4][12] = 'k'; }
    if (o.beard) { [4, 5, 10, 11].forEach(x => g[5][x] = 'h'); for (let x = 5; x <= 10; x++) g[6][x] = 'h'; for (let x = 6; x <= 9; x++) g[7][x] = 'h'; }
    if (o.helm) { for (let x = 4; x <= 11; x++) { g[2][x] = 'h'; g[3][x] = x === 4 || x === 11 ? 'h' : g[3][x]; } }
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#1a120c');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const QUAD = [
'................','................','................','................','...........ee...','..........hhhh..','..........hehhn.','...bbbbbbbhhhh..',
'..bbbbbbbbbbh...','.tbbbbbbbbbb....','t..bbbbbbbbb....','...dddddddd.....','...l.l....l.l...','...l.l....l.l...','................','................'];
function makeQuad(o) {
  const key = 'q' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {b:o.col, h:o.col, t:o.col, e:'#111', n:'#222', d:shade(o.col, -0.25), l:shade(o.col, -0.45), a:o.col2 || '#e8dcc0', E:shade(o.col, 0.2)};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = QUAD.map(r => r.split(''));
    if (f === 1) { g[12] = '....l.l..l.l....'.split(''); g[13] = g[12].slice(); }
    if (o.antler) { g[2] = '.........a....a.'.split(''); g[3] = '..........a..a..'.split(''); }
    if (o.mane) { for (let x = 9; x <= 11; x++) g[6][x] = 'a'; g[7][10] = 'a'; }
    if (o.wings) { for (let x = 4; x <= 9; x++) { g[5][x] = 'a'; g[6][x - 1] = 'a'; } }
    for (let x = 4; x <= 9; x++) if (g[8][x] === 'b') g[8][x] = 'E';
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#140e0a');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const SLIME = ['......gggg......','.....gGgggg.....','....gGgggggg....','...gggeggeggg...','...gggggggggg...','...dggggggggd...','....dddddddd....'];
function makeSlime(col) {
  const key = 's' + col; if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {g:col, G:shade(col, 0.35), d:shade(col, -0.3), e:'#141414'};
  const a = mkCanvas(16, 16); paint(a.getContext('2d'), SLIME, pal, 0, 8); addOutline(a, '#10140c');
  const b = mkCanvas(16, 16); const sq = SLIME.slice(1); sq.unshift('................'); paint(b.getContext('2d'), sq, pal, 0, 8); addOutline(b, '#10140c');
  SPR_CACHE[key] = [a, b]; return SPR_CACHE[key];
}
function enemySprite(type) {
  const d = ENEMIES[type];
  if (ANIMAL_LOOK[type]) return makeAnimal(type);
  if (d.shape === 'quad') return makeQuad({col:d.col, col2:d.col2, antler:d.antler, mane:d.mane, wings:d.wings});
  if (d.shape === 'slime') return makeSlime(d.col);
  return makeHumanoid({skin:d.col, hair:d.hair || shade(d.outfit, -0.3), outfit:d.outfit, ears:d.ears, helm:d.helm, bald:d.bald, eye:d.eye});
}
// --- Kacheln ---
const TILE_CACHE = {};
function getTile(t, v) { const k = t * 16 + v; let c = TILE_CACHE[k]; if (!c) { c = drawTile(t, v); TILE_CACHE[k] = c; } return c; }
function rockBlob(x, s) {
  circ(x, 8, 9.5, 6.5, '#6a6a70'); circ(x, 7.5, 8.5, 6, '#8d8d92'); circ(x, 6, 7, 3.2, '#a6a6ad'); circ(x, 5.5, 6, 1.4, '#bdbdc4');
}
function specks(x, cols, n, s) { for (let k = 0; k < n; k++) { const px = 4 + Math.floor(hash2(k, 3, s) * 8), py = 5 + Math.floor(hash2(3, k, s) * 6); x.fillStyle = cols[k % cols.length]; x.fillRect(px, py, 2, 1); x.fillRect(px, py + 1, 1, 1); } }
function drawTile(t, v) {
  const tall = (t === TL.TREE || t === TL.PINE || t === TL.DEADTREE);
  const c = mkCanvas(tall ? 20 : 16, tall ? 28 : 16), x = c.getContext('2d'), s = t * 100 + v * 7 + 11;
  let outline = false;
  switch (t) {
    case TL.GRASS:
      speck(x, 16, 16, '#5b9b3d', ['#68ad47', '#4f8c35', '#71b44f'], 0.25, s);
      for (let k = 0; k < 3; k++) { const bx = 1 + Math.floor(hash2(k, v, s) * 13), by = 2 + Math.floor(hash2(v, k, s + 1) * 11); x.fillStyle = '#82c65a'; x.fillRect(bx, by, 1, 2); x.fillRect(bx + 1, by + 1, 1, 1); }
      break;
    case TL.SAND: speck(x, 16, 16, '#d9c58a', ['#ccb679', '#e6d6a2', '#c4ad70'], 0.28, s); break;
    case TL.PATH:
      speck(x, 16, 16, '#a98457', ['#9a774c', '#b9946a', '#8f6c42'], 0.32, s);
      x.fillStyle = '#c4a47a'; x.fillRect(3 + v * 2, 4 + v, 2, 1); x.fillRect(11 - v, 11, 1, 1);
      break;
    case TL.WATER: {
      speck(x, 16, 16, '#3576bd', ['#3d82cb', '#2f6aab'], 0.18, 900);
      x.fillStyle = '#7ab4ec';
      for (const row of [3, 8, 13]) { const x0 = (v * 2 + row * 5) % 16; for (let k = 0; k < 4; k++) x.fillRect((x0 + k) % 16, row, 1, 1); }
      break; }
    case TL.SWAMP: speck(x, 16, 16, '#4b5a33', ['#3e4c2a', '#566a3a', '#3a4a44'], 0.32, s); x.fillStyle = '#35484a'; x.fillRect(4 + v, 9, 4, 2); break;
    case TL.DARK: speck(x, 16, 16, '#3b3142', ['#463a50', '#2e2635', '#4f2a33'], 0.3, s); if (v === 2) { x.fillStyle = '#7a2a2a'; x.fillRect(5, 7, 4, 1); x.fillRect(8, 8, 3, 1); } break;
    case TL.SNOW: speck(x, 16, 16, '#e6edf3', ['#d3deea', '#f8fbfd', '#c8d6e4'], 0.25, s); break;
    case TL.GRAVEL: speck(x, 16, 16, '#857b6c', ['#766c5e', '#978d7d', '#6a6052'], 0.42, s); break;
    case TL.FLOOR:
      x.fillStyle = '#8c867a'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6c665c';
      for (let r = 0; r < 2; r++) { x.fillRect(0, r * 8 + 7, 16, 1); const off = (r % 2) * 4 + (v % 2) * 2; for (let k = 0; k < 2; k++) x.fillRect((off + k * 8) % 16, r * 8, 1, 7); }
      x.fillStyle = '#9d978b'; for (let k = 0; k < 6; k++) x.fillRect(Math.floor(hash2(k, v, s) * 15), Math.floor(hash2(v, k, s) * 15), 1, 1);
      break;
    case TL.BRIDGE:
      x.fillStyle = '#8b5a2b'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#6a4220';
      for (let r = 3; r < 16; r += 4) x.fillRect(0, r, 16, 1);
      x.fillStyle = '#4a2c12'; x.fillRect(0, 0, 1, 16); x.fillRect(15, 0, 1, 16);
      x.fillStyle = '#b08040'; x.fillRect(3, 1, 1, 1); x.fillRect(12, 5, 1, 1); x.fillRect(6, 9, 1, 1);
      break;
    case TL.ROOF: {
      const base = ['#9c3b2b', '#3a5a8c', '#4a6a3a', '#6a5040'][v % 4], dark = shade(base, -0.3), lite = shade(base, 0.2);
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 4 === 3) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if ((k + (Math.floor(y / 4) % 2) * 2) % 4 === 0) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if (y % 4 === 0) { x.fillStyle = lite; x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.WALL: {
      const base = v === 0 ? '#7b7b84' : '#6e6a64';
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 5 === 4 || (k + (Math.floor(y / 5) % 2) * 4) % 8 === 0) { x.fillStyle = shade(base, -0.28); x.fillRect(k, y, 1, 1); }
        else if (y % 5 === 0) { x.fillStyle = shade(base, 0.15); x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.DOOR:
      x.fillStyle = '#3a2412'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6b4422'; x.fillRect(3, 2, 10, 14);
      x.fillStyle = '#53341a'; x.fillRect(6, 2, 1, 14); x.fillRect(9, 2, 1, 14);
      x.fillStyle = '#e0b84a'; x.fillRect(11, 9, 1, 1);
      break;
    case TL.TREE: {
      const autumn = v === 3;
      const c1 = autumn ? '#9a4a1a' : '#2f6a26', c2 = autumn ? '#c8702a' : '#3d8a30', c3 = autumn ? '#e8a040' : '#56a83f', c4 = autumn ? '#f4c060' : '#6cc04e';
      x.fillStyle = '#5c3c20'; x.fillRect(8, 18, 4, 10); x.fillStyle = '#4a2e18'; x.fillRect(8, 18, 1, 10); x.fillRect(7, 26, 6, 2);
      const ox = (v % 2) * 0.5;
      circ(x, 10 + ox, 11, 9, c1); circ(x, 10 + ox, 10, 8, c2); circ(x, 7 + ox, 7, 4, c3);
      circ(x, 13 + ox, 12, 3, c3);
      x.fillStyle = c4; x.fillRect(6, 5, 2, 1); x.fillRect(12, 9, 1, 1); x.fillRect(5, 11, 1, 1);
      if (v === 1) { x.fillStyle = '#d83a3a'; x.fillRect(6, 13, 1, 1); x.fillRect(13, 8, 1, 1); x.fillRect(10, 15, 1, 1); }
      outline = true; break; }
    case TL.PINE: {
      x.fillStyle = '#5c3c20'; x.fillRect(9, 21, 3, 7);
      for (let k = 0; k < 4; k++) { const top = 2 + k * 5, hw = 3 + k * 2; for (let y = 0; y < 7; y++) { const w = Math.floor(hw * (y + 1) / 7); x.fillStyle = '#2c5e3c'; x.fillRect(10 - w, top + y, w * 2 + 1, 1); x.fillStyle = '#3c7a4c'; x.fillRect(10 - w, top + y, Math.max(1, w >> 1), 1); } }
      if (v >= 2) { x.fillStyle = '#eef4fa'; for (let k = 0; k < 4; k++) { const top = 2 + k * 5; x.fillRect(9, top, 3, 1); x.fillRect(10 - 2 - k, top + 6, 2, 1); } }
      outline = true; break; }
    case TL.DEADTREE:
      x.fillStyle = '#5e5044'; x.fillRect(9, 8, 2, 20); x.fillRect(7, 26, 6, 2);
      x.fillStyle = '#4a3e34';
      for (let k = 0; k < 5; k++) { x.fillRect(8 - k, 14 - k, 1, 1); x.fillRect(11 + k, 11 - k, 1, 1); }
      for (let k = 0; k < 3; k++) { x.fillRect(10 + k, 6 - k, 1, 1); x.fillRect(6 - k, 18 - k, 1, 1); }
      outline = true; break;
    case TL.ROCK: rockBlob(x, s); outline = true; break;
    case TL.IRON: rockBlob(x, s); specks(x, ['#c8783a', '#e8a060'], 5, s); outline = true; break;
    case TL.SILVER: rockBlob(x, s); specks(x, ['#f0f4fa', '#b8c4d0'], 5, s); outline = true; break;
    case TL.MITHRIL: rockBlob(x, s); specks(x, ['#3ac8f0', '#a0f4ff'], 6, s); outline = true; break;
    case TL.CRYSTAL:
      rockBlob(x, s);
      x.fillStyle = '#3aa0c0'; x.fillRect(5, 3, 2, 7); x.fillRect(9, 1, 3, 9); x.fillRect(12, 5, 2, 5);
      x.fillStyle = '#7ae4f4'; x.fillRect(5, 3, 1, 6); x.fillRect(9, 1, 1, 8); x.fillRect(12, 5, 1, 4);
      x.fillStyle = '#e0fcff'; x.fillRect(10, 2, 1, 2);
      outline = true; break;
    case TL.HERB:
      for (const p of [[6,9],[8,8],[10,9],[7,11],[9,11],[5,11],[11,11],[8,12]]) { x.fillStyle = '#3f9a3f'; x.fillRect(p[0], p[1], 2, 2); }
      x.fillStyle = '#6ad06a'; x.fillRect(7, 8, 1, 1); x.fillRect(10, 10, 1, 1);
      x.fillStyle = '#f6f4e0'; x.fillRect(6, 7, 1, 1); x.fillRect(10, 7, 1, 1); x.fillRect(8, 6, 1, 1);
      outline = true; break;
    case TL.MUSHROOM:
      for (const m of [[5,9,3],[10,10,2]]) { x.fillStyle = '#efe6d0'; x.fillRect(m[0], m[1], 2, 4); circ(x, m[0] + 1, m[1], m[2], '#c83a2a'); x.fillStyle = '#fff'; x.fillRect(m[0], m[1] - 1, 1, 1); }
      outline = true; break;
    case TL.FLOWER: {
      const cols = ['#f06aa0', '#f0d040', '#7aa0f0', '#f4f4f4', '#e8603a'];
      for (let k = 0; k < 5; k++) { const fx = 2 + Math.floor(hash2(k, v, 41) * 11), fy = 3 + Math.floor(hash2(v, k, 43) * 10); x.fillStyle = '#3f8a32'; x.fillRect(fx, fy + 1, 1, 2); x.fillStyle = cols[(k + v) % 5]; x.fillRect(fx - 1, fy, 3, 1); x.fillRect(fx, fy - 1, 1, 3); x.fillStyle = '#f8e070'; x.fillRect(fx, fy, 1, 1); }
      break; }
    case TL.CHEST:
      x.fillStyle = '#8a5226'; x.fillRect(3, 6, 10, 8); x.fillStyle = '#a8682e'; x.fillRect(3, 6, 10, 3);
      x.fillStyle = '#6a3c18'; x.fillRect(3, 9, 10, 1);
      x.fillStyle = '#d8b040'; x.fillRect(3, 6, 1, 8); x.fillRect(12, 6, 1, 8); x.fillRect(7, 8, 2, 3);
      x.fillStyle = '#2a1a0a'; x.fillRect(7, 10, 2, 1);
      outline = true; break;
    case TL.ANVIL:
      x.fillStyle = '#4a4a52'; x.fillRect(3, 6, 10, 3); x.fillRect(1, 7, 2, 1); x.fillRect(6, 9, 4, 3); x.fillRect(4, 12, 8, 2);
      x.fillStyle = '#74747e'; x.fillRect(3, 6, 10, 1);
      outline = true; break;
    case TL.HEARTH: {
      for (let k = 0; k < 8; k++) { const a = k / 8 * TAU; x.fillStyle = k % 2 ? '#7a7a80' : '#5e5e64'; x.fillRect(Math.round(8 + Math.cos(a) * 5) - 1, Math.round(10 + Math.sin(a) * 3) - 1, 3, 2); }
      const h = [6, 8, 7, 9][v];
      x.fillStyle = '#e04a1a'; x.fillRect(5, 11 - h * 0.6, 6, h * 0.6 + 1);
      x.fillStyle = '#f0a020'; x.fillRect(6, 11 - h * 0.5 + 1, 4, h * 0.5);
      x.fillStyle = '#ffe070'; x.fillRect(7, 10 - (v % 2), 2, 2);
      outline = true; break; }
    case TL.FENCE:
      x.fillStyle = '#7a5228'; x.fillRect(2, 4, 2, 11); x.fillRect(12, 4, 2, 11);
      x.fillStyle = '#a07440'; x.fillRect(0, 6, 16, 2); x.fillRect(0, 11, 16, 2);
      outline = true; break;
    case TL.VOID: x.fillStyle = '#000'; x.fillRect(0, 0, 16, 16); break;
    case TL.WOOD:
      x.fillStyle = '#8a5a32'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6e4626'; for (let r = 0; r < 16; r += 4) x.fillRect(0, r + 3, 16, 1);
      for (let r = 0; r < 4; r++) x.fillRect(((r * 5 + v * 3) % 12) + 2, r * 4, 1, 3);
      x.fillStyle = '#9c6a3c'; x.fillRect(2 + v, 1, 3, 1); x.fillRect(9, 9 - v, 3, 1);
      break;
    case TL.IWALL:
      x.fillStyle = '#5a3a22'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#4a2e1a'; for (let k = 0; k < 16; k += 4) x.fillRect(k, 0, 1, 16);
      x.fillStyle = '#3a2212'; x.fillRect(0, 12, 16, 4); x.fillStyle = '#6e4a2c'; x.fillRect(0, 12, 16, 1);
      break;
    case TL.EXIT:
      x.fillStyle = '#8a5a32'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#9a2a2a'; x.fillRect(2, 2, 12, 12); x.fillStyle = '#d8b040'; x.fillRect(3, 3, 10, 1); x.fillRect(3, 12, 10, 1);
      x.fillStyle = 'rgba(255,240,200,.5)'; x.fillRect(5, 13, 6, 3);
      break;
    case TL.BED:
      x.fillStyle = '#6a4220'; x.fillRect(1, 1, 14, 14); x.fillStyle = '#e8e0d0'; x.fillRect(2, 2, 12, 4);
      x.fillStyle = '#3a6aa8'; x.fillRect(2, 6, 12, 8); x.fillStyle = '#5a8ac8'; x.fillRect(2, 6, 12, 2);
      outline = true; break;
    case TL.TABLE:
      x.fillStyle = '#5a3a1a'; x.fillRect(3, 11, 2, 4); x.fillRect(11, 11, 2, 4);
      x.fillStyle = '#9a6a3a'; x.fillRect(1, 4, 14, 8); x.fillStyle = '#b8844a'; x.fillRect(1, 4, 14, 2);
      x.fillStyle = '#e8e0d0'; x.fillRect(5, 5, 3, 2); x.fillStyle = '#c8a040'; x.fillRect(10, 5, 2, 2);
      outline = true; break;
    case TL.SHELF:
      x.fillStyle = '#5a3a1a'; x.fillRect(1, 0, 14, 16); x.fillStyle = '#3a2410'; x.fillRect(2, 1, 12, 14);
      for (let r = 0; r < 3; r++) { x.fillStyle = '#7a5228'; x.fillRect(2, 5 + r * 5, 12, 1); for (let k = 0; k < 5; k++) { x.fillStyle = ['#a03030','#3050a0','#30803a','#c8a040','#7a3a8a'][(k + r + v) % 5]; x.fillRect(3 + k * 2, 1 + r * 5, 2, 4); } }
      outline = true; break;
    case TL.THRONE:
      x.fillStyle = '#c8a030'; x.fillRect(3, 0, 10, 15); x.fillStyle = '#e8c850'; x.fillRect(4, 1, 8, 1);
      x.fillStyle = '#8a1a2a'; x.fillRect(5, 3, 6, 10); x.fillStyle = '#c8a030'; x.fillRect(2, 8, 2, 7); x.fillRect(12, 8, 2, 7);
      outline = true; break;
    case TL.ALTAR:
      x.fillStyle = '#c8c8d0'; x.fillRect(1, 6, 14, 9); x.fillStyle = '#e8e8f0'; x.fillRect(1, 6, 14, 2);
      x.fillStyle = '#f8e8a0'; x.fillRect(4, 2, 1, 4); x.fillRect(11, 2, 1, 4); x.fillStyle = '#ffb030'; x.fillRect(4, 1, 1, 1); x.fillRect(11, 1, 1, 1);
      outline = true; break;
    case TL.TROPHY:
      x.fillStyle = '#6a4a2a'; x.fillRect(4, 3, 8, 8); x.fillStyle = '#a8743c'; x.fillRect(6, 6, 4, 5);
      x.fillStyle = '#e8dcc0'; x.fillRect(3, 1, 1, 4); x.fillRect(12, 1, 1, 4); x.fillRect(4, 2, 2, 1); x.fillRect(10, 2, 2, 1);
      outline = true; break;
    case TL.BARREL:
      x.fillStyle = '#7a4a22'; x.fillRect(3, 3, 10, 12); x.fillStyle = '#9a6232'; x.fillRect(5, 3, 3, 12);
      x.fillStyle = '#4a4a50'; x.fillRect(3, 5, 10, 1); x.fillRect(3, 12, 10, 1);
      outline = true; break;
    case TL.CARPET:
      x.fillStyle = '#8a2a2a'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#a83a3a'; x.fillRect(2, 2, 12, 12);
      x.fillStyle = '#d8b040'; x.fillRect(7, 6, 2, 4); x.fillRect(6, 7, 4, 2);
      break;
    case TL.HCHEST:
      x.fillStyle = '#5a3a1a'; x.fillRect(2, 5, 12, 10); x.fillStyle = '#7a5228'; x.fillRect(2, 5, 12, 4);
      x.fillStyle = '#b8b8c0'; x.fillRect(2, 9, 12, 1); x.fillRect(7, 8, 2, 3);
      outline = true; break;
    case TL.COUNTER:
      x.fillStyle = '#6a4220'; x.fillRect(0, 5, 16, 11); x.fillStyle = '#a8743c'; x.fillRect(0, 4, 16, 3);
      x.fillStyle = '#4a2a12'; x.fillRect(0, 9, 16, 1);
      break;
    case TL.BOARD:
      x.fillStyle = '#5a3a1a'; x.fillRect(1, 1, 14, 12); x.fillRect(3, 13, 2, 3); x.fillRect(11, 13, 2, 3);
      x.fillStyle = '#a8743c'; x.fillRect(2, 2, 12, 10);
      x.fillStyle = '#f4ead0'; x.fillRect(3, 3, 4, 4); x.fillRect(8, 4, 5, 3); x.fillRect(4, 8, 5, 3);
      x.fillStyle = '#c03030'; x.fillRect(5, 3, 1, 1); x.fillRect(10, 4, 1, 1);
      outline = true; break;
    case TL.SLOT:
      x.fillStyle = 'rgba(255,240,200,.35)';
      for (let k = 1; k < 15; k += 3) { x.fillRect(k, 1, 2, 1); x.fillRect(k, 14, 2, 1); x.fillRect(1, k, 1, 2); x.fillRect(14, k, 1, 2); }
      x.fillStyle = 'rgba(255,240,200,.6)'; x.fillRect(7, 5, 2, 6); x.fillRect(5, 7, 6, 2);
      break;
  }
  if (outline) addOutline(c, '#1a140e');
  return c;
}
// ---------- Tiere: jede Art mit eigener Silhouette ----------
// Blickrichtung rechts, Füße unten (y=15). f = Lauf-Frame 0/1
const ANIMAL_DRAW = {
  ratte(R, f, c) {
    const pink = '#d89a9a', l = shade(c, 0.25), d = shade(c, -0.3);
    R(0, 12, 1, 1, pink); R(1, 13, 2, 1, pink); R(3, 12, 2, 1, pink);
    R(5, 10, 7, 3, c); R(6, 9, 5, 1, c); R(6, 12, 5, 1, l);
    R(11, 10, 3, 2, c); R(14, 11, 1, 1, pink); R(12, 8, 2, 2, pink); R(12, 10, 1, 1, '#111');
    if (f) { R(6, 13, 1, 2, d); R(10, 13, 1, 2, d); } else { R(7, 13, 1, 2, d); R(11, 13, 1, 2, d); }
  },
  wolf(R, f, c, o) {
    const l = shade(c, 0.35), d = shade(c, -0.35), eye = o.eye || '#f0d040';
    R(0, 4, 2, 2, c); R(1, 6, 2, 2, c); R(2, 7, 2, 1, c); R(0, 4, 1, 1, l);
    R(3, 6, 9, 5, c); R(4, 5, 7, 1, c); R(4, 10, 7, 1, l); R(4, 6, 6, 1, d);
    R(10, 4, 4, 4, c); R(13, 6, 3, 2, c); R(15, 6, 1, 1, '#111'); R(13, 8, 2, 1, l);
    R(10, 2, 1, 2, c); R(12, 2, 1, 2, c); R(10, 3, 1, 1, d); R(12, 5, 1, 1, eye);
    if (o.spikes) for (let k = 4; k < 11; k += 2) R(k, 4, 1, 1, d);
    const legs = f ? [3, 6, 9, 11] : [4, 5, 10, 11];
    legs.forEach((x, k) => R(x, 11, 1, 4, k % 2 ? c : d));
  },
  eber(R, f, c) {
    const d = shade(c, -0.4), l = shade(c, 0.2);
    R(1, 7, 1, 2, d); R(2, 7, 9, 5, c); R(3, 6, 7, 1, c); R(6, 5, 5, 1, c); R(7, 4, 4, 1, d);
    for (let k = 3; k < 11; k += 2) R(k, k < 7 ? 6 : 5, 1, 1, d);
    R(11, 6, 3, 5, c); R(14, 8, 2, 3, '#c88a7a'); R(15, 9, 1, 1, '#5a2a2a');
    R(13, 11, 1, 1, '#f8f4e8'); R(14, 10, 1, 1, '#f8f4e8'); R(12, 5, 1, 2, d); R(12, 8, 1, 1, '#111');
    R(3, 11, 7, 1, l);
    const legs = f ? [3, 5, 8, 10] : [2, 5, 9, 10];
    legs.forEach(x => R(x, 12, 1, 3, d));
  },
  hirsch(R, f, c, o) {
    const l = o.belly || '#f0e4c8', d = shade(c, -0.35), ant = o.ant || '#e8dcc0';
    R(2, 6, 1, 2, '#ffffff'); R(3, 7, 9, 3, c); R(4, 6, 7, 1, c); R(4, 9, 7, 1, l);
    R(10, 3, 2, 5, c); R(11, 2, 3, 3, c); R(14, 3, 1, 2, d); R(13, 3, 1, 1, '#111'); R(10, 2, 1, 1, d);
    R(11, 0, 1, 2, ant); R(13, 0, 1, 2, ant); R(10, 0, 1, 1, ant); R(14, 0, 1, 1, ant); R(12, 1, 1, 1, ant);
    const legs = f ? [4, 6, 9, 11] : [3, 5, 10, 11];
    legs.forEach(x => R(x, 10, 1, 5, d));
    if (o.spark) { R(5, 7, 1, 1, '#ffffff'); R(9, 8, 1, 1, '#ffffff'); }
  },
  pferd(R, f, c, o) {
    const d = shade(c, -0.35), m = o.mane || '#2a1a0a';
    R(1, 6, 1, 6, m); R(2, 6, 1, 3, m);
    R(2, 6, 10, 4, c); R(3, 5, 8, 1, c); R(3, 9, 8, 1, shade(c, 0.15));
    R(10, 2, 3, 5, c); R(12, 2, 3, 3, c); R(14, 3, 2, 2, d); R(15, 4, 1, 1, '#111'); R(12, 3, 1, 1, '#111'); R(11, 1, 1, 1, c);
    R(9, 1, 2, 6, m);
    const legs = f ? [3, 5, 9, 11] : [2, 4, 10, 11];
    legs.forEach(x => { R(x, 10, 1, 4, d); R(x, 14, 1, 1, '#2a1a0a'); });
  },
  baer(R, f, c) {
    const d = shade(c, -0.35), l = shade(c, 0.2);
    R(1, 7, 2, 2, c); R(2, 5, 10, 7, c); R(3, 4, 8, 1, c); R(4, 5, 6, 1, l);
    R(10, 4, 5, 5, c); R(14, 6, 2, 2, '#a8865a'); R(15, 6, 1, 1, '#111'); R(13, 5, 1, 1, '#111');
    R(10, 3, 2, 1, c); R(14, 3, 1, 1, c); R(10, 3, 1, 1, d);
    const legs = f ? [3, 6, 9, 11] : [2, 5, 9, 12];
    legs.forEach(x => R(x, 12, 2, 3, d));
  }
};
const ANIMAL_LOOK = {
  ratte:['ratte', {}], wolf:['wolf', {}], warg:['wolf', {spikes:true, eye:'#f03030'}], eber:['eber', {}],
  hirsch:['hirsch', {}], goldhirsch:['hirsch', {ant:'#fff6a0', belly:'#fff6c0', spark:true}], pferd:['pferd', {}], baer:['baer', {}]
};
function makeAnimal(type) {
  const key = 'a' + type; if (SPR_CACHE[key]) return SPR_CACHE[key];
  const d = ENEMIES[type], lk = ANIMAL_LOOK[type], frames = [];
  for (let f = 0; f < 2; f++) {
    const c = mkCanvas(16, 16), x = c.getContext('2d');
    const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
    ANIMAL_DRAW[lk[0]](R, f, d.col, lk[1]); addOutline(c, '#140e0a'); frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
// ---------- Entwicklungsstufen gezähmter Tiere ----------
// 0 Jungtier · 1 Kampferprobt (St. 5) · 2 Veteran (St. 10) · 3 Legendär (St. 15)
const PET_TIERS = [
  {lvl:1, name:'Jungtier'}, {lvl:5, name:'Kampferprobt'}, {lvl:10, name:'Veteran'}, {lvl:15, name:'Legendär'}
];
function petTier(lvl) { let t = 0; PET_TIERS.forEach((p, k) => { if (lvl >= p.lvl) t = k; }); return t; }
// gear: {armor:Farbe|null, saddle:Farbe|null}
function makePetSprite(type, tier, gear) {
  gear = gear || {};
  const key = 'p' + type + tier + (gear.armor || '') + (gear.saddle || ''); if (SPR_CACHE[key]) return SPR_CACHE[key];
  const d = ENEMIES[type], lk = ANIMAL_LOOK[type], frames = [];
  const base = tier >= 2 ? shade(d.col, -0.18) : d.col;
  for (let f = 0; f < 2; f++) {
    const c = mkCanvas(16, 16), x = c.getContext('2d');
    const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
    ANIMAL_DRAW[lk[0]](R, f, base, Object.assign({}, lk[1], tier >= 3 ? {eye:'#7af0ff'} : tier >= 2 ? {eye:'#f06a20'} : {}));
    const img = x.getImageData(0, 0, 16, 16).data, on = (a, b) => a >= 0 && b >= 0 && a < 16 && b < 16 && img[(b * 16 + a) * 4 + 3] > 0;
    const top = []; for (let a = 0; a < 16; a++) { top[a] = -1; for (let b = 0; b < 12; b++) if (on(a, b)) { top[a] = b; break; } }
    // Stufe 1+: Kampfnarben / Kriegsbemalung
    if (tier >= 1) for (let a = 4; a <= 9; a += 2) { const t = top[a]; if (t < 0) continue; for (let b = t + 1; b <= t + 3; b++) if (on(a, b)) R(a, b, 1, 1, tier >= 3 ? '#e8c040' : '#7a1a12'); }
    // Stufe 2+: Stachelhalsband
    if (tier >= 2) for (let b = 0; b < 16; b++) if (on(10, b) && on(10, b + 1) && b > top[10] + 1) { R(10, b, 1, 2, '#3a2a1a'); R(11, b, 1, 1, '#d8dce4'); R(9, b, 1, 1, '#d8dce4'); break; }
    // Rüstung: Platten auf dem Rücken
    if (gear.armor) { const hi = shade(gear.armor, 0.4); for (let a = 3; a <= 10; a++) { const t = top[a]; if (t < 0) continue; R(a, t, 1, 2, gear.armor); R(a, t, 1, 1, hi); if (on(a, t + 2) && a % 2) R(a, t + 2, 1, 1, shade(gear.armor, -0.3)); } }
    // Sattel mit Decke und Steigbügel
    if (gear.saddle) {
      const sx = 5, t = Math.min(top[5], top[6], top[7]); if (t >= 0) {
        R(sx - 1, t, 5, 2, '#a8282a'); R(sx - 1, t + 1, 5, 1, '#e8c040');
        R(sx, t - 1, 3, 2, gear.saddle); R(sx, t - 1, 1, 1, shade(gear.saddle, 0.3)); R(sx + 2, t - 2, 1, 1, gear.saddle);
        R(sx + 1, t + 2, 1, 2, '#3a2a1a'); R(sx, t + 4, 3, 1, '#a8acb8');
      }
    }
    // Stufe 3: Hörner/Stacheln aus Gold
    if (tier >= 3) for (const a of [4, 8]) { const t = top[a]; if (t > 0 && !(gear.saddle && a < 9 && a > 3)) { R(a, t - 1, 1, 1, '#fff6b0'); if (t > 1) R(a, t - 2, 1, 1, '#e8c040'); } }
    addOutline(c, tier >= 3 ? '#3a2a00' : '#140e0a'); frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
function petGearLook(p) { const g = p.gear || {}; return {armor:g.armor ? ITEMS[g.armor.id].petCol : null, saddle:g.saddle ? ITEMS[g.saddle.id].petCol : null}; }
function petSprite(p) { return makePetSprite(p.type, petTier(p.lvl || 1), petGearLook(p)); }
function petSize(p) { return (ENEMIES[p.type].size || 1) * (1 + 0.08 * petTier(p.lvl || 1)); }
