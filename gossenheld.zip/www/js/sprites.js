'use strict';
// ---------- Pixel-Grafik (prozedural erzeugt) ----------
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function paint(ctx, pat, pal, ox, oy) {
  for (let y = 0; y < pat.length; y++) { const row = pat[y];
    for (let x = 0; x < row.length; x++) { const col = pal[row[x]]; if (!col) continue; ctx.fillStyle = col; ctx.fillRect((ox || 0) + x, (oy || 0) + y, 1, 1); } }
}
function addOutline(c, col) {
  const ctx = c.getContext('2d'), w = c.width, h = c.height;
  const img = ctx.getImageData(0, 0, w, h), d = img.data, src = new Uint8ClampedArray(d);
  const r = parseInt(col.slice(1, 3), 16), g = parseInt(col.slice(3, 5), 16), b = parseInt(col.slice(5, 7), 16);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4; if (src[i + 3] > 0) continue;
    if ((x > 0 && src[i - 1] > 0) || (x < w - 1 && src[i + 7] > 0) || (y > 0 && src[i - w * 4 + 3] > 0) || (y < h - 1 && src[i + w * 4 + 3] > 0)) {
      d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 220;
    }
  }
  ctx.putImageData(img, 0, 0); return c;
}
function circ(ctx, cx, cy, r, col) {
  ctx.fillStyle = col;
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
    const dx = x + 0.5 - cx, dy = y + 0.5 - cy; if (dx * dx + dy * dy <= r * r) ctx.fillRect(x, y, 1, 1);
  }
}
function speck(ctx, w, h, base, cols, dens, seed) {
  ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (hash2(x, y, seed) < dens) {
    ctx.fillStyle = cols[Math.floor(hash2(x + 31, y + 17, seed) * cols.length)]; ctx.fillRect(x, y, 1, 1);
  }
}
// --- Figuren ---
const HUM = [
'................','.....hhhhhh.....','....hhhhhhhh....','....hhsssshh....','....hsessesh....','....ssssssss....','.....ssssss.....','......kkkk......',
'....oooooooo....','...soooooooos...','...soOooooOos...','....bbbbbbbb....','....pppppppp....','.....pp..pp.....','.....pp..pp.....','.....ff..ff.....'];
const SPR_CACHE = {};
function makeHumanoid(o) {
  const key = 'h' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {h:o.hair, s:o.skin, e:o.eye || '#1a1a2a', k:shade(o.skin, -0.2), o:o.outfit, O:shade(o.outfit, -0.28), b:o.belt || '#4a3018', p:o.pants || shade(o.outfit, -0.45), f:o.feet || '#2a1c10'};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = HUM.map(r => r.split(''));
    if (f === 1) { g[13] = '....pp....pp....'.split(''); g[14] = g[13].slice(); g[15] = '....ff....ff....'.split(''); }
    if (o.bald) for (let y = 1; y < 5; y++) for (let x = 0; x < 16; x++) if (g[y][x] === 'h') g[y][x] = 's';
    if (o.longHair) for (let y = 3; y < 9; y++) { g[y][3] = 'h'; g[y][12] = 'h'; }
    if (o.ears) { g[3][3] = 'k'; g[4][3] = 'k'; g[3][12] = 'k'; g[4][12] = 'k'; }
    if (o.beard) { [4, 5, 10, 11].forEach(x => g[5][x] = 'h'); for (let x = 5; x <= 10; x++) g[6][x] = 'h'; for (let x = 6; x <= 9; x++) g[7][x] = 'h'; }
    if (o.helm) { for (let x = 4; x <= 11; x++) { g[2][x] = 'h'; g[3][x] = x === 4 || x === 11 ? 'h' : g[3][x]; } }
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#1a120c');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const QUAD = [
'................','................','................','................','...........ee...','..........hhhh..','..........hehhn.','...bbbbbbbhhhh..',
'..bbbbbbbbbbh...','.tbbbbbbbbbb....','t..bbbbbbbbb....','...dddddddd.....','...l.l....l.l...','...l.l....l.l...','................','................'];
function makeQuad(o) {
  const key = 'q' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {b:o.col, h:o.col, t:o.col, e:'#111', n:'#222', d:shade(o.col, -0.25), l:shade(o.col, -0.45), a:o.col2 || '#e8dcc0', E:shade(o.col, 0.2)};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = QUAD.map(r => r.split(''));
    if (f === 1) { g[12] = '....l.l..l.l....'.split(''); g[13] = g[12].slice(); }
    if (o.antler) { g[2] = '.........a....a.'.split(''); g[3] = '..........a..a..'.split(''); }
    if (o.mane) { for (let x = 9; x <= 11; x++) g[6][x] = 'a'; g[7][10] = 'a'; }
    if (o.wings) { for (let x = 4; x <= 9; x++) { g[5][x] = 'a'; g[6][x - 1] = 'a'; } }
    for (let x = 4; x <= 9; x++) if (g[8][x] === 'b') g[8][x] = 'E';
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#140e0a');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const SLIME = ['......gggg......','.....gGgggg.....','....gGgggggg....','...gggeggeggg...','...gggggggggg...','...dggggggggd...','....dddddddd....'];
function makeSlime(col) {
  const key = 's' + col; if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {g:col, G:shade(col, 0.35), d:shade(col, -0.3), e:'#141414'};
  const a = mkCanvas(16, 16); paint(a.getContext('2d'), SLIME, pal, 0, 8); addOutline(a, '#10140c');
  const b = mkCanvas(16, 16); const sq = SLIME.slice(1); sq.unshift('................'); paint(b.getContext('2d'), sq, pal, 0, 8); addOutline(b, '#10140c');
  SPR_CACHE[key] = [a, b]; return SPR_CACHE[key];
}
function enemySprite(type) {
  const d = ENEMIES[type];
  if (d.shape === 'quad') return makeQuad({col:d.col, col2:d.col2, antler:d.antler, mane:d.mane, wings:d.wings});
  if (d.shape === 'slime') return makeSlime(d.col);
  return makeHumanoid({skin:d.col, hair:d.hair || shade(d.outfit, -0.3), outfit:d.outfit, ears:d.ears, helm:d.helm, bald:d.bald, eye:d.eye});
}
// --- Kacheln ---
const TILE_CACHE = {};
function getTile(t, v) { const k = t * 16 + v; let c = TILE_CACHE[k]; if (!c) { c = drawTile(t, v); TILE_CACHE[k] = c; } return c; }
function rockBlob(x, s) {
  circ(x, 8, 9.5, 6.5, '#6a6a70'); circ(x, 7.5, 8.5, 6, '#8d8d92'); circ(x, 6, 7, 3.2, '#a6a6ad'); circ(x, 5.5, 6, 1.4, '#bdbdc4');
}
function specks(x, cols, n, s) { for (let k = 0; k < n; k++) { const px = 4 + Math.floor(hash2(k, 3, s) * 8), py = 5 + Math.floor(hash2(3, k, s) * 6); x.fillStyle = cols[k % cols.length]; x.fillRect(px, py, 2, 1); x.fillRect(px, py + 1, 1, 1); } }
function drawTile(t, v) {
  const tall = (t === TL.TREE || t === TL.PINE || t === TL.DEADTREE);
  const c = mkCanvas(tall ? 20 : 16, tall ? 28 : 16), x = c.getContext('2d'), s = t * 100 + v * 7 + 11;
  let outline = false;
  switch (t) {
    case TL.GRASS:
      speck(x, 16, 16, '#5b9b3d', ['#68ad47', '#4f8c35', '#71b44f'], 0.25, s);
      for (let k = 0; k < 3; k++) { const bx = 1 + Math.floor(hash2(k, v, s) * 13), by = 2 + Math.floor(hash2(v, k, s + 1) * 11); x.fillStyle = '#82c65a'; x.fillRect(bx, by, 1, 2); x.fillRect(bx + 1, by + 1, 1, 1); }
      break;
    case TL.SAND: speck(x, 16, 16, '#d9c58a', ['#ccb679', '#e6d6a2', '#c4ad70'], 0.28, s); break;
    case TL.PATH:
      speck(x, 16, 16, '#a98457', ['#9a774c', '#b9946a', '#8f6c42'], 0.32, s);
      x.fillStyle = '#c4a47a'; x.fillRect(3 + v * 2, 4 + v, 2, 1); x.fillRect(11 - v, 11, 1, 1);
      break;
    case TL.WATER: {
      speck(x, 16, 16, '#3576bd', ['#3d82cb', '#2f6aab'], 0.18, 900);
      x.fillStyle = '#7ab4ec';
      for (const row of [3, 8, 13]) { const x0 = (v * 2 + row * 5) % 16; for (let k = 0; k < 4; k++) x.fillRect((x0 + k) % 16, row, 1, 1); }
      break; }
    case TL.SWAMP: speck(x, 16, 16, '#4b5a33', ['#3e4c2a', '#566a3a', '#3a4a44'], 0.32, s); x.fillStyle = '#35484a'; x.fillRect(4 + v, 9, 4, 2); break;
    case TL.DARK: speck(x, 16, 16, '#3b3142', ['#463a50', '#2e2635', '#4f2a33'], 0.3, s); if (v === 2) { x.fillStyle = '#7a2a2a'; x.fillRect(5, 7, 4, 1); x.fillRect(8, 8, 3, 1); } break;
    case TL.SNOW: speck(x, 16, 16, '#e6edf3', ['#d3deea', '#f8fbfd', '#c8d6e4'], 0.25, s); break;
    case TL.GRAVEL: speck(x, 16, 16, '#857b6c', ['#766c5e', '#978d7d', '#6a6052'], 0.42, s); break;
    case TL.FLOOR:
      x.fillStyle = '#8c867a'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6c665c';
      for (let r = 0; r < 2; r++) { x.fillRect(0, r * 8 + 7, 16, 1); const off = (r % 2) * 4 + (v % 2) * 2; for (let k = 0; k < 2; k++) x.fillRect((off + k * 8) % 16, r * 8, 1, 7); }
      x.fillStyle = '#9d978b'; for (let k = 0; k < 6; k++) x.fillRect(Math.floor(hash2(k, v, s) * 15), Math.floor(hash2(v, k, s) * 15), 1, 1);
      break;
    case TL.BRIDGE:
      x.fillStyle = '#8b5a2b'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#6a4220';
      for (let r = 3; r < 16; r += 4) x.fillRect(0, r, 16, 1);
      x.fillStyle = '#4a2c12'; x.fillRect(0, 0, 1, 16); x.fillRect(15, 0, 1, 16);
      x.fillStyle = '#b08040'; x.fillRect(3, 1, 1, 1); x.fillRect(12, 5, 1, 1); x.fillRect(6, 9, 1, 1);
      break;
    case TL.ROOF: {
      const base = ['#9c3b2b', '#3a5a8c', '#4a6a3a', '#6a5040'][v % 4], dark = shade(base, -0.3), lite = shade(base, 0.2);
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 4 === 3) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if ((k + (Math.floor(y / 4) % 2) * 2) % 4 === 0) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if (y % 4 === 0) { x.fillStyle = lite; x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.WALL: {
      const base = v === 0 ? '#7b7b84' : '#6e6a64';
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 5 === 4 || (k + (Math.floor(y / 5) % 2) * 4) % 8 === 0) { x.fillStyle = shade(base, -0.28); x.fillRect(k, y, 1, 1); }
        else if (y % 5 === 0) { x.fillStyle = shade(base, 0.15); x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.DOOR:
      x.fillStyle = '#3a2412'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6b4422'; x.fillRect(3, 2, 10, 14);
      x.fillStyle = '#53341a'; x.fillRect(6, 2, 1, 14); x.fillRect(9, 2, 1, 14);
      x.fillStyle = '#e0b84a'; x.fillRect(11, 9, 1, 1);
      break;
    case TL.TREE: {
      const autumn = v === 3;
      const c1 = autumn ? '#9a4a1a' : '#2f6a26', c2 = autumn ? '#c8702a' : '#3d8a30', c3 = autumn ? '#e8a040' : '#56a83f', c4 = autumn ? '#f4c060' : '#6cc04e';
      x.fillStyle = '#5c3c20'; x.fillRect(8, 18, 4, 10); x.fillStyle = '#4a2e18'; x.fillRect(8, 18, 1, 10); x.fillRect(7, 26, 6, 2);
      const ox = (v % 2) * 0.5;
      circ(x, 10 + ox, 11, 9, c1); circ(x, 10 + ox, 10, 8, c2); circ(x, 7 + ox, 7, 4, c3);
      circ(x, 13 + ox, 12, 3, c3);
      x.fillStyle = c4; x.fillRect(6, 5, 2, 1); x.fillRect(12, 9, 1, 1); x.fillRect(5, 11, 1, 1);
      if (v === 1) { x.fillStyle = '#d83a3a'; x.fillRect(6, 13, 1, 1); x.fillRect(13, 8, 1, 1); x.fillRect(10, 15, 1, 1); }
      outline = true; break; }
    case TL.PINE: {
      x.fillStyle = '#5c3c20'; x.fillRect(9, 21, 3, 7);
      for (let k = 0; k < 4; k++) { const top = 2 + k * 5, hw = 3 + k * 2; for (let y = 0; y < 7; y++) { const w = Math.floor(hw * (y + 1) / 7); x.fillStyle = '#2c5e3c'; x.fillRect(10 - w, top + y, w * 2 + 1, 1); x.fillStyle = '#3c7a4c'; x.fillRect(10 - w, top + y, Math.max(1, w >> 1), 1); } }
      if (v >= 2) { x.fillStyle = '#eef4fa'; for (let k = 0; k < 4; k++) { const top = 2 + k * 5; x.fillRect(9, top, 3, 1); x.fillRect(10 - 2 - k, top + 6, 2, 1); } }
      outline = true; break; }
    case TL.DEADTREE:
      x.fillStyle = '#5e5044'; x.fillRect(9, 8, 2, 20); x.fillRect(7, 26, 6, 2);
      x.fillStyle = '#4a3e34';
      for (let k = 0; k < 5; k++) { x.fillRect(8 - k, 14 - k, 1, 1); x.fillRect(11 + k, 11 - k, 1, 1); }
      for (let k = 0; k < 3; k++) { x.fillRect(10 + k, 6 - k, 1, 1); x.fillRect(6 - k, 18 - k, 1, 1); }
      outline = true; break;
    case TL.ROCK: rockBlob(x, s); outline = true; break;
    case TL.IRON: rockBlob(x, s); specks(x, ['#c8783a', '#e8a060'], 5, s); outline = true; break;
    case TL.SILVER: rockBlob(x, s); specks(x, ['#f0f4fa', '#b8c4d0'], 5, s); outline = true; break;
    case TL.MITHRIL: rockBlob(x, s); specks(x, ['#3ac8f0', '#a0f4ff'], 6, s); outline = true; break;
    case TL.CRYSTAL:
      rockBlob(x, s);
      x.fillStyle = '#3aa0c0'; x.fillRect(5, 3, 2, 7); x.fillRect(9, 1, 3, 9); x.fillRect(12, 5, 2, 5);
      x.fillStyle = '#7ae4f4'; x.fillRect(5, 3, 1, 6); x.fillRect(9, 1, 1, 8); x.fillRect(12, 5, 1, 4);
      x.fillStyle = '#e0fcff'; x.fillRect(10, 2, 1, 2);
      outline = true; break;
    case TL.HERB:
      for (const p of [[6,9],[8,8],[10,9],[7,11],[9,11],[5,11],[11,11],[8,12]]) { x.fillStyle = '#3f9a3f'; x.fillRect(p[0], p[1], 2, 2); }
      x.fillStyle = '#6ad06a'; x.fillRect(7, 8, 1, 1); x.fillRect(10, 10, 1, 1);
      x.fillStyle = '#f6f4e0'; x.fillRect(6, 7, 1, 1); x.fillRect(10, 7, 1, 1); x.fillRect(8, 6, 1, 1);
      outline = true; break;
    case TL.MUSHROOM:
      for (const m of [[5,9,3],[10,10,2]]) { x.fillStyle = '#efe6d0'; x.fillRect(m[0], m[1], 2, 4); circ(x, m[0] + 1, m[1], m[2], '#c83a2a'); x.fillStyle = '#fff'; x.fillRect(m[0], m[1] - 1, 1, 1); }
      outline = true; break;
    case TL.FLOWER: {
      const cols = ['#f06aa0', '#f0d040', '#7aa0f0', '#f4f4f4', '#e8603a'];
      for (let k = 0; k < 5; k++) { const fx = 2 + Math.floor(hash2(k, v, 41) * 11), fy = 3 + Math.floor(hash2(v, k, 43) * 10); x.fillStyle = '#3f8a32'; x.fillRect(fx, fy + 1, 1, 2); x.fillStyle = cols[(k + v) % 5]; x.fillRect(fx - 1, fy, 3, 1); x.fillRect(fx, fy - 1, 1, 3); x.fillStyle = '#f8e070'; x.fillRect(fx, fy, 1, 1); }
      break; }
    case TL.CHEST:
      x.fillStyle = '#8a5226'; x.fillRect(3, 6, 10, 8); x.fillStyle = '#a8682e'; x.fillRect(3, 6, 10, 3);
      x.fillStyle = '#6a3c18'; x.fillRect(3, 9, 10, 1);
      x.fillStyle = '#d8b040'; x.fillRect(3, 6, 1, 8); x.fillRect(12, 6, 1, 8); x.fillRect(7, 8, 2, 3);
      x.fillStyle = '#2a1a0a'; x.fillRect(7, 10, 2, 1);
      outline = true; break;
    case TL.ANVIL:
      x.fillStyle = '#4a4a52'; x.fillRect(3, 6, 10, 3); x.fillRect(1, 7, 2, 1); x.fillRect(6, 9, 4, 3); x.fillRect(4, 12, 8, 2);
      x.fillStyle = '#74747e'; x.fillRect(3, 6, 10, 1);
      outline = true; break;
    case TL.HEARTH: {
      for (let k = 0; k < 8; k++) { const a = k / 8 * TAU; x.fillStyle = k % 2 ? '#7a7a80' : '#5e5e64'; x.fillRect(Math.round(8 + Math.cos(a) * 5) - 1, Math.round(10 + Math.sin(a) * 3) - 1, 3, 2); }
      const h = [6, 8, 7, 9][v];
      x.fillStyle = '#e04a1a'; x.fillRect(5, 11 - h * 0.6, 6, h * 0.6 + 1);
      x.fillStyle = '#f0a020'; x.fillRect(6, 11 - h * 0.5 + 1, 4, h * 0.5);
      x.fillStyle = '#ffe070'; x.fillRect(7, 10 - (v % 2), 2, 2);
      outline = true; break; }
    case TL.FENCE:
      x.fillStyle = '#7a5228'; x.fillRect(2, 4, 2, 11); x.fillRect(12, 4, 2, 11);
      x.fillStyle = '#a07440'; x.fillRect(0, 6, 16, 2); x.fillRect(0, 11, 16, 2);
      outline = true; break;
  }
  if (outline) addOutline(c, '#1a140e');
  return c;
}
