'use strict';
// ---------- Pixel-Grafik (prozedural erzeugt) ----------
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function paint(ctx, pat, pal, ox, oy) {
  for (let y = 0; y < pat.length; y++) { const row = pat[y];
    for (let x = 0; x < row.length; x++) { const col = pal[row[x]]; if (!col) continue; ctx.fillStyle = col; ctx.fillRect((ox || 0) + x, (oy || 0) + y, 1, 1); } }
}
function addOutline(c, col) {
  const ctx = c.getContext('2d'), w = c.width, h = c.height;
  const img = ctx.getImageData(0, 0, w, h), d = img.data, src = new Uint8ClampedArray(d);
  const r = parseInt(col.slice(1, 3), 16), g = parseInt(col.slice(3, 5), 16), b = parseInt(col.slice(5, 7), 16);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4; if (src[i + 3] > 0) continue;
    if ((x > 0 && src[i - 1] > 0) || (x < w - 1 && src[i + 7] > 0) || (y > 0 && src[i - w * 4 + 3] > 0) || (y < h - 1 && src[i + w * 4 + 3] > 0)) {
      d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 220;
    }
  }
  ctx.putImageData(img, 0, 0); return c;
}
function circ(ctx, cx, cy, r, col) {
  ctx.fillStyle = col;
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
    const dx = x + 0.5 - cx, dy = y + 0.5 - cy; if (dx * dx + dy * dy <= r * r) ctx.fillRect(x, y, 1, 1);
  }
}
function speck(ctx, w, h, base, cols, dens, seed) {
  ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (hash2(x, y, seed) < dens) {
    ctx.fillStyle = cols[Math.floor(hash2(x + 31, y + 17, seed) * cols.length)]; ctx.fillRect(x, y, 1, 1);
  }
}
// --- Figuren ---
const HUM = [
'................','.....hhhhhh.....','....hhhhhhhh....','....hhsssshh....','....hsessesh....','....ssssssss....','.....ssssss.....','......kkkk......',
'....oooooooo....','...soooooooos...','...soOooooOos...','....bbbbbbbb....','....pppppppp....','.....pp..pp.....','.....pp..pp.....','.....ff..ff.....'];
const SPR_CACHE = {};
function makeHumanoidOld(o) {
  const key = 'h' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {h:o.hair, s:o.skin, e:o.eye || '#1a1a2a', k:shade(o.skin, -0.2), o:o.outfit, O:shade(o.outfit, -0.28), b:o.belt || '#4a3018', p:o.pants || shade(o.outfit, -0.45), f:o.feet || '#2a1c10'};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = HUM.map(r => r.split(''));
    if (f === 1) { g[13] = '....pp....pp....'.split(''); g[14] = g[13].slice(); g[15] = '....ff....ff....'.split(''); }
    if (o.bald) for (let y = 1; y < 5; y++) for (let x = 0; x < 16; x++) if (g[y][x] === 'h') g[y][x] = 's';
    if (o.longHair) for (let y = 3; y < 9; y++) { g[y][3] = 'h'; g[y][12] = 'h'; }
    if (o.ears) { g[3][3] = 'k'; g[4][3] = 'k'; g[3][12] = 'k'; g[4][12] = 'k'; }
    if (o.beard) { [4, 5, 10, 11].forEach(x => g[5][x] = 'h'); for (let x = 5; x <= 10; x++) g[6][x] = 'h'; for (let x = 6; x <= 9; x++) g[7][x] = 'h'; }
    if (o.helm) { for (let x = 4; x <= 11; x++) { g[2][x] = 'h'; g[3][x] = x === 4 || x === 11 ? 'h' : g[3][x]; } }
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#1a120c');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const QUAD = [
'................','................','................','................','...........ee...','..........hhhh..','..........hehhn.','...bbbbbbbhhhh..',
'..bbbbbbbbbbh...','.tbbbbbbbbbb....','t..bbbbbbbbb....','...dddddddd.....','...l.l....l.l...','...l.l....l.l...','................','................'];
function makeQuad(o) {
  const key = 'q' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {b:o.col, h:o.col, t:o.col, e:'#111', n:'#222', d:shade(o.col, -0.25), l:shade(o.col, -0.45), a:o.col2 || '#e8dcc0', E:shade(o.col, 0.2)};
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = QUAD.map(r => r.split(''));
    if (f === 1) { g[12] = '....l.l..l.l....'.split(''); g[13] = g[12].slice(); }
    if (o.antler) { g[2] = '.........a....a.'.split(''); g[3] = '..........a..a..'.split(''); }
    if (o.mane) { for (let x = 9; x <= 11; x++) g[6][x] = 'a'; g[7][10] = 'a'; }
    if (o.wings) { for (let x = 4; x <= 9; x++) { g[5][x] = 'a'; g[6][x - 1] = 'a'; } }
    for (let x = 4; x <= 9; x++) if (g[8][x] === 'b') g[8][x] = 'E';
    const c = mkCanvas(16, 16); paint(c.getContext('2d'), g.map(r => r.join('')), pal); addOutline(c, '#140e0a');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
const SLIME = ['......gggg......','.....gGgggg.....','....gGgggggg....','...gggeggeggg...','...gggggggggg...','...dggggggggd...','....dddddddd....'];
function makeSlime(col) {
  const key = 's' + col; if (SPR_CACHE[key]) return SPR_CACHE[key];
  const pal = {g:col, G:shade(col, 0.35), d:shade(col, -0.3), e:'#141414'};
  const a = mkCanvas(16, 16); paint(a.getContext('2d'), SLIME, pal, 0, 8); addOutline(a, '#10140c');
  const b = mkCanvas(16, 16); const sq = SLIME.slice(1); sq.unshift('................'); paint(b.getContext('2d'), sq, pal, 0, 8); addOutline(b, '#10140c');
  SPR_CACHE[key] = [a, b]; return SPR_CACHE[key];
}
function enemySprite(type) {
  const d = ENEMIES[type];
  if (ANIMAL_LOOK[type]) return makeAnimal(type);
  if (d.shape === 'quad') return makeQuad({col:d.col, col2:d.col2, antler:d.antler, mane:d.mane, wings:d.wings});
  if (d.shape === 'slime') return makeSlime(d.col);
  return makeHumanoid(Object.assign({skin:d.col, hair:d.hair || shade(d.outfit, -0.3), outfit:d.outfit, ears:d.ears, helm:d.helm, bald:d.bald, eye:d.eye, female:false}, ENEMY_STYLE[type] || {}));
}
// --- Kacheln ---
const TILE_CACHE = {};
function getTile(t, v) { const k = t * 16 + v; let c = TILE_CACHE[k]; if (!c) { c = drawTile(t, v); TILE_CACHE[k] = c; } return c; }
function rockBlob(x, s) {
  circ(x, 8, 9.5, 6.5, '#6a6a70'); circ(x, 7.5, 8.5, 6, '#8d8d92'); circ(x, 6, 7, 3.2, '#a6a6ad'); circ(x, 5.5, 6, 1.4, '#bdbdc4');
}
function specks(x, cols, n, s) { for (let k = 0; k < n; k++) { const px = 4 + Math.floor(hash2(k, 3, s) * 8), py = 5 + Math.floor(hash2(3, k, s) * 6); x.fillStyle = cols[k % cols.length]; x.fillRect(px, py, 2, 1); x.fillRect(px, py + 1, 1, 1); } }
function drawTile(t, v) {
  const tall = (t === TL.TREE || t === TL.PINE || t === TL.DEADTREE);
  const c = mkCanvas(tall ? 20 : 16, tall ? 28 : 16), x = c.getContext('2d'), s = t * 100 + v * 7 + 11;
  let outline = false;
  switch (t) {
    case TL.GRASS:
      speck(x, 16, 16, '#5b9b3d', ['#68ad47', '#4f8c35', '#71b44f'], 0.25, s);
      for (let k = 0; k < 3; k++) { const bx = 1 + Math.floor(hash2(k, v, s) * 13), by = 2 + Math.floor(hash2(v, k, s + 1) * 11); x.fillStyle = '#82c65a'; x.fillRect(bx, by, 1, 2); x.fillRect(bx + 1, by + 1, 1, 1); }
      break;
    case TL.SAND: speck(x, 16, 16, '#d9c58a', ['#ccb679', '#e6d6a2', '#c4ad70'], 0.28, s); break;
    case TL.PATH:
      speck(x, 16, 16, '#a98457', ['#9a774c', '#b9946a', '#8f6c42'], 0.32, s);
      x.fillStyle = '#c4a47a'; x.fillRect(3 + v * 2, 4 + v, 2, 1); x.fillRect(11 - v, 11, 1, 1);
      break;
    case TL.WATER: {
      speck(x, 16, 16, '#3576bd', ['#3d82cb', '#2f6aab'], 0.18, 900);
      x.fillStyle = '#7ab4ec';
      for (const row of [3, 8, 13]) { const x0 = (v * 2 + row * 5) % 16; for (let k = 0; k < 4; k++) x.fillRect((x0 + k) % 16, row, 1, 1); }
      break; }
    case TL.SWAMP: speck(x, 16, 16, '#4b5a33', ['#3e4c2a', '#566a3a', '#3a4a44'], 0.32, s); x.fillStyle = '#35484a'; x.fillRect(4 + v, 9, 4, 2); break;
    case TL.DARK: speck(x, 16, 16, '#3b3142', ['#463a50', '#2e2635', '#4f2a33'], 0.3, s); if (v === 2) { x.fillStyle = '#7a2a2a'; x.fillRect(5, 7, 4, 1); x.fillRect(8, 8, 3, 1); } break;
    case TL.SNOW: speck(x, 16, 16, '#e6edf3', ['#d3deea', '#f8fbfd', '#c8d6e4'], 0.25, s); break;
    case TL.GRAVEL: speck(x, 16, 16, '#857b6c', ['#766c5e', '#978d7d', '#6a6052'], 0.42, s); break;
    case TL.FLOOR:
      x.fillStyle = '#8c867a'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6c665c';
      for (let r = 0; r < 2; r++) { x.fillRect(0, r * 8 + 7, 16, 1); const off = (r % 2) * 4 + (v % 2) * 2; for (let k = 0; k < 2; k++) x.fillRect((off + k * 8) % 16, r * 8, 1, 7); }
      x.fillStyle = '#9d978b'; for (let k = 0; k < 6; k++) x.fillRect(Math.floor(hash2(k, v, s) * 15), Math.floor(hash2(v, k, s) * 15), 1, 1);
      break;
    case TL.BRIDGE:
      x.fillStyle = '#8b5a2b'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#6a4220';
      for (let r = 3; r < 16; r += 4) x.fillRect(0, r, 16, 1);
      x.fillStyle = '#4a2c12'; x.fillRect(0, 0, 1, 16); x.fillRect(15, 0, 1, 16);
      x.fillStyle = '#b08040'; x.fillRect(3, 1, 1, 1); x.fillRect(12, 5, 1, 1); x.fillRect(6, 9, 1, 1);
      break;
    case TL.ROOF: {
      const base = ['#9c3b2b', '#3a5a8c', '#4a6a3a', '#6a5040'][v % 4], dark = shade(base, -0.3), lite = shade(base, 0.2);
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 4 === 3) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if ((k + (Math.floor(y / 4) % 2) * 2) % 4 === 0) { x.fillStyle = dark; x.fillRect(k, y, 1, 1); }
        else if (y % 4 === 0) { x.fillStyle = lite; x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.WALL: {
      const base = v === 0 ? '#7b7b84' : '#6e6a64';
      x.fillStyle = base; x.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) for (let k = 0; k < 16; k++) {
        if (y % 5 === 4 || (k + (Math.floor(y / 5) % 2) * 4) % 8 === 0) { x.fillStyle = shade(base, -0.28); x.fillRect(k, y, 1, 1); }
        else if (y % 5 === 0) { x.fillStyle = shade(base, 0.15); x.fillRect(k, y, 1, 1); }
      }
      break; }
    case TL.DOOR:
      x.fillStyle = '#3a2412'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6b4422'; x.fillRect(3, 2, 10, 14);
      x.fillStyle = '#53341a'; x.fillRect(6, 2, 1, 14); x.fillRect(9, 2, 1, 14);
      x.fillStyle = '#e0b84a'; x.fillRect(11, 9, 1, 1);
      break;
    case TL.TREE: {
      const autumn = v === 3;
      const c1 = autumn ? '#9a4a1a' : '#2f6a26', c2 = autumn ? '#c8702a' : '#3d8a30', c3 = autumn ? '#e8a040' : '#56a83f', c4 = autumn ? '#f4c060' : '#6cc04e';
      x.fillStyle = '#5c3c20'; x.fillRect(8, 18, 4, 10); x.fillStyle = '#4a2e18'; x.fillRect(8, 18, 1, 10); x.fillRect(7, 26, 6, 2);
      const ox = (v % 2) * 0.5;
      circ(x, 10 + ox, 11, 9, c1); circ(x, 10 + ox, 10, 8, c2); circ(x, 7 + ox, 7, 4, c3);
      circ(x, 13 + ox, 12, 3, c3);
      x.fillStyle = c4; x.fillRect(6, 5, 2, 1); x.fillRect(12, 9, 1, 1); x.fillRect(5, 11, 1, 1);
      if (v === 1) { x.fillStyle = '#d83a3a'; x.fillRect(6, 13, 1, 1); x.fillRect(13, 8, 1, 1); x.fillRect(10, 15, 1, 1); }
      outline = true; break; }
    case TL.PINE: {
      x.fillStyle = '#5c3c20'; x.fillRect(9, 21, 3, 7);
      for (let k = 0; k < 4; k++) { const top = 2 + k * 5, hw = 3 + k * 2; for (let y = 0; y < 7; y++) { const w = Math.floor(hw * (y + 1) / 7); x.fillStyle = '#2c5e3c'; x.fillRect(10 - w, top + y, w * 2 + 1, 1); x.fillStyle = '#3c7a4c'; x.fillRect(10 - w, top + y, Math.max(1, w >> 1), 1); } }
      if (v >= 2) { x.fillStyle = '#eef4fa'; for (let k = 0; k < 4; k++) { const top = 2 + k * 5; x.fillRect(9, top, 3, 1); x.fillRect(10 - 2 - k, top + 6, 2, 1); } }
      outline = true; break; }
    case TL.DEADTREE:
      x.fillStyle = '#5e5044'; x.fillRect(9, 8, 2, 20); x.fillRect(7, 26, 6, 2);
      x.fillStyle = '#4a3e34';
      for (let k = 0; k < 5; k++) { x.fillRect(8 - k, 14 - k, 1, 1); x.fillRect(11 + k, 11 - k, 1, 1); }
      for (let k = 0; k < 3; k++) { x.fillRect(10 + k, 6 - k, 1, 1); x.fillRect(6 - k, 18 - k, 1, 1); }
      outline = true; break;
    case TL.ROCK: rockBlob(x, s); outline = true; break;
    case TL.IRON: rockBlob(x, s); specks(x, ['#c8783a', '#e8a060'], 5, s); outline = true; break;
    case TL.SILVER: rockBlob(x, s); specks(x, ['#f0f4fa', '#b8c4d0'], 5, s); outline = true; break;
    case TL.MITHRIL: rockBlob(x, s); specks(x, ['#3ac8f0', '#a0f4ff'], 6, s); outline = true; break;
    case TL.CRYSTAL:
      rockBlob(x, s);
      x.fillStyle = '#3aa0c0'; x.fillRect(5, 3, 2, 7); x.fillRect(9, 1, 3, 9); x.fillRect(12, 5, 2, 5);
      x.fillStyle = '#7ae4f4'; x.fillRect(5, 3, 1, 6); x.fillRect(9, 1, 1, 8); x.fillRect(12, 5, 1, 4);
      x.fillStyle = '#e0fcff'; x.fillRect(10, 2, 1, 2);
      outline = true; break;
    case TL.HERB:
      for (const p of [[6,9],[8,8],[10,9],[7,11],[9,11],[5,11],[11,11],[8,12]]) { x.fillStyle = '#3f9a3f'; x.fillRect(p[0], p[1], 2, 2); }
      x.fillStyle = '#6ad06a'; x.fillRect(7, 8, 1, 1); x.fillRect(10, 10, 1, 1);
      x.fillStyle = '#f6f4e0'; x.fillRect(6, 7, 1, 1); x.fillRect(10, 7, 1, 1); x.fillRect(8, 6, 1, 1);
      outline = true; break;
    case TL.MUSHROOM:
      for (const m of [[5,9,3],[10,10,2]]) { x.fillStyle = '#efe6d0'; x.fillRect(m[0], m[1], 2, 4); circ(x, m[0] + 1, m[1], m[2], '#c83a2a'); x.fillStyle = '#fff'; x.fillRect(m[0], m[1] - 1, 1, 1); }
      outline = true; break;
    case TL.FLOWER: {
      const cols = ['#f06aa0', '#f0d040', '#7aa0f0', '#f4f4f4', '#e8603a'];
      for (let k = 0; k < 5; k++) { const fx = 2 + Math.floor(hash2(k, v, 41) * 11), fy = 3 + Math.floor(hash2(v, k, 43) * 10); x.fillStyle = '#3f8a32'; x.fillRect(fx, fy + 1, 1, 2); x.fillStyle = cols[(k + v) % 5]; x.fillRect(fx - 1, fy, 3, 1); x.fillRect(fx, fy - 1, 1, 3); x.fillStyle = '#f8e070'; x.fillRect(fx, fy, 1, 1); }
      break; }
    case TL.CHEST:
      x.fillStyle = '#8a5226'; x.fillRect(3, 6, 10, 8); x.fillStyle = '#a8682e'; x.fillRect(3, 6, 10, 3);
      x.fillStyle = '#6a3c18'; x.fillRect(3, 9, 10, 1);
      x.fillStyle = '#d8b040'; x.fillRect(3, 6, 1, 8); x.fillRect(12, 6, 1, 8); x.fillRect(7, 8, 2, 3);
      x.fillStyle = '#2a1a0a'; x.fillRect(7, 10, 2, 1);
      outline = true; break;
    case TL.ANVIL:
      x.fillStyle = '#4a4a52'; x.fillRect(3, 6, 10, 3); x.fillRect(1, 7, 2, 1); x.fillRect(6, 9, 4, 3); x.fillRect(4, 12, 8, 2);
      x.fillStyle = '#74747e'; x.fillRect(3, 6, 10, 1);
      outline = true; break;
    case TL.HEARTH: {
      for (let k = 0; k < 8; k++) { const a = k / 8 * TAU; x.fillStyle = k % 2 ? '#7a7a80' : '#5e5e64'; x.fillRect(Math.round(8 + Math.cos(a) * 5) - 1, Math.round(10 + Math.sin(a) * 3) - 1, 3, 2); }
      const h = [6, 8, 7, 9][v];
      x.fillStyle = '#e04a1a'; x.fillRect(5, 11 - h * 0.6, 6, h * 0.6 + 1);
      x.fillStyle = '#f0a020'; x.fillRect(6, 11 - h * 0.5 + 1, 4, h * 0.5);
      x.fillStyle = '#ffe070'; x.fillRect(7, 10 - (v % 2), 2, 2);
      outline = true; break; }
    case TL.FENCE:
      x.fillStyle = '#7a5228'; x.fillRect(2, 4, 2, 11); x.fillRect(12, 4, 2, 11);
      x.fillStyle = '#a07440'; x.fillRect(0, 6, 16, 2); x.fillRect(0, 11, 16, 2);
      outline = true; break;
    case TL.VOID: x.fillStyle = '#000'; x.fillRect(0, 0, 16, 16); break;
    case TL.WOOD:
      x.fillStyle = '#8a5a32'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#6e4626'; for (let r = 0; r < 16; r += 4) x.fillRect(0, r + 3, 16, 1);
      for (let r = 0; r < 4; r++) x.fillRect(((r * 5 + v * 3) % 12) + 2, r * 4, 1, 3);
      x.fillStyle = '#9c6a3c'; x.fillRect(2 + v, 1, 3, 1); x.fillRect(9, 9 - v, 3, 1);
      break;
    case TL.IWALL:
      x.fillStyle = '#5a3a22'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#4a2e1a'; for (let k = 0; k < 16; k += 4) x.fillRect(k, 0, 1, 16);
      x.fillStyle = '#3a2212'; x.fillRect(0, 12, 16, 4); x.fillStyle = '#6e4a2c'; x.fillRect(0, 12, 16, 1);
      break;
    case TL.EXIT:
      x.fillStyle = '#8a5a32'; x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#9a2a2a'; x.fillRect(2, 2, 12, 12); x.fillStyle = '#d8b040'; x.fillRect(3, 3, 10, 1); x.fillRect(3, 12, 10, 1);
      x.fillStyle = 'rgba(255,240,200,.5)'; x.fillRect(5, 13, 6, 3);
      break;
    case TL.BED:
      x.fillStyle = '#6a4220'; x.fillRect(1, 1, 14, 14); x.fillStyle = '#e8e0d0'; x.fillRect(2, 2, 12, 4);
      x.fillStyle = '#3a6aa8'; x.fillRect(2, 6, 12, 8); x.fillStyle = '#5a8ac8'; x.fillRect(2, 6, 12, 2);
      outline = true; break;
    case TL.TABLE:
      x.fillStyle = '#5a3a1a'; x.fillRect(3, 11, 2, 4); x.fillRect(11, 11, 2, 4);
      x.fillStyle = '#9a6a3a'; x.fillRect(1, 4, 14, 8); x.fillStyle = '#b8844a'; x.fillRect(1, 4, 14, 2);
      x.fillStyle = '#e8e0d0'; x.fillRect(5, 5, 3, 2); x.fillStyle = '#c8a040'; x.fillRect(10, 5, 2, 2);
      outline = true; break;
    case TL.SHELF:
      x.fillStyle = '#5a3a1a'; x.fillRect(1, 0, 14, 16); x.fillStyle = '#3a2410'; x.fillRect(2, 1, 12, 14);
      for (let r = 0; r < 3; r++) { x.fillStyle = '#7a5228'; x.fillRect(2, 5 + r * 5, 12, 1); for (let k = 0; k < 5; k++) { x.fillStyle = ['#a03030','#3050a0','#30803a','#c8a040','#7a3a8a'][(k + r + v) % 5]; x.fillRect(3 + k * 2, 1 + r * 5, 2, 4); } }
      outline = true; break;
    case TL.THRONE:
      x.fillStyle = '#c8a030'; x.fillRect(3, 0, 10, 15); x.fillStyle = '#e8c850'; x.fillRect(4, 1, 8, 1);
      x.fillStyle = '#8a1a2a'; x.fillRect(5, 3, 6, 10); x.fillStyle = '#c8a030'; x.fillRect(2, 8, 2, 7); x.fillRect(12, 8, 2, 7);
      outline = true; break;
    case TL.ALTAR:
      x.fillStyle = '#c8c8d0'; x.fillRect(1, 6, 14, 9); x.fillStyle = '#e8e8f0'; x.fillRect(1, 6, 14, 2);
      x.fillStyle = '#f8e8a0'; x.fillRect(4, 2, 1, 4); x.fillRect(11, 2, 1, 4); x.fillStyle = '#ffb030'; x.fillRect(4, 1, 1, 1); x.fillRect(11, 1, 1, 1);
      outline = true; break;
    case TL.TROPHY:
      x.fillStyle = '#6a4a2a'; x.fillRect(4, 3, 8, 8); x.fillStyle = '#a8743c'; x.fillRect(6, 6, 4, 5);
      x.fillStyle = '#e8dcc0'; x.fillRect(3, 1, 1, 4); x.fillRect(12, 1, 1, 4); x.fillRect(4, 2, 2, 1); x.fillRect(10, 2, 2, 1);
      outline = true; break;
    case TL.BARREL:
      x.fillStyle = '#7a4a22'; x.fillRect(3, 3, 10, 12); x.fillStyle = '#9a6232'; x.fillRect(5, 3, 3, 12);
      x.fillStyle = '#4a4a50'; x.fillRect(3, 5, 10, 1); x.fillRect(3, 12, 10, 1);
      outline = true; break;
    case TL.CARPET:
      x.fillStyle = '#8a2a2a'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#a83a3a'; x.fillRect(2, 2, 12, 12);
      x.fillStyle = '#d8b040'; x.fillRect(7, 6, 2, 4); x.fillRect(6, 7, 4, 2);
      break;
    case TL.HCHEST:
      x.fillStyle = '#5a3a1a'; x.fillRect(2, 5, 12, 10); x.fillStyle = '#7a5228'; x.fillRect(2, 5, 12, 4);
      x.fillStyle = '#b8b8c0'; x.fillRect(2, 9, 12, 1); x.fillRect(7, 8, 2, 3);
      outline = true; break;
    case TL.COUNTER:
      x.fillStyle = '#6a4220'; x.fillRect(0, 5, 16, 11); x.fillStyle = '#a8743c'; x.fillRect(0, 4, 16, 3);
      x.fillStyle = '#4a2a12'; x.fillRect(0, 9, 16, 1);
      break;
    case TL.BOARD:
      x.fillStyle = '#5a3a1a'; x.fillRect(1, 1, 14, 12); x.fillRect(3, 13, 2, 3); x.fillRect(11, 13, 2, 3);
      x.fillStyle = '#a8743c'; x.fillRect(2, 2, 12, 10);
      x.fillStyle = '#f4ead0'; x.fillRect(3, 3, 4, 4); x.fillRect(8, 4, 5, 3); x.fillRect(4, 8, 5, 3);
      x.fillStyle = '#c03030'; x.fillRect(5, 3, 1, 1); x.fillRect(10, 4, 1, 1);
      outline = true; break;
    case TL.SLOT:
      x.fillStyle = 'rgba(255,240,200,.35)';
      for (let k = 1; k < 15; k += 3) { x.fillRect(k, 1, 2, 1); x.fillRect(k, 14, 2, 1); x.fillRect(1, k, 1, 2); x.fillRect(14, k, 1, 2); }
      x.fillStyle = 'rgba(255,240,200,.6)'; x.fillRect(7, 5, 2, 6); x.fillRect(5, 7, 6, 2);
      break;
  }
  if (outline) addOutline(c, '#1a140e');
  return c;
}
// ---------- Tiere: jede Art mit eigener Silhouette ----------
// Blickrichtung rechts, Füße unten (y=15). f = Lauf-Frame 0/1
const ANIMAL_DRAW = {
  ratte(R, f, c) {
    const pink = '#d89a9a', l = shade(c, 0.25), d = shade(c, -0.3);
    R(0, 12, 1, 1, pink); R(1, 13, 2, 1, pink); R(3, 12, 2, 1, pink);
    R(5, 10, 7, 3, c); R(6, 9, 5, 1, c); R(6, 12, 5, 1, l);
    R(11, 10, 3, 2, c); R(14, 11, 1, 1, pink); R(12, 8, 2, 2, pink); R(12, 10, 1, 1, '#111');
    if (f) { R(6, 13, 1, 2, d); R(10, 13, 1, 2, d); } else { R(7, 13, 1, 2, d); R(11, 13, 1, 2, d); }
  },
  wolf(R, f, c, o) {
    const l = shade(c, 0.35), d = shade(c, -0.35), eye = o.eye || '#f0d040';
    R(0, 4, 2, 2, c); R(1, 6, 2, 2, c); R(2, 7, 2, 1, c); R(0, 4, 1, 1, l);
    R(3, 6, 9, 5, c); R(4, 5, 7, 1, c); R(4, 10, 7, 1, l); R(4, 6, 6, 1, d);
    R(10, 4, 4, 4, c); R(13, 6, 3, 2, c); R(15, 6, 1, 1, '#111'); R(13, 8, 2, 1, l);
    R(10, 2, 1, 2, c); R(12, 2, 1, 2, c); R(10, 3, 1, 1, d); R(12, 5, 1, 1, eye);
    if (o.spikes) for (let k = 4; k < 11; k += 2) R(k, 4, 1, 1, d);
    const legs = f ? [3, 6, 9, 11] : [4, 5, 10, 11];
    legs.forEach((x, k) => R(x, 11, 1, 4, k % 2 ? c : d));
  },
  eber(R, f, c) {
    const d = shade(c, -0.4), l = shade(c, 0.2);
    R(1, 7, 1, 2, d); R(2, 7, 9, 5, c); R(3, 6, 7, 1, c); R(6, 5, 5, 1, c); R(7, 4, 4, 1, d);
    for (let k = 3; k < 11; k += 2) R(k, k < 7 ? 6 : 5, 1, 1, d);
    R(11, 6, 3, 5, c); R(14, 8, 2, 3, '#c88a7a'); R(15, 9, 1, 1, '#5a2a2a');
    R(13, 11, 1, 1, '#f8f4e8'); R(14, 10, 1, 1, '#f8f4e8'); R(12, 5, 1, 2, d); R(12, 8, 1, 1, '#111');
    R(3, 11, 7, 1, l);
    const legs = f ? [3, 5, 8, 10] : [2, 5, 9, 10];
    legs.forEach(x => R(x, 12, 1, 3, d));
  },
  hirsch(R, f, c, o) {
    const l = o.belly || '#f0e4c8', d = shade(c, -0.35), ant = o.ant || '#e8dcc0';
    R(2, 6, 1, 2, '#ffffff'); R(3, 7, 9, 3, c); R(4, 6, 7, 1, c); R(4, 9, 7, 1, l);
    R(10, 3, 2, 5, c); R(11, 2, 3, 3, c); R(14, 3, 1, 2, d); R(13, 3, 1, 1, '#111'); R(10, 2, 1, 1, d);
    R(11, 0, 1, 2, ant); R(13, 0, 1, 2, ant); R(10, 0, 1, 1, ant); R(14, 0, 1, 1, ant); R(12, 1, 1, 1, ant);
    const legs = f ? [4, 6, 9, 11] : [3, 5, 10, 11];
    legs.forEach(x => R(x, 10, 1, 5, d));
    if (o.spark) { R(5, 7, 1, 1, '#ffffff'); R(9, 8, 1, 1, '#ffffff'); }
  },
  pferd(R, f, c, o) {
    const d = shade(c, -0.35), m = o.mane || '#2a1a0a';
    R(1, 6, 1, 6, m); R(2, 6, 1, 3, m);
    R(2, 6, 10, 4, c); R(3, 5, 8, 1, c); R(3, 9, 8, 1, shade(c, 0.15));
    R(10, 2, 3, 5, c); R(12, 2, 3, 3, c); R(14, 3, 2, 2, d); R(15, 4, 1, 1, '#111'); R(12, 3, 1, 1, '#111'); R(11, 1, 1, 1, c);
    R(9, 1, 2, 6, m);
    const legs = f ? [3, 5, 9, 11] : [2, 4, 10, 11];
    legs.forEach(x => { R(x, 10, 1, 4, d); R(x, 14, 1, 1, '#2a1a0a'); });
  },
  baer(R, f, c) {
    const d = shade(c, -0.35), l = shade(c, 0.2);
    R(1, 7, 2, 2, c); R(2, 5, 10, 7, c); R(3, 4, 8, 1, c); R(4, 5, 6, 1, l);
    R(10, 4, 5, 5, c); R(14, 6, 2, 2, '#a8865a'); R(15, 6, 1, 1, '#111'); R(13, 5, 1, 1, '#111');
    R(10, 3, 2, 1, c); R(14, 3, 1, 1, c); R(10, 3, 1, 1, d);
    const legs = f ? [3, 6, 9, 11] : [2, 5, 9, 12];
    legs.forEach(x => R(x, 12, 2, 3, d));
  }
};
const ANIMAL_LOOK = {
  ratte:['ratte', {}], wolf:['wolf', {}], warg:['wolf', {spikes:true, eye:'#f03030'}], eber:['eber', {}],
  hirsch:['hirsch', {}], goldhirsch:['hirsch', {ant:'#fff6a0', belly:'#fff6c0', spark:true}], pferd:['pferd', {}], baer:['baer', {}]
};
function makeAnimal(type) {
  const key = 'a' + type; if (SPR_CACHE[key]) return SPR_CACHE[key];
  const d = ENEMIES[type], lk = ANIMAL_LOOK[type], frames = [];
  for (let f = 0; f < 2; f++) {
    const c = mkCanvas(16, 16), x = c.getContext('2d');
    const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
    ANIMAL_DRAW[lk[0]](R, f, d.col, lk[1]); addOutline(c, '#140e0a'); frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
// ---------- Entwicklungsstufen gezähmter Tiere ----------
// 0 Jungtier · 1 Kampferprobt (St. 5) · 2 Veteran (St. 10) · 3 Legendär (St. 15)
const PET_TIERS = [
  {lvl:1, name:'Jungtier'}, {lvl:5, name:'Kampferprobt'}, {lvl:10, name:'Veteran'}, {lvl:15, name:'Legendär'}
];
function petTier(lvl) { let t = 0; PET_TIERS.forEach((p, k) => { if (lvl >= p.lvl) t = k; }); return t; }
// gear: {armor:Farbe|null, saddle:Farbe|null}
function makePetSprite(type, tier, gear) {
  gear = gear || {};
  const key = 'p' + type + tier + (gear.armor || '') + (gear.saddle || ''); if (SPR_CACHE[key]) return SPR_CACHE[key];
  const d = ENEMIES[type], lk = ANIMAL_LOOK[type], frames = [];
  const base = tier >= 2 ? shade(d.col, -0.18) : d.col;
  for (let f = 0; f < 2; f++) {
    const c = mkCanvas(16, 16), x = c.getContext('2d');
    const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
    ANIMAL_DRAW[lk[0]](R, f, base, Object.assign({}, lk[1], tier >= 3 ? {eye:'#7af0ff'} : tier >= 2 ? {eye:'#f06a20'} : {}));
    const img = x.getImageData(0, 0, 16, 16).data, on = (a, b) => a >= 0 && b >= 0 && a < 16 && b < 16 && img[(b * 16 + a) * 4 + 3] > 0;
    const top = []; for (let a = 0; a < 16; a++) { top[a] = -1; for (let b = 0; b < 12; b++) if (on(a, b)) { top[a] = b; break; } }
    // Stufe 1+: Kampfnarben / Kriegsbemalung
    if (tier >= 1) for (let a = 4; a <= 9; a += 2) { const t = top[a]; if (t < 0) continue; for (let b = t + 1; b <= t + 3; b++) if (on(a, b)) R(a, b, 1, 1, tier >= 3 ? '#e8c040' : '#7a1a12'); }
    // Stufe 2+: Stachelhalsband
    if (tier >= 2) for (let b = 0; b < 16; b++) if (on(10, b) && on(10, b + 1) && b > top[10] + 1) { R(10, b, 1, 2, '#3a2a1a'); R(11, b, 1, 1, '#d8dce4'); R(9, b, 1, 1, '#d8dce4'); break; }
    // Rüstung: Platten auf dem Rücken
    if (gear.armor) { const hi = shade(gear.armor, 0.4); for (let a = 3; a <= 10; a++) { const t = top[a]; if (t < 0) continue; R(a, t, 1, 2, gear.armor); R(a, t, 1, 1, hi); if (on(a, t + 2) && a % 2) R(a, t + 2, 1, 1, shade(gear.armor, -0.3)); } }
    // Sattel mit Decke und Steigbügel
    if (gear.saddle) {
      const sx = 5, t = Math.min(top[5], top[6], top[7]); if (t >= 0) {
        R(sx - 1, t, 5, 2, '#a8282a'); R(sx - 1, t + 1, 5, 1, '#e8c040');
        R(sx, t - 1, 3, 2, gear.saddle); R(sx, t - 1, 1, 1, shade(gear.saddle, 0.3)); R(sx + 2, t - 2, 1, 1, gear.saddle);
        R(sx + 1, t + 2, 1, 2, '#3a2a1a'); R(sx, t + 4, 3, 1, '#a8acb8');
      }
    }
    // Stufe 3: Hörner/Stacheln aus Gold
    if (tier >= 3) for (const a of [4, 8]) { const t = top[a]; if (t > 0 && !(gear.saddle && a < 9 && a > 3)) { R(a, t - 1, 1, 1, '#fff6b0'); if (t > 1) R(a, t - 2, 1, 1, '#e8c040'); } }
    addOutline(c, tier >= 3 ? '#3a2a00' : '#140e0a'); frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
function petGearLook(p) { const g = p.gear || {}; return {armor:g.armor ? ITEMS[g.armor.id].petCol : null, saddle:g.saddle ? ITEMS[g.saddle.id].petCol : null}; }
function petSprite(p) { return makePetSprite(p.type, petTier(p.lvl || 1), petGearLook(p)); }
function petSize(p) { return (ENEMIES[p.type].size || 1) * (1 + 0.08 * petTier(p.lvl || 1)); }

// ================= HÄUSER VON AUSSEN =================
// b = {x, y, w, h, v, wall, door}  (Felder). Das Bild reicht 8 px über das Gebäude hinaus (Dachüberstand / Türme).
const HOUSE_CACHE = {};
const ROOF_COL = ['#a8402e', '#3a5a8c', '#4a6a3a', '#b89a5a'];
const PLASTER = ['#eadfc4', '#e2d4b4', '#e8dcc8', '#d8c8a4'];
function houseCanvas(b) {
  const key = [b.w, b.h, b.v, b.wall ? 1 : 0, b.door, b.poor ? 1 : 0].join(',');
  if (HOUSE_CACHE[key]) return HOUSE_CACHE[key];
  const UP = 8, W = b.w * 16, H = b.h * 16 + UP, c = mkCanvas(W, H), x = c.getContext('2d');
  const R = (a, y, w, h, col) => { x.fillStyle = col; x.fillRect(a, y, w, h); };
  const hh = (a, y) => hash2(a, y, b.w * 31 + b.h * 7 + b.v);
  const dx = b.door * 16;
  if (b.wall) {
    // ---- Steinbau (Burg) ----
    const top = UP + 6;
    for (let y = top; y < H; y++) for (let a = 0; a < W; a++) {
      const row = Math.floor((y - top) / 5), off = (row % 2) * 6, edge = (y - top) % 5 === 0 || (a + off) % 12 === 0;
      R(a, y, 1, 1, edge ? '#5a5a62' : (hh(Math.floor((a + off) / 12), row) < 0.3 ? '#8a8a92' : '#7b7b84'));
    }
    for (let a = 0; a < W; a += 8) { R(a, top - 5, 5, 5, '#8a8a92'); R(a, top - 5, 5, 1, '#a8a8b0'); }   // Zinnen
    R(0, H - 3, W, 3, '#4a4a52');
    // Ecktürme
    for (const tx of [0, W - 14]) {
      R(tx, 0, 14, H, '#6e6e78'); for (let y = 4; y < H; y += 5) R(tx, y, 14, 1, '#5a5a62');
      for (let a = 0; a < 14; a += 5) R(tx + a, 0, 3, 4, '#8a8a92');
      R(tx + 5, 12, 3, 6, '#1a1a22'); R(tx + 5, 28, 3, 6, '#1a1a22');
    }
    // Banner
    for (const bx of [W * 0.3, W * 0.7]) { const px = Math.round(bx) - 4; R(px, top + 2, 8, 16, '#8a1a2a'); R(px, top + 2, 8, 2, '#c8a040'); R(px + 2, top + 7, 4, 4, '#e8c040'); R(px, top + 18, 3, 2, '#8a1a2a'); R(px + 5, top + 18, 3, 2, '#8a1a2a'); }
    // Schießscharten
    for (let a = 22; a < W - 22; a += 18) if (Math.abs(a - dx - 8) > 14) R(a, top + 24, 2, 6, '#1a1a22');
    // Tor
    R(dx - 3, H - 22, 22, 22, '#5a5a62'); R(dx - 1, H - 20, 18, 20, '#3a2412');
    for (let a = 0; a < 18; a += 3) R(dx - 1 + a, H - 20, 1, 20, '#2a180a');
    R(dx + 1, H - 22, 14, 2, '#5a5a62'); R(dx + 12, H - 10, 2, 2, '#e0b84a');
  } else {
    // ---- Fachwerkhaus ----
    const wallTop = H - 18, thatch = b.v === 3;
    const plaster = PLASTER[b.v % 4], beam = '#5a3a1a', beamL = '#7a5228';
    R(0, wallTop, W, 18, plaster);
    for (let y = wallTop; y < H; y++) for (let a = 0; a < W; a++) if (hh(a, y) < 0.08) R(a, y, 1, 1, shade(plaster, -0.08));
    R(0, wallTop, W, 2, beam); R(0, H - 4, W, 4, '#7a7a80'); R(0, H - 4, W, 1, '#9a9aa0');
    for (let a = 0; a < W; a += 16) { R(a, wallTop, 2, 18, beam); R(a + 1, wallTop, 1, 18, beamL); }
    R(W - 2, wallTop, 2, 18, beam);
    if (b.poor) {   // Rattenviertel: verwitterte Bretterwand statt Putz
      for (let a = 0; a < W; a += 3) { R(a, wallTop + 2, 3, 14, hh(a, 1) < 0.5 ? '#7a5a3a' : '#6a4a2e'); R(a, wallTop + 2, 1, 14, '#4a3018'); }
      R(5, wallTop + 6, 4, 3, '#8a6a4a'); R(W - 10, wallTop + 9, 5, 2, '#8a6a4a');
    }
    // Fenster
    for (let col = 0; col < b.w; col++) {
      const a = col * 16; if (a === dx) continue;
      const wx = a + 4, wy = wallTop + 4;
      R(wx - 1, wy - 1, 10, 9, beam); R(wx, wy, 8, 7, '#6aa4d8'); R(wx, wy, 8, 2, '#a8d0f0'); R(wx + 3, wy, 2, 7, beam); R(wx, wy + 3, 8, 1, beam);
      if (b.poor) { if (hh(col, 3) < 0.5) { R(wx - 1, wy + 1, 10, 2, '#8a6236'); R(wx - 1, wy + 4, 10, 2, '#7a5228'); } continue; }   // vernagelt
      R(wx - 3, wy - 1, 2, 9, '#4a6a3a'); R(wx + 9, wy - 1, 2, 9, '#4a6a3a');   // Fensterläden
      if (hh(col, 9) < 0.6) { R(wx - 1, wy + 8, 10, 2, '#6a4422'); for (let k = 0; k < 4; k++) R(wx + k * 2, wy + 6 + (k % 2), 2, 2, ['#e8603a', '#f0d040', '#e85a9a', '#ffffff'][(k + col) % 4]); }
    }
    // Tür mit Laterne und Stufe
    R(dx + 2, wallTop + 2, 12, 16, beam); R(dx + 3, wallTop + 3, 10, 15, '#7a4a22');
    R(dx + 5, wallTop + 3, 1, 15, '#5a3416'); R(dx + 9, wallTop + 3, 1, 15, '#5a3416'); R(dx + 11, wallTop + 10, 1, 2, '#e0b84a');
    R(dx + 1, H - 2, 14, 2, '#9a9aa0');
    R(dx + 14, wallTop + 4, 2, 3, '#3a3a3a'); R(dx + 14, wallTop + 6, 2, 2, '#ffd060');
    // Dach
    const rc = ROOF_COL[b.v % 4], rd = shade(rc, -0.3), rl = shade(rc, 0.2);
    const roofBottom = wallTop + 1;
    for (let y = 0; y < roofBottom; y++) {
      const inset = Math.max(0, 3 - y);   // abgerundeter First
      for (let a = inset; a < W - inset; a++) {
        let col;
        if (thatch) { col = hh(a, Math.floor(y / 2)) < 0.3 ? '#a88a4a' : hh(a + 3, y) < 0.15 ? '#8a6a32' : '#c8a868'; if (y % 6 === 5) col = '#8a6a32'; }
        else { const row = Math.floor(y / 4), off = (row % 2) * 4; col = y % 4 === 3 ? rd : ((a + off) % 8 === 0 ? rd : (y % 4 === 0 ? rl : rc)); }
        if (a < inset + 2 || a >= W - inset - 2) col = shade(col, -0.25);   // Giebelkanten
        R(a, y, 1, 1, col);
      }
    }
    R(3, 0, W - 6, 2, thatch ? '#7a5a2a' : shade(rc, -0.45)); R(4, 0, W - 8, 1, thatch ? '#a88a4a' : rl);   // First
    R(0, roofBottom - 2, W, 2, thatch ? '#7a5a2a' : rd); R(0, roofBottom, W, 2, 'rgba(0,0,0,0.25)');     // Traufe + Schatten
    // Schornstein
    if (!thatch && b.w >= 4) { const cx = W - 22; R(cx, 0, 7, 12, '#7a6a64'); R(cx - 1, 0, 9, 2, '#5a4a44'); for (let y = 3; y < 12; y += 3) R(cx, y, 7, 1, '#5a4a44'); }
  }
  addOutline(c, '#1a120c');
  HOUSE_CACHE[key] = c; return c;
}

// ================= FIGUREN v2 (16 × 24, Stardew-Stil) =================
// o: skin, hair, outfit, pants, feet, trim, gloves, eye, female/longHair, bald, beard, ears, helm, helmCol, plume, style, metal, scales, jewel, gem, cape
function makeHumanoid(o) {
  const key = 'H2' + JSON.stringify(o);
  if (SPR_CACHE[key]) return SPR_CACHE[key];
  const fem = o.female != null ? !!o.female : !!o.longHair;
  const st = o.style || 'cloth';
  const S = (c, f) => shade(c, f);
  const skin = o.skin, skS = S(skin, -0.18), skD = S(skin, -0.32), skL = S(skin, 0.12);
  const hair = o.hair || '#4a3018', hS = S(hair, -0.28), hL = S(hair, 0.32);
  const out = o.outfit || '#7a6a58', oS = S(out, -0.25), oD = S(out, -0.42), oL = S(out, 0.22);
  const pants = o.pants || S(out, -0.45), pS = S(pants, -0.3), pL = S(pants, 0.18);
  const feet = o.feet || '#4a2e1a', fS = S(feet, -0.35), fL = S(feet, 0.25);
  const trim = o.trim || '#d8b040', tS = S(trim, -0.3);
  const metal = o.metal || '#b4b8c4', mS = S(metal, -0.25), mD = S(metal, -0.45), mL = S(metal, 0.35);
  const eye = o.eye || '#2a1e3a', hand = o.gloves || skin, handS = S(hand, -0.2);
  const frames = [];
  for (let f = 0; f < 2; f++) {
    const g = []; for (let y = 0; y < 24; y++) g.push(new Array(16).fill(null));
    const P = (x, y, c) => { if (x >= 0 && x < 16 && y >= 0 && y < 24 && c) g[y][x] = c; };
    const H = (y, x0, x1, c) => { for (let x = x0; x <= x1; x++) P(x, y, c); };
    // Zeile mit Licht links, Schatten rechts
    const Row = (y, x0, x1, c, cL, cS) => { H(y, x0, x1, c); P(x0, y, cL || c); P(x1, y, cS || c); };
    const isBones = st === 'bones';
    const longBody = st === 'robe' || st === 'royal' || (fem && st === 'cloth');
    // ---------- Haare hinten (lange Haare fallen hinter die Schultern) ----------
    if (fem && !o.bald && !o.helm) { for (let y = 6; y <= 16; y++) H(y, 3, 12, hS); H(16, 4, 11, hS); H(17, 5, 10, hS); }
    // ---------- Beine ----------
    if (!longBody) {
      const legC = st === 'plate' ? metal : pants, legS = st === 'plate' ? mS : pS, legL = st === 'plate' ? mL : pL;
      const L0 = fem ? [5, 7] : [5, 7], R0 = fem ? [8, 10] : [8, 10];
      for (const [x0, x1, side] of [[L0[0], L0[1], 0], [R0[0], R0[1], 1]]) {
        const up = f === 1 && side === 0 ? 1 : 0;
        for (let y = 19; y <= 21 - up; y++) Row(y, x0, x1, legC, legL, legS);
        if (st === 'plate') P(x0 + 1, 20 - up, mL);
        // Stiefel
        const bc = st === 'plate' ? mS : feet, bS = st === 'plate' ? mD : fS, bL = st === 'plate' ? metal : fL;
        Row(22 - up, x0, x1, bc, bL, bS);
        H(23 - up, side === 0 ? x0 - 1 : x0, side === 0 ? x1 : x1 + 1, bS);
        P(side === 0 ? x0 - 1 : x1 + 1, 23 - up, bS);
      }
    } else {
      // Rock / Robe bis zum Boden
      const rc = out, rS = oS, rL = oL;
      const rows = st === 'cloth' ? [[19, 4, 11], [20, 4, 11], [21, 3, 12]] : [[19, 4, 11], [20, 4, 11], [21, 3, 12], [22, 3, 12]];
      for (const [y, x0, x1] of rows) { Row(y, x0, x1, rc, rL, rS); if (y % 2) P(x0 + 3, y, rS); }
      const hem = st === 'cloth' ? 21 : 22;
      H(hem, rows[rows.length - 1][1], rows[rows.length - 1][2], st === 'cloth' ? oD : trim);
      if (st !== 'cloth') { H(19, 7, 8, trim); H(20, 7, 8, trim); H(21, 7, 8, trim); }
      const sy = st === 'cloth' ? 22 : 23;
      const step = f === 1 ? 1 : 0;
      H(sy, 5 - step, 6 - step, feet); H(sy, 9, 10, feet); if (st === 'cloth') { H(23, 5 - step, 6 - step, fS); H(23, 9, 10, fS); }
    }
    // ---------- Oberkörper ----------
    if (isBones) {
      for (let y = 13; y <= 18; y++) H(y, 6, 9, '#2a2420');
      for (const y of [14, 16]) H(y, 5, 10, '#e8e4d8');
      H(13, 6, 9, '#d8d4c8'); for (let y = 13; y <= 19; y++) H(y, 7, 8, '#cfcbc0'); H(18, 5, 10, '#c8c4b8');
      for (const ax of [4, 11]) for (let y = 14; y <= 18; y++) P(ax, y + (f === 1 ? (ax === 4 ? 1 : -1) : 0), '#e8e4d8');
      for (const lx of [6, 9]) for (let y = 19; y <= 22; y++) P(lx, y - (f === 1 && lx === 6 ? 1 : 0), '#e8e4d8');
      H(23, 5, 6, '#c8c4b8'); H(23, 9, 10, '#c8c4b8');
    } else {
      // Arme (hängen am Körper, schwingen beim Gehen)
      const armC = st === 'plate' ? metal : st === 'chain' ? '#8a8e9a' : out;
      const armS = st === 'plate' ? mS : st === 'chain' ? '#6a6e7a' : oS;
      const arms = fem ? [[3, 4], [11, 12]] : [[2, 3], [12, 13]];
      arms.forEach(([x0, x1], k) => {
        const dy = f === 1 ? (k === 0 ? 1 : -1) : 0;
        for (let y = 14; y <= 17; y++) { P(x0, y + dy, k === 0 ? S(armC, 0.15) : armS); P(x1, y + dy, k === 0 ? armC : S(armS, -0.12)); }
        if (st === 'robe' || st === 'royal') { H(17 + dy, x0 - (k ? 0 : 1), x1 + (k ? 1 : 0), armC); H(18 + dy, x0 - (k ? 0 : 1), x1 + (k ? 1 : 0), trim); }
        if (st === 'leather') { P(x0, 16 + dy, oD); P(x1, 16 + dy, oD); }   // Armschienen
        const hc = st === 'plate' ? mS : hand, hcS = st === 'plate' ? mD : handS;
        H(18 + dy + (st === 'robe' || st === 'royal' ? 1 : 0), x0, x1, hc); P(k ? x1 : x0, 19 + dy + (st === 'robe' || st === 'royal' ? 1 : 0), hcS); P(k ? x0 : x1, 19 + dy + (st === 'robe' || st === 'royal' ? 1 : 0), hc);
      });
      // Rumpf-Silhouette
      const T = fem
        ? [[13, 5, 10], [14, 4, 11], [15, 4, 11], [16, 5, 10], [17, 6, 9], [18, 5, 10]]
        : [[13, 4, 11], [14, 3, 12], [15, 4, 11], [16, 4, 11], [17, 4, 11], [18, 5, 10]];
      for (const [y, x0, x1] of T) Row(y, x0, x1, out, oL, oS);
      // Hüfte
      if (!longBody) { Row(19, fem ? 4 : 5, fem ? 11 : 10, pants, pL, pS); }
      else Row(19, 4, 11, out, oL, oS);
      // ---------- Stile ----------
      if (st === 'cloth') {
        P(6, 15, oS); P(9, 16, oS); P(7, 17, oS);                       // Falten
        if (!longBody) { H(18, 5, 10, '#6a4a2a'); P(7, 18, '#a88a5a'); }   // Gürtel
        else { H(17, 6, 9, oS); }
      } else if (st === 'leather') {
        H(13, 3, 5, oD); H(13, 10, 12, oD); H(14, 2, 4, oD); H(14, 11, 13, oD); P(3, 13, oS);   // Schulterpolster
        for (let k = 0; k < 5; k++) P(5 + k, 14 + k, '#3a2210');                                 // Gurt
        H(18, 5, 10, '#3a2210'); P(7, 18, trim); P(8, 18, tS);
      } else if (st === 'chain') {
        for (const [y, x0, x1] of T) for (let x = x0; x <= x1; x++) P(x, y, (x + y) % 2 ? '#9a9eaa' : '#7a7e8a');
        for (let y = 14; y <= 20; y++) H(y, 6, 9, y === 14 ? trim : out); P(6, 20, trim); P(9, 20, trim); H(16, 7, 8, trim); H(17, 7, 8, tS); P(7, 16, S(trim, 0.35));  // Wappenrock mit Emblem
        H(18, 5, 10, '#3a2a1a'); P(7, 18, trim);
      } else if (st === 'plate') {
        for (const [y, x0, x1] of T) { H(y, x0, x1, metal); P(x0, y, mL); P(x1, y, mS); P(x0 + 1, y, mL); }
        // Schulterplatten
        for (const [x0, x1] of [[2, 5], [10, 13]]) { H(13, x0 + 1, x1 - 1, mL); H(14, x0, x1, metal); H(15, x0, x1, mS); H(16, x0 + 1, x1 - 1, trim); }
        if (fem) { P(6, 14, '#ffffff'); P(9, 14, mL); H(16, 6, 9, mD); P(7, 17, mL); }
        else { H(14, 7, 8, mL); H(15, 7, 8, mL); H(17, 5, 10, mD); }
        H(18, 5, 10, trim); P(5, 19, mS); P(10, 19, mS);
        if (o.scales) for (let y = 14; y <= 17; y++) for (let x = 5; x <= 10; x += 2) P(x + (y % 2), y, o.scales);
      } else if (st === 'robe' || st === 'royal') {
        for (let y = 13; y <= 19; y++) H(y, 7, 8, trim);
        H(17, fem ? 6 : 5, fem ? 9 : 10, trim); P(fem ? 6 : 5, 18, tS);
        if (st === 'royal') { H(13, 3, 12, '#f4f0e8'); H(14, 2, 4, '#f4f0e8'); H(14, 11, 13, '#f4f0e8'); P(4, 13, '#1a1a1a'); P(11, 13, '#1a1a1a'); P(3, 14, '#1a1a1a'); P(12, 14, '#1a1a1a'); H(15, 6, 9, trim); }
      }
      if (o.cape) { for (let y = 14; y <= 20; y++) { P(fem ? 2 : 1, y, o.cape); P(fem ? 13 : 14, y, S(o.cape, -0.3)); } }
      // ---------- Ausschnitt & Schmuck ----------
      if (fem && st !== 'plate' && st !== 'chain') {
        H(13, 6, 9, skin); H(14, 7, 8, skin); P(9, 13, skS); P(8, 14, skS);
        P(5, 15, oL); P(10, 15, oL); H(16, 6, 9, oS);                      // Büste mit Schatten
        if (o.jewel !== false) { P(6, 13, trim); P(9, 13, trim); P(7, 14, trim); P(8, 15, o.gem || '#d0386a'); }   // Halskette
        if (st === 'leather' || (st === 'cloth' && longBody)) { P(7, 17, '#2a1a0a'); P(8, 18, '#2a1a0a'); }   // Schnürung
      } else if (!fem && (st === 'cloth' || st === 'leather')) { P(7, 13, skS); P(8, 13, skS); P(8, 14, skS); }
    }
    // ---------- Kopf ----------
    if (isBones) {
      for (const [y, x0, x1] of [[2, 6, 9], [3, 5, 10], [4, 4, 11], [5, 4, 11], [6, 4, 11], [7, 4, 11], [8, 4, 11], [9, 5, 10], [10, 5, 10]]) H(y, x0, x1, '#ece8dc');
      H(7, 5, 6, '#1a1410'); H(7, 9, 10, '#1a1410'); H(8, 5, 6, '#1a1410'); H(8, 9, 10, '#1a1410'); P(6, 7, eye); P(9, 7, eye);
      P(7, 9, '#5a5450'); P(8, 9, '#5a5450'); H(11, 6, 9, '#c8c4b8'); P(6, 11, '#3a3430'); P(8, 11, '#3a3430'); P(11, 5, '#c8c4b8');
      if (o.helm) { const hc = o.helmCol || '#c8a040'; H(2, 5, 10, hc); P(5, 1, hc); P(7, 0, hc); P(7, 1, hc); P(10, 1, hc); P(8, 2, '#c83a3a'); }
    } else {
      P(7, 12, skS); P(8, 12, skD);                                  // Hals
      const HD = [[2, 6, 9], [3, 5, 10], [4, 4, 11], [5, 4, 11], [6, 4, 11], [7, 4, 11], [8, 4, 11], [9, 4, 11], [10, 5, 10], [11, 6, 9]];
      for (const [y, x0, x1] of HD) { H(y, x0, x1, skin); P(x1, y, skS); }
      P(4, 7, skL); P(4, 8, skL); P(10, 10, skS); P(9, 11, skS);
      // Ohren
      P(3, 7, skS); P(3, 8, skD); P(12, 7, skS); P(12, 8, skD);
      if (o.ears) { P(2, 6, skS); P(2, 5, skS); P(13, 6, skS); P(13, 5, skS); P(3, 6, skin); P(12, 6, skin); }
      // Augen: Pupille 2 hoch mit Lichtpunkt
      for (const ex of [6, 9]) { P(ex, 7, eye); P(ex, 8, S(eye, -0.3)); }
      P(6, 7, S(eye, 0.5)); P(9, 7, S(eye, 0.5));
      if (fem) {
        P(5, 6, hS); P(10, 6, hS); P(5, 7, '#1a1010'); P(10, 7, '#1a1010');     // Wimpern
        P(5, 9, '#f0a0a0'); P(10, 9, '#f0a0a0');                               // Wangen
        P(7, 10, '#c8505a'); P(8, 10, '#a83a48');                              // Lippen
        P(8, 9, skS);
      } else {
        H(6, 5, 6, hS); H(6, 9, 10, hS);                                       // Brauen
        P(8, 9, skS); H(10, 7, 8, skD);
      }
      // ---------- Haare ----------
      if (!o.bald && !o.helm) {
        if (fem) {
          H(1, 5, 10, hair); H(2, 4, 11, hair); H(3, 3, 12, hair); H(4, 3, 12, hair);
          H(5, 3, 7, hair); P(8, 5, hair); H(5, 11, 12, hair); H(6, 3, 4, hair); P(5, 6, null); P(11, 6, hair); P(12, 6, hair);
          for (let y = 7; y <= 14; y++) { P(3, y, hair); P(12, y, hS); } for (let y = 10; y <= 15; y++) { P(2, y, hair); P(13, y, hS); }
          P(2, 16, hS); P(13, 16, hS); P(3, 15, hair);
          H(2, 6, 7, hL); P(5, 3, hL); P(4, 4, hL); for (let y = 8; y <= 13; y += 2) P(3, y, hL); P(9, 2, hL);
          H(4, 9, 12, hS); P(12, 5, hS);
          P(5, 6, skin);
        } else {
          H(1, 5, 10, hair); H(2, 4, 11, hair); H(3, 3, 12, hair); H(4, 3, 12, hair);
          H(5, 3, 6, hair); P(8, 5, hair); H(5, 10, 12, hair); P(3, 6, hair); P(12, 6, hair); P(3, 7, hS); P(12, 7, hS);
          H(2, 6, 8, hL); P(5, 3, hL); P(4, 4, hL); H(4, 10, 12, hS); P(9, 5, hS);
        }
      }
      if (fem && !o.helm && o.jewel !== false) { P(3, 9, trim); P(12, 9, trim); }   // Ohrringe
      if (o.beard) { P(4, 9, hair); P(11, 9, hS); H(10, 4, 6, hair); H(10, 9, 11, hS); H(11, 5, 10, hair); H(12, 6, 9, hS); P(7, 10, skD); P(8, 10, skD); P(6, 11, hL); }
      if (o.helm) {
        const hc = o.helmCol || hair, hcL = S(hc, 0.35), hcS = S(hc, -0.28), hcD = S(hc, -0.45);
        if (st === 'royal') { H(4, 4, 11, hc); H(3, 4, 11, hc); P(4, 2, hc); P(6, 1, hc); P(6, 2, hc); P(9, 1, hc); P(9, 2, hc); P(11, 2, hc); H(3, 5, 6, hcL); P(7, 3, '#c83a3a'); P(10, 3, '#3a8ad0'); H(5, 3, 4, hair); H(5, 11, 12, hair); }
        else {
          H(1, 5, 10, hc); H(2, 4, 11, hc); H(3, 3, 12, hc); H(4, 3, 12, hc); H(5, 3, 12, hcS); P(3, 6, hcS); P(12, 6, hcS); P(3, 7, hcD); P(12, 7, hcD);
          H(2, 5, 7, hcL); P(4, 3, hcL); H(3, 10, 12, hcS); P(7, 6, hcS); P(8, 6, hcD); P(7, 5, hcL);
          if (o.plume) { P(7, 0, o.plume); P(8, 0, o.plume); P(8, -1, o.plume); P(9, 0, S(o.plume, -0.3)); }
        }
      }
    }
    // ---------- Zeichnen ----------
    const c = mkCanvas(16, 24), x = c.getContext('2d');
    for (let y = 0; y < 24; y++) for (let xx = 0; xx < 16; xx++) if (g[y][xx]) { x.fillStyle = g[y][xx]; x.fillRect(xx, y, 1, 1); }
    addOutline(c, '#2a1a10');
    frames.push(c);
  }
  SPR_CACHE[key] = frames; return frames;
}
// Rüstungsstil der Spielfigur je nach Brustrüstung
const ARMOR_STYLE = {lumpen:['cloth'], robe:['robe'], magierrobe:['robe'], lederruestung:['leather'], kettenhemd:['chain'],
  plattenruestung:['plate', '#b8bcc8'], mithrilruestung:['plate', '#7ac8e0'], drachenruestung:['plate', '#a8402e', '#e8a040']};

// Kleidungsstil menschlicher Gegner
const ENEMY_STYLE = {goblin:{style:'cloth', female:false}, goblinboss:{style:'leather', female:false}, bandit:{style:'leather'}, bandit_bogen:{style:'leather', female:true, longHair:true},
  skelett:{style:'bones'}, knochenkoenig:{style:'bones'}, troll:{style:'cloth', female:false}, brueckentroll:{style:'cloth', female:false},
  soldat:{style:'plate', metal:'#6a5a6a', trim:'#8a1a2a'}, soldat_bogen:{style:'chain', outfit:'#3a2030'}, schattenritter:{style:'plate', metal:'#3a3a4a', trim:'#8a3ad0', cape:'#2a1030'},
  varek:{style:'royal', outfit:'#4a1a3a', trim:'#a080c0'}, hexe:{style:'robe', outfit:'#2a4a2a', trim:'#8ad070', female:true, longHair:true, jewel:true, gem:'#7ae040'},
  malgor:{style:'plate', metal:'#2a1a3a', trim:'#c83a3a', cape:'#6a0a1a'}};
