'use strict';
// ================= OBERFLÄCHE =================
const UI = {panel:null, tab:null, sel:null, shop:null, dlgNpc:null};
function toast(msg, cls) {
  const box = $('toasts'); if (!box) return;
  const t = el('div', 'toast ' + (cls || ''), msg); box.appendChild(t);
  setTimeout(() => t.classList.add('out'), 3400); setTimeout(() => t.remove(), 4000);
  while (box.children.length > 5) box.firstChild.remove();
}
function btn(label, fn, cls, disabled) {
  const b = el('button', 'b ' + (cls || ''), label); if (disabled) b.disabled = true;
  b.addEventListener('click', e => { e.stopPropagation(); if (!b.disabled) { sfx('click'); fn(); } }); return b;
}
// ---------- Dialoge ----------
function showDialog(name, text, opts, after) {
  G.paused = true;
  $('dialog').classList.remove('hidden');
  $('dname').textContent = name; $('dtext').innerHTML = text;
  const box = $('dopts'); box.innerHTML = '';
  (opts && opts.length ? opts : [{t:'Weiter'}]).forEach(o => {
    box.appendChild(btn(o.t, () => {
      const r = o.f ? o.f() : null;
      if (r === 'close') { closeDialog(); return; }
      if (r && r.text) { showDialog(name, r.text, r.opts || [{t:'Weiter', f:() => { if (after) { after(); return 'keep'; } return 'close'; }}], after); return; }
      if (r === 'keep') return;
      if (after && !o.f) { after(); return; }
      closeDialog();
    }, o.q ? 'quest' : ''));
  });
}
function showNpcDialog(n, r) {
  UI.dlgNpc = n;
  const again = () => { if (!G.npcMap[n.id] && !n.def.tmpNpc) { closeDialog(); return; } refreshNpcs(); const d = n.def.comp ? compDialog(n.id) : n.def.talk.call(n.def); showNpcDialog(n, d); };
  const opts = npcOptions(n, r).map(o => ({t:o.t, q:o.q, f:() => { const res = o.f ? o.f() : 'close'; if (res && res.text) { showDialog(n.def.name, res.text, res.opts ? res.opts.map(x => wrapOpt(x, again)) : [{t:'Weiter', f:() => { again(); return 'keep'; }}]); return 'keep'; } return res; }}));
  showDialog(n.def.name, r.text, opts);
}
function wrapOpt(o, again) { return {t:o.t, f:() => { const r = o.f ? o.f() : null; if (r && r.text) { showDialog(UI.dlgNpc.def.name, r.text, [{t:'Weiter', f:() => { again(); return 'keep'; }}]); return 'keep'; } if (r === 'close') return 'close'; again(); return 'keep'; }}; }
function askText(title, text, def, cb) {
  showDialog(title, text + '<br><input id="askinp" class="inp" maxlength="16">', [
    {t:'✅ Übernehmen', f:() => { const v = $('askinp').value; cb(v || def); return 'close'; }},
    {t:'Abbrechen'}]);
  const i = $('askinp'); i.value = def || ''; setTimeout(() => { try { i.focus(); i.select(); } catch (e) {} }, 50);
  i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') { cb(i.value || def); closeDialog(); } });
}
function closeDialog() { $('dialog').classList.add('hidden'); UI.dlgNpc = null; if (!UI.panel) G.paused = false; refreshNpcs(); }
function showStory(title, html) { showDialog(title, html, [{t:'Los geht’s'}]); }
function showScene(icon, html, done) {
  G.paused = true; const f = $('fade'); f.classList.remove('hidden');
  $('fadetext').innerHTML = '<div class="big">' + icon + '</div>' + html;
  $('fadebtn').onclick = () => { f.classList.add('hidden'); G.paused = false; if (done) done(); };
}
function showDeath() { G.paused = true; $('death').classList.remove('hidden'); }
function flashScreen() { const f = $('flash'); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go'); }
$('respawnbtn') && 0;
// ---------- Schlossknacken ----------
function startLockpick(lock, cb) {
  G.paused = true; const mg = $('minigame'); mg.classList.remove('hidden');
  const learned = !!P.learned.schloss, lvl = learned ? P.prof.schloss.lvl : 0;
  const tol = clamp((10 + lvl * 2.2 - lock * 1.2) * (learned ? 1 : 0.8), 5, 26);   // Toleranz in Grad
  const need = 1 + Math.floor((lock - 1) / 2);
  let target = rnd(15, 165), pins = 0, turn = 0, turnTo = 0, back = false, alive = true, busy = false, buzzed = false;
  const sl = $('mg-slider'), cv = $('mg-lock'), x = cv.getContext('2d');
  sl.value = 90;
  const info = () => { $('mg-info').textContent = 'Stifte: ' + pins + '/' + need + '   ·   Dietriche: ' + countItem('dietrich') + (learned ? '' : '   ·   ungeübt'); };
  const hint = (t, cls) => { const h = $('mg-hint'); h.textContent = t; h.className = cls || ''; };
  hint('Taste dich heran …'); info();
  const draw = () => {
    if (!alive) return;
    turn += (turnTo - turn) * 0.18;
    if (back && Math.abs(turn - turnTo) < 0.02) { turnTo = 0; back = false; }
    const W = cv.width, H = cv.height, cx = W / 2, cy = H - 18;
    x.clearRect(0, 0, W, H);
    // Schlossgehäuse
    x.fillStyle = '#6a4a2a'; x.beginPath(); x.arc(cx, cy, 64, Math.PI, 0); x.fill();
    x.fillStyle = '#8a6236'; x.beginPath(); x.arc(cx, cy, 58, Math.PI, 0); x.fill();
    // Zylinder dreht sich mit
    x.save(); x.translate(cx, cy); x.rotate(-turn * 1.4);
    x.fillStyle = '#c8a040'; x.beginPath(); x.arc(0, 0, 34, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#e8c860'; x.beginPath(); x.arc(-6, -6, 26, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#1a0e06'; x.fillRect(-4, -18, 8, 22); x.beginPath(); x.arc(0, -18, 7, 0, Math.PI * 2); x.fill();
    x.restore();
    // Stifte oben am Gehäuse
    for (let k = 0; k < need; k++) { const px = cx - (need - 1) * 14 + k * 28; x.fillStyle = k < pins ? '#7ae040' : '#3a2a1c'; x.fillRect(px - 5, 6, 10, 14); x.strokeStyle = '#1a0e06'; x.strokeRect(px - 5, 6, 10, 14); }
    // Dietrich
    const a = Math.PI - sl.value / 180 * Math.PI;
    x.strokeStyle = '#d8dce4'; x.lineWidth = 4; x.lineCap = 'round';
    x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(a) * 70, cy - Math.sin(a) * 70); x.stroke();
    x.strokeStyle = '#8a8e9a'; x.lineWidth = 2; x.beginPath(); x.moveTo(cx + Math.cos(a) * 70, cy - Math.sin(a) * 70); x.lineTo(cx + Math.cos(a) * 78 + Math.sin(a) * 6, cy - Math.sin(a) * 78 + Math.cos(a) * 6); x.stroke();
    requestAnimationFrame(draw);
  };
  requestAnimationFrame(draw);
  const end = ok => { alive = false; mg.classList.add('hidden'); G.paused = false; cb(ok); };
  sl.oninput = () => {
    const near = Math.abs(sl.value - target) <= tol;
    if (near && !buzzed) { buzzed = true; sfx('lock'); try { navigator.vibrate && navigator.vibrate(18); } catch (e) {} }
    if (!near) buzzed = false;
  };
  $('mg-l').onclick = () => { sl.value = Math.max(0, +sl.value - 3); sl.oninput(); };
  $('mg-r').onclick = () => { sl.value = Math.min(180, +sl.value + 3); sl.oninput(); };
  $('mg-try').onclick = () => {
    if (busy || !alive) return;
    const d = Math.abs(sl.value - target); gainProf('schloss', 2);
    if (d <= tol) {
      pins++; sfx('unlock'); turnTo = 1; info();
      if (pins >= need) { hint('Klick! Das Schloss springt auf.', 'ok'); busy = true; setTimeout(() => { toast('🔓 Geknackt!'); end(true); }, 650); return; }
      hint('Ein Stift sitzt! Noch ' + (need - pins) + '.', 'ok');
      busy = true; setTimeout(() => { turnTo = 0; busy = false; target = rnd(15, 165); }, 600);
      return;
    }
    turnTo = clamp(1 - (d - tol) / 70, 0.05, 0.85); back = true; sfx('fail');
    const dir = learned && lvl >= 2 ? (sl.value < target ? ' – eher nach rechts' : ' – eher nach links') : '';
    hint(d <= tol * 2 ? 'Ganz nah! Nur ein kleines Stück' + dir + '.' : d <= tol * 4 ? 'Warm …' + dir : 'Kalt. Das Schloss rührt sich kaum.', d <= tol * 2 ? 'warm' : '');
    if (d > tol * 3 && chance(learned ? 0.15 : 0.25)) {
      removeItem('dietrich', 1); toast('💥 Dietrich abgebrochen!'); info();
      if (!countItem('dietrich')) { toast('Keine Dietriche mehr.'); end(false); }
    }
  };
  $('mg-quit').onclick = () => end(false);
}
// ---------- Panels ----------
const PANELS = {
  inv:{title:'Inventar', tabs:() => [['bag', '🎒 Ausrüstung']].concat(nearTile(TL.HCHEST, 2.6) ? [['store', '🧰 Truhe']] : []), render:renderInv},
  char:{title:() => P.name + ' – ' + P.title, tabs:[['stats', 'Werte'], ['skills', 'Fähigkeiten'], ['rep', 'Ruf']], render:renderChar},
  craft:{title:'Berufe', tabs:[['all', 'Berufe']], render:renderCraft},
  quest:{title:'Questbuch', tabs:[['act', 'Aktiv'], ['avail', 'Verfügbar'], ['done', 'Erledigt']], render:renderQuests},
  map:{title:'Weltkarte', tabs:[['map', 'Karte']], render:renderMap},
  party:{title:'Gruppe', tabs:[['comp', '👥 Gefährten'], ['pets', '🐾 Tiere']], render:renderParty},
  estate:{title:'Besitz', tabs:[['house', '🏠 Häuser'], ['biz', '💰 Betriebe'], ['guild', '🛡️ Gilde']], render:renderEstate},
  shop:{title:() => UI.shop.name, tabs:() => [['buy', 'Kaufen'], ['sell', 'Verkaufen']].concat(UI.shop.smith ? [['smith', '⚒️ Schmiede']] : []), render:renderShop},
  sys:{title:'Menü', tabs:[['sys', 'Spiel'], ['help', 'Hilfe']], render:renderSys}
};
function openPanel(type, tab) {
  UI.panel = type; const tabs = typeof PANELS[type].tabs === 'function' ? PANELS[type].tabs() : PANELS[type].tabs;
  UI.tab = tab || tabs[0][0]; UI.sel = null; G.paused = true;
  $('panel').classList.remove('hidden'); renderPanel();
}
function closePanel() { UI.panel = null; UI.shop = null; $('panel').classList.add('hidden'); G.paused = false; refreshNpcs(); }
function renderPanel() {
  if (!UI.panel) return; const def = PANELS[UI.panel];
  $('ptitle').textContent = typeof def.title === 'function' ? def.title() : def.title;
  const tabs = typeof def.tabs === 'function' ? def.tabs() : def.tabs, tb = $('ptabs'); tb.innerHTML = '';
  if (tabs.length > 1) tabs.forEach(t => tb.appendChild(btn(t[1], () => { UI.tab = t[0]; UI.sel = null; renderPanel(); }, 'tab' + (UI.tab === t[0] ? ' on' : ''))));
  const body = $('pbody'), sc = body.scrollTop; body.innerHTML = ''; def.render(body, UI.tab); body.scrollTop = sc;
  $('pgold').textContent = fmt(P.gold) + ' Gold';
}
function row(icon, title, sub, buttons, cls) {
  const r = el('div', 'row ' + (cls || ''));
  r.appendChild(el('div', 'ric', icon));
  const t = el('div', 'rtx'); t.appendChild(el('div', 'rt', title)); if (sub) t.appendChild(el('div', 'rs', sub)); r.appendChild(t);
  const bx = el('div', 'rbt'); (buttons || []).forEach(b => bx.appendChild(b)); r.appendChild(bx);
  return r;
}
function iname(s) { return ITEMS[s.id].name + (s.up ? ' +' + s.up : ''); }
function idesc(s) {
  const it = ITEMS[s.id], o = [];
  if (it.type === 'waffe') o.push({melee:'Nahkampf', bow:'Bogen', staff:'Stab'}[it.wt] + ' · Schaden ' + Math.round(it.dmg * (1 + 0.12 * (s.up || 0))));
  if (ARMOR_SLOTS.includes(it.type)) o.push({helm:'Kopf', ruestung:'Brust', handschuhe:'Hände', hose:'Beine', schuhe:'Füße'}[it.type] + ' · Rüstung ' + Math.round(it.def * (1 + 0.12 * (s.up || 0))));
  if (it.cap) o.push('Fasst ' + it.cap + ' Pfeile');
  if (it.slots) o.push(it.slots + ' Inventarplätze');
  if (it.bonus) o.push(Object.keys(it.bonus).map(k => STAT_NAMES[k] + ' +' + it.bonus[k]).join(', '));
  if (it.def && it.type === 'schmuck') o.push('Rüstung +' + it.def);
  if (it.luck) o.push('Mehr Beute');
  if (it.heal) o.push(it.heal >= 999 ? 'Volle Heilung' : 'Heilt ' + it.heal);
  if (it.mana) o.push('+' + it.mana + ' Energie');
  if (it.buff) o.push(BUFF_NAMES[it.buff[0]]);
  if (it.holy) o.push('Doppelter Schaden gegen Untote');
  if (it.healBonus) o.push('+20 % Heilung');
  if (s.dur != null && (it.type === 'waffe' || ARMOR_SLOTS.includes(it.type))) o.push('Zustand ' + Math.round(s.dur) + ' %');
  if (it.type === 'tiergear') o.push('Für Tiere ab Stufe ' + it.minLvl + (it.def ? ' · Rüstung +' + it.def : '') + (it.hpB ? ' · Leben +' + Math.round(it.hpB * 100) + ' %' : '') + (it.speed ? ' · Reittempo +' + Math.round(it.speed * 100) + ' %' : '') + (it.slot === 'sattel' ? ' · nötig zum Reiten (ab Tierzähmung ' + RIDE_SKILL + '; Kampftiere ab Tierstufe ' + RIDE_LVL + ')' : ''));
  if (it.gift) o.push('Gutes Geschenk');
  if (it.type === 'tool') o.push(it.desc || 'Werkzeug');
  return o.join(' · ');
}
function renderInv(b, tab) {
  if (tab === 'store') {
    b.appendChild(el('p', 'hint', 'Truhe (' + P.storage.length + '/30). Tippe zum Ein- oder Auslagern.'));
    const cols = el('div', 'cols'), l = el('div', 'col'), r = el('div', 'col');
    l.appendChild(el('h3', '', 'Rucksack')); r.appendChild(el('h3', '', 'Truhe'));
    P.inv.forEach((s, i) => l.appendChild(row(ITEMS[s.id].icon, iname(s) + (s.n > 1 ? ' ×' + s.n : ''), '', [btn('→', () => { if (P.storage.length >= 30) return toast('Truhe voll'); P.storage.push(P.inv.splice(i, 1)[0]); renderPanel(); })])));
    P.storage.forEach((s, i) => r.appendChild(row(ITEMS[s.id].icon, iname(s) + (s.n > 1 ? ' ×' + s.n : ''), '', [btn('←', () => { if (P.inv.length >= invCap()) return toast('Rucksack voll'); const it = P.storage.splice(i, 1)[0]; const ex = ITEMS[it.id].stack && P.inv.find(x => x.id === it.id); if (ex) ex.n += it.n; else P.inv.push(it); renderPanel(); })])));
    cols.appendChild(l); cols.appendChild(r); b.appendChild(cols); return;
  }
  const st = stats(), cols = el('div', 'cols'), l = el('div', 'col'), r = el('div', 'col');
  l.appendChild(el('h3', '', 'Ausrüstung'));
  const slotN = {waffe:'Waffe', helm:'Kopf', ruestung:'Brust', handschuhe:'Hände', hose:'Beine', schuhe:'Füße', koecher:'Köcher', rucksack:'Rucksack', schmuck:'Schmuck'};
  EQ_TYPES.forEach(sl => {
    const s = P.eq[sl];
    l.appendChild(row(s ? ITEMS[s.id].icon : '▫️', s ? iname(s) : '— leer —', (s ? (ARMOR_SLOTS.includes(sl) ? '' : slotN[sl] + ' · ') + idesc(s) : slotN[sl]), s && sl !== 'rucksack' ? [btn('Ablegen', () => { unequip(sl); renderPanel(); })] : []));
  });
  l.appendChild(el('div', 'statbox', 'Leben ' + Math.round(P.hp) + '/' + st.maxHp + ' · Energie ' + Math.round(P.en) + '/' + st.maxEn + '<br>Rüstung ' + Math.round(st.def) + ' · Waffenschaden ' + Math.round(weaponDmg()) + '<br>Pfeile ' + P.arrows + '/' + quiverCap()));
  r.appendChild(el('h3', '', 'Rucksack ' + P.inv.length + '/' + invCap()));
  const grid = el('div', 'grid');
  for (let i = 0; i < invCap(); i++) {
    const s = P.inv[i], c = el('div', 'slot' + (UI.sel === i ? ' sel' : ''));
    if (s) { c.innerHTML = '<span>' + ITEMS[s.id].icon + '</span>' + (s.n > 1 ? '<i>' + s.n + '</i>' : '') + (s.up ? '<u>+' + s.up + '</u>' : ''); c.addEventListener('click', () => { UI.sel = i; renderPanel(); }); }
    grid.appendChild(c);
  }
  r.appendChild(grid);
  const s = P.inv[UI.sel];
  if (s) {
    const it = ITEMS[s.id], bt = [];
    if (s.id === 'reparaturset' || s.id === 'meisterset') bt.push(btn('🧰 Benutzen', () => { useRepairKit(s.id); if (UI.panel) renderPanel(); }, 'gold'));
    if (s.id === 'kochset') bt.push(btn('🔥 Feuer machen', () => { closePanel(); placeCampfire(); }, 'gold'));
    if (it.type === 'food') bt.push(btn('Benutzen', () => { useItem(UI.sel); if (!P.inv[UI.sel] || P.inv[UI.sel] !== s) UI.sel = null; renderPanel(); }, 'gold'));
    if (it.type === 'tiergear') bt.push(btn('🐾 Tier ausrüsten', () => { openPanel('party', 'pets'); }, 'gold'));
    if (EQ_TYPES.includes(it.type)) bt.push(btn('Ausrüsten', () => { equipItem(UI.sel); UI.sel = null; renderPanel(); }, 'gold'));
    if (it.type !== 'quest') bt.push(btn('Wegwerfen', () => { P.inv.splice(UI.sel, 1); UI.sel = null; renderPanel(); }, 'warn'));
    const d = el('div', 'detail'); d.appendChild(el('div', 'rt', it.icon + ' ' + iname(s) + (s.n > 1 ? ' ×' + s.n : ''))); d.appendChild(el('div', 'rs', idesc(s) || 'Material')); const bx = el('div', 'rbt'); bt.forEach(x => bx.appendChild(x)); d.appendChild(bx); r.appendChild(d);
  }
  cols.appendChild(l); cols.appendChild(r); b.appendChild(cols);
}
function renderChar(b, tab) {
  const st = stats();
  if (tab === 'stats') {
    b.appendChild(el('div', 'statbox', '<b>' + P.name + '</b> · ' + RACES[P.race].name + ' · ' + CLASSES[P.cls].name + (P.cls === 'hybrid' ? ' (' + Object.keys(P.discs).map(d => DISC[d].name).join(' + ') + ')' : '') +
      '<br>Stufe ' + P.lvl + ' · Erfahrung ' + fmt(P.xp) + '/' + fmt(xpNeed(P.lvl)) + '<br>' + RACES[P.race].trait + '<br>Gildenrang: ' + P.rank + ' · Titel: ' + P.title));
    b.appendChild(el('h3', '', 'Attribute' + (P.attrPts ? ' – ' + P.attrPts + ' Punkte frei' : '')));
    for (const k in STAT_NAMES) b.appendChild(row('', STAT_NAMES[k] + ': ' + st[k] + (st[k] !== P.base[k] ? ' (' + P.base[k] + ')' : ''), STAT_DESC[k], P.attrPts ? [btn('+', () => { P.base[k]++; P.attrPts--; renderPanel(); }, 'gold')] : []));
    b.appendChild(el('div', 'statbox', 'Leben ' + st.maxHp + ' · Energie ' + st.maxEn + ' · Rüstung ' + Math.round(st.def) + ' · Krit ' + Math.round(st.crit * 100) + ' %'));
  } else if (tab === 'skills') {
    b.appendChild(el('p', 'hint', 'Fähigkeitspunkte: ' + P.skillPts + '. Tippe 1/2/3, um eine Fähigkeit auf einen Schnellknopf zu legen. Jeder Rang: +20 % Wirkung, −6 % Abklingzeit, −4 % Energie, Stärkungen halten länger.'));
    for (const d of Object.keys(P.discs)) {
      if (!P.dl[d]) { b.appendChild(row(DISC[d].icon, DISC[d].name + ' – noch nicht erlernt', 'Dein Talent liegt hier. Ausbildung bei ' + DISC_TRAIN[d].where + ' (' + DISC_TRAIN[d].price + ' Gold).', [], 'dim')); continue; }
      b.appendChild(el('h3', '', DISC[d].icon + ' ' + DISC[d].name + (P.discs[d] < 1 ? ' (Hybrid – 80 % Wirkung)' : '')));
      for (const id in SKILLS) {
        const sk = SKILLS[id]; if (sk.d !== d) continue; const rk = P.skills[id] || 0;
        const bt = [];
        if (rk < 5 && P.skillPts > 0 && P.lvl >= sk.lvl) bt.push(btn(rk ? 'Rang +' : 'Lernen', () => { P.skills[id] = rk + 1; P.skillPts--; if (!rk) { const f = P.slots.indexOf(null); if (f >= 0) P.slots[f] = id; } renderPanel(); }, 'gold'));
        if (rk) [0, 1, 2].forEach(k => bt.push(btn(String(k + 1), () => { const o = P.slots.indexOf(id); if (o >= 0) P.slots[o] = null; P.slots[k] = id; renderPanel(); }, P.slots[k] === id ? 'on' : '')));
        const now = skillInfo(id, Math.max(1, rk)), next = rk && rk < 5 ? skillInfo(id, rk + 1) : '';
        b.appendChild(row(sk.icon, sk.name + (rk ? ' – Rang ' + rk + '/5' : ''), (P.lvl < sk.lvl ? 'Ab Stufe ' + sk.lvl + ' · ' : '') + sk.desc +
          '<br><b>' + (rk ? 'Jetzt' : 'Rang 1') + ':</b> ' + now + (next ? '<br><span class="nextrk"><b>Rang ' + (rk + 1) + ':</b> ' + next + '</span>' : rk >= 5 ? '<br><i>Höchster Rang erreicht</i>' : ''), bt, rk ? '' : 'dim'));
      }
    }
  } else if (tab === 'profs') {
    b.appendChild(el('p', 'hint', 'Berufe steigen, wenn du sie anwendest. Lehrmeister geben gegen Gold Unterricht (einmal pro Tag) und belohnen manche Aufträge mit Wissen. Höheres Können = weniger Fehlschläge und mehr Meisterstücke.'));
    for (const id in PROFS) {
      const pr = PROFS[id], p = P.prof[id];
      b.appendChild(row(pr.icon, pr.name + (P.learned[id] ? ' – Stufe ' + p.lvl : ''), (P.learned[id] ? (p.lvl >= 10 ? 'Meister' : 'Erfahrung ' + Math.floor(p.xp) + '/' + profNeed(p.lvl) + ' (steigt durch Anwenden)') : 'Noch nicht erlernt – ' + profTeacher(id)) + '<br><small>Unterricht: ' + PROF_TEACHERS[id] + '</small>', [], P.learned[id] ? '' : 'dim'));
    }
  } else {
    const t = (v, a) => v >= 60 ? a[4] : v >= 25 ? a[3] : v > -10 ? a[2] : v > -40 ? a[1] : a[0];
    b.appendChild(row('🏰', 'Ruf in Aldenmark: ' + t(P.rep.stadt, ['Verhasst', 'Verrufen', 'Unbekannt', 'Geachtet', 'Gefeiert']), 'Wert ' + P.rep.stadt + ' – beeinflusst Preise und wie Leute dich ansprechen.'));
    b.appendChild(row('⚖️', 'Gesinnung: ' + t(P.rep.karma, ['Schurke', 'Zwielichtig', 'Neutral', 'Ehrenhaft', 'Heilig']), 'Wert ' + P.rep.karma));
    b.appendChild(row('🗝️', 'Diebesgilde: ' + (P.rep.diebe >= 30 ? 'Familie' : P.f.krummFeind ? 'Feind' : 'Fremd'), 'Wert ' + P.rep.diebe));
    const k = Object.keys(P.kills).map(x => ENEMIES[x].name + ' ' + P.kills[x]).join(', ');
    b.appendChild(row('💀', 'Besiegte Gegner', k || 'Noch keine'));
  }
}
function profTeacher(id) { return {schmieden:'Schmied Gunnar (Aldenmark)', kochen:'Wirtin Rosa (Taverne, Aldenmark)', schloss:'jemand im Rattenviertel…', diebstahl:'jemand im Rattenviertel…', zaehmen:'Jägerin Wilma (Eichenrast)'}[id] || ''; }
const PROF_TEACHERS = {holz:'Bauer Jost (Eichenrast)', bergbau:'Brann (Zwergenmine)', sammeln:'Jägerin Wilma, später Hexe Morla', schmieden:'Gunnar (bis 6), Brann (bis 9)', kochen:'Rosa (bis 5), Hexe Morla (bis 9)', schloss:'Krummfinger / Grimm', diebstahl:'Krummfinger', zaehmen:'Jägerin Wilma (bis 5)'};
// ---------- Berufe: ein Menü für alles ----------
const PROF_GROUPS = [['Handwerk', ['schmieden', 'kochen']], ['Sammeln', ['bergbau', 'holz', 'sammeln']], ['Fertigkeiten', ['schloss', 'diebstahl', 'zaehmen']]];
const PROF_ICON = {schmieden:'eisenbarren', kochen:'eintopf', bergbau:'spitzhacke', holz:'axt', sammeln:'kraut', schloss:'dietrich', diebstahl:'beutel', zaehmen:'sattel'};
const PROF_HOW = {schmieden:'Gegenstände herstellen, reparieren und verbessern', kochen:'Essen und Tränke zubereiten', bergbau:'Erz und Gestein abbauen (Spitzhacke)', holz:'Bäume fällen (Axt)',
  sammeln:'Kräuter, Pilze und Blumen sammeln', schloss:'Truhen und Schlösser knacken', diebstahl:'Leute bestehlen (Vorsicht!)', zaehmen:'Tiere zähmen und füttern'};
const PROF_TEACH = {schmieden:'Gunnar in Aldenmark (bis 6) · Brann in der Mine (bis 9) · Runenmeisterin Hilda (bis 10)', kochen:'Wirtin Rosa (bis 5) · Einsiedler Oswin (bis 7) · Hexe Morla (bis 9)',
  bergbau:'Brann (bis 8) · Runenmeisterin Hilda (bis 10)', holz:'Bauer Jost in Eichenrast (bis 5)', sammeln:'Jägerin Wilma (bis 5) · Einsiedler Oswin (bis 8) · Hexe Morla (bis 9)',
  schloss:'Krummfinger oder Grimm (je nach deinem Weg)', diebstahl:'Krummfinger im Rattenviertel', zaehmen:'Jägerin Wilma (bis 5) · Jäger Ragnar in der Heide (bis 7)'};
function recipeCat(r) {
  const it = ITEMS[r.out], t = it.type;
  if (t === 'waffe') return 'Waffen'; if (ARMOR_SLOTS.includes(t)) return 'Rüstung'; if (t === 'tiergear') return 'Tierausrüstung';
  if (t === 'schmuck' || r.out === 'ring') return 'Schmuck'; if (t === 'food') return r.out.includes('trank') ? 'Tränke' : 'Essen';
  if (t === 'mat') return 'Material'; return 'Ausrüstung & Werkzeug';
}
function profBar(p) { return p.lvl >= 10 ? 100 : Math.round(p.xp / profNeed(p.lvl) * 100); }
function renderCraft(b) {
  if (!UI.prof) UI.prof = 'schmieden';
  if (!UI.sub) UI.sub = 'make';
  const wrap = el('div', 'profwrap'), list = el('div', 'proflist'), det = el('div', 'profdet');
  for (const [g, ids] of PROF_GROUPS) {
    list.appendChild(el('div', 'profgrp', g));
    for (const id of ids) {
      const p = P.prof[id], on = P.learned[id];
      const c = el('div', 'profcard' + (UI.prof === id ? ' sel' : '') + (on ? '' : ' off'),
        iconHTML(PROF_ICON[id]) + '<div><b>' + PROF_NAMES_SHORT[id] + '</b><small>' + (on ? 'Stufe ' + p.lvl + (p.lvl >= 10 ? ' · Meister' : '') : 'nicht erlernt') + '</small>' +
        (on ? '<span class="pbar"><i style="width:' + profBar(p) + '%"></i></span>' : '') + '</div>');
      c.addEventListener('click', () => { UI.prof = id; UI.sub = 'make'; sfx('click'); renderPanel(); });
      list.appendChild(c);
    }
  }
  renderProfDetail(det, UI.prof);
  wrap.appendChild(list); wrap.appendChild(det); b.appendChild(wrap);
}
const PROF_NAMES_SHORT = {schmieden:'Schmieden', kochen:'Kochen', bergbau:'Bergbau', holz:'Holzfällen', sammeln:'Kräuterkunde', schloss:'Schlösser', diebstahl:'Taschendiebstahl', zaehmen:'Tierzähmung'};
function renderProfDetail(d, id) {
  const pr = PROFS[id], p = P.prof[id], on = P.learned[id];
  const head = el('div', 'profhead');
  head.innerHTML = '<div class="bigic">' + iconHTML(PROF_ICON[id]) + '</div><div><h2>' + pr.name + '</h2>' +
    (on ? '<div>Stufe <b>' + p.lvl + '</b> von 10' + (p.lvl < 10 ? ' · ' + Math.floor(p.xp) + ' / ' + profNeed(p.lvl) + ' Erfahrung' : ' · Meister') + '</div><span class="pbar big"><i style="width:' + profBar(p) + '%"></i></span>' : '<div class="warn">Noch nicht erlernt</div>') +
    '<div class="howto">📈 Steigt durch: ' + PROF_HOW[id] + '<br>🎓 Unterricht: ' + PROF_TEACH[id] + '</div></div>';
  d.appendChild(head);
  if (id === 'schmieden' || id === 'kochen') {
    if (id === 'schmieden') {
      const seg = el('div', 'seg');
      [['make', '🔨 Herstellen'], ['fix', '⚒️ Reparieren & Verbessern']].forEach(([k, l]) => seg.appendChild(btn(l, () => { UI.sub = k; renderPanel(); }, UI.sub === k ? 'on' : '')));
      d.appendChild(seg);
      if (UI.sub === 'fix') { renderSmithFix(d); return; }
    }
    renderRecipes(d, id);
  } else if (HARVEST_INFO[id]) renderGatherInfo(d, id);
  else renderSkillInfo(d, id);
}
function renderRecipes(d, prof) {
  const station = prof === 'kochen' ? hasStation('feuer') : hasStation('amboss');
  d.appendChild(el('div', 'banner ' + (station ? 'ok' : 'no'), prof === 'kochen'
    ? (station ? '🔥 Du stehst an einer Feuerstelle – du kannst kochen.' : '🔥 Kochen geht nur an einer Feuerstelle: Tritt heran und drücke ✋ Aktion. Feuer gibt es in der Taverne, an Lagern, mit einem Herd zu Hause – oder du entzündest selbst eins mit dem Lagerfeuer-Set.')
    : (station ? '⚒️ Du stehst an einem Amboss – du kannst herstellen.' : '⚒️ Herstellen geht nur am Amboss: Tritt heran und drücke ✋ Aktion. Ambosse stehen in Gunnars Schmiede, in der Zwergenmine und – wenn du einen kaufst – bei dir zu Hause. Hier kannst du die Rezepte ansehen.')));
  const chips = el('div', 'seg small');
  [[false, 'Alle Rezepte'], [true, 'Nur herstellbare']].forEach(([v, l]) => chips.appendChild(btn(l, () => { UI.onlyCan = v; renderPanel(); }, !!UI.onlyCan === v ? 'on' : '')));
  d.appendChild(chips);
  const groups = {};
  for (const r of RECIPES) if (r.prof === prof) { if (UI.onlyCan && !canCraft(r)) continue; (groups[recipeCat(r)] = groups[recipeCat(r)] || []).push(r); }
  if (!Object.keys(groups).length) d.appendChild(el('p', 'hint', 'Im Moment kannst du nichts herstellen. Sammle Material oder schau unter „Alle Rezepte“, was du brauchst.'));
  for (const g in groups) {
    d.appendChild(el('h3', '', g));
    groups[g].sort((a, c) => (canCraft(c) - canCraft(a)) || a.lvl - c.lvl);
    for (const r of groups[g]) {
      const it = ITEMS[r.out], blk = craftBlock(r), ok = !blk;
      const locked = (r.lvl >= 1 && !P.learned[r.prof]) || P.prof[r.prof].lvl < r.lvl - 1;
      let status;
      if (ok) status = '<span class="st ok">✔ Bereit · ' + Math.round(craftChance(r) * 100) + ' % Erfolg' + (masterChance(r) > 0 ? ' · ' + Math.round(masterChance(r) * 100) + ' % Meisterstück' : '') + '</span>';
      else if (locked) status = '<span class="st lock">🔒 ' + (r.lvl >= 1 && !P.learned[r.prof] ? 'Beruf erlernen' : 'Ab Stufe ' + (r.lvl - 1)) + '</span>';
      else if (blk === 'Material fehlt') status = '<span class="st no">Fehlt: ' + Object.keys(r.req).filter(k => countItem(k) < r.req[k]).map(k => (r.req[k] - countItem(k)) + '× ' + ITEMS[k].name).join(', ') + '</span>';
      else status = '<span class="st warn">' + blk + '</span>';
      const mats = Object.keys(r.req).map(k => '<span class="mat ' + (countItem(k) >= r.req[k] ? 'ok' : 'no') + '">' + ITEMS[k].icon + countItem(k) + '/' + r.req[k] + '</span>').join('');
      d.appendChild(row(it.icon, it.name + (r.n ? ' ×' + r.n : ''), status + '<div class="mats">' + mats + '</div><small>' + idesc({id:r.out, dur:100}) + '</small>',
        [btn('Herstellen', () => { craft(r); renderPanel(); }, 'gold', !ok)], ok ? 'rec' : 'rec dim'));
    }
  }
}
function renderSmithFix(d) {
  const lvl = P.learned.schmieden ? P.prof.schmieden.lvl : 0, anvil = hasStation('amboss');
  d.appendChild(el('div', 'banner ' + (anvil ? 'ok' : 'no'), anvil ? '⚒️ Du stehst an einem Amboss.' : '⚒️ Geh zu einem Amboss (Schmiede in Aldenmark, Zwergenmine oder dein eigener Amboss zu Hause).'));
  const kitInfo = ['reparaturset', 'meisterset'].map(k => ITEMS[k].name + ': ' + countItem(k) + (kitBlock(k) && countItem(k) ? ' (ab Stufe ' + KIT_LVL[k] + ')' : '')).join(' · ');
  d.appendChild(el('div', 'banner ' + (P.prof.schmieden.lvl >= 4 ? 'ok' : 'no'), '🧰 Unterwegs reparieren: Ab Schmieden-Stufe 4 mit einem Reparaturset (repariert ein Teil), ab Stufe 7 mit einem Meister-Reparaturset (alles Angelegte). Du hast: ' + kitInfo));
  d.appendChild(el('p', 'hint', 'Ab Schmieden-Stufe 2 reparierst du selbst. Verbessern auf +1 geht ab Stufe 2, +2 ab Stufe 4 … bis +5 mit Stufe 10. Schmied Gunnar macht beides gegen Gold, aber nur bis +3.'));
  const list = [];
  for (const sl of ['waffe'].concat(ARMOR_SLOTS)) if (P.eq[sl]) list.push([P.eq[sl], 'angelegt']);
  P.inv.forEach(s => { const t = ITEMS[s.id].type; if (t === 'waffe' || ARMOR_SLOTS.includes(t)) list.push([s, 'Rucksack']); });
  if (!list.length) { d.appendChild(el('p', 'hint', 'Du hast keine Waffen oder Rüstungsteile.')); return; }
  for (const [s, where] of list) {
    const it = ITEMS[s.id], c = upgradeCost(s, true), mat = repairMat(s), bt = [];
    const canFix = anvil && lvl >= 2 && s.dur < 100 && countItem(mat) > 0;
    bt.push(btn(s.dur >= 100 ? 'Heil' : 'Reparieren', () => { doRepair(s, true); renderPanel(); }, '', !canFix));
    if (!anvil && s.dur < 100) bt.push(btn('🧰 Mit Set', () => { repairWithKit(s, 'reparaturset'); renderPanel(); }, '', !!kitBlock('reparaturset')));
    const canUp = anvil && c.nu <= 5 && lvl >= c.nu * 2 && Object.keys(c.mats).every(k => countItem(k) >= c.mats[k]);
    if (c.nu <= 5) bt.push(btn('Auf +' + c.nu, () => { doUpgrade(s, true); renderPanel(); }, 'gold', !canUp));
    const durCol = s.dur > 50 ? '#4caa44' : s.dur > 20 ? '#d8a830' : '#c83a2a';
    const fixInfo = lvl < 2 ? '🔒 Reparieren ab Stufe 2' : s.dur >= 100 ? 'In bestem Zustand' : 'Reparieren kostet 1× ' + ITEMS[mat].name + (countItem(mat) ? '' : ' (fehlt)');
    const upInfo = c.nu > 5 ? 'Höchste Stufe erreicht' : (lvl < c.nu * 2 ? '🔒 +' + c.nu + ' ab Stufe ' + c.nu * 2 : '+' + c.nu + ' kostet ' + Object.keys(c.mats).map(k => c.mats[k] + '× ' + ITEMS[k].name + (countItem(k) >= c.mats[k] ? '' : ' (fehlt)')).join(', '));
    d.appendChild(row(it.icon, iname(s) + ' <small>(' + where + ')</small>', 'Zustand <span class="pbar"><i style="width:' + s.dur + '%;background:' + durCol + '"></i></span> ' + Math.round(s.dur) + ' %<br>' + fixInfo + '<br>' + upInfo, bt));
  }
}
const HARVEST_INFO = {
  bergbau:[[0, 'stein', 'Felsen'], [0, 'eisenerz', 'Felsen mit braunen Adern'], [3, 'silbererz', 'Felsen mit hellen Adern'], [4, 'kristall', 'Kristallfelsen'], [6, 'mithrilerz', 'Felsen mit blauen Adern']],
  holz:[[0, 'holz', 'Laub-, Nadel- und tote Bäume']],
  sammeln:[[0, 'kraut', 'Heilkräuter (weiße Blüten)'], [0, 'pilz', 'Rote Pilze'], [0, 'blume', 'Wildblumen']]
};
function renderGatherInfo(d, id) {
  const p = P.prof[id];
  d.appendChild(el('div', 'banner ok', 'Bei jeder Ernte: ' + Math.round(p.lvl * 4) + ' % schneller' + (Math.floor(p.lvl / 4) ? ', +' + Math.floor(p.lvl / 4) + ' zusätzliche Ausbeute' : '') + '. Nächster Bonus bei Stufe ' + (Math.floor(p.lvl / 4) + 1) * 4 + '.'));
  d.appendChild(el('h3', '', 'Was du abbauen kannst'));
  for (const [need, item, src] of HARVEST_INFO[id]) {
    const ok = p.lvl >= need;
    d.appendChild(row(ITEMS[item].icon, ITEMS[item].name, src + ' · ' + (ok ? '<span class="st ok">✔ möglich</span>' : '<span class="st lock">🔒 ab Stufe ' + need + '</span>'), [], ok ? '' : 'dim'));
  }
  if (id === 'bergbau' && !countItem('spitzhacke')) d.appendChild(el('p', 'hint warn', 'Du brauchst eine Spitzhacke (bei Baldur oder selbst schmieden).'));
  if (id === 'holz' && !countItem('axt')) d.appendChild(el('p', 'hint warn', 'Du brauchst eine Axt (bei Baldur).'));
}
function renderSkillInfo(d, id) {
  const p = P.prof[id], on = P.learned[id], lv = on ? p.lvl : 0;
  if (id === 'schloss') {
    const tol = l => clamp((10 + l * 2.2 - 3 * 1.2) * (on ? 1 : 0.8), 5, 26);
    d.appendChild(row(iconHTML('dietrich'), 'Schlösser knacken', 'Spielraum bei einem mittleren Schloss: <b>' + Math.round(tol(lv)) + '°</b> (nächste Stufe: ' + Math.round(tol(lv + 1)) + '°)<br>Richtungshinweis: ' + (on && lv >= 2 ? '✔ aktiv' : '🔒 ab Stufe 2') + '<br>Dietrich bricht bei groben Fehlern: ' + (on ? '15 %' : '25 %')));
  } else if (id === 'diebstahl') {
    const ch = l => Math.round(clamp(0.2 + (on ? 0.2 : 0) + l * 0.05, 0.1, 0.85) * 100);
    d.appendChild(row(iconHTML('beutel'), 'Taschendiebstahl', 'Erfolgschance: <b>' + ch(lv) + ' %</b> (nachts +5 %) · nächste Stufe: ' + ch(lv + 1) + ' %<br>Beute: +' + lv * 20 + ' % Gold'));
  } else {
    d.appendChild(el('h3', '', 'Zähmbare Tiere'));
    const zl = lv + (P.race === 'ork' ? 1 : 0);
    for (const t in ENEMIES) {
      const tm = ENEMIES[t].tame; if (!tm) continue;
      const ok = on && zl >= tm.lvl;
      d.appendChild(row('🐾', ENEMIES[t].name, (tm.roles.includes('reit') ? 'Reittier' : 'Kampftier') + ' · Futter: ' + ITEMS[tm.food || 'fleisch'].name + ' · ' + (ok ? '<span class="st ok">✔ zähmbar</span>' : '<span class="st lock">🔒 ab Stufe ' + tm.lvl + '</span>'), [], ok ? '' : 'dim'));
    }
  }
}
function questSub(id) {
  const q = getQ(id), s = P.q[id]; if (!s) return q.steps[0].txt; if (s.done) return 'Abgeschlossen';
  const st = q.steps[s.s];
  return st.txt + (st.t === 'kill' ? ' (' + s.c + '/' + st.n + ')' : st.t === 'collect' ? ' (' + Math.min(countItem(st.item), st.n) + '/' + st.n + ')' : '');
}
function renderQuests(b, tab) {
  if (tab === 'avail') {
    refreshBoard();
    const ids = Object.keys(P.avail);
    b.appendChild(el('p', 'hint', 'Aufträge, die dir angeboten wurden. Nimm sie hier an – angenommene Quests erscheinen am Bildschirmrand.'));
    if (!ids.length) b.appendChild(el('p', 'hint', 'Keine offenen Angebote. Personen mit einem ? über dem Kopf haben Arbeit für dich.'));
    for (const id of ids) { const q = getQ(id); b.appendChild(row(q.main ? '👑' : '📜', q.name, (q.giver ? '<b>' + q.giver + ':</b> ' : '') + q.desc + (q.lvl ? '<br><small>Empfohlen ab Stufe ' + q.lvl + (q.lvl > P.lvl + 1 ? ' ⚠️' : '') + '</small>' : ''), [btn('Annehmen', () => { acceptQuest(id); renderPanel(); }, 'gold')], q.main ? 'main' : '')); }
    if (questDone('gilde')) {
      b.appendChild(el('h3', '', '📋 Auftragsbrett der Gilde (neu jeden Tag)'));
      const full = bountyCount() >= 2;
      if (!P.board.list.length) b.appendChild(el('p', 'hint', 'Heute keine weiteren Kopfgelder.'));
      for (const bq of P.board.list) b.appendChild(row('💰', bq.name, bq.steps[0].txt + ' · Lohn ' + bq.reward.gold + ' Gold, ' + bq.reward.xp + ' EP, +2 Ansehen', [btn(full ? 'Max. 2 aktiv' : 'Annehmen', () => { acceptQuest(bq.id); renderPanel(); }, 'gold', full)]));
    }
    return;
  }
  const ids = Object.keys(P.q).filter(id => tab === 'act' ? !P.q[id].done : P.q[id].done && getQ(id));
  if (!ids.length) b.appendChild(el('p', 'hint', tab === 'act' ? 'Keine aktiven Quests. Schau unter „Verfügbar“ oder sprich mit Leuten, die ein ? über dem Kopf haben.' : 'Noch nichts erledigt.'));
  ids.sort((a, c) => (getQ(c).main ? 1 : 0) - (getQ(a).main ? 1 : 0));
  const tr = trackedQuest();
  for (const id of ids) {
    const q = getQ(id), bt = [];
    if (tab === 'act') {
      bt.push(btn(tr === id ? '📌 Verfolgt' : '📌 Verfolgen', () => { P.track = id; renderPanel(); }, tr === id ? 'on' : ''));
      if (!q.main) bt.push(btn('Abbrechen', () => { abandonQuest(id); renderPanel(); }, 'warn'));
    }
    b.appendChild(row(q.main ? '👑' : q.bounty ? '💰' : '📜', q.name, questSub(id) + (tab === 'act' && q.desc ? '<br><small>' + q.desc + '</small>' : ''), bt, q.main ? 'main' : ''));
  }
}
function worldPosOf(p) {
  // Ziele in Innenräumen werden auf der Karte an der Haustür angezeigt
  if (p[1] >= WORLD_H) { const r = regionAt(p[0], p[1]); if (r.startsWith('i_')) { const d = INTERIORS[r.slice(2)].door; return [d[0] + 0.5, d[1] + 1]; } }
  return p;
}
function questTargets(only) {
  const out = [];
  const pos = id => { const d = NPC_DEFS.find(n => n.id === id); if (d) return npcPos(d); if (COMPS[id]) return compHome(id); return null; };
  for (const id of (only ? [only] : Object.keys(P.q))) {
    const st = curStep(id); if (!st) continue; let p = null;
    if (st.npc) p = pos(st.npc);
    else if (st.t === 'branch') p = pos(st.opts[0].npc);
    else if (st.t === 'goto') p = REGION_INFO[st.region].c;
    else if (st.t === 'kill' && BOSS_POS[st.e]) p = BOSS_POS[st.e];
    else if (st.t === 'kill' && st.e === 'ratte') p = shiftOld(59, 116);
    if (p) out.push(worldPosOf(p));
  }
  return out;
}
function renderMap(b) {
  const c = el('canvas', 'bigmap'); c.width = 640; c.height = 640; b.appendChild(c);
  const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
  flushMap(); x.fillStyle = '#1a140e'; x.fillRect(0, 0, 640, 640); x.drawImage(G.mapC, 0, 0, MW, WORLD_H, 0, 0, 640, 640); const K = 640 / MW;
  x.font = 'bold 15px Georgia, serif'; x.textAlign = 'center';
  for (const k in REGION_INFO) {
    const r = REGION_INFO[k]; if (!r.c) continue; const cx = Math.floor(r.c[0]), cy = Math.floor(r.c[1]);
    if (!G.explored[idx(cx, cy)]) continue;
    x.lineWidth = 3; x.strokeStyle = 'rgba(0,0,0,.8)'; const lab = r.name + (r.lv ? ' (' + r.lv[0] + '–' + r.lv[1] + ')' : ''); const lx = clamp(r.c[0] * K, x.measureText(lab).width / 2 + 4, 636 - x.measureText(lab).width / 2), ly = clamp(r.c[1] * K, 16, 630); x.strokeText(lab, lx, ly); x.fillStyle = r.lv && r.lv[0] > P.lvl + 2 ? '#ffb0a0' : '#f6e7c1'; x.fillText(lab, lx, ly);
  }
  for (const p of questTargets()) { x.fillStyle = '#ffd23a'; x.strokeStyle = '#000'; x.lineWidth = 2; x.beginPath(); x.arc(p[0] * K, p[1] * K, 7, 0, TAU); x.fill(); x.stroke(); x.fillStyle = '#000'; x.fillText('!', p[0] * K, p[1] * K + 5); }
  const pp = worldPosOf([P.x, P.y]); x.fillStyle = '#fff'; x.strokeStyle = '#c00'; x.lineWidth = 3; x.beginPath(); x.arc(pp[0] * K, pp[1] * K, 6, 0, TAU); x.fill(); x.stroke();
  let ex = 0; for (let i = 0; i < MW * WORLD_H; i++) ex += G.explored[i];
  b.appendChild(el('p', 'hint', 'Erkundet: ' + Math.round(ex / (MW * WORLD_H) * 100) + ' %. Gelbe Punkte zeigen deine Questziele.'));
}
function renderParty(b, tab) {
  if (tab === 'comp') {
    b.appendChild(el('p', 'hint', 'Die Gruppe levelt gemeinsam: Gefährten, dein Kampftier und dein Reittier bekommen dieselbe Erfahrung wie du – auch aus Quests. Wer mehr als eine Stufe zurückliegt, holt doppelt so schnell auf. Bis zu 4 Gefährten begleiten dich. Gefährten triffst du in Städten und Dörfern – manche schließen sich erst nach Quests an. Freundschaft und Liebe wachsen durch Gespräche, Flirts und Geschenke.'));
    if (!P.party.length) b.appendChild(el('p', 'hint', 'Du reist allein. Grimm im Rattenviertel und Mira im Tempel von Aldenmark suchen Arbeit…'));
    for (const id of P.party) {
      const c = COMPS[id], a = G.allies.find(x => x.id === id), s = P.comp[id];
      const lv = compLvl(id), st = compStats(id), pic = el('canvas', 'petpic'); pic.width = 16; pic.height = 24; pic.getContext('2d').drawImage(makeHumanoid(c.look)[0], 0, 0);
      const ic = '<img class="pix" src="' + pic.toDataURL() + '">';
      b.appendChild(row(ic, c.name + ' – ' + c.title + ' <small>· Stufe ' + lv + '</small>', '<i>' + COMP_ROLE[c.cls] + '</i><br>' + (a ? (a.down ? 'Bewusstlos' : 'Leben ' + Math.round(a.hp) + '/' + a.maxHp) : '') +
        (c.cls === 'heil' ? ' · Heilkraft ' + Math.round(8 + lv * 3.2) : ' · Schaden ' + Math.round(st.dmg)) +
        '<br>Erfahrung ' + Math.floor(s.xp || 0) + '/' + compXpNeed(lv) + ' <span class="pbar"><i style="width:' + Math.round((s.xp || 0) / compXpNeed(lv) * 100) + '%"></i></span><br>' + hearts(s.aff) + (s.lover ? ' 💞' : ''),
        [btn('Reden', () => { closePanel(); const fake = {id, def:{id, name:c.name, comp:true}}; showNpcDialog(fake, compDialog(id)); })]));
    }
    const away = Object.keys(COMPS).filter(id => !P.party.includes(id) && P.comp[id].hired);
    if (away.length) { b.appendChild(el('h3', '', 'Zuhause wartend')); away.forEach(id => { const h = compHome(id); b.appendChild(row('🏠', COMPS[id].name, 'Wartet in: ' + locName(h[0], h[1]))); }); }
  } else {
    if (!P.learned.zaehmen) b.appendChild(el('p', 'hint', 'Lerne Tierzähmung bei Jägerin Wilma in Eichenrast. Schwäche dann ein Tier (unter 35 % Leben, Pferde und Hirsche nicht nötig) und nutze die Aktionstaste mit Futter: Fleisch für Raubtiere, Heilkraut für Pflanzenfresser.'));
    if (P.pets.length) b.appendChild(el('p', 'hint', 'Dein Kampftier und dein Reittier leveln gemeinsam mit dir und bekommen dieselbe Erfahrung wie du. Ab Stufe 5, 10 und 15 entwickeln sie sich und sehen wilder aus. Reiten geht nur mit Sattel und ab Tierzähmung ' + RIDE_SKILL + '. Pferde und Hirsche trägst du dann sofort, Kampftiere ab Tierstufe ' + RIDE_LVL + '.'));
    P.pets.forEach((p, i) => {
      const ph = petHp(i), st = petStats(p), tier = petTier(p.lvl || 1), g = p.gear || {};
      const card = el('div', 'petcard' + (tier >= 3 ? ' legend' : ''));
      const pic = el('canvas', 'petpic'); pic.width = 16; pic.height = 16; pic.getContext('2d').drawImage(petSprite(p)[0], 0, 0); card.appendChild(pic);
      const info = el('div', 'rtx');
      const roles = [p.roles.includes('kampf') ? 'Kampftier' : null, canRide(p) ? 'Reittier (Tempo ×' + mountSpeed(p).toFixed(2) + ')' : null].filter(Boolean).join(' & ');
      info.appendChild(el('div', 'rt', p.name + ' <small>(' + p.species + ')</small>' + (ph.down ? ' – 💔 bewusstlos' : '')));
      info.appendChild(el('div', 'rs', 'Stufe ' + p.lvl + ' · ' + PET_TIERS[tier].name + (tier < 3 ? ' (nächste Entwicklung ab Stufe ' + PET_TIERS[tier + 1].lvl + ')' : '') + '<br>' +
        'Leben ' + Math.round(ph.hp) + '/' + ph.max + '<span class="petbar"><i style="width:' + Math.round(ph.hp / ph.max * 100) + '%"></i></span> · Schaden ' + Math.round(st.dmg) + ' · Rüstung ' + Math.round(st.def) + '<br>' +
        'Erfahrung ' + Math.floor(p.xp || 0) + '/' + petXpNeed(p.lvl) + '<span class="petbar xpb"><i style="width:' + Math.round((p.xp || 0) / petXpNeed(p.lvl) * 100) + '%"></i></span>' + (roles ? '<br>' + roles : '') +
        '<br><small>Futter: ' + petFoods(p).map(f => ITEMS[f].icon + ' ' + ITEMS[f].name + ' (' + countItem(f) + ')').join(', ') + '</small>'));
      // Ausrüstungsplätze
      const gear = el('div', 'petgear');
      [['armor', 'panzer', 'Panzer'], ['saddle', 'sattel', 'Sattel']].forEach(([slot, kind, label]) => {
        const cur = g[slot], box = el('div', 'gslot');
        box.innerHTML = (cur ? ITEMS[cur.id].icon + ' ' + ITEMS[cur.id].name : '▫️ ' + label + ': leer');
        const opts = P.inv.map((x, k) => [x, k]).filter(([x]) => ITEMS[x.id].type === 'tiergear' && ITEMS[x.id].slot === kind);
        if (cur) box.appendChild(btn('Ablegen', () => { unequipPet(i, slot); renderPanel(); }));
        if (opts.length) box.appendChild(btn(cur ? 'Wechseln' : 'Anlegen', () => {
          showDialog(label + ' für ' + p.name, 'Was soll ' + p.name + ' tragen?', opts.map(([x, k]) => ({t:ITEMS[x.id].icon + ' ' + ITEMS[x.id].name + ' (ab St. ' + ITEMS[x.id].minLvl + ')', f:() => { equipPet(i, k); setTimeout(renderPanel, 0); return 'close'; }})).concat([{t:'Abbrechen'}]));
        }, 'gold'));
        gear.appendChild(box);
      });
      info.appendChild(gear);
      card.appendChild(info);
      const bt = el('div', 'rbt');
      bt.appendChild(btn(ph.down ? '💚 Wiederbeleben' : '🍖 Füttern', () => { feedPet(i); renderPanel(); }, ph.down ? 'gold' : '', !ph.down && ph.hp >= ph.max));
      bt.appendChild(btn('✏️ Umbenennen', () => askText('Umbenennen', 'Neuer Name für ' + p.name + ':', p.name, n => { renamePet(i, n); if (UI.panel) renderPanel(); })));
      if (p.roles.includes('kampf')) bt.appendChild(btn(P.petActive === i ? 'Kämpft ✓' : 'Kämpfen lassen', () => { P.petActive = P.petActive === i ? -1 : i; syncAllies(); renderPanel(); }, P.petActive === i ? 'on' : ''));
      if (!canRide(p) && (p.roles.includes('reit') || (p.gear && p.gear.saddle))) bt.appendChild(btn('🐎 ' + rideBlock(p), () => {}, '', true));
      if (canRide(p)) bt.appendChild(btn(P.mount === i ? 'Reittier ✓' : 'Als Reittier', () => { P.mount = i; P.mounted = false; syncAllies(); renderPanel(); }, P.mount === i ? 'on' : ''));
      bt.appendChild(btn('Freilassen', () => { showDialog('Freilassen', p.name + ' wirklich freilassen? Ausrüstung kommt in deinen Rucksack.', [{t:'Ja, freilassen', f:() => {
        for (const sl of ['armor', 'saddle']) if (p.gear && p.gear[sl]) P.inv.push(p.gear[sl]);
        P.pets.splice(i, 1); if (P.petActive === i) P.petActive = -1; else if (P.petActive > i) P.petActive--; if (P.mount === i) { P.mount = -1; P.mounted = false; } else if (P.mount > i) P.mount--; G.allies = G.allies.filter(a => a.kind !== 'pet'); syncAllies(); setTimeout(renderPanel, 0); return 'close'; }}, {t:'Nein'}]); }, 'warn'));
      card.appendChild(bt);
      b.appendChild(card);
    });
  }
}
function renderEstate(b, tab) {
  const here = inCity() && !regionAt(P.x, P.y).startsWith('i_h_');
  const rs = Math.floor(P.rep.stadt);
  b.appendChild(el('p', 'hint' + (here ? '' : ' warn'), 'Dein Ansehen in Aldenmark: ' + rs + '. Ansehen erhältst du durch Quests, Kopfgelder, Spenden im Tempel und gute Taten.' + (here ? '' : ' Kaufen und Ausbauen geht nur in Aldenmark oder im Rattenviertel.')));
  if (tab === 'house') {
    b.appendChild(el('p', 'hint', 'Nach dem Kauf betrittst du dein Haus durch die Tür und richtest es dort an den markierten Plätzen ein.'));
    for (const id in HOUSES) {
      const h = HOUSES[id], own = P.houses.includes(id), repOkH = repOk(h.rep);
      const f = (P.furn[id] || []).filter(Boolean).map(x => FURNITURE[x].icon).join(' ');
      b.appendChild(row(h.icon, h.name, own ? 'Dein Zuhause · Einrichtung: ' + (f || 'leer') + ' (' + (P.furn[id] || []).filter(Boolean).length + '/' + h.slots.length + ')' : fmt(h.cost) + ' Gold · ' + h.slots.length + ' Möbelplätze · benötigt Ansehen ' + h.rep + (repOkH ? ' ✓' : ' ✗'),
        own ? [] : [btn('Kaufen', () => { buyHouse(id); renderPanel(); }, 'gold', !here || P.gold < h.cost || !repOkH)]));
    }
  } else if (tab === 'biz') {
    b.appendChild(el('p', 'hint', 'Betriebe werden von Angestellten geführt und zahlen dir jeden Morgen Gewinn. Ausbauen erhöht den Ertrag.'));
    for (const id in BUSINESSES) {
      const z = BUSINESSES[id], s = P.biz[id], ok = repOk(z.rep, z.thief);
      if (s) b.appendChild(row(z.icon, z.name + ' – Stufe ' + s.lvl, '+' + bizIncome(id) + ' Gold/Tag · bisher ' + fmt(s.total) + ' Gold', s.lvl < 5 ? [btn('Ausbauen (' + fmt(z.upCost * s.lvl) + ')', () => { upgradeBiz(id); renderPanel(); }, 'gold', !here || P.gold < z.upCost * s.lvl)] : []));
      else b.appendChild(row(z.icon, z.name, z.desc + '<br>' + fmt(z.cost) + ' Gold · ca. ' + z.income + ' Gold/Tag · benötigt Ansehen ' + z.rep + (ok ? ' ✓' : ' ✗'), [btn('Kaufen', () => { buyBiz(id); renderPanel(); }, 'gold', !here || P.gold < z.cost || !ok)]));
    }
  } else {
    if (!P.guild) {
      const req = [['Gildenrang Silber (Quest „Goblinplage“)', questDone('goblins')], ['Ansehen ' + GUILD_REP + ' in Aldenmark (du: ' + rs + ')', P.rep.stadt >= GUILD_REP], ['3.000 Gold', P.gold >= 3000]];
      b.appendChild(el('p', 'hint', 'Gründe deine eigene Abenteurergilde. Mitglieder erledigen Aufträge und bringen täglich Gold und Material. Jede Gildenstufe gibt dir +5 % Erfahrung.'));
      req.forEach(r => b.appendChild(row(r[1] ? '✅' : '❌', r[0], '')));
      const inp = el('input', 'inp'); inp.placeholder = 'Name deiner Gilde'; inp.maxLength = 28; b.appendChild(inp);
      b.appendChild(btn('Gilde gründen', () => { foundGuild(inp.value.trim()); renderPanel(); }, 'gold', !req.every(r => r[1])));
    } else {
      const g = P.guild;
      b.appendChild(row('🛡️', g.name + ' – Stufe ' + g.lvl, 'Mitglieder ' + g.members + '/' + guildMax() + ' · ca. ' + g.members * 12 * g.lvl + ' Gold/Tag · +' + g.lvl * 5 + ' % Erfahrung'));
      b.appendChild(btn('Mitglied anwerben (150 Gold)', () => { recruitMember(); renderPanel(); }, 'gold', g.members >= guildMax() || P.gold < 150));
      if (g.lvl < 5) b.appendChild(btn('Gildenhaus ausbauen (' + fmt(2500 * g.lvl) + ' Gold)', () => { upgradeGuild(); renderPanel(); }, 'gold', P.gold < 2500 * g.lvl));
    }
  }
}
function openShop(id, npc, tab) { UI.shop = {id, name:npc.def.name, npc, fence:!!npc.def.fence, smith:!!npc.def.smith}; openPanel('shop', tab); }
function renderShop(b, tab) {
  const sh = UI.shop;
  if (tab === 'buy') {
    for (const id of SHOPS[sh.id]) {
      const it = ITEMS[id], pr = buyPrice(id);
      b.appendChild(row(it.icon, it.name, pr + ' Gold · ' + idesc({id, dur:100}), [btn('Kaufen', () => { if (P.gold < pr) return toast('Nicht genug Gold.'); if (addItem(id, 1)) { P.gold -= pr; renderPanel(); } }, 'gold', P.gold < pr)]));
    }
  } else if (tab === 'sell') {
    if (!P.inv.length) b.appendChild(el('p', 'hint', 'Dein Rucksack ist leer.'));
    P.inv.forEach((s, i) => {
      const pr = sellPrice(s, sh.fence); if (!pr) return;
      const bt = [btn('1 für ' + pr, () => { P.gold += pr; s.n--; if (s.n <= 0) P.inv.splice(i, 1); renderPanel(); })];
      if (s.n > 1) bt.push(btn('Alle (' + pr * s.n + ')', () => { P.gold += pr * s.n; P.inv.splice(i, 1); renderPanel(); }));
      b.appendChild(row(ITEMS[s.id].icon, iname(s) + (s.n > 1 ? ' ×' + s.n : ''), idesc(s), bt));
    });
  } else {
    b.appendChild(el('p', 'hint', 'Gunnar verbessert Waffen und Rüstungen bis +3 und repariert sie. Mit eigenem Schmiede-Können (Stufe 2× Ziel) erreichst du am Amboss bis +5.'));
    const list = [];
    ['waffe'].concat(ARMOR_SLOTS).forEach(sl => { if (P.eq[sl]) list.push(P.eq[sl]); });
    P.inv.forEach(s => { const t = ITEMS[s.id].type; if (t === 'waffe' || ARMOR_SLOTS.includes(t)) list.push(s); });
    for (const s of list) {
      const c = upgradeCost(s, false), cs = upgradeCost(s, true), bt = [];
      const mats = m => m ? Object.keys(m).map(k => m[k] + '× ' + ITEMS[k].name).join(', ') : '';
      if (c.nu <= 3) bt.push(btn('+' + c.nu + ' (' + c.gold + ' G)', () => { doUpgrade(s, false); renderPanel(); }, 'gold'));
      if (cs.nu <= 5 && P.learned.schmieden && P.prof.schmieden.lvl >= cs.nu * 2 && hasStation('amboss')) bt.push(btn('Selbst +' + cs.nu, () => { doUpgrade(s, true); renderPanel(); }));
      if (s.dur < 100) bt.push(btn('Reparieren (' + repairCost(s) + ' G)', () => { doRepair(s, false); renderPanel(); }));
      b.appendChild(row(ITEMS[s.id].icon, iname(s), 'Zustand ' + Math.round(s.dur) + ' %' + (c.nu <= 5 ? ' · Nächste Stufe braucht: ' + mats(c.mats) : ' · Maximal verbessert'), bt));
    }
  }
}
function renderSys(b, tab) {
  if (tab === 'sys') {
    const vol = (label, val, set) => { const w = el('div', 'volrow'); w.appendChild(el('span', '', label)); const r = el('input'); r.type = 'range'; r.min = 0; r.max = 100; r.value = Math.round(val * 100); r.oninput = () => set(r.value / 100); w.appendChild(r); b.appendChild(w); };
    vol('🎵 Musik', AU.musicVol, v => setVolumes(v, AU.sfxVol));
    vol('🔊 Effekte', AU.sfxVol, v => { setVolumes(AU.musicVol, v); sfx('coin'); });
    b.appendChild(btn('💾 Spiel speichern', () => { saveGame(); }, 'gold wide'));
    b.appendChild(btn('📤 Spielstand sichern (als Code)', () => {
      const code = exportSave(); closePanel();
      showDialog('Spielstand sichern', 'Kopiere diesen Code und bewahre ihn auf (z. B. in einer Notiz). Damit kannst du deinen Spielstand jederzeit wiederherstellen – auch nach einer Neuinstallation.<br><textarea id="savecode" class="inp code" readonly></textarea>', [
        {t:'📋 Kopieren', f:() => { const t = $('savecode'); t.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} try { navigator.clipboard && navigator.clipboard.writeText(t.value).then(() => toast('Kopiert!')); } catch (e) {} if (ok) toast('Kopiert!'); return 'keep'; }},
        {t:'Fertig'}]);
      $('savecode').value = code;
    }, 'wide'));
    b.appendChild(btn('📥 Spielstand aus Code laden', () => {
      closePanel();
      showDialog('Spielstand laden', 'Füge hier deinen gesicherten Code ein. Achtung: Der aktuelle Stand wird ersetzt (eine Sicherheitskopie wird angelegt).<br><textarea id="loadcode" class="inp code"></textarea>', [
        {t:'📥 Laden', f:() => { if (importSave($('loadcode').value)) { toast('Spielstand geladen!', 'gold'); return 'close'; } return {text:'Der Code ist ungültig. Prüfe, ob du ihn vollständig kopiert hast.'}; }},
        {t:'Abbrechen'}]);
    }, 'wide'));
    b.appendChild(btn('↩️ Sicherheitskopie laden (vorletzter Stand)', () => { closePanel(); try { loadGame(localStorage.getItem(SAVE_KEY + '_bak')); toast('Sicherheitskopie geladen'); } catch (e) { toast('Keine gültige Sicherheitskopie.', 'warn'); } }, 'wide', !hasBackup()));
    b.appendChild(btn('📂 Letzten Spielstand laden', () => { closePanel(); loadGame(); toast('Geladen'); }, 'wide', !hasSave()));
    b.appendChild(btn('⛶ Vollbild', () => { try { document.documentElement.requestFullscreen(); } catch (e) {} }, 'wide'));
    b.appendChild(btn('🏠 Zum Hauptmenü', () => { saveGame(true); closePanel(); G.running = false; $('hud').classList.add('hidden'); showTitle(); playMusic('title'); }, 'wide'));
    b.appendChild(el('p', 'hint', 'Das Spiel speichert automatisch alle 90 Sekunden und beim Schlafen. Tag ' + G.day + ', ' + clock() + ' Uhr.'));
  } else {
    b.appendChild(el('div', 'help', `<b>Steuerung</b><br>Linker Daumen: bewegen. ⚔️ Angriff (halten = Dauerangriff, zielt automatisch). Die drei runden Knöpfe sind deine Fähigkeiten. ✋ Aktion: sprechen, Bäume fällen, Erz abbauen, Kräuter sammeln, Truhen öffnen, Tiere zähmen. 🧪 trinkt den besten Heiltrank. 🐎 auf- und absitzen.<br><br>
    <b>Tastatur</b> (zum Testen am PC): WASD, Leertaste, E, 1–3, Q Trank, R Reiten, I Inventar, M Karte.<br><br>
    <b>Tipps</b><br>• Gegner holen vor dem Schlag aus (roter Kreis) – weich rechtzeitig aus!<br>• Namensfarbe zeigt die Gefahr: grau = leicht, orange = stärker als du, rot = sehr gefährlich.<br>• Gezähmte Tiere bekommen Namen, steigen mit dir auf und tragen Panzer und Sattel (🐾 im Gruppenmenü).<br>• Verletzte oder bewusstlose Tiere fütterst du mit Fleisch (Pflanzenfresser mit Kräutern) – einfach danebenstellen und ✋ drücken.<br>• Am Anfang hast du nur ein Messer. Kampf, Bogen, Magie und Heilung lernst du bei Lehrmeistern (siehe ⭐ Fähigkeiten).<br>• Axt und Spitzhacke gibt’s bei Baldur.<br>• Türen betrittst du, indem du hineinläufst oder ✋ drückst.<br>• Bogenschützen brauchen Pfeile – kaufen oder aus Holz und Stein herstellen. Größere Köcher fassen mehr.<br>• Größere Rucksäcke stellst du aus Leder her (Fell → Leder).<br>• Nachts ist es gefährlicher, aber Taschendiebstahl klappt besser.<br>• Deine Entscheidungen verändern, wie Leute auf dich reagieren.<br>• Halte die Augen offen: Händler, Fremde, Sternschnuppen und Truhen tauchen unterwegs auf.`));
  }
}
// ---------- HUD ----------
function showGameUI() { $('title').classList.add('hidden'); $('create').classList.add('hidden'); $('death').classList.add('hidden'); $('hud').classList.remove('hidden'); updateHUD(); }
// ---------- Stärkungen & Schwächungen ----------
const BUFF_INFO = {
  schrei:{n:'Kriegsschrei', d:'+35 % Schaden', img:() => skillCanvas('schrei')},
  segen:{n:'Segen', d:'Regeneration und +10 Rüstung', img:() => skillCanvas('segen')},
  held:{n:'Heldenmahl', d:'Alle Werte +3, +20 % Schaden und Rüstung', img:() => iconCanvas('festmahl')},
  satt:{n:'Satt', d:'Leben regeneriert schneller', img:() => iconCanvas('eintopf')},
  mut:{n:'Angeheitert', d:'Flirten fällt leichter', img:() => iconCanvas('bier')},
  verliebt:{n:'Verliebt', d:'+10 % Erfahrung', img:() => iconCanvas('blume')},
  gift:{n:'Vergiftet', d:'Verliert jede Sekunde Leben. Heiltrank oder Heilung hilft.', bad:true, img:() => skillCanvas('gift')},
  fluch:{n:'Verflucht', d:'Deine Angriffe machen 25 % weniger Schaden.', bad:true, img:() => iconCanvas('schattenkristall')},
  potcd:{n:'Trank-Pause', d:'Du kannst gerade keinen weiteren Trank trinken.', bad:true, img:() => iconCanvas('heiltrank')}
};
const BUFF_URL = {};
function fmtDur(s) { s = Math.ceil(s); return s >= 60 ? Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') : s + 's'; }
function updateBuffs() {
  const box = $('buffs'), act = Object.keys(P.buffs).filter(k => BUFF_INFO[k] && P.buffs[k] > 0);
  if (P.potCd > 0) act.push('potcd');
  const sig = act.join(',');
  if (box._sig !== sig) {
    box._sig = sig; box.innerHTML = '';
    for (const k of act) {
      const bi = BUFF_INFO[k]; if (!BUFF_URL[k]) BUFF_URL[k] = bi.img().toDataURL();
      const c = el('div', 'bf ' + (bi.bad ? 'bad' : 'good'), '<img class="pix" src="' + BUFF_URL[k] + '"><span></span>');
      c.addEventListener('click', () => toast((bi.bad ? '⬇️ ' : '⬆️ ') + bi.n + ': ' + bi.d));
      c.dataset.k = k; box.appendChild(c);
    }
  }
  for (const c of box.children) { const k = c.dataset.k, v = k === 'potcd' ? P.potCd : P.buffs[k]; c.lastChild.textContent = fmtDur(v); c.classList.toggle('ending', v < 4); }
  const st = $('stats'); box.style.top = (st.offsetTop + st.offsetHeight + 6) + 'px';
}
function updateHUD() {
  updateBuffs();
  const st = G.st || stats();
  $('h-name').textContent = P.name + ' · Stufe ' + P.lvl + (P.attrPts || P.skillPts ? ' ✦' : '');
  $('b-hp').style.width = (P.hp / st.maxHp * 100) + '%'; $('t-hp').textContent = Math.ceil(P.hp) + '/' + st.maxHp;
  $('b-en').style.width = (P.en / st.maxEn * 100) + '%'; $('t-en').textContent = Math.floor(P.en) + '/' + st.maxEn;
  $('b-xp').style.width = (P.xp / xpNeed(P.lvl) * 100) + '%';
  $('h-info').textContent = fmt(P.gold) + ' Gold' + (quiverCap() ? ' · 🪶 ' + P.arrows : '') + ' · Tag ' + G.day + ' · ' + clock() + (isNight() ? ' 🌙' : ' ☀️');
  $('h-region').textContent = REGION_INFO[G.region] ? REGION_INFO[G.region].name : '';
  for (let k = 0; k < 3; k++) {
    const id = P.slots[k], b = $('b-s' + k);
    if (!id) { if (b._h !== '') { b._h = ''; b.innerHTML = ''; } b.classList.add('empty'); continue; }
    b.classList.remove('empty');
    const cd = P.cds[id] || 0, sk = SKILLS[id];
    const h = sk.icon + (cd > 0 ? '<em>' + Math.ceil(cd) + '</em>' : ''); if (b._h !== h) { b._h = h; b.innerHTML = h; }
    b.classList.toggle('noen', P.en < skillCost(id));
  }
  const wid = P.eq.waffe ? P.eq.waffe.id : 'fist', atk = $('b-atk');
  if (atk._w !== wid) { atk._w = wid; atk.innerHTML = P.eq.waffe ? '<img class="pix" src="' + iconURL(wid) + '">' : '👊'; }
  const it = G.inter, ab = $('b-act');
  ab.innerHTML = (it ? it.icon : '✋') + '<small>' + (it ? it.label : 'Aktion') + '</small>'; ab.classList.toggle('dim', !it);
  const pots = countItem('grheiltrank') + countItem('heiltrank'); $('pot-n').textContent = pots || '';
  $('b-ride').classList.toggle('hidden', P.mount < 0); $('b-ride').classList.toggle('on', P.mounted);
  const boss = G.enemies.find(e => e.boss && !e.dead && dist(e.x, e.y, P.x, P.y) < 16);
  const bb = $('bossbar');
  if (boss) { bb.classList.remove('hidden'); $('boss-name').textContent = boss.def.name; $('boss-fill').style.width = (boss.hp / boss.maxHp * 100) + '%'; } else bb.classList.add('hidden');
  const tq = trackedQuest(), tk = $('tracker');
  if (tq && !UI.panel) { tk.classList.remove('hidden'); const q = getQ(tq); const n = Object.keys(P.q).filter(questActive).length; tk.innerHTML = '<b>' + (q.main ? '👑 ' : '📜 ') + q.name + '</b><span>' + questSub(tq) + '</span>' + (n > 1 ? '<i>+' + (n - 1) + ' weitere</i>' : ''); }
  else tk.classList.add('hidden');
  const wb = $('workbar'); if (P.work) { wb.classList.remove('hidden'); wb.firstChild.style.width = (P.work.t / P.work.dur * 100) + '%'; } else wb.classList.add('hidden');
}
// ---------- Karte ----------
function buildMapCanvas() {
  G.mapC = mkCanvas(MW, WORLD_H); const x = G.mapC.getContext('2d');
  G.mapImg = x.createImageData(MW, WORLD_H); G.mapDirty = true;
  for (let i = 0; i < MW * WORLD_H; i++) if (G.explored[i]) setMapPx(i); else { G.mapImg.data[i * 4 + 3] = 0; }
}
function setMapPx(i) {
  const t = WT[i] === TL.CHEST ? WG[i] : WT[i], c = TILE_COLORS[t], d = G.mapImg.data;
  d[i * 4] = parseInt(c.slice(1, 3), 16); d[i * 4 + 1] = parseInt(c.slice(3, 5), 16); d[i * 4 + 2] = parseInt(c.slice(5, 7), 16); d[i * 4 + 3] = 255;
}
function flushMap() { if (G.mapDirty) { G.mapC.getContext('2d').putImageData(G.mapImg, 0, 0); G.mapDirty = false; } }
function revealAround() {
  if (P.y >= WORLD_H) return;
  const r = P.race === 'elf' ? 11 : 9, px = Math.floor(P.x), py = Math.floor(P.y);
  for (let y = py - r; y <= py + r; y++) for (let x = px - r; x <= px + r; x++) {
    if (!inb(x, y) || y >= WORLD_H || (x - px) * (x - px) + (y - py) * (y - py) > r * r) continue;
    const i = idx(x, y); if (!G.explored[i]) { G.explored[i] = 1; setMapPx(i); G.mapDirty = true; }
  }
}
function drawMinimap() {
  flushMap(); const c = $('minimap'), x = c.getContext('2d'); x.imageSmoothingEnabled = false;
  x.fillStyle = '#1a140e'; x.fillRect(0, 0, 120, 120);
  const pp = worldPosOf([P.x, P.y]);
  x.drawImage(G.mapC, pp[0] - 20, pp[1] - 20, 40, 40, 0, 0, 120, 120);
  for (const p of questTargets(trackedQuest())) { const dx = (p[0] - pp[0] + 20) * 3, dy = (p[1] - pp[1] + 20) * 3; x.fillStyle = '#ffd23a'; x.fillRect(clamp(dx, 3, 114) - 3, clamp(dy, 3, 114) - 3, 6, 6); }
  x.fillStyle = '#fff'; x.fillRect(57, 57, 6, 6); x.strokeStyle = '#c00'; x.lineWidth = 2; x.strokeRect(57, 57, 6, 6);
}
// ---------- Titel & Charaktererstellung ----------
const CC = {name:'', race:'mensch', cls:'krieger', gender:'m', hair:'#5a3a1a', discs:['kampf', 'magie']};
const HAIRS = ['#1a1a1a', '#5a3a1a', '#a34a1f', '#e8d070', '#d8d8d8', '#6a2a8a'];
function showTitle() {
  $('title').classList.remove('hidden'); $('create').classList.add('hidden');
  $('t-cont').disabled = !hasSave();
}
function showCreate() { $('title').classList.add('hidden'); $('create').classList.remove('hidden'); renderCreate(); }
function renderCreate() {
  const opt = (box, list, cur, set) => { const b = $(box); b.innerHTML = ''; list.forEach(([k, label, sub]) => { const e = el('button', 'card' + (cur === k ? ' on' : ''), '<b>' + label + '</b>' + (sub ? '<small>' + sub + '</small>' : '')); e.onclick = () => { set(k); renderCreate(); }; b.appendChild(e); }); };
  opt('c-gender', [['m', 'Männlich'], ['w', 'Weiblich']], CC.gender, v => CC.gender = v);
  opt('c-race', Object.keys(RACES).map(k => [k, RACES[k].name, RACES[k].desc]), CC.race, v => CC.race = v);
  opt('c-class', Object.keys(CLASSES).map(k => [k, CLASSES[k].name]), CC.cls, v => CC.cls = v);
  const hb = $('c-hair'); hb.innerHTML = '';
  HAIRS.forEach(h => { const e = el('button', 'sw' + (CC.hair === h ? ' on' : '')); e.style.background = h; e.onclick = () => { CC.hair = h; renderCreate(); }; hb.appendChild(e); });
  const hy = $('c-hybrid'); hy.innerHTML = '';
  if (CC.cls === 'hybrid') {
    hy.appendChild(el('div', 'lbl', 'Wähle genau zwei Disziplinen:'));
    Object.keys(DISC).forEach(d => { const on = CC.discs.includes(d); const e = el('button', 'card small' + (on ? ' on' : ''), DISC[d].icon + ' ' + DISC[d].name); e.onclick = () => { if (on) CC.discs = CC.discs.filter(x => x !== d); else { CC.discs.push(d); if (CC.discs.length > 2) CC.discs.shift(); } renderCreate(); }; hy.appendChild(e); });
    const names = {'kampf+magie':'Kampfmagier', 'kampf+bogen':'Waldläufer', 'kampf+heil':'Paladin', 'magie+bogen':'Arkanschütze', 'magie+heil':'Druide', 'bogen+heil':'Wildhüter'};
    const key = Object.keys(DISC).filter(d => CC.discs.includes(d)).join('+');
    if (names[key]) hy.appendChild(el('div', 'lbl', '→ ' + names[key]));
  }
  const cl = CLASSES[CC.cls], rc = RACES[CC.race];
  $('c-desc').innerHTML = '<b>' + cl.name + ':</b> ' + cl.desc + '<br><b>' + rc.name + ':</b> ' + rc.trait + '<br><i>Deine Klasse bestimmt dein Talent. Alle beginnen mit einem rostigen Messer – Kampfkunst, Bogen, Magie und Heilung lernst du erst bei Lehrmeistern.</i>';
  drawPreview();
}
function drawPreview() {
  const cl = CLASSES[CC.cls], rc = RACES[CC.race];
  const pv = $('c-prev'), x = pv.getContext('2d'); x.imageSmoothingEnabled = false; x.clearRect(0, 0, pv.width, pv.height);
  const as = ARMOR_STYLE[(cl.start && cl.start.ruestung) || 'lumpen'] || ['cloth'];
  const spr = makeHumanoid({skin:rc.skin, hair:CC.hair, outfit:ARMOR_COLOR[(cl.start && cl.start.ruestung) || 'lumpen'] || cl.outfit, pants:cl.outfit2, female:CC.gender === 'w', style:as[0], ears:CC.race === 'elf', beard:CC.race === 'zwerg' && CC.gender === 'm', jewel:CC.gender === 'w'});
  x.drawImage(spr[Math.floor(Date.now() / 400) % 2], 0, 0, 16, 24, 28, 2, 80, 120);
}
function finishCreate() {
  CC.name = $('c-name').value.trim() || pick(['Finn', 'Mara', 'Tobin', 'Elsa', 'Rook', 'Kira']);
  if (CC.cls === 'hybrid' && CC.discs.length !== 2) { alert('Bitte genau zwei Disziplinen wählen.'); return; }
  startNewGame({name:CC.name, race:CC.race, cls:CC.cls, gender:CC.gender, hair:CC.hair, discs:CC.discs.slice()});
}
// ---------- Eingabe ----------
function initInput() {
  const ua = () => { audioInit(); if (!G.running) playMusic('title'); };
  document.addEventListener('pointerdown', ua); document.addEventListener('keydown', ua);
  const joy = $('joy'), knob = $('joy-knob'), base = $('joy-base');
  let jid = null, cx = 0, cy = 0;
  joy.addEventListener('pointerdown', e => {
    if (jid !== null) return; jid = e.pointerId; joy.setPointerCapture(e.pointerId);
    cx = e.clientX; cy = e.clientY; base.style.left = (cx - 60) + 'px'; base.style.top = (cy - 60) + 'px'; base.classList.add('on');
  });
  joy.addEventListener('pointermove', e => {
    if (e.pointerId !== jid) return;
    let dx = e.clientX - cx, dy = e.clientY - cy; const l = Math.hypot(dx, dy), m = 50;
    if (l > m) { dx = dx / l * m; dy = dy / l * m; }
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    G.joy.x = dx / m; G.joy.y = dy / m;
  });
  const up = e => { if (e.pointerId !== jid) return; jid = null; G.joy.x = 0; G.joy.y = 0; knob.style.transform = ''; base.classList.remove('on'); };
  joy.addEventListener('pointerup', up); joy.addEventListener('pointercancel', up);
  const hold = (id, down, upf) => { const b = $(id); b.addEventListener('pointerdown', e => { e.preventDefault(); down(); }); if (upf) { b.addEventListener('pointerup', upf); b.addEventListener('pointerleave', upf); b.addEventListener('pointercancel', upf); } };
  hold('b-atk', () => { G.atkHeld = true; }, () => { G.atkHeld = false; });
  hold('b-act', () => doAction());
  hold('b-pot', () => quickPotion());
  hold('b-ride', () => toggleRide());
  [0, 1, 2].forEach(k => hold('b-s' + k, () => castSkill(k)));
  document.querySelectorAll('#menubtns button').forEach(b => { b.innerHTML = '<img class="pix" src="' + menuIconURL(b.dataset.p) + '" alt="">'; b.addEventListener('click', () => openPanel(b.dataset.p)); });
  $('pclose').onclick = closePanel;
  $('respawnbtn').onclick = () => { $('death').classList.add('hidden'); G.paused = false; respawn(); };
  window.addEventListener('keydown', e => {
    G.keys[e.key.toLowerCase()] = true;
    if (!G.running || P.dead) return;
    if (UI.panel || !$('dialog').classList.contains('hidden')) { if (e.key === 'Escape') { if (UI.panel) closePanel(); else closeDialog(); } return; }
    const k = e.key.toLowerCase();
    if (k === ' ') G.atkHeld = true; if (k === 'e') doAction(); if (k === 'q') quickPotion(); if (k === 'r') toggleRide();
    if (k === '1' || k === '2' || k === '3') castSkill(+k - 1);
    if (k === 'i') openPanel('inv'); if (k === 'm') openPanel('map'); if (k === 'c') openPanel('char'); if (k === 'j') openPanel('quest');
  });
  window.addEventListener('keyup', e => { G.keys[e.key.toLowerCase()] = false; if (e.key === ' ') G.atkHeld = false; });
  $('tracker').onclick = () => openPanel('quest');
  $('pot-ic').src = iconURL('heiltrank');
  $('t-new').onclick = showCreate;
  $('t-cont').onclick = () => {
    try { loadGame(); }
    catch (err) {
      console.error(err);
      if (hasBackup()) { try { loadGame(localStorage.getItem(SAVE_KEY + '_bak')); toast('Der letzte Spielstand war beschädigt – die Sicherheitskopie wurde geladen.', 'warn'); return; } catch (e2) {} }
      alert('Spielstand konnte nicht geladen werden.');
    }
  };
  $('c-start').onclick = finishCreate;
  $('c-back').onclick = showTitle;
  setInterval(() => { if (!$('create').classList.contains('hidden')) drawPreview(); }, 400);
}
