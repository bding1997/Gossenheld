'use strict';
// ================= HAUPTSCHLEIFE & ZEICHNEN =================
const canvas = $('game'), ctx = canvas.getContext('2d');
function resize() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.floor(innerWidth * dpr); canvas.height = Math.floor(innerHeight * dpr);
  G.scale = Math.max(2, Math.round(canvas.height / (16 * 13)));
}
window.addEventListener('resize', resize); resize();

function update(dt) {
  G.t += dt; G.time += dt;
  if (G.time >= DAY_LEN) { G.time -= DAY_LEN; G.day++; newDay(); }
  G.st = stats(); const st = G.st;
  for (const k in P.buffs) { P.buffs[k] -= dt; if (P.buffs[k] <= 0) delete P.buffs[k]; }
  for (const k in P.cds) { P.cds[k] -= dt; if (P.cds[k] <= 0) delete P.cds[k]; }
  P.atkCd -= dt; if (P.potCd > 0) P.potCd -= dt; if (P.invuln > 0) P.invuln -= dt; if (P.swing > 0) P.swing -= dt; if (P.spin > 0) P.spin -= dt; if (P.hitT > 0) P.hitT -= dt;
  if (P.dead) return;
  // Bewegung
  let mx = G.joy.x, my = G.joy.y;
  if (G.keys.w || G.keys.arrowup) my = -1; if (G.keys.s || G.keys.arrowdown) my = 1;
  if (G.keys.a || G.keys.arrowleft) mx = -1; if (G.keys.d || G.keys.arrowright) mx = 1;
  const ml = Math.hypot(mx, my); if (ml > 1) { mx /= ml; my /= ml; }
  P.moving = false;
  if (P.dash) {
    moveEnt(P, P.dash.vx * dt, P.dash.vy * dt); P.dash.t -= dt;
    if (P.dash.dmg) for (const e of G.enemies) if (!e.dead && !P.dash.hit.includes(e) && dist(P.x, P.y, e.x, e.y) < 1.2) { P.dash.hit.push(e); dealDmg(e, P.dash.dmg, {src:'p', kb:1.2}); }
    if (P.dash.t <= 0) P.dash = null;
  } else if (Math.hypot(mx, my) > 0.15) {
    if (P.work) P.work = null;
    const sp = st.speed * (P.mounted && P.pets[P.mount] ? mountSpeed(P.pets[P.mount]) : 1) * Math.min(1, Math.hypot(mx, my) * 1.3);
    if (moveEnt(P, mx * sp * dt, my * sp * dt)) P.moving = true;
    if (P.moving && P.mounted && P.mount >= 0) { P.rideXp = (P.rideXp || 0) + dt * 0.6; if (P.rideXp >= 5) { gainPetXp(P.mount, Math.floor(P.rideXp)); P.rideXp = 0; } }
    // Gegen eine Tür laufen = eintreten
    if (my < -0.5 && tileAt(P.x, P.y - 0.55) === TL.DOOR) { P.doorPush = (P.doorPush || 0) + dt; if (P.doorPush > 0.25) { P.doorPush = 0; enterDoor(Math.floor(P.x), Math.floor(P.y - 0.55)); } } else P.doorPush = 0;
    P.face = {x:mx / (Math.hypot(mx, my)), y:my / (Math.hypot(mx, my))}; if (Math.abs(mx) > 0.1) P.dir = mx < 0 ? -1 : 1;
  }
  if (P.work) { P.work.t += dt; if (P.work.t >= P.work.dur) finishWork(); else { P.workSnd = (P.workSnd || 0) - dt; if (P.workSnd <= 0) { P.workSnd = 0.35; const t = tileAt(P.work.x, P.work.y); sfx(t === TL.TREE || t === TL.PINE || t === TL.DEADTREE ? 'chop' : HARVEST[t] && HARVEST[t].tool ? 'mine' : 'gather'); } } }
  if (tileAt(P.x, P.y) === TL.EXIT) exitInterior();
  if (G.atkHeld) attack();
  // Regeneration
  P.en = Math.min(st.maxEn, P.en + dt * (1.5 + st.wis * 0.12));
  let rg = 0; if (G.t - P.lastHit > 8) rg += 0.007; if (P.buffs.satt) rg += 0.01; if (P.buffs.segen) rg += 0.02;
  P.hp = Math.min(st.maxHp, P.hp + st.maxHp * rg * dt);
  // Welt
  for (const e of G.enemies) if (!e.dead) updEnemy(e, dt);
  G.enemies = G.enemies.filter(e => !e.dead && (e.boss || dist(e.x, e.y, P.x, P.y) < 34));
  for (const a of G.allies) updAlly(a, dt);
  for (const n of G.npcs) updNpc(n, dt);
  updProj(dt);
  for (let i = G.drops.length - 1; i >= 0; i--) {
    const d = G.drops[i]; d.t += dt;
    if (d.vz != null) { d.vz -= 9 * dt; d.z += d.vz * dt; if (d.z <= 0) { d.z = 0; d.vz = null; } }
    if (d.wait > 0) d.wait -= dt;
    const dd = dist(d.x, d.y, P.x, P.y);
    if (!P.dead && !(d.wait > 0) && d.t > 0.35 && dd < 2) {
      // Beute fliegt zum Spieler (auch aus Ecken, die man nicht erreicht)
      const sp = Math.min(dd, (3 + (2 - dd) * 4) * dt); d.x += (P.x - d.x) / (dd || 1) * sp; d.y += (P.y - d.y) / (dd || 1) * sp;
      if (dist(d.x, d.y, P.x, P.y) < 0.5 && tryPickup(d)) { G.drops.splice(i, 1); continue; }
    }
    if (d.t > 300) G.drops.splice(i, 1);
  }
  for (let i = G.fx.length - 1; i >= 0; i--) {
    const f = G.fx[i]; f.t = (f.t || 0) + dt;
    if (f.k === 'p') { f.x += f.vx * dt; f.y += f.vy * dt; f.vy += 6 * dt; }
    if (f.k === 'ring') f.r = f.max * (f.t / f.life);
    if (f.k === 'meteor' && f.t >= f.life && !f.done) { f.done = true; for (const e of G.enemies) if (!e.dead && dist(f.x, f.y, e.x, e.y) < 2.6) dealDmg(e, f.dmg, {src:'p', kb:0.8, fx:f.x, fy:f.y}); ring(f.x, f.y, 2.6, '#f80'); burst(f.x, f.y, '#fa4', 30); G.shake = 0.35; }
    if (f.k === 'rain') { f.tick -= dt; if (f.tick <= 0) { f.tick = 0.2; for (const e of G.enemies) if (!e.dead && dist(f.x, f.y, e.x, e.y) < 2.6) dealDmg(e, f.dmg * 0.45, {src:'p'}); } }
    if (f.t >= (f.life || 0.5) + (f.k === 'meteor' ? 0.05 : 0)) G.fx.splice(i, 1);
  }
  for (let i = G.texts.length - 1; i >= 0; i--) { const t = G.texts[i]; t.t += dt; t.y -= dt * 0.9; if (t.t > 1.1) G.texts.splice(i, 1); }
  if (G.shake > 0) G.shake -= dt;
  // Timer
  G.spawnT -= dt; if (G.spawnT <= 0) { G.spawnT = 1.2; spawnTick(); }
  G.bossT -= dt; if (G.bossT <= 0) { G.bossT = 1; bossTick(); }
  G.revealT -= dt; if (G.revealT <= 0) { G.revealT = 0.25; revealAround(); drawMinimap(); }
  G.interT -= dt; if (G.interT <= 0) { G.interT = 0.15; G.inter = findInteract(); }
  G.npcT -= dt; if (G.npcT <= 0) { G.npcT = 2; refreshNpcs(); }
  G.saveT += dt; if (G.saveT > 90) { G.saveT = 0; saveGame(true); }
  const reg = regionAt(P.x, P.y);
  if (reg !== G.region) { G.region = reg; if (!REGION_INFO[reg].inside) { const lv = REGION_INFO[reg].lv; toast('📍 ' + REGION_INFO[reg].name + (lv ? ' (Stufe ' + lv[0] + '–' + lv[1] + ')' : REGION_INFO[reg].safe || reg === 'gosse' ? ' – sicher' : ''), lv && lv[0] > P.lvl + 2 ? 'warn' : ''); } questEvent('goto', reg); }
  if (!REGION_INFO[reg].safe && reg !== 'gosse') { G.evT -= dt; if (G.evT <= 0) { G.evT = 45; if (chance(0.22)) randomEvent(); } }
  G.hudT -= dt; if (G.hudT <= 0) { G.hudT = 0.1; updateHUD(); }
  G.musT = (G.musT || 0) - dt; if (G.musT <= 0) { G.musT = 0.5; if (!(G.musicHold > G.t)) chooseMusic(); }
}
function updProj(dt) {
  for (const p of G.proj) {
    p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
    let boom = p.life <= 0 || PSOLID[tileAt(p.x, p.y + 0.3)];
    if (!boom && p.team === 'p') {
      for (const e of G.enemies) {
        if (e.dead || (e.def.passive && !e.flee && p.kind !== 'arrow' && p.kind !== 'poison')) {}
        if (e.dead) continue;
        if (dist(p.x, p.y, e.x, e.y - 0.4 * e.size) < p.r + 0.35 * e.size) {
          if (!p.aoe) { dealDmg(e, p.dmg, {src:'p', holy:p.holy, kb:0.15, fx:p.x - p.vx, fy:p.y - p.vy}); if (p.poison && !e.dead) e.poison = {t:6, dps:p.poison}; }
          boom = true; break;
        }
      }
    } else if (!boom) {
      for (const a of allyTargets()) if (dist(p.x, p.y, a.x, a.y - 0.4) < p.r + 0.3) { hurt(a, p.dmg); boom = true; break; }
    }
    if (boom) {
      p.dead = true;
      if (p.aoe && p.team === 'p') { for (const e of G.enemies) if (!e.dead && dist(p.x, p.y, e.x, e.y) < p.aoe) dealDmg(e, p.dmg, {src:'p', kb:0.3, fx:p.x, fy:p.y}); ring(p.x, p.y, p.aoe, '#f94'); }
      burst(p.x, p.y, PROJ_COL[p.kind] || '#fff', 5);
    }
  }
  G.proj = G.proj.filter(p => !p.dead);
}
const PROJ_COL = {arrow:'#c8a060', fire:'#ff8a20', bolt:'#b080ff', holy:'#fff27a', shadow:'#8a3ad0', poison:'#7ae040'};

// ---------- Zeichnen ----------
function tileVar(t, tx, ty, i) {
  if (t === TL.WATER || t === TL.HEARTH) return Math.floor(G.t * 3) % 4;
  if ((t === TL.ROOF || t === TL.WALL) && WV[i] !== 255) return WV[i];
  return Math.floor(hash2(tx, ty, 7) * 4);
}
function drawSprite(frames, x, y, o) {
  o = o || {}; const sz = o.size || 1, f = frames[o.frame || 0];
  const w = 16 * sz, px = x * 16, py = y * 16;
  ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(px, py, 5 * sz, 2 * sz, 0, 0, TAU); ctx.fill();
  if (o.flash && Math.floor(G.t * 30) % 2) return;
  ctx.save(); ctx.translate(px, py - (o.lift || 0));
  if (o.flip) ctx.scale(-1, 1);
  ctx.drawImage(f, -w / 2, -w + 1 * sz - (o.bob || 0), w, w);
  ctx.restore();
}
function drawWeapon(x, y, dir, wt, swing, lift) {
  const px = x * 16, py = y * 16 - 8 - (lift || 0);
  ctx.save(); ctx.translate(px, py); ctx.scale(dir, 1);
  if (wt === 'melee') { ctx.rotate(swing > 0 ? -1.2 + (0.2 - swing) * 12 : 0.5); ctx.fillStyle = '#5a3a1a'; ctx.fillRect(4, -1, 2, 3); ctx.fillStyle = '#d8dce4'; ctx.fillRect(4, -8, 2, 7); ctx.fillStyle = '#fff'; ctx.fillRect(4, -8, 1, 6); ctx.fillStyle = '#c8a040'; ctx.fillRect(3, -1, 4, 1); }
  else if (wt === 'bow') { ctx.fillStyle = '#7a4a1a'; for (let k = -5; k <= 5; k++) ctx.fillRect(6 + Math.round(2 - Math.abs(k) * 0.4), k, 1, 1); ctx.fillStyle = '#ddd'; ctx.fillRect(swing > 0 ? 4 : 5, -5, 1, 11); }
  else { ctx.fillStyle = '#6a4220'; ctx.fillRect(5, -7, 1, 13); ctx.fillStyle = swing > 0 ? '#fff' : '#7ae0ff'; ctx.fillRect(4, -9, 3, 3); }
  ctx.restore();
}
function render() {
  const cw = canvas.width, ch = canvas.height, S = G.scale;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#123'; ctx.fillRect(0, 0, cw, ch);
  if (!P) return;
  let sx = 0, sy = 0; if (G.shake > 0) { sx = rnd(-3, 3) * S; sy = rnd(-3, 3) * S; }
  const ox = Math.round(cw / 2 - P.x * 16 * S + sx), oy = Math.round(ch / 2 - (P.y - 0.4) * 16 * S + sy);
  ctx.setTransform(S, 0, 0, S, ox, oy); ctx.imageSmoothingEnabled = false;
  const x0 = Math.floor(-ox / (16 * S)) - 1, y0 = Math.floor(-oy / (16 * S)) - 1, x1 = x0 + Math.ceil(cw / (16 * S)) + 2, y1 = y0 + Math.ceil(ch / (16 * S)) + 3;
  const list = [];
  const insideR = (REGION_INFO[G.region] || {}).inside ? RIDX[G.region] : -1;
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
    if (!inb(tx, ty)) { ctx.drawImage(getTile(TL.WATER, Math.floor(G.t * 3) % 4), tx * 16, ty * 16); continue; }
    const i = idx(tx, ty), g = WG[i], t = WT[i];
    if (insideR >= 0 && WR[i] !== insideR) { ctx.drawImage(getTile(TL.VOID, 0), tx * 16, ty * 16); continue; }
    ctx.drawImage(getTile(g, tileVar(g, tx, ty, i)), tx * 16, ty * 16);
    if (t !== g) {
      if (TALL[t]) list.push({y:ty + 0.95, f:() => ctx.drawImage(getTile(t, tileVar(t, tx, ty, i)), tx * 16 - 2, ty * 16 - 12)});
      else ctx.drawImage(getTile(t, tileVar(t, tx, ty, i)), tx * 16, ty * 16);
    }
  }
  // Beute am Boden
  for (const d of G.drops) {
    const b = (d.z || 0) * 6 + Math.sin(G.t * 4 + d.x * 3) * 1.2 + 2, px = d.x * 16, py = d.y * 16;
    ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(px, py, 4, 1.6, 0, 0, TAU); ctx.fill();
    ctx.drawImage(iconCanvas(d.id), px - 6, py - 12 - b, 12, 12);
    if (Math.floor(G.t * 2 + d.x * 5) % 4 === 0) { ctx.fillStyle = '#fff6b0'; ctx.fillRect(px + 4, py - 13 - b, 1, 1); }
    if (d.n > 1) { ctx.font = 'bold 4px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 1.2; ctx.strokeStyle = '#000'; ctx.strokeText(d.n, px + 5, py - 1 - b); ctx.fillStyle = '#fff'; ctx.fillText(d.n, px + 5, py - 1 - b); }
  }
  const anim = Math.floor(G.t * 7) % 2;
  const vis = e => insideR < 0 || WR[idx(Math.floor(e.x), Math.floor(e.y))] === insideR;
  for (const n of G.npcs) if (vis(n)) list.push({y:n.y, f:() => {
    drawSprite(n.spr, n.x, n.y, {frame:n.moving ? anim : 0, flip:n.dir < 0});
    const m = G.marks[n.id];
    ctx.font = 'bold 5px sans-serif'; ctx.textAlign = 'center';
    if (m) { const b = Math.sin(G.t * 5) * 1.5; ctx.fillStyle = '#000'; ctx.fillText(m, n.x * 16 + 0.5, n.y * 16 - 19 + b + 0.5); ctx.fillStyle = m === '!' ? '#ffd23a' : '#9fe0ff'; ctx.font = 'bold 9px sans-serif'; ctx.fillText(m, n.x * 16, n.y * 16 - 18 + b); }
    if (dist(n.x, n.y, P.x, P.y) < 5) { ctx.font = '4px sans-serif'; ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,.8)'; ctx.strokeText(n.def.name, n.x * 16, n.y * 16 - 16.5); ctx.fillStyle = '#f6e7c1'; ctx.fillText(n.def.name, n.x * 16, n.y * 16 - 16.5); }
  }});
  for (const e of G.enemies) list.push({y:e.y, f:() => {
    if (e.wind > 0) { ctx.fillStyle = 'rgba(255,60,40,' + (0.25 + 0.35 * (1 - e.wind / 0.38)) + ')'; ctx.beginPath(); ctx.ellipse(e.x * 16, e.y * 16, 7 * e.size, 3 * e.size, 0, 0, TAU); ctx.fill(); }
    drawSprite(e.spr, e.x, e.y, {size:e.size, frame:e.moving ? anim : 0, flip:e.dir < 0, flash:e.hitT > 0, bob:e.atk > 0 ? 2 : 0, lift:e.wind > 0 ? 1.5 : 0});
    if (!e.boss && dist(e.x, e.y, P.x, P.y) < 7) {
      const g = lvlGap(e), col = e.def.passive ? '#bfe8a0' : g >= 4 ? '#ff5a4a' : g >= 2 ? '#ffa040' : g <= -4 ? '#9a9a9a' : '#f6e7c1';
      const lab = e.def.name + ' · St. ' + e.lvl;
      ctx.font = '4px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,.85)';
      const ty = e.y * 16 - 16 * e.size - (e.hp < e.maxHp ? 5 : 2);
      ctx.strokeText(lab, e.x * 16, ty); ctx.fillStyle = col; ctx.fillText(lab, e.x * 16, ty);
    }
    if (e.poison) { ctx.fillStyle = 'rgba(120,230,60,.6)'; ctx.fillRect(e.x * 16 - 1, e.y * 16 - 16 * e.size - 2, 2, 2); }
    if (e.slow > 0) { ctx.fillStyle = 'rgba(140,200,255,.35)'; ctx.fillRect(e.x * 16 - 6 * e.size, e.y * 16 - 14 * e.size, 12 * e.size, 13 * e.size); }
    if (e.hp < e.maxHp && !e.boss) { const w = 14; ctx.fillStyle = '#000'; ctx.fillRect(e.x * 16 - w / 2 - 0.5, e.y * 16 - 16 * e.size - 3.5, w + 1, 2.5); ctx.fillStyle = e.def.passive ? '#e8c040' : '#d33'; ctx.fillRect(e.x * 16 - w / 2, e.y * 16 - 16 * e.size - 3, w * e.hp / e.maxHp, 1.5); }
    if (e.def.tame && P.learned.zaehmen && (e.def.passive || e.hp < e.maxHp * 0.35)) { ctx.font = '6px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('🐾', e.x * 16, e.y * 16 - 16 * e.size - 5); }
  }});
  for (const a of G.allies) list.push({y:a.y, f:() => {
    ctx.globalAlpha = a.down ? 0.45 : 1;
    drawSprite(a.spr, a.x, a.y, {size:a.size, frame:a.moving ? anim : 0, flip:a.dir < 0, flash:a.hitT > 0, bob:a.atk > 0 ? 1.5 : 0});
    if (a.kind === 'pet') { const lab = a.name + ' · St. ' + (a.lvl || 1); ctx.font = '4px sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,.85)'; const ty = a.y * 16 - 17 * a.size - 5; ctx.strokeText(lab, a.x * 16, ty); ctx.fillStyle = petTier(a.lvl || 1) >= 3 ? '#ffe070' : '#a8f0a0'; ctx.fillText(lab, a.x * 16, ty);
      if (petTier(a.lvl || 1) >= 3 && !a.down) { ctx.globalAlpha = 0.18 + Math.sin(G.t * 3) * 0.08; ctx.fillStyle = '#ffe070'; ctx.beginPath(); ctx.ellipse(a.x * 16, a.y * 16 - 5 * a.size, 9 * a.size, 7 * a.size, 0, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; } }
    if (a.down && a.kind === 'pet') { ctx.font = '7px sans-serif'; ctx.textAlign = 'center'; ctx.globalAlpha = 0.6 + Math.sin(G.t * 5) * 0.4; ctx.fillText('💔', a.x * 16, a.y * 16 - 18 * a.size); }
    ctx.globalAlpha = 1;
    if (a.kind === 'comp' && !a.down) drawWeapon(a.x, a.y, a.dir || 1, {melee:'melee', arrow:'bow', magic:'staff', heal:'staff'}[a.style], 0);
    const w = 12; ctx.fillStyle = '#000'; ctx.fillRect(a.x * 16 - w / 2 - 0.5, a.y * 16 - 17 * a.size - 3.5, w + 1, 2.5); ctx.fillStyle = '#4c4'; ctx.fillRect(a.x * 16 - w / 2, a.y * 16 - 17 * a.size - 3, w * a.hp / a.maxHp, 1.5);
  }});
  list.push({y:P.y, f:() => {
    const w = weaponDef(), lift = P.mounted ? 6 : 0;
    if (P.mounted && P.pets[P.mount]) { const pt = P.pets[P.mount]; drawSprite(petSprite(pt), P.x, P.y + 0.15, {size:petSize(pt), frame:P.moving ? anim : 0, flip:P.dir < 0}); }
    if (P.spin > 0) { ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(P.x * 16, P.y * 16 - 6, 22 * (1 - P.spin / 0.3) + 6, 0, TAU); ctx.stroke(); }
    drawSprite(G.pspr, P.x, P.y, {frame:P.moving && !P.mounted ? anim : 0, flip:P.dir < 0, flash:P.hitT > 0 || P.invuln > 0.1, lift, bob:P.work ? Math.abs(Math.sin(G.t * 12)) * 1.5 : 0});
    if (w) drawWeapon(P.x, P.y, P.dir, w.wt, P.swing || (P.work ? Math.abs(Math.sin(G.t * 12)) * 0.2 : 0), lift);
  }});
  list.sort((a, b) => a.y - b.y);
  for (const o of list) o.f();
  // Geschosse
  for (const p of G.proj) {
    const c = PROJ_COL[p.kind] || '#fff';
    if (p.kind === 'arrow' || p.kind === 'poison') { const a = Math.atan2(p.vy, p.vx); ctx.save(); ctx.translate(p.x * 16, p.y * 16); ctx.rotate(a); ctx.fillStyle = '#6a4a2a'; ctx.fillRect(-5, -0.5, 8, 1); ctx.fillStyle = p.kind === 'poison' ? c : '#ddd'; ctx.fillRect(3, -1, 2, 2); ctx.fillStyle = '#eee'; ctx.fillRect(-6, -1, 2, 2); ctx.restore(); }
    else { ctx.fillStyle = c; ctx.globalAlpha = 0.35; ctx.beginPath(); ctx.arc(p.x * 16, p.y * 16, p.kind === 'fire' ? 5 : 4, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(p.x * 16, p.y * 16, 2.2, 0, TAU); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(p.x * 16 - 0.5, p.y * 16 - 0.5, 1, 1); }
  }
  for (const f of G.fx) {
    const life = f.life || 0.5, k = 1 - (f.t || 0) / life;
    if (f.k === 'p') { ctx.globalAlpha = Math.max(0, k); ctx.fillStyle = f.col; ctx.fillRect(f.x * 16, f.y * 16, f.sz, f.sz); }
    else if (f.k === 'ring') { ctx.globalAlpha = Math.max(0, k); ctx.strokeStyle = f.col; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(f.x * 16, f.y * 16, f.r * 16, f.r * 10, 0, 0, TAU); ctx.stroke(); }
    else if (f.k === 'line') { ctx.globalAlpha = Math.max(0, k); ctx.strokeStyle = f.col; ctx.lineWidth = 1.5; ctx.beginPath(); f.pts.forEach((q, j) => { const jx = q[0] * 16 + (j ? rnd(-2, 2) : 0), jy = q[1] * 16 + (j ? rnd(-2, 2) : 0); j ? ctx.lineTo(jx, jy) : ctx.moveTo(jx, jy); }); ctx.stroke(); }
    else if (f.k === 'meteor') { const tt = Math.min(1, f.t / f.life); ctx.globalAlpha = 0.4; ctx.strokeStyle = '#f84'; ctx.beginPath(); ctx.ellipse(f.x * 16, f.y * 16, 40, 25, 0, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; ctx.fillStyle = '#ffa030'; ctx.beginPath(); ctx.arc(f.x * 16 + (1 - tt) * 60, f.y * 16 - (1 - tt) * 120, 6, 0, TAU); ctx.fill(); }
    else if (f.k === 'rain') { ctx.fillStyle = '#ddd'; for (let j = 0; j < 8; j++) { const rx = f.x + rnd(-2.5, 2.5), ry = f.y + rnd(-2, 2); ctx.fillRect(rx * 16, ry * 16 - 6, 1, 5); } }
    ctx.globalAlpha = 1;
  }
  // Nacht
  const h = hour(); let dark = 0;
  if (h >= 19 && h < 21) dark = (h - 19) / 2; else if (h >= 21 || h < 4.5) dark = 1; else if (h >= 4.5 && h < 6.5) dark = 1 - (h - 4.5) / 2;
  if (G.region === 'morvath' || G.region === 'festung') dark = Math.max(dark, 0.35);
  if ((REGION_INFO[G.region] || {}).inside) dark = 0;
  if (G.region === 'sumpf' || G.region === 'hexe') dark = Math.max(dark, 0.2);
  if (dark > 0) {
    if (!G.nightC || G.nightC.width !== cw || G.nightC.height !== ch) G.nightC = mkCanvas(cw, ch);
    const n = G.nightC.getContext('2d');
    n.globalCompositeOperation = 'source-over'; n.clearRect(0, 0, cw, ch);
    n.fillStyle = 'rgba(8,12,40,' + (0.62 * dark) + ')'; n.fillRect(0, 0, cw, ch);
    n.globalCompositeOperation = 'destination-out';
    const light = (wx, wy, r) => { const sxp = wx * 16 * S + ox, syp = wy * 16 * S + oy, gr = n.createRadialGradient(sxp, syp, 0, sxp, syp, r * S * 16); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); n.fillStyle = gr; n.beginPath(); n.arc(sxp, syp, r * S * 16, 0, TAU); n.fill(); };
    light(P.x, P.y - 0.5, 4.5);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (inb(tx, ty) && WT[idx(tx, ty)] === TL.HEARTH) light(tx + 0.5, ty + 0.5, 4);
    for (const p of G.proj) if (p.kind !== 'arrow') light(p.x, p.y, 1.5);
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(G.nightC, 0, 0);
    ctx.setTransform(S, 0, 0, S, ox, oy);
  }
  // Schwebende Zahlen
  ctx.textAlign = 'center';
  for (const t of G.texts) {
    ctx.globalAlpha = Math.max(0, Math.min(1, 2.2 - t.t * 2)); ctx.font = 'bold ' + (t.big ? 8 : 6) + 'px sans-serif'; ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(0,0,0,.85)';
    const tx = t.img ? t.x * 16 - 5 : t.x * 16;
    ctx.strokeText(t.txt, tx, t.y * 16); ctx.fillStyle = t.col; ctx.fillText(t.txt, tx, t.y * 16);
    if (t.img) ctx.drawImage(t.img, tx + 3, t.y * 16 - 8, 10, 10);
  }
  ctx.globalAlpha = 1;
  if (P.hp < G.st.maxHp * 0.25 && !P.dead) { ctx.setTransform(1, 0, 0, 1, 0, 0); const g = ctx.createRadialGradient(cw / 2, ch / 2, ch * 0.3, cw / 2, ch / 2, ch * 0.8); g.addColorStop(0, 'rgba(160,0,0,0)'); g.addColorStop(1, 'rgba(160,0,0,' + (0.25 + Math.sin(G.t * 6) * 0.1) + ')'); ctx.fillStyle = g; ctx.fillRect(0, 0, cw, ch); }
}
let last = performance.now();
function loop(ts) {
  const dt = Math.min(0.05, (ts - last) / 1000); last = ts;
  try {
    if (G.running && !G.paused) update(dt);
    if (G.running) render();
  } catch (err) { console.error(err); if (!G.errShown) { G.errShown = true; toast('Fehler: ' + err.message, 'warn'); } }
  requestAnimationFrame(loop);
}
initInput(); showTitle();
document.addEventListener('visibilitychange', () => { if (document.hidden && G.running) saveGame(true); });
requestAnimationFrame(loop);
