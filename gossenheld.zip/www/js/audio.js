'use strict';
// ================= KLANG: Effekte & Musik (synthetisch, offline) =================
const AU = {ctx:null, master:null, sfxG:null, musG:null, noise:null, musicVol:0.35, sfxVol:0.7, track:null, pending:null, switchAt:0, step:0, nextT:0, last:{}};
try { const s = JSON.parse(localStorage.getItem('gh_audio') || '{}'); if (s.m != null) AU.musicVol = s.m; if (s.s != null) AU.sfxVol = s.s; } catch (e) {}
function audioInit() {
  if (AU.ctx) { if (AU.ctx.state === 'suspended') AU.ctx.resume(); return; }
  const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
  const c = AU.ctx = new C();
  AU.master = c.createGain(); AU.master.connect(c.destination);
  const comp = c.createDynamicsCompressor(); comp.connect(AU.master);
  AU.sfxG = c.createGain(); AU.sfxG.gain.value = AU.sfxVol; AU.sfxG.connect(comp);
  AU.musG = c.createGain(); AU.musG.gain.value = AU.musicVol; AU.musG.connect(comp);
  AU.musBus = c.createGain(); AU.musBus.gain.value = 1; AU.musBus.connect(AU.musG);
  const len = c.sampleRate; AU.noise = c.createBuffer(1, len, c.sampleRate);
  const d = AU.noise.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  AU.nextT = c.currentTime + 0.1;
  setInterval(musicTick, 40);
}
function setVolumes(m, s) {
  AU.musicVol = m; AU.sfxVol = s;
  if (AU.ctx) { AU.musG.gain.value = m; AU.sfxG.gain.value = s; }
  try { localStorage.setItem('gh_audio', JSON.stringify({m, s})); } catch (e) {}
}
const mtof = n => 440 * Math.pow(2, (n - 69) / 12);
function tone(f, dur, o) {
  o = o || {}; const c = AU.ctx, t = o.when || c.currentTime;
  const osc = c.createOscillator(), g = c.createGain();
  osc.type = o.type || 'square'; osc.frequency.setValueAtTime(f, t);
  if (o.slide) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.slide), t + dur);
  const v = o.vol == null ? 0.2 : o.vol, a = o.attack || 0.005;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  let node = osc;
  if (o.lp) { const f2 = c.createBiquadFilter(); f2.type = 'lowpass'; f2.frequency.value = o.lp; osc.connect(f2); node = f2; }
  node.connect(g); g.connect(o.dest || AU.sfxG);
  osc.start(t); osc.stop(t + dur + 0.02);
}
function noiz(dur, o) {
  o = o || {}; const c = AU.ctx, t = o.when || c.currentTime;
  const src = c.createBufferSource(); src.buffer = AU.noise;
  const f = c.createBiquadFilter(); f.type = o.ft || 'lowpass'; f.frequency.setValueAtTime(o.f || 2000, t);
  if (o.fTo) f.frequency.exponentialRampToValueAtTime(o.fTo, t + dur);
  const g = c.createGain(), v = o.vol == null ? 0.2 : o.vol;
  g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(f); f.connect(g); g.connect(o.dest || AU.sfxG);
  src.start(t, Math.random() * 0.5); src.stop(t + dur + 0.02);
}
const SFX = {
  swing:() => noiz(0.13, {ft:'bandpass', f:2500, fTo:500, vol:0.25}),
  hit:() => { tone(140, 0.09, {slide:50, vol:0.3}); noiz(0.07, {f:1800, vol:0.3}); },
  crit:() => { tone(160, 0.12, {slide:40, vol:0.35}); noiz(0.1, {f:3000, vol:0.35}); tone(1200, 0.08, {type:'triangle', vol:0.15}); },
  bow:() => { tone(320, 0.12, {type:'triangle', slide:140, vol:0.25}); noiz(0.06, {ft:'highpass', f:3000, vol:0.12}); },
  magic:() => { tone(400, 0.28, {type:'sine', slide:1300, vol:0.2}); tone(600, 0.22, {type:'triangle', slide:1800, vol:0.08}); },
  fire:() => { noiz(0.4, {f:900, fTo:200, vol:0.35}); tone(200, 0.3, {type:'sawtooth', slide:70, vol:0.1, lp:600}); },
  frost:() => { noiz(0.5, {ft:'highpass', f:4000, vol:0.2}); tone(1600, 0.4, {type:'sine', slide:800, vol:0.1}); },
  zap:() => { for (let k = 0; k < 4; k++) tone(rnd(800, 2000), 0.05, {type:'sawtooth', vol:0.12, when:AU.ctx.currentTime + k * 0.04}); },
  boom:() => { tone(90, 0.6, {type:'sine', slide:30, vol:0.5}); noiz(0.6, {f:600, fTo:80, vol:0.45}); },
  holy:() => [880, 1109, 1319].forEach((f, k) => tone(f, 0.35, {type:'sine', vol:0.12, when:AU.ctx.currentTime + k * 0.06})),
  heal:() => [523, 659, 784, 1046].forEach((f, k) => tone(f, 0.25, {type:'triangle', vol:0.13, when:AU.ctx.currentTime + k * 0.07})),
  coin:() => { tone(1320, 0.06, {vol:0.12}); tone(1760, 0.12, {vol:0.12, when:AU.ctx.currentTime + 0.06}); },
  pickup:() => tone(660, 0.1, {type:'triangle', slide:1000, vol:0.18}),
  levelup:() => [523, 659, 784, 1046, 784, 1046, 1318].forEach((f, k) => tone(f, 0.18, {type:'square', vol:0.1, lp:3000, when:AU.ctx.currentTime + k * 0.09})),
  quest:() => [784, 988, 1175, 1568].forEach((f, k) => { tone(f, 0.5, {type:'sine', vol:0.13, when:AU.ctx.currentTime + k * 0.1}); tone(f * 2, 0.3, {type:'sine', vol:0.04, when:AU.ctx.currentTime + k * 0.1}); }),
  hurt:() => tone(220, 0.16, {slide:110, vol:0.25}),
  die:() => tone(300, 1, {type:'sawtooth', slide:50, vol:0.25, lp:1200}),
  kill:() => { tone(220, 0.15, {type:'triangle', slide:60, vol:0.2}); noiz(0.1, {f:800, vol:0.15}); },
  door:() => { tone(90, 0.35, {type:'sawtooth', slide:65, vol:0.18, lp:400}); noiz(0.08, {f:500, vol:0.3, when:AU.ctx.currentTime + 0.3}); },
  craft:() => [0, 0.18].forEach(d => { tone(1250, 0.45, {type:'sine', vol:0.18, when:AU.ctx.currentTime + d}); tone(1720, 0.35, {type:'sine', vol:0.1, when:AU.ctx.currentTime + d}); noiz(0.04, {ft:'highpass', f:3000, vol:0.2, when:AU.ctx.currentTime + d}); }),
  fail:() => { tone(400, 0.15, {vol:0.15}); tone(260, 0.3, {vol:0.15, when:AU.ctx.currentTime + 0.15}); },
  click:() => tone(1100, 0.03, {type:'triangle', vol:0.08}),
  lock:() => { noiz(0.03, {ft:'highpass', f:4000, vol:0.2}); tone(2200, 0.03, {type:'triangle', vol:0.1}); },
  unlock:() => { tone(600, 0.08, {vol:0.15}); tone(900, 0.15, {vol:0.15, when:AU.ctx.currentTime + 0.08}); },
  chop:() => { noiz(0.09, {f:700, vol:0.4}); tone(160, 0.07, {type:'triangle', vol:0.25}); },
  mine:() => { tone(1900, 0.07, {type:'triangle', vol:0.15}); noiz(0.06, {ft:'highpass', f:2500, vol:0.2}); },
  gather:() => noiz(0.12, {ft:'bandpass', f:1500, vol:0.15}),
  eat:() => { for (let k = 0; k < 3; k++) noiz(0.05, {f:1200, vol:0.15, when:AU.ctx.currentTime + k * 0.09}); },
  tame:() => [660, 880, 990].forEach((f, k) => tone(f, 0.2, {type:'triangle', vol:0.14, when:AU.ctx.currentTime + k * 0.08})),
  roar:() => { tone(110, 0.9, {type:'sawtooth', slide:60, vol:0.3, lp:500}); noiz(0.9, {f:400, vol:0.25}); }
};
function sfx(name) {
  if (!AU.ctx || !SFX[name]) return;
  const now = AU.ctx.currentTime; if (AU.last[name] && now - AU.last[name] < 0.045) return; AU.last[name] = now;
  try { SFX[name](); } catch (e) {}
}
// ---------- Musik ----------
// Akkordfolgen (MIDI-Grundtöne von Dreiklängen), Tempo, Stil
const CH = (r, minor) => [r, r + (minor ? 3 : 4), r + 7];
const TRACKS = {
  title:{bpm:70, prog:[CH(50,1), CH(46), CH(53), CH(48)], lead:'sine', dens:0.4, len:3, oct:12, drums:'', bass:'long', pad:true, seed:1},
  town:{bpm:104, prog:[CH(48), CH(43), CH(45,1), CH(41)], lead:'triangle', dens:0.75, len:1, oct:24, drums:'....h...', bass:'walk', pad:false, seed:2},
  gosse:{bpm:88, prog:[CH(45,1), CH(50,1), CH(52), CH(45,1)], lead:'square', dens:0.55, len:2, oct:12, drums:'k...s...', bass:'walk', pad:false, seed:3, lvol:0.05},
  wild:{bpm:112, prog:[CH(50,1), CH(48), CH(46), CH(48)], lead:'triangle', dens:0.6, len:1, oct:24, drums:'k...k.s.', bass:'pulse', pad:true, seed:4},
  night:{bpm:64, prog:[CH(45,1), CH(41), CH(48), CH(43)], lead:'sine', dens:0.32, len:3, oct:24, drums:'', bass:'long', pad:true, seed:5},
  dark:{bpm:76, prog:[CH(48,1), CH(49), CH(48,1), CH(43)], lead:'square', dens:0.35, len:2, oct:12, drums:'k.......', bass:'long', pad:true, seed:6, lvol:0.045},
  combat:{bpm:150, prog:[CH(40,1), CH(48), CH(50), CH(47)], lead:'square', dens:0.8, len:1, oct:24, drums:'khskkhsh', bass:'eighth', pad:false, seed:7, lvol:0.05},
  boss:{bpm:162, prog:[CH(48,1), CH(44), CH(41,1), CH(43)], lead:'sawtooth', dens:0.85, len:1, oct:24, drums:'kkskkksh', bass:'eighth', pad:true, seed:8, lvol:0.045},
  inside:{bpm:126, prog:[CH(43), CH(48), CH(50), CH(43)], lead:'triangle', dens:0.8, len:1, oct:24, drums:'k..hk.h.', bass:'walk', pad:false, seed:9},
  temple:{bpm:60, prog:[CH(48), CH(45,1), CH(41), CH(43)], lead:'sine', dens:0.3, len:4, oct:24, drums:'', bass:'long', pad:true, seed:10},
  victory:{bpm:96, prog:[CH(48), CH(53), CH(55), CH(48)], lead:'square', dens:0.7, len:2, oct:24, drums:'k.s.k.s.', bass:'walk', pad:true, seed:11, lvol:0.06}
};
function buildMelody(tr) {
  // 8 Takte à 8 Achtel, aus Akkordtönen und Durchgangsnoten
  let s = tr.seed * 9301 + 49297; const r = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const out = [];
  for (let bar = 0; bar < 8; bar++) {
    const ch = tr.prog[bar % tr.prog.length], tones = ch.map(n => n + tr.oct);
    let prev = tones[0];
    for (let st = 0; st < 8; st++) {
      if (bar % 4 === 3 && st >= 6) { out.push(st === 6 ? tones[0] : 0); continue; }
      const strong = st % 2 === 0;
      if (r() > tr.dens + (strong ? 0.15 : -0.1) || (tr.len > 1 && st % tr.len)) { out.push(0); continue; }
      let n;
      if (strong || r() < 0.5) n = tones[Math.floor(r() * 3)] + (r() < 0.25 ? 12 : 0);
      else n = prev + (r() < 0.5 ? 2 : -2);
      out.push(n); prev = n;
    }
  }
  // zweite Hälfte variiert die erste leicht (Wiedererkennung)
  for (let i = 32; i < 64; i++) if (i % 8 < 4 && out[i - 32]) out[i] = out[i - 32];
  return out;
}
for (const k in TRACKS) TRACKS[k].mel = buildMelody(TRACKS[k]);
function playMusic(name) {
  if (!AU.ctx || AU.want === name) return;
  AU.want = name;
  const t = AU.ctx.currentTime;
  AU.musBus.gain.cancelScheduledValues(t); AU.musBus.gain.setValueAtTime(AU.musBus.gain.value, t); AU.musBus.gain.linearRampToValueAtTime(0.0001, t + 0.9);
  AU.pending = name; AU.switchAt = t + 0.9;
}
function drum(k, t) {
  if (k === 'k') { tone(150, 0.18, {type:'sine', slide:40, vol:0.35, when:t, dest:AU.musBus}); }
  else if (k === 's') { noiz(0.12, {ft:'bandpass', f:1800, vol:0.18, when:t, dest:AU.musBus}); tone(200, 0.06, {type:'triangle', vol:0.08, when:t, dest:AU.musBus}); }
  else if (k === 'h') noiz(0.04, {ft:'highpass', f:7000, vol:0.06, when:t, dest:AU.musBus});
}
function musicTick() {
  const c = AU.ctx; if (!c) return;
  if (c.currentTime > AU.nextT + 1) AU.nextT = c.currentTime + 0.05;
  while (AU.nextT < c.currentTime + 0.25) {
    if (AU.pending && AU.nextT >= AU.switchAt) {
      AU.track = AU.pending; AU.pending = null; AU.step = 0;
      AU.musBus.gain.cancelScheduledValues(AU.nextT); AU.musBus.gain.setValueAtTime(0.0001, AU.nextT); AU.musBus.gain.linearRampToValueAtTime(1, AU.nextT + 1.2);
    }
    const tr = TRACKS[AU.track], t = AU.nextT;
    if (tr) {
      const sd = 60 / tr.bpm / 2, st = AU.step % 64, bar = Math.floor(st / 8), inBar = st % 8, ch = tr.prog[bar % tr.prog.length];
      const n = tr.mel[st];
      if (n) tone(mtof(n), sd * tr.len * 0.95 + 0.05, {type:tr.lead, vol:tr.lvol || 0.07, attack:tr.len > 2 ? 0.08 : 0.01, lp:tr.lead === 'sawtooth' ? 1800 : 0, when:t, dest:AU.musBus});
      const root = ch[0] - 12;
      if (tr.bass === 'walk' && inBar % 2 === 0) tone(mtof(inBar % 4 === 0 ? root : root + 7), sd * 1.8, {type:'triangle', vol:0.14, when:t, dest:AU.musBus});
      if (tr.bass === 'pulse' && inBar % 2 === 0) tone(mtof(root), sd * 1.5, {type:'triangle', vol:0.13, when:t, dest:AU.musBus});
      if (tr.bass === 'eighth') tone(mtof(root), sd * 0.9, {type:'square', vol:0.06, lp:700, when:t, dest:AU.musBus});
      if (tr.bass === 'long' && inBar === 0) tone(mtof(root), sd * 8, {type:'triangle', vol:0.12, attack:0.1, when:t, dest:AU.musBus});
      if (tr.pad && inBar === 0) ch.forEach(m => tone(mtof(m), sd * 8, {type:'sine', vol:0.035, attack:0.4, when:t, dest:AU.musBus}));
      const dk = tr.drums && tr.drums[inBar]; if (dk && dk !== '.') drum(dk, t);
      AU.nextT += sd;
    } else AU.nextT += 0.25;
    AU.step++;
  }
}
function chooseMusic() {
  if (!AU.ctx || !P) return;
  if (P.f.sieg && G.t - (P.f.siegT || 0) < 0) return;
  const reg = regionAt(P.x, P.y), info = REGION_INFO[reg] || {};
  const boss = G.enemies.some(e => e.boss && !e.dead && dist(e.x, e.y, P.x, P.y) < 14);
  const fight = G.enemies.some(e => !e.dead && e.aggro && !e.def.passive && dist(e.x, e.y, P.x, P.y) < 11);
  let m;
  if (boss) m = 'boss';
  else if (fight) m = 'combat';
  else if (info.inside) m = reg === 'i_tempel' || reg === 'i_burg' ? 'temple' : 'inside';
  else if (['morvath', 'festung', 'hort', 'sumpf', 'hexe', 'ruinen', 'aschelande', 'sonnentempel', 'nachtkrone'].includes(reg) || info.dark) m = 'dark';
  else if (isNight()) m = 'night';
  else if (reg === 'gosse') m = 'gosse';
  else if (reg === 'stadt' || reg === 'dorf') m = 'town';
  else m = 'wild';
  playMusic(m);
}
