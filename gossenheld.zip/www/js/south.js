'use strict';
// ================= DER SÜDEN: SALZMARSCH, STURMKÜSTE, MÖWENHAFEN, ASCHELANDE =================
// Erweitert die Welt nach Süden bis ans Meer (WORLD_H = 352). Alle Positionen in Feldern der großen Welt.

// ---------- Neue Kacheln ----------
Object.assign(TL, {SHELL:44, PALM:45, ASH:46, LAVA:47, REED:48, BLOCKER:49});   // BLOCKER: unsichtbar, versperrt den Weg (unter Sondergebäuden)
BLOCK[TL.PALM] = 1; BLOCK[TL.LAVA] = 1; PSOLID[TL.PALM] = 1; BLOCK[TL.BLOCKER] = 1; PSOLID[TL.BLOCKER] = 1; TALL[TL.PALM] = 1;
TILE_COLORS[44] = '#e0cc94'; TILE_COLORS[45] = '#3a8a3a'; TILE_COLORS[46] = '#4a4246'; TILE_COLORS[47] = '#e0501a'; TILE_COLORS[48] = '#7a9a4a'; TILE_COLORS[49] = '#d8d0c8';
HARVEST[44] = {verb:'Sammeln', item:'muschel', n:[1, 2], prof:'sammeln', time:0.6, lvl:0, regrow:1};
HARVEST[45] = {verb:'Fällen', item:'holz', n:[1, 3], tool:'axt', prof:'holz', time:1.0, lvl:0, regrow:3};
HARVEST[48] = {verb:'Schneiden', item:'kraut', n:[1, 1], prof:'sammeln', time:0.5, lvl:0, regrow:1};

const _drawTileBase = drawTile;
drawTile = function (t, v) {
  if (t < 44) return _drawTileBase(t, v);
  const tall = t === TL.PALM, c = mkCanvas(tall ? 20 : 16, tall ? 28 : 16), x = c.getContext('2d'), s = t * 100 + v * 7 + 11;
  const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  switch (t) {
    case TL.SHELL:
      speck(x, 16, 16, '#d9c58a', ['#ccb679', '#e6d6a2', '#c4ad70'], 0.28, s);
      { const px = 3 + v * 2, py = 5 + (v % 2) * 4; R(px, py + 1, 5, 3, '#f4e8dc'); R(px + 1, py, 3, 1, '#f4e8dc'); R(px + 1, py + 1, 1, 3, '#e0b0a0'); R(px + 3, py + 1, 1, 3, '#e0b0a0'); R(px, py + 4, 5, 1, '#b89a80');
        R(11 - v, 11, 2, 2, '#e8a0b0'); R(11 - v, 11, 1, 1, '#fff0f4'); }
      break;
    case TL.PALM: {
      for (let k = 0; k < 18; k++) { const px = 9 + Math.round(Math.sin(k / 6) * 2) - (v % 2); R(px, 27 - k, 3, 1, k % 3 ? '#8a6232' : '#6a4422'); }
      const cx = 10 - (v % 2), cy = 9, fr = ['#2f7a2a', '#3d9a32', '#56b83f'];
      for (const [dx, dy] of [[-8, 3], [8, 3], [-6, -4], [6, -4], [0, -6], [-9, -1], [9, -1]]) {
        for (let k = 0; k <= 8; k++) { const t2 = k / 8, px = Math.round(cx + dx * t2), py = Math.round(cy + dy * t2 + Math.sin(t2 * 3) * 2 * Math.sign(dy + 0.1) * (dy > 0 ? 1 : 0.4) + t2 * t2 * 3);
          R(px, py, 2, 1, fr[k % 3]); if (k > 2 && k < 7) R(px, py + 1, 1, 1, fr[0]); }
      }
      R(cx - 1, cy, 3, 3, '#6a4422'); R(cx - 2, cy + 2, 2, 2, '#5a3a1a'); R(cx + 1, cy + 2, 2, 2, '#5a3a1a');
      addOutline(c, '#1a140e'); break; }
    case TL.ASH:
      speck(x, 16, 16, '#4a4246', ['#3e373a', '#57504f', '#5a4a44'], 0.36, s);
      if (v === 1) { R(4, 9, 3, 1, '#7a2a1a'); R(6, 10, 2, 1, '#a0401a'); }
      if (v === 3) { R(10, 4, 1, 1, '#f08030'); }
      break;
    case TL.LAVA:
      speck(x, 16, 16, '#d84a1a', ['#f0702a', '#c03a12', '#f89a3a'], 0.35, 500 + v);
      for (const row of [3, 9, 13]) { const x0 = (v * 3 + row * 5) % 16; for (let k = 0; k < 4; k++) R((x0 + k) % 16, row, 1, 1, '#ffd060'); }
      break;
    case TL.REED:
      speck(x, 16, 16, '#4b5a33', ['#3e4c2a', '#566a3a', '#3a4a44'], 0.32, s);
      for (let k = 0; k < 5; k++) { const px = 2 + k * 3 + (v % 2), hgt = 7 + ((k + v) % 3) * 2; R(px, 15 - hgt, 1, hgt, k % 2 ? '#8aa04a' : '#6a8a3a'); if (k % 2 === 0) R(px - 0 , 15 - hgt - 2, 1, 3, '#7a4a22'); }
      break;
  }
  return c;
};

// ---------- Neue Regionen ----------
['marsch', 'kueste', 'hafen', 'leuchtturm', 'bucht', 'aschelande'].forEach(r => { RIDX[r] = REGIONS.length; REGIONS.push(r); });
Object.assign(REGION_INFO, {
  marsch:{name:'Salzmarsch', c:[72, 282], lv:[6, 9]},
  kueste:{name:'Sturmküste', c:[88, 327], lv:[9, 12]},
  hafen:{name:'Möwenhafen', c:[118, 309], safe:true},
  leuchtturm:{name:'Alter Leuchtturm', c:[62, 329], lv:[9, 11]},
  bucht:{name:'Schmugglerbucht', c:[27, 303], lv:[10, 12]},
  aschelande:{name:'Aschelande', c:[206, 296], lv:[18, 23]}
});
Object.assign(ZONES, {
  marsch:{lv:[6, 9], cap:7, pack:0.2, mobs:[['krabbe', 3], ['schleim', 2], ['eber', 1], ['bandit', 1], ['hirsch', 1]], night:[['skelett', 1]]},
  kueste:{lv:[9, 12], cap:7, pack:0.25, mobs:[['krabbe', 3], ['pirat', 2], ['pirat_schuetze', 1]]},
  leuchtturm:{lv:[9, 11], cap:3, mobs:[['krabbe', 1]]},
  bucht:{lv:[10, 12], cap:7, hostile:true, mobs:[['pirat', 3], ['pirat_schuetze', 2]]},
  aschelande:{lv:[18, 23], cap:7, pack:0.3, mobs:[['salamander', 3], ['aschegolem', 2], ['schattenritter', 1], ['warg', 1]]}
});
const SOUTH = {hafen:[118, 319], turm:[62, 336], bucht:[26, 311], camp:[178, 277], koloss:[214, 305]};
const SOUTH_SAFE = [[SOUTH.hafen[0], SOUTH.hafen[1], 18], [SOUTH.camp[0], SOUTH.camp[1], 14]];
function seaY(x) { return 334 + Math.sin(x / 19) * 5 + Math.sin(x / 7.3) * 2; }
function southRiverX(y) { return riverX(y / WS) * WS; }

// ---------- Gegenstände ----------
defI('krabbenfleisch', {name:'Krabbenfleisch', icon:'🦀', val:9, stack:true});
defI('muschel', {name:'Muschel', icon:'🐚', val:4, stack:true, gift:true});
defI('perle', {name:'Perle', icon:'⚪', val:120, stack:true, gift:true});
defI('glutstein', {name:'Glutstein', icon:'🔥', val:70, stack:true});
defI('rum', {name:'Piratenrum', icon:'🥃', val:18, type:'food', heal:12, buff:['mut', 180], stack:true, gift:true});
defI('krabbensuppe', {name:'Krabbensuppe', icon:'🍲', val:45, type:'food', heal:130, buff:['satt', 240], stack:true});
defI('lampenoel', {name:'Leuchtturm-Öl', icon:'🫙', val:0, type:'quest', stack:true});
defI('rotbartschatz', {name:'Rotbarts Schatztruhe', icon:'💰', val:0, type:'quest', stack:true});
defI('schatzkarte', {name:'Schatzkarte', icon:'🗺️', val:60, type:'tool', stack:true, desc:'Benutzen: zeigt, wo der Schatz liegt – dort mit Spitzhacke ausgraben'});
defI('flaschenpost', {name:'Flaschenpost', icon:'🍾', val:15, type:'tool', stack:true, desc:'Benutzen: Flasche öffnen und die Nachricht lesen'});
defI('perlenring', {name:'Perlenring', icon:'💍', type:'schmuck', bonus:{int:2, wis:3}, def:2, luck:0.05, val:650});
W('saebel', 'Entermesser', '🗡️', 'melee', 21, 340, {desc:'Gebogene Klinge der Freibeuter'});
W('glutklinge', 'Glutklinge', '⚔️', 'melee', 42, 3200, {desc:'In Lava geschmiedet – brennt nie aus'});
RECIPES.push(
  {out:'krabbensuppe', req:{krabbenfleisch:2, kraut:1}, prof:'kochen', lvl:3, st:'feuer'},
  {out:'perlenring', req:{perle:2, silberbarren:1}, prof:'schmieden', lvl:5},
  {out:'saebel', req:{eisenbarren:3, leder:1}, prof:'schmieden', lvl:5},
  {out:'glutklinge', req:{glutstein:5, mithrilbarren:2}, prof:'schmieden', lvl:10}
);
Object.assign(SHOPS, {
  hein:['rum', 'bier', 'brot', 'krabbensuppe', 'gebraten', 'heiltrank', 'wein'],
  maren:['krabbenfleisch', 'muschel', 'fleisch', 'kochset', 'axt', 'reparaturset', 'pfeile', 'saebel', 'koecher', 'rucksack'],
  durgan:['mithrilbarren', 'glutstein', 'grheiltrank', 'meisterset', 'mithrilhelm', 'mithrilhandschuhe', 'mithrilhose', 'mithrilstiefel', 'mithrilruestung', 'mithrilklinge']
});
SHOPS.zeb.push('perlenring', 'schatzkarte');
RUMORS.push(
  '„Im Süden, hinter der Salzmarsch, liegt Möwenhafen. Seit der Leuchtturm dunkel ist, laufen dort ständig Schiffe auf.“',
  '„Rotbart der Pirat soll in einer Bucht im Südwesten hausen. Wer ihn findet, findet auch sein Gold. Oder seinen Säbel – im Bauch.“',
  '„Jenseits des Flusses im Süden glüht die Erde. Die Zwerge nennen es die Aschelande. Nur Narren und Zwerge gehen dorthin.“'
);

// ---------- Gegner ----------
Object.assign(ENEMIES, {
  krabbe:{name:'Riesenkrabbe', shape:'quad', size:0.95, col:'#d0583a', hp:80, dmg:12, spd:2.0, xp:60, drops:[['krabbenfleisch', 0.75], ['muschel', 0.3], ['perle', 0.05]], lvl:9, tame:{lvl:6, roles:['kampf']}},
  krabbenkoenigin:{name:'Krabbenkönigin', shape:'quad', size:2.0, col:'#e0603a', hp:900, dmg:24, spd:1.9, xp:1100, gold:[120, 200], drops:[['perle', 1, 3], ['krabbenfleisch', 1, 4]], lvl:12, boss:true},
  pirat:{name:'Pirat', shape:'hum', col:'#d8a070', outfit:'#6a2a2a', hair:'#2a1a1a', helm:true, hp:95, dmg:13, spd:2.7, xp:70, gold:[12, 35], drops:[['rum', 0.25], ['saebel', 0.03], ['schatzkarte', 0.04], ['heiltrank', 0.1]], lvl:10},
  pirat_schuetze:{name:'Piraten-Schütze', shape:'hum', col:'#c89070', outfit:'#2a3a5a', hair:'#5a3a1a', hp:75, dmg:12, spd:2.6, xp:70, gold:[10, 30], drops:[['pfeile', 0.4], ['rum', 0.15]], lvl:10, ranged:true, proj:'arrow'},
  rotbart:{name:'Kapitän Rotbart', shape:'hum', size:1.5, col:'#d8a070', outfit:'#2a2a4a', hair:'#c83a1a', helm:true, hp:1100, dmg:26, spd:2.6, xp:1500, gold:[300, 500], drops:[['saebel', 1]], lvl:12, boss:true},
  salamander:{name:'Glutsalamander', shape:'quad', size:1.15, col:'#c8401a', hp:240, dmg:30, spd:3.0, xp:260, drops:[['glutstein', 0.5], ['fleisch', 0.4]], lvl:19, tame:{lvl:9, roles:['kampf']}},
  aschegolem:{name:'Aschegolem', shape:'hum', size:1.7, col:'#5a4a46', outfit:'#3a2a2a', bald:true, eye:'#ffa030', hp:520, dmg:38, spd:1.9, xp:380, gold:[20, 60], drops:[['glutstein', 0.4], ['mithrilerz', 0.3], ['kristall', 0.2]], lvl:20},
  glutkoloss:{name:'Der Glutkoloss', shape:'hum', size:2.2, col:'#6a3a2a', outfit:'#2a1a1a', bald:true, eye:'#ffd040', hp:4200, dmg:50, spd:2.0, xp:5000, gold:[800, 1200], drops:[['glutstein', 1, 5]], lvl:23, boss:true, ranged:true, proj:'fire'}
});
Object.assign(ENEMY_STYLE, {
  pirat:{style:'leather', helmCol:'#c83a3a', beard:true}, pirat_schuetze:{style:'leather', female:true, longHair:true, helmCol:'#3a3a6a'},
  rotbart:{style:'royal', outfit:'#2a2a4a', trim:'#c8a040', helmCol:'#1a1a1a', beard:true, cape:'#7a1a1a'},
  aschegolem:{style:'plate', metal:'#4a3a3a', trim:'#f06020'}, glutkoloss:{style:'plate', metal:'#3a2a2a', trim:'#ffb030', cape:'#a02a0a'}
});
ANIMAL_DRAW.krabbe = function (R, f, c, o) {
  const l = shade(c, 0.25), d = shade(c, -0.3), lg = f ? 1 : 0;
  for (const s of [0, 1, 2]) { R(3 + s * 2 - lg, 12 + (s % 2), 1, 2, d); R(12 - s * 2 + lg, 12 + (s % 2), 1, 2, d); }
  R(4, 8, 8, 5, c); R(3, 9, 10, 3, c); R(5, 8, 6, 1, l); R(4, 12, 8, 1, d); R(6, 10, 1, 1, l); R(9, 9, 1, 1, l);
  R(6, 6, 1, 2, d); R(9, 6, 1, 2, d); R(6, 5, 1, 1, o.eye || '#111'); R(9, 5, 1, 1, o.eye || '#111');
  const cy = f ? 5 : 6;
  R(1, cy, 3, 3, c); R(1, cy, 1, 1, l); R(0, cy - 1, 2, 2, c); R(3, cy + 2, 1, 2, d);
  R(12, cy, 3, 3, c); R(14, cy, 1, 1, l); R(14, cy - 1, 2, 2, c); R(12, cy + 2, 1, 2, d);
  if (o.crown) { R(5, 3, 6, 2, '#e8c040'); R(5, 2, 1, 1, '#e8c040'); R(7, 2, 2, 1, '#e8c040'); R(10, 2, 1, 1, '#e8c040'); R(7, 3, 2, 1, '#c83a3a'); }
  if (o.spikes) { R(5, 7, 1, 1, '#f0e8d8'); R(8, 7, 1, 1, '#f0e8d8'); R(10, 7, 1, 1, '#f0e8d8'); }
};
ANIMAL_DRAW.salamander = function (R, f, c, o) {
  const l = shade(c, 0.3), d = shade(c, -0.35), g = '#ffd040';
  R(0, 11, 3, 1, c); R(2, 10, 3, 2, c);
  R(4, 9, 8, 3, c); R(5, 8, 6, 1, l); R(4, 12, 8, 1, d);
  R(12, 8, 3, 3, c); R(15, 9, 1, 2, c); R(13, 8, 1, 1, o.eye || '#111'); R(13, 7, 2, 1, l);
  R(6, 9, 1, 1, g); R(9, 10, 1, 1, g); R(3, 10, 1, 1, g);
  if (f) { R(5, 12, 1, 2, d); R(10, 13, 1, 1, d); R(11, 12, 1, 2, d); R(6, 13, 1, 1, d); } else { R(6, 12, 1, 2, d); R(11, 12, 1, 2, d); R(4, 12, 1, 1, d); }
  R(7, 7, 1, 1, '#f06020'); R(9, 7, 1, 1, '#f08030'); R(8, 6, 1, 1, '#ffd040');
  if (o.spikes) { R(5, 7, 1, 1, '#f06020'); R(11, 7, 1, 1, '#f06020'); }
};
ANIMAL_LOOK.krabbe = ['krabbe', {}]; ANIMAL_LOOK.krabbenkoenigin = ['krabbe', {crown:true, eye:'#f0d040'}]; ANIMAL_LOOK.salamander = ['salamander', {}];
BOSS_POS.krabbenkoenigin = [46.5, 331.5];
BOSS_POS.rotbart = [26.5, 309.6];
BOSS_POS.glutkoloss = [SOUTH.koloss[0] + 0.5, SOUTH.koloss[1] + 0.6];

// ---------- Icons ----------
Object.assign(ICON_DRAW, {
  crabmeat(R) { R(3, 5, 9, 7, '#e86a4a'); R(4, 5, 7, 2, '#f8a080'); R(3, 11, 9, 1, '#a83a2a'); R(11, 3, 3, 4, '#e86a4a'); R(12, 3, 2, 1, '#f8c0a0'); R(5, 8, 5, 1, '#f8e8e0'); R(6, 10, 3, 1, '#f8e8e0'); },
  shell(R) { R(3, 6, 10, 6, '#f4e0d0'); R(4, 4, 8, 2, '#f4e0d0'); R(6, 3, 4, 1, '#f4e0d0'); for (const a of [5, 8, 11]) R(a, 4, 1, 8, '#d8a090'); R(3, 12, 10, 1, '#b8806a'); R(7, 13, 2, 1, '#b8806a'); R(4, 5, 1, 2, '#ffffff'); },
  pearl(R) { R(5, 4, 6, 8, '#e8e8f0'); R(4, 5, 8, 6, '#e8e8f0'); R(5, 5, 2, 2, '#ffffff'); R(9, 10, 2, 1, '#b8b8c8'); R(5, 11, 6, 1, '#c8c8d8'); },
  tmap(R) { R(1, 3, 14, 10, '#e8d8a8'); R(1, 3, 14, 1, '#c8b080'); R(1, 12, 14, 1, '#a89060'); R(3, 6, 4, 1, '#8a6a3a'); R(7, 7, 2, 1, '#8a6a3a'); R(3, 10, 3, 1, '#4a8ad0');
    R(10, 6, 1, 1, '#c82a2a'); R(12, 6, 1, 1, '#c82a2a'); R(11, 7, 1, 1, '#c82a2a'); R(10, 8, 1, 1, '#c82a2a'); R(12, 8, 1, 1, '#c82a2a'); },
  msgbottle(R) { R(2, 7, 10, 5, '#5ab08a'); R(3, 7, 8, 1, '#8ad8b0'); R(12, 8, 2, 3, '#5ab08a'); R(14, 8, 1, 3, '#8a5a2a'); R(4, 9, 6, 2, '#f0e8c8'); R(5, 9, 1, 1, '#c82a2a'); },
  sabre(R, o) {
    const b = o.c || '#d8dce8', hi = L(b, 0.5), lo = L(b, -0.35), g = o.g || '#c8a040';
    R(2, 13, 2, 2, '#5a3418'); R(3, 12, 1, 1, '#3a2410');
    R(1, 11, 5, 1, g); R(5, 10, 1, 3, g); R(1, 12, 1, 2, g);
    const pts = [[5, 10], [6, 9], [7, 8], [8, 7], [9, 6], [10, 5], [11, 5], [12, 4], [13, 4], [14, 3]];
    pts.forEach((p, i) => { R(p[0], p[1], 1, 1, b); R(p[0], p[1] - 1, 1, 1, hi); if (i < 8) R(p[0], p[1] + 1, 1, 1, lo); });
  }
});
Object.assign(ICON_DEF, {
  krabbenfleisch:['crabmeat'], muschel:['shell'], perle:['pearl'], glutstein:['gem', {c:'#f06020'}], rum:['bottle', {c:'#8a4a1a'}], krabbensuppe:['bowl'],
  lampenoel:['potion', {c:'#e8c040'}], rotbartschatz:['seal'], schatzkarte:['tmap'], flaschenpost:['msgbottle'],
  perlenring:['ring', {metal:'#d8dce8', gem:'#f8f4f0'}], saebel:['sabre'], glutklinge:['sword', {len:10, guard:3, grip:3, fuller:true, c:'#f0803a', g:'#3a2a2a', gem:'#ffd040'}]
});
for (const id of Object.keys(ICON_DEF)) if (ITEMS[id] && !ITEMS[id].emoji) { ITEMS[id].emoji = ITEMS[id].icon; ITEMS[id].icon = iconHTML(id); }

// ---------- Leuchtturm & Schiff als Gebäudebilder ----------
const _houseCanvasBase = houseCanvas, SOUTH_HOUSE = {};
houseCanvas = function (b) {
  if (!b.tower && !b.ship) return _houseCanvasBase(b);
  const key = (b.tower ? 't' : 's') + b.w + ',' + b.h; if (SOUTH_HOUSE[key]) return SOUTH_HOUSE[key];
  const W = b.w * 16, H = b.h * 16 + 8 + (b.up || 0), c = mkCanvas(W, H), x = c.getContext('2d');
  const R = (a, y, w, h, col) => { x.fillStyle = col; x.fillRect(a, y, w, h); };
  if (b.tower) {
    const cx = W / 2, top = 18, base = H - 4;
    for (let a = 0; a < W; a += 5) { const rh = 6 + (a * 7) % 5; R(a, base - rh + 4, 6, rh, '#7a7a80'); R(a + 1, base - rh + 4, 3, 1, '#9a9aa0'); }
    for (let y = top; y < base; y++) {
      const t = (y - top) / (base - top), hw = Math.round(10 + t * 9), band = Math.floor((y - top) / 12) % 2;
      const col = band ? '#c83a3a' : '#eee8dc', sh = band ? '#9a2a2a' : '#c8c0b0';
      R(cx - hw, y, hw * 2, 1, col); R(cx + hw - 4, y, 4, 1, sh); R(cx - hw, y, 1, 1, sh);
    }
    for (const wy of [34, 58]) { R(cx - 2, wy, 4, 6, '#2a2a3a'); R(cx - 2, wy, 4, 1, '#4a4a5a'); }
    R(cx - 13, top - 2, 26, 3, '#3a3a42'); for (let a = cx - 13; a < cx + 13; a += 3) R(a, top - 6, 1, 4, '#3a3a42');   // Galerie
    R(cx - 8, 4, 16, 10, '#2a3a4a'); R(cx - 7, 5, 14, 8, '#e8d890'); R(cx - 1, 5, 2, 8, '#3a3a42'); R(cx - 7, 8, 14, 1, '#3a3a42');   // Laterne
    R(cx - 9, 2, 18, 2, '#3a3a42'); R(cx - 5, 0, 10, 2, '#4a4a52'); R(cx - 1, 0, 2, 1, '#c8a040');
    const dx = b.door * 16; R(dx + 3, base - 16, 10, 16, '#5a3a1a'); R(dx + 4, base - 15, 8, 15, '#7a4a22'); R(dx + 10, base - 8, 1, 2, '#e0b84a');
    R(0, base, W, 4, '#7a7a80'); R(2, base - 2, 6, 3, '#8d8d92'); R(W - 9, base - 1, 7, 2, '#8d8d92');
  } else {
    const wl = H - 14;
    R(4, wl, W - 8, 10, '#6a4422'); R(0, wl - 2, W, 4, '#7a5228'); R(8, wl + 10, W - 16, 3, '#4a2e18');
    for (let a = 4; a < W - 4; a += 6) R(a, wl + 2, 1, 8, '#5a3418');
    R(0, wl - 2, W, 1, '#9a6a3a'); for (let a = 14; a < W - 14; a += 14) R(a, wl + 3, 3, 3, '#2a1a0a');
    const mx = Math.round(W * 0.48); R(mx, 4, 2, wl - 4, '#5a3a1a');
    for (let y = 8; y < wl - 6; y++) { const w2 = Math.round(6 + (y - 8) * 0.55); R(mx + 2, y, w2, 1, y % 7 ? '#f0e8d8' : '#d8d0c0'); R(mx - w2 + 1, y, w2 - 1, 1, '#e8e0d0'); }
    R(mx - 3, 2, 8, 3, '#c83a3a'); R(mx + 5, 3, 3, 1, '#c83a3a');
    R(W - 10, wl - 10, 2, 8, '#5a3a1a'); R(6, wl - 6, W - 12, 1, '#5a3a1a');
  }
  addOutline(c, '#1a140e'); SOUTH_HOUSE[key] = c; return c;
};
// Leuchtfeuer & Lavaschein in der Nacht
function drawBeacons(dark) {
  if (!P || !P.f.leuchtfeuer) return;
  for (const bd of BUILDINGS) {
    if (!bd.tower || Math.abs(bd.x - P.x) > 40 || Math.abs(bd.y - P.y) > 30) continue;
    const lx = (bd.x + bd.w / 2) * 16, ly = bd.y * 16 - 8 - bd.up + 9, a = G.t * 0.9;
    ctx.save(); ctx.globalAlpha = 0.25 + 0.45 * dark;
    const gr = ctx.createRadialGradient(lx, ly, 0, lx, ly, 26); gr.addColorStop(0, 'rgba(255,240,170,0.95)'); gr.addColorStop(1, 'rgba(255,220,120,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(lx, ly, 26, 0, TAU); ctx.fill();
    if (dark > 0.2) { ctx.globalAlpha = 0.22 * dark; ctx.fillStyle = '#fff2b0'; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.arc(lx, ly, 260, a, a + 0.22); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(lx, ly); ctx.arc(lx, ly, 260, a + Math.PI, a + Math.PI + 0.22); ctx.closePath(); ctx.fill(); }
    ctx.restore();
  }
}
function extraLights(light, x0, y0, x1, y1) {
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (inb(tx, ty) && WT[idx(tx, ty)] === TL.LAVA && hash2(tx, ty, 41) < 0.14) light(tx + 0.5, ty + 0.5, 2.6);
  if (P.f.leuchtfeuer) for (const bd of BUILDINGS) if (bd.tower) light(bd.x + bd.w / 2, bd.y - bd.up / 16, 3.5);
}

// ---------- Weltgenerierung des Südens ----------
function southGen() {
  const S = 4242;
  for (let y = 250; y < WORLD_H; y++) for (let x = 0, xe = Math.min(MW, 254 + Math.round(Math.sin(y / 13) * 3)); x < xe; x++) {   // östlich davon: east.js
    const i = idx(x, y), rx = southRiverX(y), sy = seaY(x), east = x > rx + 2.2;
    const river = Math.abs(x / WS - riverX(y / WS)) < 1.35;
    const n = fbm(x, y, S), h = hash2(x, y, S + 9), h2 = hash2(x + 3, y + 7, S + 21);
    let reg = null, g = TL.GRASS, o = -1;
    if (east) {
      if (y < 262 + Math.sin(x / 9) * 4) continue;
      reg = 'aschelande';
      if (y >= sy) g = TL.WATER;
      else if (y >= sy - 3) { g = TL.GRAVEL; if (h < 0.05) o = TL.ROCK; }
      else {
        g = TL.ASH;
        if (n < 0.25) g = TL.LAVA; else if (n < 0.29) o = TL.ROCK;
        else if (n > 0.67) o = TL.DEADTREE;
        else if (h < 0.025) { o = TL.ROCK; if (h2 < 0.3) o = TL.MITHRIL; else if (h2 < 0.55) o = TL.CRYSTAL; else if (h2 < 0.8) o = TL.IRON; }
      }
    } else {
      if (y >= sy - 15) reg = 'kueste';
      else if (y >= 263 + Math.sin(x / 11) * 3) reg = 'marsch';
      else continue;
      if (y >= sy) g = TL.WATER;
      else if (reg === 'kueste') {
        const d = sy - y;
        if (d < 4) { g = TL.SAND; if (h < 0.06) o = TL.SHELL; else if (h < 0.075) o = TL.ROCK; }
        else if (d < 9) { g = n > 0.55 ? TL.GRASS : TL.SAND; if (h < 0.05) o = TL.PALM; else if (h < 0.065) o = TL.SHELL; else if (h < 0.075) o = TL.ROCK; }
        else { if (n > 0.72) o = TL.TREE; else if (h < 0.03) o = TL.PALM; else if (h < 0.045) o = TL.ROCK; else if (h < 0.05) o = TL.IRON; else if (h < 0.07) o = TL.FLOWER; else if (h < 0.08) o = TL.HERB; }
      } else {
        if (n < 0.3) g = TL.WATER; else if (n < 0.37) g = TL.SWAMP;
        else { if (n > 0.69) o = h2 < 0.5 ? TL.DEADTREE : TL.TREE; else if (h < 0.07) o = TL.REED; else if (h < 0.085) o = TL.HERB; else if (h < 0.095) o = TL.MUSHROOM; else if (h < 0.1) o = TL.FLOWER; }
      }
    }
    if (river) { g = TL.WATER; o = -1; }
    if (x < 3 || x >= MW - 3 || y >= WORLD_H - 3) { g = TL.WATER; o = -1; }
    WR[i] = RIDX[reg]; WG[i] = g; WT[i] = o >= 0 ? o : g;
  }
  const land = (x, y, t) => { if (inb(x, y)) { const i = idx(x, y); WG[i] = WT[i] = t; } };
  const clear = (cx, cy, r, t) => { for (let y = Math.floor(cy - r); y <= cy + r; y++) for (let x = Math.floor(cx - r); x <= cx + r; x++) if (inb(x, y) && Math.hypot(x - cx, y - cy) <= r) { const i = idx(x, y); if (t != null) WG[i] = t; WT[i] = WG[i]; } };
  const region = (cx, cy, r, reg) => { for (let y = Math.floor(cy - r); y <= cy + r; y++) for (let x = Math.floor(cx - r); x <= cx + r; x++) if (inb(x, y) && Math.hypot(x - cx, y - cy) <= r) WR[idx(x, y)] = RIDX[reg]; };
  // --- Möwenhafen ---
  const [hx, hy] = SOUTH.hafen;
  for (let y = hy - 13; y <= hy + 16; y++) for (let x = hx - 15; x <= hx + 15; x++) {
    if (!inb(x, y) || Math.hypot((x - hx) * 0.9, y - hy) > 14.5) continue;
    const i = idx(x, y); WR[i] = RIDX.hafen;
    if (y >= seaY(x)) continue;
    const street = Math.hypot(x - hx + 1, y - hy) < 5.5 || Math.abs(x - hx) <= 1 || Math.abs(y - hy - 4) <= 0 || (y === hy - 6 && x > hx - 9 && x < hx + 9);
    WG[i] = y >= seaY(x) - 2 ? TL.SAND : street ? TL.PATH : TL.GRASS; WT[i] = WG[i];
  }
  building(110, 309, 6, 3, 1);           // Taverne „Zur Salzigen Möwe“
  building(121, 309, 5, 3, 0);           // Hafenmeisterei
  building(105, 316, 4, 3, 3);           // Fischerhütte
  building(127, 316, 5, 3, 2);           // Werft
  building(111, 323, 4, 2, 0); building(124, 323, 4, 2, 3);
  setO(117, 318, TL.HEARTH); setO(120, 326, TL.BARREL); setO(121, 326, TL.BARREL); setO(108, 326, TL.BARREL);
  for (const p of [[110, 314], [115, 313], [126, 313], [131, 321]]) setO(p[0], p[1], TL.FLOWER);
  const pierTop = Math.floor(seaY(119)) - 2;
  for (let y = pierTop; y < pierTop + 10; y++) { land(118, y, TL.BRIDGE); land(119, y, TL.BRIDGE); WR[idx(118, y)] = WR[idx(119, y)] = RIDX.hafen; }
  for (let x = 113; x <= 124; x++) { land(x, pierTop + 9, TL.BRIDGE); WR[idx(x, pierTop + 9)] = RIDX.hafen; }
  BUILDINGS.push({x:121, y:pierTop + 3, w:6, h:3, v:3, ship:true, door:0});
  // --- Alter Leuchtturm auf der Landzunge ---
  const [tx, ty] = SOUTH.turm;
  for (let y = ty - 7; y <= ty + 7; y++) for (let x = tx - 8; x <= tx + 8; x++) {
    if (!inb(x, y)) continue; const d = Math.hypot(x - tx, (y - ty) * 1.2);
    if (d > 7.5) continue; const i = idx(x, y); WR[i] = RIDX.leuchtturm;
    WG[i] = d > 6 ? TL.SAND : d > 3.5 && hash2(x, y, 2) < 0.1 ? TL.GRAVEL : TL.GRASS; WT[i] = d > 6.4 && hash2(x, y, 3) < 0.25 ? TL.ROCK : WG[i];
  }
  building(tx - 1, ty - 4, 3, 3, 0, TL.WALL);
  { const b = BUILDINGS[BUILDINGS.length - 1]; b.tower = true; b.up = 48; b.wall = false; b.door = 1;
    for (let y = b.y; y < b.y + b.h; y++) for (let x = b.x; x < b.x + b.w; x++) { const i = idx(x, y); if (WT[i] === TL.DOOR) { WG[i] = TL.GRASS; continue; } WG[i] = TL.GRASS; WT[i] = TL.BLOCKER; } }
  // --- Schmugglerbucht ---
  const [bx, by] = SOUTH.bucht;
  region(bx, by, 12, 'bucht');
  for (let y = by - 12; y <= WORLD_H; y++) for (let x = 3; x <= bx + 4; x++) {
    if (!inb(x, y)) continue; const d = Math.hypot(x - (bx - 12), (y - (by + 12)) * 0.8);
    if (d < 9) { const i = idx(x, y); WG[i] = WT[i] = TL.WATER; } else if (d < 11) { const i = idx(x, y); if (WG[i] !== TL.WATER) WG[i] = WT[i] = TL.SAND; }
  }
  clear(bx, by - 1, 6.5, TL.SAND); clear(bx + 1, by - 3, 3.5, TL.PATH);
  building(bx - 6, by - 7, 3, 2, 3); building(bx + 4, by - 8, 3, 2, 3); building(bx - 1, by - 9, 4, 2, 3);
  setO(bx, by - 3, TL.HEARTH); setO(bx - 3, by, TL.BARREL); setO(bx - 2, by, TL.BARREL); setO(bx + 5, by - 1, TL.BARREL);
  chestAt(bx + 6, by - 4, {lock:4, gold:350, loot:[['rum', 3], ['perle', 2]]});
  chestAt(bx - 5, by - 3, {lock:3, gold:180, loot:[['schatzkarte', 1], ['grheiltrank', 1]]});
  // --- Durgans Lager am Rand der Aschelande ---
  const [cx, cy] = SOUTH.camp;
  clear(cx, cy, 5, TL.GRAVEL); region(cx, cy, 5.5, 'aschelande');
  setO(cx, cy, TL.HEARTH); setO(cx + 3, cy - 1, TL.ANVIL); setO(cx - 3, cy - 1, TL.BARREL); setO(cx - 3, cy, TL.BARREL); setO(cx + 2, cy - 3, TL.SHELF);
  // --- Arena des Glutkolosses ---
  const [kx, ky] = SOUTH.koloss;
  for (let y = ky - 8; y <= ky + 8; y++) for (let x = kx - 8; x <= kx + 8; x++) {
    if (!inb(x, y)) continue; const d = Math.hypot(x - kx, y - ky), i = idx(x, y);
    if (d < 5) { WG[i] = WT[i] = TL.ASH; } else if (d < 7.5 && !(Math.abs(x - kx) <= 1 && y < ky)) { WG[i] = WT[i] = TL.LAVA; }
  }
  for (let y = ky - 8; y < ky; y++) for (let x = kx - 1; x <= kx + 1; x++) if (inb(x, y)) { const i = idx(x, y); WG[i] = WT[i] = TL.ASH; }
  // --- Straßen ---
  const a = shiftOld(92, 124).map(Math.round);
  road(a[0], a[1], 128, 262); road(128, 262, hx, hy - 12);
  road(32, 240, 42, 288); road(42, 288, bx + 2, by - 4);
  road(hx - 14, hy + 3, 78, 326); road(78, 326, 68, 333); road(68, 333, tx + 1, ty + 1);
  road(hx + 14, hy - 2, 150, 300); road(150, 300, cx - 4, cy + 1);
  // Kutschen-Haltestellen bekommen etwas Platz
  for (const k of KUTSCHE) { const p = k.pos(); clear(Math.floor(p[0]), Math.floor(p[1]), 1.2); }
}
const _worldExtrasBase = worldExtras;
worldExtras = function () { southGen(); _worldExtrasBase(); };
function southInteriors() {
  makeInterior('moewe', 'Taverne „Zur Salzigen Möwe“', 12, 8, [113, 311, 1], TL.WOOD, o => {
    for (let x = 1; x <= 4; x++) o(x, 3, TL.COUNTER); o(10, 2, TL.HEARTH); o(1, 2, TL.SHELF); [[7, 3], [7, 5], [10, 5]].forEach(p => o(p[0], p[1], TL.TABLE));
    o(1, 6, TL.BARREL); o(2, 6, TL.BARREL); o(5, 6, TL.CARPET); o(6, 6, TL.CARPET); o(10, 6, TL.TROPHY);
  });
  makeInterior('leuchtturm', 'Im Alten Leuchtturm', 8, 7, [SOUTH.turm[0], SOUTH.turm[1] - 2, 1], TL.FLOOR, o => { o(1, 2, TL.BED); o(6, 2, TL.SHELF); o(5, 4, TL.TABLE); o(1, 5, TL.BARREL); o(6, 5, TL.HCHEST); });
}

// ---------- Kutschen (Schnellreise) ----------
const KUTSCHE = [
  {id:'alden', name:'Aldenmark (Südtor)', pos:() => shiftOld(83.5, 113.6)},
  {id:'dorf', name:'Eichenrast', pos:() => shiftOld(31.5, 64.6)},
  {id:'mine', name:'Zwergenmine Tiefgrund', pos:() => shiftOld(112.5, 35.6)},
  {id:'hafen', name:'Möwenhafen', pos:() => [114.5, 316.6]}
];
function kutschePos(k) { const d = NPC_DEFS.find(n => n.id === 'kutsche_' + k.id); return d ? [d.x, d.y] : k.pos(); }
function kutscheTalk(here) {
  const opts = [];
  for (const k of KUTSCHE) {
    if (k.id === here) continue;
    const p = kutschePos(k), known = G.explored[idx(Math.floor(p[0]), Math.floor(p[1]))];
    if (!known) { opts.push({t:'🔒 ' + k.name + ' (noch nicht besucht)', f:() => ({text:'„Dahin fahr ich erst, wenn du den Weg einmal selbst gefunden hast. Ich will wissen, dass es den Ort wirklich gibt.“'})}); continue; }
    opts.push({t:'🐴 ' + k.name + ' – 20 Gold', f:() => {
      if (P.gold < 20) return {text:'„Zwanzig Gold, Freund. Mein Gaul frisst kein Mitleid.“'};
      P.gold -= 20; sfx('coin');
      setTimeout(() => { P.mounted = false; teleport(p[0] + 0.6, p[1] + 1.1); syncAllies(); G.time = (G.time + 40) % DAY_LEN; toast('🐴 Nach holpriger Fahrt erreichst du ' + k.name + '.', 'quest'); }, 60);
      return 'close';
    }});
  }
  opts.push({t:'Tschüss'});
  return {text:pick(['„Kutsche gefällig? Bequemer als laufen – meistens.“', '„Steig ein! Die Federung ist neu. Na ja, neuer als die alte.“', '„Wohin soll’s gehen? Ich kenne jeden Weg im Reich. Fast jeden.“']), opts};
}
for (const k of KUTSCHE) {
  const p = k.pos();
  NPC_DEFS.push({id:'kutsche_' + k.id, name:'Kutscher', x:p[0], y:p[1], look:{skin:'#e0b090', hair:'#6a4a2a', outfit:'#4a5a7a', beard:k.id !== 'hafen', style:'leather', helmCol:'#3a3a2a'},
    talk() { return kutscheTalk(k.id); }});
}

// ---------- Schatzkarten & Flaschenpost ----------
function newTreasureSpot() {
  for (let k = 0; k < 400; k++) {
    const x = rint(8, MW - 8), y = rint(150, WORLD_H - 8), i = idx(x, y), r = regionAt(x, y);
    if (BLOCK[WT[i]] || WG[i] === TL.WATER || WG[i] === TL.BRIDGE || REGION_INFO[r].safe || REGION_INFO[r].inside) continue;
    if (dist(x, y, P.x, P.y) < 25) continue;
    return [x + 0.5, y + 0.5];
  }
  return [SOUTH.turm[0] + 4.5, SOUTH.turm[1] + 3.5];
}
function dirName(dx, dy) {
  const a = Math.atan2(dy, dx), d = ['Osten', 'Südosten', 'Süden', 'Südwesten', 'Westen', 'Nordwesten', 'Norden', 'Nordosten'];
  return d[(Math.round(a / (Math.PI / 4)) + 8) % 8];
}
function useTreasureMap() {
  if (!P.f.schatz) { P.f.schatz = newTreasureSpot(); toast('🗺️ Du entzifferst die Karte – das Ziel ist jetzt auf deiner Karte markiert (gelber Punkt).', 'quest'); }
  const t = P.f.schatz, d = dist(P.x, P.y, t[0], t[1]);
  if (d > 1.8) { toast('🗺️ Das Kreuz liegt etwa ' + Math.round(d) + ' Felder im ' + dirName(t[0] - P.x, t[1] - P.y) + ' (' + locName(t[0], t[1]) + ').'); return; }
  if (!countItem('spitzhacke')) { toast('⛏️ Hier ist das Kreuz! Du brauchst eine Spitzhacke zum Graben.'); sfx('fail'); return; }
  removeItem('schatzkarte', 1); P.f.schatz = null; G.shake = 0.3; burst(t[0], t[1], '#c8a060', 18); sfx('unlock');
  const g = Math.round(rint(150, 350) * Math.max(1, P.lvl / 6)); P.gold += g; gainProf('bergbau', 8);
  const pool = ['perle', 'perle', 'saebel', 'perlenring', 'grheiltrank', 'mithrilbarren', 'kristall', 'rum', 'silberbarren', 'ring'];
  const got = [pick(pool), pick(pool)]; got.forEach(id => addItem(id, 1));
  showDialog('Schatz gefunden!', 'Nach ein paar Schlägen stößt deine Spitzhacke auf Holz. Eine alte Kiste! Darin: <b>' + g + ' Gold</b>, ' + got.map(id => ITEMS[id].name).join(' und ') + '.', [{t:'Großartig'}]);
}
ITEMS.schatzkarte.use = useTreasureMap; ITEMS.schatzkarte.useLabel = '🗺️ Karte lesen';
const BOTTLE_MSGS = [
  '„Wer dies findet: Unser Schiff, die <i>Silbermöwe</i>, ist an der Sturmküste zerschellt. Ich habe den Laderaum vergraben, ehe die Piraten kamen. Die Karte liegt bei.“',
  '„Liebe Ilse, wenn du das liest, bin ich auf dem Weg nach Hause. Oder ich bin ertrunken. Dann such meinen Schatz – du weißt schon, wo. Ach nein, weißt du nicht. Karte anbei.“',
  '„Rotbart hat mich ausgesetzt, aber er vergisst, dass ich seine Verstecke kenne. Möge der Finder mehr Glück haben als ich.“'
];
ITEMS.flaschenpost.use = function () {
  removeItem('flaschenpost', 1); addItem('schatzkarte', 1); sfx('coin');
  showDialog('Flaschenpost', 'Du ziehst den Korken. Ein vergilbter Zettel und eine Karte fallen heraus:<br><br>' + pick(BOTTLE_MSGS) + '<br><br>(Du erhältst eine Schatzkarte.)', [{t:'Karte lesen', f:() => { useTreasureMap(); return 'close'; }}, {t:'Später'}]);
};
ITEMS.flaschenpost.useLabel = '🍾 Öffnen';

// ---------- Figuren ----------
const COASTAL = ['kueste', 'hafen', 'leuchtturm', 'bucht', 'marsch'];
NPC_DEFS.push(
  {id:'greta', name:'Hafenmeisterin Greta', x:122.5, y:313.6, wander:2, look:{skin:'#e0b090', hair:'#8a8a8a', outfit:'#2a4a6a', longHair:true, style:'leather', gem:'#3a8ad0'},
    talk() {
      if (questDone('rotbart')) return {text:P.f.schatzEhrlich ? '„Dank dir haben die Witwen der Ertrunkenen wieder Brot auf dem Tisch. Möwenhafen vergisst das nicht.“' : '„Rotbart ist tot. Das ist alles, was zählt… sage ich mir jedenfalls.“'};
      if (P.f.leuchtfeuer) return {text:'„Seit das Feuer wieder brennt, ist kein Schiff mehr aufgelaufen. Jetzt fehlt nur noch, dass jemand diesen verfluchten Rotbart erledigt.“'};
      return {text:'„Noch ein Fremder? Willkommen in Möwenhafen. Pass auf deinen Geldbeutel auf – und auf die Krabben.“'};
    }},
  {id:'hein', name:'Wirt Hein', at:['moewe', 3.5, 2.6], look:{skin:'#e8b896', hair:'#c8c8c8', outfit:'#6a4a2a', beard:true, bald:true, style:'cloth'}, shop:'hein', rich:2,
    talk() { return {text:pick(['„Rum, Bier oder Suppe? Bei mir gibt’s alles, was salzig ist.“', '„Hier ist jeder willkommen. Außer Rotbarts Leuten. Die müssen draußen saufen.“', '„Die Möwe hat schon drei Stürme überlebt. Und zwei Kneipenschlägereien mit Zwergen.“'])}; }},
  {id:'maren', name:'Fischerin Maren', x:107.5, y:320.6, wander:2, look:{skin:'#d8a070', hair:'#c8702a', outfit:'#3a6a6a', longHair:true, style:'cloth'}, shop:'maren', teach:{kochen:8},
    talk() {
      if (questDone('fischer')) return {text:'„Jan erzählt jedem, er hätte die Krabben allein verjagt. Ich lass ihn.“ Sie zwinkert dir zu.'};
      if (questActive('fischer')) return {text:'„Bitte beeil dich. Jan ist ein Dummkopf, aber er ist MEIN Dummkopf.“'};
      return {text:'„Frischer Fang! Na ja, frisch von gestern.“'};
    }},
  {id:'olaf', name:'Schiffbauer Olaf', x:129.5, y:320.6, wander:1, look:{skin:'#e8c0a0', hair:'#e8d070', outfit:'#5a4a3a', beard:true, style:'leather'},
    talk() {
      if (P.f.boot) return {text:'„Die <i>Neue Hoffnung</i> liegt am Steg. Sie bringt dich zum Leuchtturm oder zur Bucht – für zehn Gold.“', opts:boatOpts()};
      return {text:'„Ein Schiff braucht drei Dinge: gutes Holz, gutes Eisen und einen Narren, der damit aufs Meer fährt.“'};
    }},
  {id:'alwin', name:'Leuchtturmwärter Alwin', at:['leuchtturm', 3.5, 4.6], look:{skin:'#e0c0a0', hair:'#e8e8e8', outfit:'#3a4a5a', beard:true, style:'cloth'}, teach:{sammeln:9},
    talk() {
      if (P.f.leuchtfeuer) return {text:pick(['„Hörst du das Meer? Es klingt ruhiger, seit das Feuer brennt.“', '„Vierzig Jahre halte ich die Flamme. Und einmal hätte ich sie fast verloren. Danke.“'])};
      return {text:'„Das Licht ist aus. Zum ersten Mal seit vierzig Jahren. Und draußen sterben Seeleute.“'};
    }},
  {id:'jan', name:'Fischer Jan', x:96.5, y:292.6, look:{skin:'#d8a070', hair:'#5a3a1a', outfit:'#4a5a4a', beard:true, style:'cloth'},
    cond:() => questActive('fischer') && P.q.fischer.s <= 2,
    talk() { return {text:'„Endlich jemand! Die Krabben haben mich in diesen Schilfhaufen gejagt. Ich sitze hier seit zwei Tagen!“'}; }},
  {id:'durgan', name:'Durgan Glutbart', x:SOUTH.camp[0] + 1.5, y:SOUTH.camp[1] + 1.6, look:{skin:'#c8946a', hair:'#3a2a2a', outfit:'#4a3a3a', beard:true, style:'plate', metal:'#5a5a62', trim:'#f06020'}, shop:'durgan', smith:true, teach:{schmieden:12, bergbau:12},
    talk() {
      if (questDone('glut')) return {text:'„Der Koloss ist Schlacke. Und du hast eine Klinge, die heißer brennt als mein Temperament.“'};
      return {text:'„Was willst du hier, Langbein? Die Aschelande fressen jeden, der nicht aus Stein ist.“'};
    }}
);
function boatOpts() {
  const t = [['Alter Leuchtturm', [SOUTH.turm[0] + 0.5, SOUTH.turm[1] + 2.6]], ['Schmugglerbucht', [SOUTH.bucht[0] + 1.5, SOUTH.bucht[1] + 1.6]]];
  return t.map(([n, p]) => ({t:'⛵ ' + n + ' – 10 Gold', f:() => {
    if (P.gold < 10) return {text:'„Zehn Gold. Das Meer fährt man nicht umsonst.“'};
    P.gold -= 10; sfx('coin'); setTimeout(() => { P.mounted = false; teleport(p[0], p[1]); syncAllies(); toast('⛵ Olaf setzt dich ab: ' + n + '.', 'quest'); }, 60); return 'close';
  }})).concat([{t:'Tschüss'}]);
}
giver(NPC_DEFS.find(n => n.id === 'roderich'), ['kueste']);
giver(NPC_DEFS.find(n => n.id === 'greta'), ['leuchtfeuer', 'rotbart']);
giver(NPC_DEFS.find(n => n.id === 'hein'), ['krabbensuppe']);
giver(NPC_DEFS.find(n => n.id === 'maren'), ['fischer']);
giver(NPC_DEFS.find(n => n.id === 'olaf'), ['schiffbauer']);
giver(NPC_DEFS.find(n => n.id === 'durgan'), ['glut']);

// Neue Gefährtin
COMPS.nerina = {name:'Nerina', title:'Freibeuterin', cls:'kampf', hp:105, dmg:13, at:['moewe', 9.5, 4.6], cost:500, teach:{schloss:6},
  look:{skin:'#d8a880', hair:'#2a1a1a', outfit:'#7a1a2a', longHair:true, style:'leather', gem:'#e8c040', helmCol:'#c83a3a'}, likes:['rum', 'perle', 'wein'],
  bio:'„Nerina. Ich war Rotbarts Steuerfrau, bis ich gemerkt habe, dass er die Leute nicht nur ausraubt. Jetzt suche ich ein neues Schiff. Oder einen neuen Kapitän.“',
  lines:['„Land unter den Füßen macht mich nervös.“', '„Du kämpfst wie ein Sturm. Unordentlich, aber wirkungsvoll.“', '„Wenn das alles vorbei ist… segelst du mit mir? Nur wir zwei und der Horizont.“'],
  recruit:() => questDone('rotbart')};

// ---------- Quests ----------
Object.assign(QUEST_REQ, {
  kueste:() => P.lvl >= 6 || questDone('goblins'),
  leuchtfeuer:() => questDone('kueste'), rotbart:() => P.f.leuchtfeuer,
  krabbensuppe:() => true, fischer:() => true, schiffbauer:() => true,
  glut:() => P.lvl >= 16 || questDone('krieg')
});
Object.assign(QUESTS, {
  kueste:{name:'Ruf der Küste', giver:'Hauptmann Roderich', lvl:7, next:'leuchtfeuer', desc:'Seit Wochen kommt kein Fisch und keine Nachricht mehr aus Möwenhafen, dem Hafendorf weit im Süden hinter der Salzmarsch. Roderich will wissen, was dort los ist.', steps:[
    {t:'goto', region:'hafen', txt:'Reise nach Süden durch die Salzmarsch nach Möwenhafen.'},
    {t:'talk', npc:'greta', txt:'Sprich mit Hafenmeisterin Greta in Möwenhafen.', say:'„Aldenmark schickt endlich jemanden? Hah. Der Leuchtturm auf der Landzunge ist erloschen, seit Wochen. Drei Schiffe sind an den Klippen zerschellt – und kaum lagen sie im Wasser, kamen Rotbarts Piraten und haben die Wracks geplündert. Zufall? Ich glaube nicht an Zufälle.“'}],
    reward:{xp:500, gold:60, rep:4}},
  leuchtfeuer:{name:'Das erloschene Leuchtfeuer', giver:'Hafenmeisterin Greta', lvl:9, next:'rotbart', desc:'Ohne den Leuchtturm laufen die Schiffe auf. Der alte Wärter Alwin hockt im Turm westlich von Möwenhafen und rührt sich nicht mehr heraus.', steps:[
    {t:'talk', npc:'alwin', txt:'Besuche Leuchtturmwärter Alwin im Alten Leuchtturm (westlich vom Hafen).', say:'„Krabben, so groß wie Ochsen! Ihre Königin hat sich am Strand vor dem Turm eingenistet und meine Ölfässer zerschlagen. Ohne Öl kein Feuer. Ohne Feuer… na, du hast die Wracks gesehen.“'},
    {t:'kill', e:'krabbenkoenigin', n:1, txt:'Besiege die Krabbenkönigin am Strand vor dem Leuchtturm.', onDone:() => { addItem('lampenoel', 1); toast('🫙 In den Trümmern ihres Nests findest du einen unversehrten Ölkrug.', 'quest'); }},
    {t:'collect', item:'lampenoel', n:3, from:'krabbe', p:0.35, npc:'alwin', txt:'Sammle 3 Krüge Leuchtturm-Öl – die Krabben an der Küste haben sie verschleppt.', say:'Alwin gießt das Öl in die Lampe und reißt ein Streichholz an. Oben im Turm flammt ein Licht auf, so hell, dass du die Augen zusammenkneifen musst. „Da ist sie wieder“, flüstert er. „Meine alte Freundin.“',
      onDone:() => { const n = countItem('lampenoel'); if (n) removeItem('lampenoel', n); }}],
    reward:{xp:1100, gold:160, items:[['perle', 2]]},
    onDone:() => { P.f.leuchtfeuer = true; showScene('🗼', 'Über der Sturmküste kreist wieder das Licht des Leuchtturms.<br><br>In dieser Nacht sieht Greta vom Hafen aus ein Schiff, das sicher um die Klippen fährt – und weit draußen in der Schmugglerbucht ein Feuer, das hastig gelöscht wird.'); }},
  rotbart:{name:'Rotbarts letzte Fahrt', giver:'Hafenmeisterin Greta', lvl:11, desc:'Greta ist sicher: Rotbart hat den Leuchtturm sabotieren lassen, um die Wracks zu plündern. Sein Versteck liegt in der Schmugglerbucht im Südwesten.', steps:[
    {t:'goto', region:'bucht', txt:'Finde die Schmugglerbucht ganz im Südwesten der Sturmküste.'},
    {t:'kill', e:'pirat', n:5, txt:'Kämpfe dich durch Rotbarts Piraten (5).'},
    {t:'kill', e:'rotbart', n:1, txt:'Stelle Kapitän Rotbart in seinem Versteck.', onDone:() => { addItem('rotbartschatz', 1); toast('💰 Rotbarts Schatztruhe – voll mit Gold aus den Wracks.', 'gold'); }},
    {t:'branch', txt:'Bring Rotbarts Schatz zu Greta – oder behalte ihn.', opts:[
      {npc:'greta', need:'rotbartschatz', label:'⚖️ „Das gehört den Familien der Ertrunkenen.“', say:'Greta öffnet die Truhe und schweigt lange. „Das hätte keiner gemacht. Keiner.“ Sie wischt sich übers Gesicht. „Die Witwen bekommen ihr Gold. Und du bekommst das Bürgerrecht von Möwenhafen – auch wenn es nichts wert ist außer einem Freibier bei Hein.“',
        fn:() => { removeItem('rotbartschatz', 1); P.rep.karma += 10; P.rep.stadt += 6; P.f.schatzEhrlich = true; addItem('perlenring', 1); }},
      {npc:'greta', need:'rotbartschatz', label:'🤐 „Da war kein Schatz.“', say:'Greta mustert die schwere Tasche an deinem Gürtel. „Kein Schatz. Natürlich.“ Ihre Stimme ist kalt. „Rotbart ist tot. Das reicht wohl.“',
        fn:() => { removeItem('rotbartschatz', 1); P.gold += 900; P.rep.karma -= 12; P.f.schatzBehalten = true; }}]}],
    reward:{xp:1600, gold:150},
    onDone:() => toast('⚓ In der „Salzigen Möwe“ wartet jemand, der Rotbart sehr gut kannte…', 'quest')},
  krabbensuppe:{name:'Heins berühmte Krabbensuppe', giver:'Wirt Hein', lvl:8, desc:'Hein kocht die beste Krabbensuppe der Küste – wenn er denn Krabben hätte. Seit die Biester so groß sind, traut sich keiner mehr an den Strand.', steps:[
    {t:'collect', item:'krabbenfleisch', n:6, npc:'hein', txt:'Bring Wirt Hein 6 Krabbenfleisch (Riesenkrabben an Küste und Marsch).', say:'„Prächtig! Komm, ich zeig dir das Geheimnis: Kräuter erst ganz zum Schluss. Und niemals – NIEMALS – Rum in die Suppe. Nur in den Koch.“'}],
    reward:{xp:420, gold:50, items:[['krabbensuppe', 3]], prof:{kochen:1}}},
  fischer:{name:'Verloren in der Marsch', giver:'Fischerin Maren', lvl:7, desc:'Marens Mann Jan wollte in der Salzmarsch Reusen auslegen und ist nicht zurückgekommen.', steps:[
    {t:'goto', region:'marsch', txt:'Suche Jan in der Salzmarsch nördlich von Möwenhafen.'},
    {t:'talk', npc:'jan', txt:'Finde Jan im Schilf der Salzmarsch.', say:'„Die Krabben! Sie haben meine Reusen gefressen – mit Netz! Mach sie weg, dann renne ich heim, so schnell ich kann.“'},
    {t:'kill', e:'krabbe', n:4, txt:'Vertreibe die Riesenkrabben um Jan (4).'},
    {t:'talk', npc:'maren', txt:'Bring Maren die gute Nachricht.', say:'Jan stolpert hinter dir her und Maren fällt ihm um den Hals – um ihm danach kräftig gegen den Arm zu boxen. „Zwei Tage! Du Hornochse!“ Sie dreht sich zu dir. „Danke. Wirklich.“'}],
    reward:{xp:650, gold:80, items:[['krabbensuppe', 2]]}},
  schiffbauer:{name:'Die Neue Hoffnung', giver:'Schiffbauer Olaf', lvl:8, desc:'Olaf baut ein Boot, das zwischen Hafen, Leuchtturm und Bucht pendeln soll. Ihm fehlen Holz und Eisen.', steps:[
    {t:'collect', item:'holz', n:20, npc:'olaf', txt:'Bring Olaf 20 Holz (Palmen am Strand lassen sich fällen).', say:'„Gutes Holz! Na ja, Palmen. Aber gut genug.“'},
    {t:'collect', item:'eisenbarren', n:4, npc:'olaf', txt:'Bring Olaf 4 Eisenbarren für Nägel und Beschläge.', say:'Olaf hämmert drei Tage und drei Nächte. Dann liegt sie am Steg: ein schlankes Boot mit rotem Segel. „Die Neue Hoffnung. Du darfst sie jederzeit nehmen.“'}],
    reward:{xp:700, gold:100}, onDone:() => { P.f.boot = true; toast('⛵ Bootsfahrten: Olaf bringt dich jetzt zum Leuchtturm und zur Schmugglerbucht.', 'gold'); }},
  glut:{name:'Glut unter der Asche', giver:'Durgan Glutbart', lvl:20, desc:'Durgan sucht in den Aschelanden nach der verlorenen Glutschmiede seines Clans. Ein Koloss aus Stein und Feuer bewacht sie.', steps:[
    {t:'kill', e:'salamander', n:6, txt:'Jage 6 Glutsalamander in den Aschelanden.'},
    {t:'collect', item:'glutstein', n:5, npc:'durgan', txt:'Bring Durgan 5 Glutsteine (von Salamandern und Aschegolems).', say:'„Gute Steine. Heiß genug, um Mithril zu schmelzen. Aber die Schmiede – die liegt hinter dem Lavaring im Süden. Und dort wartet er.“'},
    {t:'kill', e:'glutkoloss', n:1, txt:'Besiege den Glutkoloss im Lavaring der Aschelande.'},
    {t:'talk', npc:'durgan', txt:'Kehre zu Durgan zurück.', say:'Durgan wiegt einen Brocken aus dem Herz des Kolosses in der Hand. Dann geht er zum Amboss. Als er dir die Klinge reicht, glüht sie noch. „Glutklinge. Die erste seit dreihundert Jahren. Pass auf, dass sie dir nicht die Scheide abfackelt.“'}],
    reward:{xp:4500, gold:600, items:[['glutklinge', 1]], prof:{schmieden:1}}}
});

// ---------- Ereignisse an der Küste ----------
STORY_EVENTS.push(
  {w:2, fn() {
    if (!COASTAL.includes(regionAt(P.x, P.y))) return;
    const s = freeSpot(4, 8); if (!s) return;
    const pool = [['rum', 2], ['muschel', 3], ['holz', 4], ['perle', 1], ['leder', 2], ['flaschenpost', 1], ['heiltrank', 2], ['eisenbarren', 2]];
    for (let k = 0; k < 3; k++) { const it = pick(pool); dropItem(s[0] + 0.5, s[1] + 0.5, it[0], rint(1, it[1])); }
    if (chance(0.15)) dropItem(s[0] + 0.5, s[1] + 0.5, 'schatzkarte', 1);
    burst(s[0] + 0.5, s[1] + 0.5, '#8ac8f0', 12); toast('🌊 Die Wellen haben Strandgut angespült!', 'quest');
  }},
  {w:1, fn() {
    if (!COASTAL.includes(regionAt(P.x, P.y))) return;
    const s = freeSpot(3, 6); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'matrose');
    G.tmp.push({id:'matrose', name:'Gestrandeter Matrose', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e0b090', hair:'#e8d070', outfit:'#3a5a8a', beard:true, style:'cloth'},
      talk() {
        if (this.done) return {text:'„Möge dir der Wind immer von hinten wehen!“'};
        return {text:'„Ahoi… Mein Schiff ist weg, mein Kapitän ist weg, und mein Durst ist schlimmer als beides. Ich hab nur noch diese alte Karte.“', opts:[
          {t:'🥃 Rum geben', f:() => { if (!countItem('rum')) return {text:'Du hast keinen Rum dabei.'}; removeItem('rum', 1); this.done = true; addItem('schatzkarte', 1); P.rep.karma += 2; return {text:'Er trinkt die Flasche in einem Zug leer. „Bei Neptuns Bart! Hier, nimm die Karte. Ich bin zu betrunken, um zu graben.“ (Du erhältst eine Schatzkarte.)'}; }},
          {t:'💰 50 Gold für die Karte', f:() => { if (P.gold < 50) return {text:'Du hast nicht genug Gold.'}; P.gold -= 50; this.done = true; addItem('schatzkarte', 1); return {text:'„Ein faires Geschäft. Fast.“ (Du erhältst eine Schatzkarte.)'}; }},
          {t:'Weitergehen'}]};
      }});
    refreshNpcs(); toast('⚓ Am Strand sitzt ein durchnässter Seemann…', 'quest');
  }},
  {w:1, fn() {
    if (regionAt(P.x, P.y) !== 'aschelande') return;
    const s = freeSpot(5, 9); if (!s) return;
    for (let k = 0; k < 4; k++) { const x = s[0] + rint(-1, 1), y = s[1] + rint(-1, 1); if (!inb(x, y) || BLOCK[WT[idx(x, y)]]) continue; const i = idx(x, y); WT[i] = chance(0.5) ? TL.MITHRIL : TL.CRYSTAL; G.mods[i] = {t:WT[i], r:-1}; }
    G.shake = 0.6; burst(s[0], s[1], '#ff8030', 30); toast('🌋 Die Erde bricht auf! Glühendes Gestein legt seltene Erze frei.', 'quest');
  }}
);

// ---------- Aussehen ----------
LOOK_STYLE.nerina = COMPS.nerina.look;
