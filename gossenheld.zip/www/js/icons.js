'use strict';
// ================= PIXEL-ICONS FÜR GEGENSTÄNDE =================
// Jeder Gegenstand bekommt ein eigenes 16×16-Pixelbild (statt Emoji).
const ICON_CACHE = {}, ICON_URL = {};
function iconCanvas(id) {
  if (ICON_CACHE[id]) return ICON_CACHE[id];
  const c = mkCanvas(16, 16), x = c.getContext('2d');
  const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  const def = ICON_DEF[id] || ['bag', {c:'#8a6a3a'}];
  try { ICON_DRAW[def[0]](R, def[1] || {}, x); } catch (e) { R(4, 4, 8, 8, '#f0f'); }
  addOutline(c, '#140c06');
  ICON_CACHE[id] = c; return c;
}
function iconURL(id) { if (!ICON_URL[id]) ICON_URL[id] = iconCanvas(id).toDataURL(); return ICON_URL[id]; }
function iconHTML(id) { return '<img class="pix" src="' + iconURL(id) + '" alt="">'; }
const L = (c, f) => shade(c, f);
const ICON_DRAW = {
  log(R) { R(2, 6, 11, 5, '#7a4a22'); R(2, 6, 11, 1, '#9a6232'); R(2, 10, 11, 1, '#5a3418'); R(12, 5, 3, 7, '#c89a5a'); R(13, 7, 1, 3, '#9a6a3a'); R(4, 8, 3, 1, '#5a3418'); R(8, 7, 2, 1, '#5a3418'); },
  stone(R) { R(3, 6, 10, 7, '#7a7a80'); R(4, 5, 7, 1, '#8d8d92'); R(4, 6, 6, 3, '#a6a6ad'); R(5, 6, 2, 1, '#c4c4ca'); R(3, 12, 10, 1, '#5a5a60'); },
  ore(R, o) { ICON_DRAW.stone(R); R(5, 8, 2, 2, o.c); R(9, 7, 2, 1, o.c); R(8, 10, 2, 2, o.c); R(5, 8, 1, 1, L(o.c, 0.4)); R(9, 7, 1, 1, L(o.c, 0.4)); },
  ingot(R, o) { R(2, 9, 12, 4, L(o.c, -0.3)); R(3, 7, 10, 2, o.c); R(4, 7, 8, 1, L(o.c, 0.35)); R(2, 9, 12, 1, L(o.c, 0.15)); R(4, 11, 3, 1, L(o.c, 0.2)); },
  gem(R, o) { R(6, 2, 4, 2, L(o.c, 0.4)); R(4, 4, 8, 3, o.c); R(5, 7, 6, 3, L(o.c, -0.15)); R(6, 10, 4, 2, L(o.c, -0.35)); R(7, 12, 2, 2, L(o.c, -0.5)); R(6, 4, 2, 2, '#ffffff'); },
  herb(R) { R(7, 6, 2, 8, '#3a7a2a'); R(3, 7, 4, 3, '#4f9a3f'); R(9, 5, 4, 3, '#4f9a3f'); R(4, 10, 3, 2, '#3f8a32'); R(10, 9, 3, 2, '#3f8a32'); R(4, 7, 2, 1, '#7ad06a'); R(10, 5, 2, 1, '#7ad06a'); R(6, 3, 1, 1, '#f6f4e0'); R(8, 2, 2, 2, '#f6f4e0'); R(11, 3, 1, 1, '#f6f4e0'); },
  mushroom(R) { R(6, 9, 4, 5, '#efe6d0'); R(6, 13, 4, 1, '#c8bca0'); R(2, 5, 12, 4, '#c83a2a'); R(4, 3, 8, 2, '#c83a2a'); R(3, 8, 10, 1, '#8a2418'); R(5, 4, 2, 2, '#fff'); R(10, 6, 2, 1, '#fff'); R(3, 6, 1, 1, '#fff'); },
  meat(R) { R(3, 4, 9, 9, '#c84a4a'); R(4, 3, 7, 1, '#c84a4a'); R(4, 5, 6, 6, '#e06a6a'); R(5, 6, 2, 2, '#f4dada'); R(8, 9, 2, 1, '#f4dada'); R(11, 10, 4, 2, '#f0ead8'); R(14, 9, 1, 4, '#f0ead8'); },
  cooked(R) { R(2, 3, 8, 8, '#8a4a1a'); R(3, 4, 6, 5, '#b86a2a'); R(4, 4, 2, 2, '#e09a4a'); R(8, 9, 2, 2, '#8a4a1a'); R(9, 10, 3, 2, '#f0ead8'); R(12, 9, 2, 2, '#f0ead8'); R(12, 12, 2, 2, '#f0ead8'); },
  fur(R) { R(3, 3, 10, 10, '#8a7058'); R(1, 5, 2, 2, '#8a7058'); R(13, 5, 2, 2, '#8a7058'); R(1, 11, 2, 2, '#8a7058'); R(13, 11, 2, 2, '#8a7058'); R(5, 5, 6, 6, '#a88a6a'); R(6, 6, 2, 1, '#c4a888'); R(6, 13, 4, 2, '#8a7058'); },
  leather(R) { R(2, 3, 12, 10, '#a8743c'); R(3, 4, 10, 8, '#c08a4a'); for (let k = 3; k < 13; k += 2) { R(k, 3, 1, 1, '#6a4422'); R(k, 12, 1, 1, '#6a4422'); } R(4, 6, 8, 1, '#a8743c'); },
  bone(R) { R(3, 11, 2, 2, '#f0ead8'); R(2, 10, 2, 2, '#f0ead8'); R(4, 9, 8, 2, '#e4dcc4'); R(5, 8, 7, 1, '#f0ead8'); R(11, 4, 2, 2, '#f0ead8'); R(12, 5, 2, 2, '#f0ead8'); R(10, 5, 2, 4, '#e4dcc4'); },
  scale(R) { R(4, 3, 8, 3, '#c83a1a'); R(3, 6, 10, 4, '#a82a12'); R(5, 10, 6, 2, '#8a1a0a'); R(7, 12, 2, 2, '#6a1006'); R(5, 4, 3, 2, '#f08a4a'); R(4, 7, 2, 1, '#e86a3a'); },
  flower(R) { R(7, 8, 2, 7, '#3f8a32'); R(9, 11, 3, 2, '#4f9a3f'); R(6, 2, 4, 2, '#f06aa0'); R(4, 4, 8, 3, '#f06aa0'); R(6, 7, 4, 1, '#d04a80'); R(7, 4, 2, 2, '#f8e070'); },
  bottle(R, o) { R(7, 1, 2, 2, '#8a5a2a'); R(7, 3, 2, 3, L(o.c, -0.2)); R(5, 6, 6, 8, o.c); R(4, 7, 8, 6, o.c); R(5, 8, 1, 4, L(o.c, 0.4)); R(5, 9, 6, 3, '#e8dcb0'); R(6, 10, 4, 1, '#a08a50'); },
  book(R, o) { R(3, 2, 10, 12, o.c); R(3, 2, 2, 12, L(o.c, -0.35)); R(12, 3, 1, 10, '#f0e8d0'); R(6, 4, 5, 2, '#d8b040'); R(6, 9, 4, 1, L(o.c, 0.3)); R(3, 13, 10, 1, L(o.c, -0.45)); },
  ring(R) { R(4, 6, 8, 2, '#c8ccd8'); R(3, 8, 2, 4, '#c8ccd8'); R(11, 8, 2, 4, '#9a9eaa'); R(4, 12, 8, 2, '#9a9eaa'); R(6, 2, 4, 4, '#3ac8f0'); R(7, 3, 1, 1, '#fff'); },
  bread(R) { R(2, 7, 12, 6, '#a8642a'); R(3, 5, 10, 2, '#c8823a'); R(4, 4, 8, 1, '#c8823a'); R(4, 6, 2, 1, '#f0c070'); R(7, 5, 2, 1, '#f0c070'); R(10, 6, 2, 1, '#f0c070'); R(2, 12, 12, 1, '#7a4418'); },
  mug(R) { R(3, 4, 8, 10, '#9a6a3a'); R(3, 6, 8, 1, '#5a3a1a'); R(3, 11, 8, 1, '#5a3a1a'); R(11, 6, 3, 1, '#9a6a3a'); R(13, 6, 1, 5, '#9a6a3a'); R(11, 10, 3, 1, '#9a6a3a'); R(2, 2, 10, 3, '#f8f4e8'); R(4, 1, 5, 1, '#f8f4e8'); R(4, 7, 6, 4, '#e8b030'); },
  bowl(R) { R(3, 4, 4, 2, '#e8e8f0'); R(9, 3, 3, 3, '#e8e8f0'); R(2, 7, 12, 2, '#8a5a2a'); R(3, 9, 10, 3, '#a8743c'); R(5, 12, 6, 2, '#8a5a2a'); R(3, 7, 10, 1, '#b8642a'); R(5, 7, 2, 1, '#6aa04a'); R(9, 7, 2, 1, '#e0a040'); },
  feast(R) { R(1, 11, 14, 3, '#c8ccd8'); R(2, 13, 12, 1, '#8a8e9a'); R(3, 5, 9, 6, '#b86a2a'); R(4, 4, 7, 1, '#b86a2a'); R(5, 5, 3, 2, '#e09a4a'); R(12, 4, 2, 3, '#f0ead8'); R(2, 8, 1, 3, '#f0ead8'); R(10, 9, 2, 2, '#6aa04a'); },
  potion(R, o) { const s = o.big ? 1 : 0; R(7, 1, 2, 2, '#8a5a2a'); R(6, 3, 4, 2, '#c8e0f0'); R(4 - s, 5, 8 + 2 * s, 8 + s, '#c8e0f0'); R(5 - s, 7, 6 + 2 * s, 6 + s, o.c); R(5 - s, 7, 6 + 2 * s, 1, L(o.c, 0.35)); R(6, 9, 1, 2, '#ffffff'); if (o.big) R(5, 14, 6, 1, '#c8e0f0'); },
  arrows(R) { for (const o of [-3, 0, 3]) { for (let i = 1; i < 9; i++) R(3 + i + o, 12 - i + o, 1, 1, '#9a6a3a'); R(11 + o, 3 + o, 2, 1, '#c8ccd8'); R(12 + o, 3 + o, 1, 2, '#c8ccd8'); R(12 + o, 2 + o, 1, 1, '#ffffff'); R(2 + o, 12 + o, 2, 1, '#e8e8e8'); R(3 + o, 13 + o, 1, 1, '#c83a3a'); } },
  tool_axe(R) { for (let i = 0; i < 10; i++) R(3 + i, 13 - i, 2, 1, '#8a5a2a'); R(9, 2, 5, 5, '#a8acb8'); R(13, 2, 1, 5, '#e8ecf4'); R(9, 3, 1, 3, '#7a7e8a'); },
  tool_pick(R) { for (let i = 0; i < 10; i++) R(3 + i, 13 - i, 2, 1, '#8a5a2a'); R(6, 2, 8, 2, '#a8acb8'); R(5, 3, 2, 2, '#a8acb8'); R(13, 3, 2, 3, '#a8acb8'); R(4, 4, 2, 2, '#e8ecf4'); R(14, 6, 1, 1, '#e8ecf4'); },
  pan(R) { R(2, 6, 9, 6, '#4a4a52'); R(3, 7, 7, 4, '#6a6a74'); R(4, 8, 2, 1, '#9a9aa4'); R(11, 8, 4, 2, '#5a3a1a'); },
  lockpick(R) { R(2, 12, 3, 3, '#8a8e9a'); R(4, 4, 1, 9, '#c8ccd8'); R(4, 3, 3, 1, '#c8ccd8'); R(9, 2, 1, 11, '#9a9eaa'); R(9, 2, 3, 1, '#9a9eaa'); R(11, 3, 1, 2, '#9a9eaa'); R(8, 12, 3, 3, '#8a6a3a'); },
  sword(R, o) {
    const len = o.len || 9, b = o.c || '#c8ccd8', g = o.g || '#c8a040';
    for (let i = 0; i < len; i++) { R(4 + i, 11 - i, 2, 2, b); R(5 + i, 11 - i, 1, 1, L(b, 0.45)); }
    R(4 + len, 11 - len, 1, 1, L(b, 0.3)); R(2, 9, 5, 2, g); R(4, 11, 2, 2, g); R(1, 13, 3, 2, '#5a3a1a'); R(0, 15, 2, 1, g);
    if (o.gem) R(4, 10, 1, 1, o.gem);
  },
  knife(R) { for (let i = 0; i < 5; i++) R(7 + i, 9 - i, 2, 2, '#9a7a5a'); R(8, 8, 1, 1, '#b89a7a'); R(12, 4, 1, 1, '#9a7a5a'); R(5, 9, 4, 2, '#5a4a3a'); R(3, 11, 3, 3, '#6a4422'); R(10, 7, 1, 1, '#7a4a2a'); },
  waraxe(R) { for (let i = 0; i < 12; i++) R(2 + i, 14 - i, 2, 1, '#6a4422'); R(8, 1, 6, 7, '#a8acb8'); R(13, 1, 2, 7, '#e8ecf4'); R(8, 2, 1, 5, '#7a7e8a'); R(6, 3, 3, 3, '#a8acb8'); },
  bow(R, o) {
    const w = o.c || '#8a5a2a';
    R(3, 1, 2, 2, w); R(5, 3, 2, 2, w); R(7, 5, 2, 2, w); R(9, 7, 2, 2, w); R(7, 9, 2, 2, w); R(5, 11, 2, 2, w); R(3, 13, 2, 2, w);
    R(8, 6, 1, 4, o.g || '#c8a040');
    for (let i = 0; i < 13; i++) R(3, 2 + i, 1, 1, '#e8e8e8');
    if (o.gem) { R(3, 1, 1, 1, o.gem); R(3, 14, 1, 1, o.gem); }
  },
  staff(R, o) {
    for (let i = 0; i < 11; i++) R(2 + i, 14 - i, 2, 1, o.w || '#6a4422');
    if (o.gem) { R(10, 1, 5, 5, L(o.gem, -0.3)); R(11, 1, 3, 4, o.gem); R(11, 1, 1, 2, '#ffffff'); }
    else { R(11, 2, 3, 2, o.w || '#6a4422'); R(13, 1, 2, 2, '#3a7a2a'); R(10, 1, 2, 1, '#4f9a3f'); }
  },
  armor(R, o) {
    const c = o.c, d = L(c, -0.3), l = L(c, 0.3);
    R(3, 3, 10, 11, c); R(1, 4, 3, 5, c); R(12, 4, 3, 5, c); R(6, 2, 4, 2, d);
    R(1, 8, 3, 1, d); R(12, 8, 3, 1, d); R(3, 13, 10, 1, d);
    if (o.t === 'robe') { R(2, 12, 12, 3, c); R(7, 4, 2, 10, d); R(6, 8, 4, 1, o.a || '#d8b040'); }
    if (o.t === 'cloth') { R(5, 6, 1, 1, d); R(10, 9, 2, 1, d); R(3, 13, 2, 1, '#000'); R(9, 3, 1, 2, d); }
    if (o.t === 'leather') { R(3, 9, 10, 1, '#4a2a12'); R(7, 9, 2, 1, '#c8a040'); R(5, 5, 1, 3, d); R(10, 5, 1, 3, d); }
    if (o.t === 'chain') for (let y = 4; y < 13; y++) for (let k = 3 + (y % 2); k < 13; k += 2) R(k, y, 1, 1, l);
    if (o.t === 'plate') { R(4, 4, 8, 4, l); R(5, 5, 6, 1, '#ffffff'); R(3, 9, 10, 1, d); R(1, 4, 3, 2, l); R(12, 4, 3, 2, l); }
    if (o.t === 'dragon') { for (let y = 4; y < 13; y += 2) for (let k = 3 + (y % 4 ? 1 : 0); k < 13; k += 3) R(k, y, 2, 1, l); R(6, 6, 4, 3, '#f0a030'); }
    if (o.t === 'mithril') { R(4, 4, 8, 4, l); R(7, 4, 2, 9, '#ffffff'); R(3, 9, 10, 1, d); }
  },
  quiver(R, o) {
    const s = o.size || 1, c = o.c || '#8a5a2a';
    const h = 7 + s * 2, y0 = 15 - h;
    for (let k = 0; k < 2 + s; k++) { R(5 + k * 2, y0 - 3, 1, 3, '#8a5a2a'); R(4 + k * 2, y0 - 4, 3, 2, '#e8e8e8'); }
    R(4, y0, 4 + s * 2, h, c); R(4, y0, 4 + s * 2, 1, L(c, 0.3)); R(4, y0 + h - 2, 4 + s * 2, 1, L(c, -0.35));
    if (o.g) R(5, y0 + 2, 2 + s * 2, 1, o.g);
    R(3 + s * 2 + 4, y0 + 1, 1, h - 2, '#5a3a1a');
  },
  bag(R, o) {
    const s = o.size || 1, c = o.c || '#8a6a3a', w = 6 + s * 2, h = 6 + s, x0 = 8 - w / 2, y0 = 14 - h;
    R(x0, y0, w, h, c); R(x0 + 1, y0 - 1, w - 2, 1, c); R(x0, y0 + h - 1, w, 1, L(c, -0.35));
    R(6, y0 - 4, 4, 1, L(c, -0.25)); R(5, y0 - 3, 1, 3, L(c, -0.25)); R(10, y0 - 3, 1, 3, L(c, -0.25));
    R(x0 + 1, y0 + 1, w - 2, 2, L(c, 0.2));
    if (s >= 2) R(7, y0 + 3, 2, 2, o.g || '#c8a040');
    if (o.glow) { R(6, y0 + 3, 4, 3, o.glow); R(7, y0 + 4, 1, 1, '#ffffff'); }
  },
  amulet(R, o) { for (let i = 0; i < 5; i++) { R(3 + i, 2 + i, 1, 1, '#c8a040'); R(12 - i, 2 + i, 1, 1, '#c8a040'); } R(5, 7, 6, 6, '#c8a040'); R(6, 8, 4, 4, o.c || '#3a8ad0'); R(7, 9, 1, 1, '#ffffff'); },
  coin(R) { R(4, 3, 8, 10, '#c8a040'); R(3, 4, 10, 8, '#c8a040'); R(5, 4, 6, 8, '#e8c860'); R(7, 5, 2, 6, '#a8801a'); R(5, 4, 2, 1, '#fff6c0'); },
  seal(R) { R(2, 6, 12, 7, '#e8c040'); R(2, 3, 2, 3, '#e8c040'); R(7, 2, 2, 4, '#e8c040'); R(12, 3, 2, 3, '#e8c040'); R(2, 12, 12, 1, '#a8801a'); R(5, 8, 2, 2, '#c83a3a'); R(9, 8, 2, 2, '#3a8ad0'); R(3, 7, 10, 1, '#fff6c0'); },
  saddle(R, o) { const c = o.c; R(2, 9, 12, 3, '#a8282a'); R(2, 11, 12, 1, '#e8c040'); R(4, 5, 8, 4, c); R(3, 4, 2, 2, c); R(11, 3, 2, 3, c); R(5, 5, 5, 1, shade(c, 0.35)); R(7, 12, 1, 2, '#3a2a1a'); R(6, 14, 3, 1, '#a8acb8'); if (o.g) { R(4, 7, 8, 1, o.g); R(11, 3, 2, 1, o.g); } },
  barding(R, o) { const c = o.c, l = shade(c, 0.35), d = shade(c, -0.3); R(2, 5, 12, 6, c); R(3, 4, 10, 1, l); for (let k = 3; k < 13; k += 3) R(k, 5, 2, 5, l); R(2, 10, 12, 1, d); R(1, 11, 2, 3, c); R(13, 11, 2, 3, c); R(6, 11, 4, 2, d); R(7, 7, 2, 2, '#ffffff'); },
  ledger(R) { R(3, 2, 10, 12, '#6a4a2a'); R(4, 3, 8, 10, '#f0e8d0'); for (let k = 5; k < 12; k += 2) R(5, k, 6, 1, '#8a7a5a'); R(3, 2, 1, 12, '#4a3018'); }
};
const ICON_DEF = {
  holz:['log'], stein:['stone'], eisenerz:['ore', {c:'#c8783a'}], silbererz:['ore', {c:'#e8eef6'}], mithrilerz:['ore', {c:'#3ac8f0'}],
  eisenbarren:['ingot', {c:'#8a8e9a'}], silberbarren:['ingot', {c:'#d8dce8'}], mithrilbarren:['ingot', {c:'#4ac0e0'}],
  kristall:['gem', {c:'#5ad0f0'}], schattenkristall:['gem', {c:'#8a3ad0'}], kraut:['herb'], pilz:['mushroom'],
  fleisch:['meat'], fell:['fur'], leder:['leather'], knochen:['bone'], schuppe:['scale'], blume:['flower'],
  wein:['bottle', {c:'#7a1a4a'}], buch:['book', {c:'#3a5a9a'}], ring:['ring'], rechnungsbuch:['ledger'],
  brot:['bread'], bier:['mug'], gebraten:['cooked'], eintopf:['bowl'], festmahl:['feast'],
  heiltrank:['potion', {c:'#d83a3a'}], grheiltrank:['potion', {c:'#e01a5a', big:true}], manatrank:['potion', {c:'#3a6ae0'}],
  pfeile:['arrows'], axt:['tool_axe'], spitzhacke:['tool_pick'], kochset:['pan'], dietrich:['lockpick'],
  messer:['knife'], kurzschwert:['sword', {len:6}], eisenschwert:['sword', {len:9}], kriegsaxt:['waraxe'],
  silberschwert:['sword', {len:9, c:'#eef2fa', g:'#e8e8f0', gem:'#3a8ad0'}], mithrilklinge:['sword', {len:10, c:'#7ad8f4', g:'#c8a040'}],
  drachentoeter:['sword', {len:10, c:'#e8603a', g:'#2a2a2a', gem:'#f0d040'}],
  kurzbogen:['bow', {c:'#8a5a2a'}], langbogen:['bow', {c:'#6a4422', g:'#3a6a2a'}], elfenbogen:['bow', {c:'#e8d070', g:'#3a8a3a', gem:'#7ae04a'}], mithrilbogen:['bow', {c:'#7ad8f4', g:'#c8a040', gem:'#ffffff'}],
  knorrstab:['staff'], pilgerstab:['staff', {w:'#c8a870', gem:'#f8e8a0'}], kristallstab:['staff', {gem:'#5ad0f0'}], arkanstab:['staff', {w:'#3a2a4a', gem:'#a04af0'}], sternenstab:['staff', {w:'#e8e8f0', gem:'#f8e070'}],
  lumpen:['armor', {c:'#7a6a58', t:'cloth'}], robe:['armor', {c:'#c8b898', t:'robe', a:'#8a6a3a'}], lederruestung:['armor', {c:'#8a5a32', t:'leather'}],
  magierrobe:['armor', {c:'#3a3aa0', t:'robe'}], kettenhemd:['armor', {c:'#7a7e8a', t:'chain'}], plattenruestung:['armor', {c:'#9a9eaa', t:'plate'}],
  mithrilruestung:['armor', {c:'#5ab8d8', t:'mithril'}], drachenruestung:['armor', {c:'#9a2a1a', t:'dragon'}],
  koecher_klein:['quiver', {size:0, c:'#8a6a4a'}], koecher:['quiver', {size:1, c:'#8a5a2a'}], koecher_gross:['quiver', {size:2, c:'#6a3a1a', g:'#c8ccd8'}], elfenkoecher:['quiver', {size:3, c:'#3a6a2a', g:'#e8d070'}],
  beutel:['bag', {size:0, c:'#a89878'}], rucksack:['bag', {size:1, c:'#8a5a2a'}], grosser_rucksack:['bag', {size:2, c:'#7a4a22'}], packtasche:['bag', {size:3, c:'#5a4a2a', g:'#c8ccd8'}], dimensionsbeutel:['bag', {size:2, c:'#3a2a6a', glow:'#a04af0'}],
  sattel:['saddle', {c:'#6a3a1a'}], kampfsattel:['saddle', {c:'#4a2a12', g:'#a8acb8'}], koenigssattel:['saddle', {c:'#7a1a2a', g:'#e8c040'}],
  tierlederpanzer:['barding', {c:'#8a5a32'}], tiereisenpanzer:['barding', {c:'#8a8e9a'}], tiersilberpanzer:['barding', {c:'#d0d4e0'}], tiermithrilpanzer:['barding', {c:'#4ab0d0'}],
  amulett:['amulet', {c:'#3ab06a'}], glueckstaler:['coin'], koenigssiegel:['seal']
};
// Nach dem Laden: alle Emoji-Icons der Gegenstände durch Pixelbilder ersetzen
function installItemIcons() { for (const id in ITEMS) { ITEMS[id].emoji = ITEMS[id].icon; ITEMS[id].icon = iconHTML(id); } }
installItemIcons();
