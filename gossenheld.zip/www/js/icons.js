'use strict';
// ================= PIXEL-ICONS FÜR GEGENSTÄNDE =================
// Jeder Gegenstand bekommt ein eigenes 16×16-Pixelbild (statt Emoji).
const ICON_CACHE = {}, ICON_URL = {};
function iconCanvas(id) {
  if (ICON_CACHE[id]) return ICON_CACHE[id];
  const c = mkCanvas(16, 16), x = c.getContext('2d');
  const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  const def = ICON_DEF[id] || ['bag', {c:'#8a6a3a'}];
  try { ICON_DRAW[def[0]](R, def[1] || {}, x); } catch (e) { R(4, 4, 8, 8, '#f0f'); }
  addOutline(c, '#140c06');
  ICON_CACHE[id] = c; return c;
}
function iconURL(id) { if (!ICON_URL[id]) ICON_URL[id] = iconCanvas(id).toDataURL(); return ICON_URL[id]; }
function iconHTML(id) { return '<img class="pix" src="' + iconURL(id) + '" alt="">'; }
const L = (c, f) => shade(c, f);
const ICON_DRAW = {
  log(R) { R(2, 6, 11, 5, '#7a4a22'); R(2, 6, 11, 1, '#9a6232'); R(2, 10, 11, 1, '#5a3418'); R(12, 5, 3, 7, '#c89a5a'); R(13, 7, 1, 3, '#9a6a3a'); R(4, 8, 3, 1, '#5a3418'); R(8, 7, 2, 1, '#5a3418'); },
  stone(R) { R(3, 6, 10, 7, '#7a7a80'); R(4, 5, 7, 1, '#8d8d92'); R(4, 6, 6, 3, '#a6a6ad'); R(5, 6, 2, 1, '#c4c4ca'); R(3, 12, 10, 1, '#5a5a60'); },
  ore(R, o) { ICON_DRAW.stone(R); R(5, 8, 2, 2, o.c); R(9, 7, 2, 1, o.c); R(8, 10, 2, 2, o.c); R(5, 8, 1, 1, L(o.c, 0.4)); R(9, 7, 1, 1, L(o.c, 0.4)); },
  ingot(R, o) { R(2, 9, 12, 4, L(o.c, -0.3)); R(3, 7, 10, 2, o.c); R(4, 7, 8, 1, L(o.c, 0.35)); R(2, 9, 12, 1, L(o.c, 0.15)); R(4, 11, 3, 1, L(o.c, 0.2)); },
  gem(R, o) { R(6, 2, 4, 2, L(o.c, 0.4)); R(4, 4, 8, 3, o.c); R(5, 7, 6, 3, L(o.c, -0.15)); R(6, 10, 4, 2, L(o.c, -0.35)); R(7, 12, 2, 2, L(o.c, -0.5)); R(6, 4, 2, 2, '#ffffff'); },
  herb(R) { R(7, 6, 2, 8, '#3a7a2a'); R(3, 7, 4, 3, '#4f9a3f'); R(9, 5, 4, 3, '#4f9a3f'); R(4, 10, 3, 2, '#3f8a32'); R(10, 9, 3, 2, '#3f8a32'); R(4, 7, 2, 1, '#7ad06a'); R(10, 5, 2, 1, '#7ad06a'); R(6, 3, 1, 1, '#f6f4e0'); R(8, 2, 2, 2, '#f6f4e0'); R(11, 3, 1, 1, '#f6f4e0'); },
  mushroom(R) { R(6, 9, 4, 5, '#efe6d0'); R(6, 13, 4, 1, '#c8bca0'); R(2, 5, 12, 4, '#c83a2a'); R(4, 3, 8, 2, '#c83a2a'); R(3, 8, 10, 1, '#8a2418'); R(5, 4, 2, 2, '#fff'); R(10, 6, 2, 1, '#fff'); R(3, 6, 1, 1, '#fff'); },
  meat(R) { R(3, 4, 9, 9, '#c84a4a'); R(4, 3, 7, 1, '#c84a4a'); R(4, 5, 6, 6, '#e06a6a'); R(5, 6, 2, 2, '#f4dada'); R(8, 9, 2, 1, '#f4dada'); R(11, 10, 4, 2, '#f0ead8'); R(14, 9, 1, 4, '#f0ead8'); },
  cooked(R) { R(2, 3, 8, 8, '#8a4a1a'); R(3, 4, 6, 5, '#b86a2a'); R(4, 4, 2, 2, '#e09a4a'); R(8, 9, 2, 2, '#8a4a1a'); R(9, 10, 3, 2, '#f0ead8'); R(12, 9, 2, 2, '#f0ead8'); R(12, 12, 2, 2, '#f0ead8'); },
  fur(R) { R(3, 3, 10, 10, '#8a7058'); R(1, 5, 2, 2, '#8a7058'); R(13, 5, 2, 2, '#8a7058'); R(1, 11, 2, 2, '#8a7058'); R(13, 11, 2, 2, '#8a7058'); R(5, 5, 6, 6, '#a88a6a'); R(6, 6, 2, 1, '#c4a888'); R(6, 13, 4, 2, '#8a7058'); },
  leather(R) { R(2, 3, 12, 10, '#a8743c'); R(3, 4, 10, 8, '#c08a4a'); for (let k = 3; k < 13; k += 2) { R(k, 3, 1, 1, '#6a4422'); R(k, 12, 1, 1, '#6a4422'); } R(4, 6, 8, 1, '#a8743c'); },
  bone(R) { R(3, 11, 2, 2, '#f0ead8'); R(2, 10, 2, 2, '#f0ead8'); R(4, 9, 8, 2, '#e4dcc4'); R(5, 8, 7, 1, '#f0ead8'); R(11, 4, 2, 2, '#f0ead8'); R(12, 5, 2, 2, '#f0ead8'); R(10, 5, 2, 4, '#e4dcc4'); },
  scale(R) { R(4, 3, 8, 3, '#c83a1a'); R(3, 6, 10, 4, '#a82a12'); R(5, 10, 6, 2, '#8a1a0a'); R(7, 12, 2, 2, '#6a1006'); R(5, 4, 3, 2, '#f08a4a'); R(4, 7, 2, 1, '#e86a3a'); },
  flower(R) { R(7, 8, 2, 7, '#3f8a32'); R(9, 11, 3, 2, '#4f9a3f'); R(6, 2, 4, 2, '#f06aa0'); R(4, 4, 8, 3, '#f06aa0'); R(6, 7, 4, 1, '#d04a80'); R(7, 4, 2, 2, '#f8e070'); },
  bottle(R, o) { R(7, 1, 2, 2, '#8a5a2a'); R(7, 3, 2, 3, L(o.c, -0.2)); R(5, 6, 6, 8, o.c); R(4, 7, 8, 6, o.c); R(5, 8, 1, 4, L(o.c, 0.4)); R(5, 9, 6, 3, '#e8dcb0'); R(6, 10, 4, 1, '#a08a50'); },
  book(R, o) { R(3, 2, 10, 12, o.c); R(3, 2, 2, 12, L(o.c, -0.35)); R(12, 3, 1, 10, '#f0e8d0'); R(6, 4, 5, 2, '#d8b040'); R(6, 9, 4, 1, L(o.c, 0.3)); R(3, 13, 10, 1, L(o.c, -0.45)); },
  ring(R, o) { const m = o.metal || '#c8ccd8'; R(4, 6, 8, 2, m); R(3, 8, 2, 4, m); R(11, 8, 2, 4, shade(m, -0.25)); R(4, 12, 8, 2, shade(m, -0.25)); R(6, 2, 4, 4, o.gem || '#3ac8f0'); R(7, 3, 1, 1, '#fff'); },
  letter(R, o) { R(1, 4, 14, 9, '#f0e8d0'); R(1, 12, 14, 1, '#c8bc9c'); for (let i = 0; i < 7; i++) { R(1 + i, 4 + i * 0.7 | 0, 1, 1, '#c8bc9c'); R(14 - i, 4 + i * 0.7 | 0, 1, 1, '#c8bc9c'); } R(6, 8, 4, 3, o.seal); R(7, 8, 1, 1, shade(o.seal, 0.4)); if (o.dark) R(2, 5, 12, 1, '#3a3a3a'); },
  bread(R) { R(2, 7, 12, 6, '#a8642a'); R(3, 5, 10, 2, '#c8823a'); R(4, 4, 8, 1, '#c8823a'); R(4, 6, 2, 1, '#f0c070'); R(7, 5, 2, 1, '#f0c070'); R(10, 6, 2, 1, '#f0c070'); R(2, 12, 12, 1, '#7a4418'); },
  mug(R) { R(3, 4, 8, 10, '#9a6a3a'); R(3, 6, 8, 1, '#5a3a1a'); R(3, 11, 8, 1, '#5a3a1a'); R(11, 6, 3, 1, '#9a6a3a'); R(13, 6, 1, 5, '#9a6a3a'); R(11, 10, 3, 1, '#9a6a3a'); R(2, 2, 10, 3, '#f8f4e8'); R(4, 1, 5, 1, '#f8f4e8'); R(4, 7, 6, 4, '#e8b030'); },
  bowl(R) { R(3, 4, 4, 2, '#e8e8f0'); R(9, 3, 3, 3, '#e8e8f0'); R(2, 7, 12, 2, '#8a5a2a'); R(3, 9, 10, 3, '#a8743c'); R(5, 12, 6, 2, '#8a5a2a'); R(3, 7, 10, 1, '#b8642a'); R(5, 7, 2, 1, '#6aa04a'); R(9, 7, 2, 1, '#e0a040'); },
  feast(R) { R(1, 11, 14, 3, '#c8ccd8'); R(2, 13, 12, 1, '#8a8e9a'); R(3, 5, 9, 6, '#b86a2a'); R(4, 4, 7, 1, '#b86a2a'); R(5, 5, 3, 2, '#e09a4a'); R(12, 4, 2, 3, '#f0ead8'); R(2, 8, 1, 3, '#f0ead8'); R(10, 9, 2, 2, '#6aa04a'); },
  potion(R, o) { const s = o.big ? 1 : 0; R(7, 1, 2, 2, '#8a5a2a'); R(6, 3, 4, 2, '#c8e0f0'); R(4 - s, 5, 8 + 2 * s, 8 + s, '#c8e0f0'); R(5 - s, 7, 6 + 2 * s, 6 + s, o.c); R(5 - s, 7, 6 + 2 * s, 1, L(o.c, 0.35)); R(6, 9, 1, 2, '#ffffff'); if (o.big) R(5, 14, 6, 1, '#c8e0f0'); },
  arrows(R) { for (const o of [-3, 0, 3]) { for (let i = 1; i < 9; i++) R(3 + i + o, 12 - i + o, 1, 1, '#9a6a3a'); R(11 + o, 3 + o, 2, 1, '#c8ccd8'); R(12 + o, 3 + o, 1, 2, '#c8ccd8'); R(12 + o, 2 + o, 1, 1, '#ffffff'); R(2 + o, 12 + o, 2, 1, '#e8e8e8'); R(3 + o, 13 + o, 1, 1, '#c83a3a'); } },
  tool_axe(R) { for (let i = 0; i < 10; i++) R(3 + i, 13 - i, 2, 1, '#8a5a2a'); R(9, 2, 5, 5, '#a8acb8'); R(13, 2, 1, 5, '#e8ecf4'); R(9, 3, 1, 3, '#7a7e8a'); },
  tool_pick(R) { for (let i = 0; i < 10; i++) R(3 + i, 13 - i, 2, 1, '#8a5a2a'); R(6, 2, 8, 2, '#a8acb8'); R(5, 3, 2, 2, '#a8acb8'); R(13, 3, 2, 3, '#a8acb8'); R(4, 4, 2, 2, '#e8ecf4'); R(14, 6, 1, 1, '#e8ecf4'); },
  pan(R) { R(2, 6, 9, 6, '#4a4a52'); R(3, 7, 7, 4, '#6a6a74'); R(4, 8, 2, 1, '#9a9aa4'); R(11, 8, 4, 2, '#5a3a1a'); },
  lockpick(R) { R(2, 12, 3, 3, '#8a8e9a'); R(4, 4, 1, 9, '#c8ccd8'); R(4, 3, 3, 1, '#c8ccd8'); R(9, 2, 1, 11, '#9a9eaa'); R(9, 2, 3, 1, '#9a9eaa'); R(11, 3, 1, 2, '#9a9eaa'); R(8, 12, 3, 3, '#8a6a3a'); },
  // Klinge diagonal von unten links (Griff) nach oben rechts (Spitze), läuft spitz zu
  sword(R, o) {
    const len = o.len || 8, b = o.c || '#c8ccd8', hi = L(b, 0.5), lo = L(b, -0.35), g = o.g || '#c8a040', wide = o.wide || 0;
    const gx = o.grip || 2, sx = 3 + gx, sy = 12 - gx;   // Klingenansatz
    for (let i = 0; i < len; i++) {
      const x = sx + i, y = sy - i, tip = len - i;
      if (tip <= 1) { R(x, y, 1, 1, hi); continue; }               // Spitze: ein Pixel
      R(x, y, 1, 1, b); R(x, y - 1, 1, 1, hi);                       // obere Schneide hell
      if (tip > 2) { R(x + 1, y, 1, 1, lo); if (wide && tip > 3) R(x + 1, y + 1, 1, 1, L(b, -0.5)); }
      if (o.fuller && i > 0 && tip > 3) R(x, y, 1, 1, L(b, -0.15));   // Blutrinne
    }
    // Parierstange quer zur Klinge
    const cw = o.guard || 2;
    for (let k = -cw; k <= cw; k++) R(sx - 1 + k, sy + 1 + k, 1, 1, k === 0 ? L(g, -0.2) : g);
    // Griff und Knauf
    for (let k = 0; k < gx; k++) R(sx - 2 - k, sy + 2 + k, 1, 1, k % 2 ? '#3a2410' : '#6a4422');
    R(sx - 2 - gx, sy + 2 + gx, 2, 2, g);
    if (o.gem) R(sx - 1, sy + 1, 1, 1, o.gem);
  },
  knife(R) {
    // kurze, breite Klinge mit gebogenem Rücken und dickem Holzgriff
    R(9, 5, 1, 1, '#d8dce4'); R(8, 6, 2, 1, '#b8bcc8'); R(7, 7, 3, 1, '#a8acb8'); R(6, 8, 3, 1, '#a8acb8'); R(6, 9, 2, 1, '#8a8e9a');
    R(10, 4, 1, 1, '#ffffff'); R(9, 6, 1, 1, '#e8ecf4'); R(8, 7, 1, 1, '#e8ecf4');
    R(8, 8, 1, 1, '#7a5a3a'); R(9, 7, 1, 1, '#8a6a4a');   // Rost
    R(5, 9, 2, 2, '#4a4a52');
    R(2, 11, 4, 3, '#7a4a22'); R(2, 11, 4, 1, '#9a6232'); R(3, 12, 1, 1, '#c8a040');
  },
  waraxe(R) { for (let i = 0; i < 12; i++) R(2 + i, 14 - i, 2, 1, '#6a4422'); R(8, 1, 6, 7, '#a8acb8'); R(13, 1, 2, 7, '#e8ecf4'); R(8, 2, 1, 5, '#7a7e8a'); R(6, 3, 3, 3, '#a8acb8'); },
  bow(R, o) {
    const w = o.c || '#8a5a2a';
    R(3, 1, 2, 2, w); R(5, 3, 2, 2, w); R(7, 5, 2, 2, w); R(9, 7, 2, 2, w); R(7, 9, 2, 2, w); R(5, 11, 2, 2, w); R(3, 13, 2, 2, w);
    R(8, 6, 1, 4, o.g || '#c8a040');
    for (let i = 0; i < 13; i++) R(3, 2 + i, 1, 1, '#e8e8e8');
    if (o.gem) { R(3, 1, 1, 1, o.gem); R(3, 14, 1, 1, o.gem); }
  },
  staff(R, o) {
    for (let i = 0; i < 11; i++) R(2 + i, 14 - i, 2, 1, o.w || '#6a4422');
    if (o.gem) { R(10, 1, 5, 5, L(o.gem, -0.3)); R(11, 1, 3, 4, o.gem); R(11, 1, 1, 2, '#ffffff'); }
    else { R(11, 2, 3, 2, o.w || '#6a4422'); R(13, 1, 2, 2, '#3a7a2a'); R(10, 1, 2, 1, '#4f9a3f'); }
  },
  armor(R, o) {
    const c = o.c, d = L(c, -0.3), l = L(c, 0.3);
    R(3, 3, 10, 11, c); R(1, 4, 3, 5, c); R(12, 4, 3, 5, c); R(6, 2, 4, 2, d);
    R(1, 8, 3, 1, d); R(12, 8, 3, 1, d); R(3, 13, 10, 1, d);
    if (o.t === 'robe') { R(2, 12, 12, 3, c); R(7, 4, 2, 10, d); R(6, 8, 4, 1, o.a || '#d8b040'); }
    if (o.t === 'cloth') { R(5, 6, 1, 1, d); R(10, 9, 2, 1, d); R(3, 13, 2, 1, '#000'); R(9, 3, 1, 2, d); }
    if (o.t === 'leather') { R(3, 9, 10, 1, '#4a2a12'); R(7, 9, 2, 1, '#c8a040'); R(5, 5, 1, 3, d); R(10, 5, 1, 3, d); }
    if (o.t === 'chain') for (let y = 4; y < 13; y++) for (let k = 3 + (y % 2); k < 13; k += 2) R(k, y, 1, 1, l);
    if (o.t === 'plate') { R(4, 4, 8, 4, l); R(5, 5, 6, 1, '#ffffff'); R(3, 9, 10, 1, d); R(1, 4, 3, 2, l); R(12, 4, 3, 2, l); }
    if (o.t === 'dragon') { for (let y = 4; y < 13; y += 2) for (let k = 3 + (y % 4 ? 1 : 0); k < 13; k += 3) R(k, y, 2, 1, l); R(6, 6, 4, 3, '#f0a030'); }
    if (o.t === 'mithril') { R(4, 4, 8, 4, l); R(7, 4, 2, 9, '#ffffff'); R(3, 9, 10, 1, d); }
  },
  quiver(R, o) {
    const s = o.size || 1, c = o.c || '#8a5a2a';
    const h = 7 + s * 2, y0 = 15 - h;
    for (let k = 0; k < 2 + s; k++) { R(5 + k * 2, y0 - 3, 1, 3, '#8a5a2a'); R(4 + k * 2, y0 - 4, 3, 2, '#e8e8e8'); }
    R(4, y0, 4 + s * 2, h, c); R(4, y0, 4 + s * 2, 1, L(c, 0.3)); R(4, y0 + h - 2, 4 + s * 2, 1, L(c, -0.35));
    if (o.g) R(5, y0 + 2, 2 + s * 2, 1, o.g);
    R(3 + s * 2 + 4, y0 + 1, 1, h - 2, '#5a3a1a');
  },
  bag(R, o) {
    const s = o.size || 1, c = o.c || '#8a6a3a', w = 6 + s * 2, h = 6 + s, x0 = 8 - w / 2, y0 = 14 - h;
    R(x0, y0, w, h, c); R(x0 + 1, y0 - 1, w - 2, 1, c); R(x0, y0 + h - 1, w, 1, L(c, -0.35));
    R(6, y0 - 4, 4, 1, L(c, -0.25)); R(5, y0 - 3, 1, 3, L(c, -0.25)); R(10, y0 - 3, 1, 3, L(c, -0.25));
    R(x0 + 1, y0 + 1, w - 2, 2, L(c, 0.2));
    if (s >= 2) R(7, y0 + 3, 2, 2, o.g || '#c8a040');
    if (o.glow) { R(6, y0 + 3, 4, 3, o.glow); R(7, y0 + 4, 1, 1, '#ffffff'); }
  },
  amulet(R, o) { for (let i = 0; i < 5; i++) { R(3 + i, 2 + i, 1, 1, '#c8a040'); R(12 - i, 2 + i, 1, 1, '#c8a040'); } R(5, 7, 6, 6, '#c8a040'); R(6, 8, 4, 4, o.c || '#3a8ad0'); R(7, 9, 1, 1, '#ffffff'); },
  coin(R) { R(4, 3, 8, 10, '#c8a040'); R(3, 4, 10, 8, '#c8a040'); R(5, 4, 6, 8, '#e8c860'); R(7, 5, 2, 6, '#a8801a'); R(5, 4, 2, 1, '#fff6c0'); },
  seal(R) { R(2, 6, 12, 7, '#e8c040'); R(2, 3, 2, 3, '#e8c040'); R(7, 2, 2, 4, '#e8c040'); R(12, 3, 2, 3, '#e8c040'); R(2, 12, 12, 1, '#a8801a'); R(5, 8, 2, 2, '#c83a3a'); R(9, 8, 2, 2, '#3a8ad0'); R(3, 7, 10, 1, '#fff6c0'); },
  saddle(R, o) { const c = o.c; R(2, 9, 12, 3, '#a8282a'); R(2, 11, 12, 1, '#e8c040'); R(4, 5, 8, 4, c); R(3, 4, 2, 2, c); R(11, 3, 2, 3, c); R(5, 5, 5, 1, shade(c, 0.35)); R(7, 12, 1, 2, '#3a2a1a'); R(6, 14, 3, 1, '#a8acb8'); if (o.g) { R(4, 7, 8, 1, o.g); R(11, 3, 2, 1, o.g); } },
  barding(R, o) { const c = o.c, l = shade(c, 0.35), d = shade(c, -0.3); R(2, 5, 12, 6, c); R(3, 4, 10, 1, l); for (let k = 3; k < 13; k += 3) R(k, 5, 2, 5, l); R(2, 10, 12, 1, d); R(1, 11, 2, 3, c); R(13, 11, 2, 3, c); R(6, 11, 4, 2, d); R(7, 7, 2, 2, '#ffffff'); },
  kit(R, o) { const c = o.c; R(1, 6, 14, 8, c); R(1, 6, 14, 2, shade(c, 0.25)); R(1, 13, 14, 1, shade(c, -0.35)); R(6, 4, 4, 2, '#3a2a1a'); R(5, 5, 1, 2, '#3a2a1a'); R(10, 5, 1, 2, '#3a2a1a');
    R(7, 9, 2, 2, o.g || '#c8ccd8'); for (let i = 0; i < 4; i++) R(2 + i, 3 - (i > 1 ? 1 : 0) + 0, 1, 1, '#a8acb8'); R(12, 1, 2, 5, '#8a5a2a'); R(11, 1, 4, 2, '#a8acb8'); },
  ledger(R) { R(3, 2, 10, 12, '#6a4a2a'); R(4, 3, 8, 10, '#f0e8d0'); for (let k = 5; k < 12; k += 2) R(5, k, 6, 1, '#8a7a5a'); R(3, 2, 1, 12, '#4a3018'); }
};
const ICON_DEF = {
  holz:['log'], stein:['stone'], eisenerz:['ore', {c:'#c8783a'}], silbererz:['ore', {c:'#e8eef6'}], mithrilerz:['ore', {c:'#3ac8f0'}],
  eisenbarren:['ingot', {c:'#8a8e9a'}], silberbarren:['ingot', {c:'#d8dce8'}], mithrilbarren:['ingot', {c:'#4ac0e0'}],
  kristall:['gem', {c:'#5ad0f0'}], schattenkristall:['gem', {c:'#8a3ad0'}], kraut:['herb'], pilz:['mushroom'],
  fleisch:['meat'], fell:['fur'], leder:['leather'], knochen:['bone'], schuppe:['scale'], blume:['flower'],
  wein:['bottle', {c:'#7a1a4a'}], buch:['book', {c:'#3a5a9a'}], ring:['ring'], rechnungsbuch:['ledger'],
  brot:['bread'], bier:['mug'], gebraten:['cooked'], eintopf:['bowl'], festmahl:['feast'],
  heiltrank:['potion', {c:'#d83a3a'}], grheiltrank:['potion', {c:'#e01a5a', big:true}], manatrank:['potion', {c:'#3a6ae0'}],
  pfeile:['arrows'], axt:['tool_axe'], spitzhacke:['tool_pick'], kochset:['pan'], dietrich:['lockpick'],
  messer:['knife'], kurzschwert:['sword', {len:5, guard:1, grip:2, c:'#b8bcc8'}], eisenschwert:['sword', {len:8, guard:2, grip:2, fuller:true}], langschwert:['sword', {len:10, guard:2, grip:3, fuller:true, c:'#d0d4dc'}], kriegsaxt:['waraxe'],
  silberschwert:['sword', {len:9, guard:2, grip:2, fuller:true, c:'#eef2fa', g:'#e8e8f0', gem:'#3a8ad0'}], mithrilklinge:['sword', {len:10, guard:3, grip:2, fuller:true, c:'#7ad8f4', g:'#c8a040'}],
  drachentoeter:['sword', {len:10, guard:3, grip:3, wide:1, c:'#e8603a', g:'#2a2a2a', gem:'#f0d040'}],
  kurzbogen:['bow', {c:'#8a5a2a'}], langbogen:['bow', {c:'#6a4422', g:'#3a6a2a'}], elfenbogen:['bow', {c:'#e8d070', g:'#3a8a3a', gem:'#7ae04a'}], mithrilbogen:['bow', {c:'#7ad8f4', g:'#c8a040', gem:'#ffffff'}],
  knorrstab:['staff'], pilgerstab:['staff', {w:'#c8a870', gem:'#f8e8a0'}], kristallstab:['staff', {gem:'#5ad0f0'}], arkanstab:['staff', {w:'#3a2a4a', gem:'#a04af0'}], sternenstab:['staff', {w:'#e8e8f0', gem:'#f8e070'}],
  lumpen:['armor', {c:'#7a6a58', t:'cloth'}], robe:['armor', {c:'#c8b898', t:'robe', a:'#8a6a3a'}], lederruestung:['armor', {c:'#8a5a32', t:'leather'}],
  magierrobe:['armor', {c:'#3a3aa0', t:'robe'}], kettenhemd:['armor', {c:'#7a7e8a', t:'chain'}], plattenruestung:['armor', {c:'#9a9eaa', t:'plate'}],
  mithrilruestung:['armor', {c:'#5ab8d8', t:'mithril'}], drachenruestung:['armor', {c:'#9a2a1a', t:'dragon'}],
  koecher_klein:['quiver', {size:0, c:'#8a6a4a'}], koecher:['quiver', {size:1, c:'#8a5a2a'}], koecher_gross:['quiver', {size:2, c:'#6a3a1a', g:'#c8ccd8'}], elfenkoecher:['quiver', {size:3, c:'#3a6a2a', g:'#e8d070'}],
  beutel:['bag', {size:0, c:'#a89878'}], rucksack:['bag', {size:1, c:'#8a5a2a'}], grosser_rucksack:['bag', {size:2, c:'#7a4a22'}], packtasche:['bag', {size:3, c:'#5a4a2a', g:'#c8ccd8'}], dimensionsbeutel:['bag', {size:2, c:'#3a2a6a', glow:'#a04af0'}],
  sattel:['saddle', {c:'#6a3a1a'}], kampfsattel:['saddle', {c:'#4a2a12', g:'#a8acb8'}], koenigssattel:['saddle', {c:'#7a1a2a', g:'#e8c040'}],
  tierlederpanzer:['barding', {c:'#8a5a32'}], tiereisenpanzer:['barding', {c:'#8a8e9a'}], tiersilberpanzer:['barding', {c:'#d0d4e0'}], tiermithrilpanzer:['barding', {c:'#4ab0d0'}],
  medaillon:['amulet', {c:'#8a2a2a'}], liebesbrief:['letter', {seal:'#e04a7a'}], geheimbrief:['letter', {seal:'#4a1a5a', dark:true}], valdrinring:['ring', {metal:'#e8c040', gem:'#c83a3a'}],
  reparaturset:['kit', {c:'#8a5a2a'}], meisterset:['kit', {c:'#3a3a6a', g:'#e8c040'}],
  amulett:['amulet', {c:'#3ab06a'}], glueckstaler:['coin'], koenigssiegel:['seal']
};
// Nach dem Laden: alle Emoji-Icons der Gegenstände durch Pixelbilder ersetzen
function installItemIcons() { for (const id in ITEMS) { ITEMS[id].emoji = ITEMS[id].icon; ITEMS[id].icon = iconHTML(id); } }
installItemIcons();

// ================= PIXEL-ICONS FÜR FÄHIGKEITEN =================
const SKILL_ICON_CACHE = {};
function skillCanvas(id) {
  if (SKILL_ICON_CACHE[id]) return SKILL_ICON_CACHE[id];
  const c = mkCanvas(16, 16), x = c.getContext('2d');
  const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  const D = (a, b, col) => R(Math.round(a), Math.round(b), 1, 1, col);
  const line = (x0, y0, x1, y1, col, w) => { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 2 + 1; for (let i = 0; i <= n; i++) { const t = i / n, px = x0 + (x1 - x0) * t, py = y0 + (y1 - y0) * t; R(Math.round(px), Math.round(py), w || 1, w || 1, col); } };
  const disc = (cx, cy, r, col) => { for (let yy = Math.floor(cy - r); yy <= Math.ceil(cy + r); yy++) for (let xx = Math.floor(cx - r); xx <= Math.ceil(cx + r); xx++) if ((xx + 0.5 - cx) ** 2 + (yy + 0.5 - cy) ** 2 <= r * r) D(xx, yy, col); };
  try { (SKILL_DRAW[id] || SKILL_DRAW.licht)(R, D, line, disc); } catch (e) { R(4, 4, 8, 8, '#f0f'); }
  addOutline(c, '#140c06');
  SKILL_ICON_CACHE[id] = c; return c;
}
const SKILL_DRAW = {
  wirbel(R, D, line, disc) {
    for (let a = 0; a < TAU * 1.6; a += 0.04) { const r = 7 - a * 0.55, px = 8 + Math.cos(a) * r, py = 8 + Math.sin(a) * r; D(px, py, a < 3 ? '#ffffff' : a < 6 ? '#d0d4dc' : '#8a8e9a'); D(px + 0.5, py + 0.5, a < 3 ? '#e8ecf4' : '#a8acb8'); }
    disc(8, 8, 1.6, '#e8c040'); D(8, 7, '#fff6b0');
  },
  schrei(R, D, line, disc) {
    for (let t = 0; t <= 1; t += 0.04) { const px = 1.5 + t * 9, py = 11 - t * 5 - Math.sin(t * Math.PI) * 1.4; disc(px, py, 0.8 + t * 2.6, t > 0.28 && t < 0.36 || t > 0.62 && t < 0.7 ? '#6a4422' : '#d8a870'); }
    disc(11.2, 5.4, 1.6, '#4a2a12');
    R(13, 2, 1, 2, '#ff6a3a'); R(14, 4, 1, 4, '#ff8a3a'); R(13, 8, 1, 2, '#ff6a3a'); R(15, 3, 1, 1, '#ffb070'); R(15, 8, 1, 1, '#ffb070');
  },
  ansturm(R) {
    const rows = [[6, 13], [6, 13], [6, 13], [6, 13], [6, 13], [6, 13], [7, 12], [7, 12], [8, 11], [9, 10]];
    rows.forEach((r, k) => { R(r[0], 3 + k, r[1] - r[0], 1, '#3a5aa8'); R(r[0], 3 + k, 1, 1, '#c8ccd8'); R(r[1] - 1, 3 + k, 1, 1, '#c8ccd8'); });
    R(6, 3, 7, 1, '#c8ccd8'); R(9, 5, 1, 6, '#e8c040'); R(7, 7, 5, 1, '#e8c040');
    R(0, 5, 4, 1, '#ffffff'); R(1, 8, 4, 1, '#e8ecf4'); R(0, 11, 5, 1, '#ffffff');
  },
  beben(R, D, line) {
    R(0, 11, 16, 5, '#7a5a3a'); R(0, 11, 16, 1, '#a8804a'); R(0, 14, 16, 2, '#5a3e22');
    line(8, 11, 6, 13, '#1a0e06'); line(6, 13, 9, 15, '#1a0e06'); line(8, 11, 11, 12, '#1a0e06'); R(7, 12, 1, 1, '#ffd040');
    R(2, 6, 2, 2, '#8d8d92'); R(11, 3, 3, 2, '#8d8d92'); R(6, 1, 2, 2, '#a6a6ad'); R(13, 8, 2, 2, '#7a7a80');
    R(4, 9, 1, 1, '#c8a870'); R(10, 7, 1, 1, '#c8a870'); R(1, 9, 1, 1, '#c8a870');
  },
  feuerball(R, D, line, disc) {
    for (let t = 0; t <= 1; t += 0.12) disc(2.5 + t * 6, 13.5 - t * 6, 0.8 + t * 2, t < 0.5 ? '#c8301a' : '#f07a20');
    disc(10, 6, 4.6, '#c8301a'); disc(10.2, 5.8, 3.6, '#f07a20'); disc(10.4, 5.6, 2.4, '#ffd040'); disc(10.6, 5.2, 1.1, '#fff6c0');
  },
  frost(R, D, line) {
    const arms = [[0, -7], [6, -3.5], [6, 3.5], [0, 7], [-6, 3.5], [-6, -3.5]];
    for (const [dx, dy] of arms) { line(8, 8, 8 + dx, 8 + dy, '#bfefff'); const bx = 8 + dx * 0.6, by = 8 + dy * 0.6; line(bx, by, bx + dy * 0.25, by - dx * 0.25, '#e8faff'); line(bx, by, bx - dy * 0.25, by + dx * 0.25, '#e8faff'); D(8 + dx, 8 + dy, '#ffffff'); }
    R(7, 7, 3, 3, '#5ab0e0'); R(8, 8, 1, 1, '#ffffff');
  },
  blitz(R, D, line) {
    line(10, 0, 5, 8, '#ffe040', 2); line(5, 8, 11, 7, '#ffe040', 2); line(11, 7, 6, 15, '#ffe040', 2);
    line(10, 1, 6, 8, '#ffffff'); line(10, 8, 7, 14, '#ffffff');
    R(2, 3, 1, 1, '#fff6a0'); R(13, 11, 1, 1, '#fff6a0'); R(13, 2, 1, 1, '#fff6a0');
  },
  meteor(R, D, line, disc) {
    for (let t = 0; t <= 1; t += 0.1) disc(1.5 + t * 7, 1.5 + t * 7, 0.6 + t * 1.8, t < 0.4 ? '#f8a030' : '#e05020');
    disc(10.5, 10.5, 4, '#5a3a2a'); disc(10, 10, 3.2, '#6a4a3a');
    line(8, 9, 11, 12, '#ff8a20'); line(11, 8, 9, 11, '#ff8a20'); D(12, 9, '#ffd040'); D(9, 12, '#ffd040');
  },
  mehrfach(R, D, line) {
    for (const [ex, ey] of [[14, 2], [14, 8], [8, 2]]) {
      line(2, 14, ex, ey, '#9a6a3a');
      const l = Math.hypot(ex - 2, ey - 14), ux = (ex - 2) / l, uy = (ey - 14) / l;
      R(Math.round(ex - ux), Math.round(ey - uy), 2, 2, '#d8dce4'); D(ex, ey, '#ffffff');
    }
    R(1, 13, 3, 3, '#e8e8e8'); R(2, 14, 1, 1, '#c83a3a');
  },
  gift(R, D, line) {
    line(2, 13, 11, 4, '#9a6a3a'); R(11, 3, 3, 3, '#5ac030'); R(12, 2, 2, 1, '#8af050'); R(14, 2, 1, 1, '#8af050');
    R(1, 13, 2, 2, '#e8e8e8'); R(12, 8, 1, 2, '#7ae040'); R(14, 10, 1, 2, '#7ae040'); R(10, 11, 1, 2, '#5ac030'); R(12, 13, 1, 1, '#5ac030');
  },
  rolle(R, D, line) {
    for (let a = Math.PI; a <= TAU + 0.6; a += 0.05) { D(8 + Math.cos(a) * 5.5, 9 + Math.sin(a) * 5.5, '#e8ecf4'); D(8 + Math.cos(a) * 4.5, 9 + Math.sin(a) * 4.5, '#7ae0a0'); }
    R(11, 10, 5, 2, '#7ae0a0'); R(12, 12, 3, 1, '#7ae0a0'); R(13, 13, 1, 1, '#7ae0a0');
    R(1, 13, 1, 1, '#c8ccd8'); R(3, 14, 1, 1, '#c8ccd8'); R(0, 11, 1, 1, '#c8ccd8');
  },
  hagel(R, D, line) {
    R(2, 1, 12, 4, '#8a8e9a'); R(4, 0, 8, 1, '#a8acb8'); R(3, 1, 4, 2, '#c8ccd8'); R(1, 3, 14, 2, '#6a6e7a');
    for (const [ax, ay] of [[3, 7], [7, 9], [11, 7], [14, 10], [5, 12]]) { R(ax, ay, 1, 3, '#9a6a3a'); R(ax - 1, ay + 3, 3, 1, '#d8dce4'); D(ax, ay + 4, '#ffffff'); }
  },
  heilung(R) {
    R(6, 2, 4, 12, '#2a8a3a'); R(2, 6, 12, 4, '#2a8a3a'); R(7, 3, 2, 10, '#7af07a'); R(3, 7, 10, 2, '#7af07a'); R(7, 7, 2, 2, '#ffffff');
    R(1, 1, 1, 1, '#ffffff'); R(14, 2, 1, 1, '#ffffff'); R(13, 13, 1, 1, '#d8ffd8'); R(2, 13, 1, 1, '#d8ffd8');
  },
  licht(R, D, line, disc) {
    for (let k = 0; k < 8; k++) { const a = k / 8 * TAU; line(8 + Math.cos(a) * 3.5, 8 + Math.sin(a) * 3.5, 8 + Math.cos(a) * 7, 8 + Math.sin(a) * 7, k % 2 ? '#ffd040' : '#fff6a0'); }
    disc(8, 8, 3.6, '#ffd040'); disc(8, 8, 2.6, '#fff6a0'); disc(8, 8, 1.2, '#ffffff');
  },
  segen(R, D) {
    for (let a = 0; a < TAU; a += 0.05) D(8 + Math.cos(a) * 5, 3 + Math.sin(a) * 1.6, '#ffd040');
    const rows = [[4, 12], [4, 12], [4, 12], [4, 12], [5, 11], [6, 10], [7, 9]];
    rows.forEach((r, k) => R(r[0], 7 + k, r[1] - r[0], 1, '#e8ecf4'));
    R(7, 8, 2, 5, '#e8c040'); R(5, 9, 6, 2, '#e8c040'); R(4, 7, 8, 1, '#ffffff');
  },
  wunder(R, D) {
    for (let k = 0; k < 6; k++) { R(7 - k - 1, 4 + k, k + 1, 1, k % 2 ? '#ffffff' : '#e0e8f0'); R(9, 4 + k, k + 1, 1, k % 2 ? '#ffffff' : '#e0e8f0'); }
    R(1, 10, 5, 2, '#c8d0dc'); R(10, 10, 5, 2, '#c8d0dc'); R(2, 12, 3, 1, '#c8d0dc'); R(11, 12, 3, 1, '#c8d0dc');
    R(7, 3, 2, 8, '#ffd040'); R(6, 6, 4, 2, '#ffd040'); R(7, 6, 2, 2, '#ffffff'); R(7, 1, 2, 1, '#fff6a0');
  }
};
function skillURL(id) { return skillCanvas(id).toDataURL(); }
function installSkillIcons() {
  for (const id in SKILLS) SKILLS[id].icon = '<img class="pix" src="' + skillURL(id) + '" alt="">';
  DISC.kampf.icon = iconHTML('eisenschwert'); DISC.bogen.icon = iconHTML('langbogen');
  DISC.magie.icon = SKILLS.feuerball.icon; DISC.heil.icon = SKILLS.heilung.icon;
}
installSkillIcons();

// ================= MENÜ-ICONS =================
const MENU_DRAW = {
  inv(R) { ICON_DRAW.bag(R, {size:2, c:'#8a5a2a'}); },
  char(R) {   // Held mit Stern
    R(5, 3, 6, 6, '#e9b896'); R(5, 2, 6, 2, '#6a3a1a'); R(4, 3, 1, 3, '#6a3a1a'); R(11, 3, 1, 3, '#6a3a1a'); R(6, 5, 1, 1, '#1a1a2a'); R(9, 5, 1, 1, '#1a1a2a'); R(7, 7, 2, 1, '#b07a5a');
    R(3, 10, 10, 5, '#8a2d2d'); R(4, 10, 8, 1, '#a84040'); R(7, 10, 2, 5, '#c8a040');
    R(12, 0, 3, 1, '#ffd040'); R(13, 0, 1, 3, '#ffd040'); R(12, 1, 3, 1, '#fff6a0'); R(11, 1, 1, 1, '#ffd040'); R(15, 1, 1, 1, '#ffd040');
  },
  craft(R) {  // Amboss mit Hammer
    R(2, 9, 12, 2, '#5a5a62'); R(1, 9, 2, 1, '#5a5a62'); R(3, 9, 10, 1, '#8a8a94'); R(6, 11, 4, 2, '#4a4a52'); R(4, 13, 8, 2, '#3a3a42');
    for (let i = 0; i < 6; i++) R(5 + i, 7 - i, 1, 1, '#8a5a2a');
    R(9, 0, 5, 3, '#a8acb8'); R(9, 0, 5, 1, '#d8dce4'); R(13, 1, 1, 2, '#7a7e8a');
    R(3, 6, 1, 1, '#ffd040'); R(13, 6, 1, 1, '#ff8a20');
  },
  quest(R) {  // Schriftrolle mit Siegel
    R(3, 2, 10, 12, '#f0e4c0'); R(2, 1, 12, 2, '#c8a870'); R(2, 13, 12, 2, '#c8a870'); R(1, 1, 1, 2, '#a8885a'); R(14, 13, 1, 2, '#a8885a');
    for (let y = 5; y <= 10; y += 2) R(5, y, 6, 1, '#8a7a5a');
    R(10, 10, 3, 3, '#c83a3a'); R(11, 11, 1, 1, '#f07a7a');
  },
  map(R) {    // gefaltete Karte
    R(1, 3, 5, 11, '#e8dcb0'); R(6, 2, 5, 11, '#d8cca0'); R(11, 3, 4, 11, '#e8dcb0');
    R(2, 6, 3, 3, '#5b9b3d'); R(7, 8, 3, 2, '#3576bd'); R(12, 5, 2, 4, '#5b9b3d');
    for (let i = 0; i < 4; i++) R(3 + i * 3, 11 - i, 1, 1, '#a8322b');
    R(12, 9, 2, 2, '#a8322b'); R(13, 10, 1, 1, '#ffffff');
  },
  party(R) {  // zwei Gefährten
    R(2, 4, 5, 5, '#f0c8a8'); R(2, 3, 5, 2, '#e8c860'); R(3, 6, 1, 1, '#1a1a2a'); R(5, 6, 1, 1, '#1a1a2a'); R(1, 10, 7, 5, '#3f6a35');
    R(9, 3, 5, 5, '#d8a070'); R(9, 2, 5, 2, '#2a2a2a'); R(10, 5, 1, 1, '#1a1a2a'); R(12, 5, 1, 1, '#1a1a2a'); R(8, 9, 7, 6, '#8a2d2d'); R(11, 9, 1, 6, '#c8a040');
  },
  estate(R) { // Haus
    for (let k = 0; k < 7; k++) R(8 - k - 1, 1 + k, (k + 1) * 2, 1, k % 2 ? '#9c3b2b' : '#b84a38');
    R(2, 8, 12, 7, '#e8dcc0'); R(2, 8, 12, 1, '#6a4422'); R(2, 14, 12, 1, '#6a4422');
    R(7, 10, 3, 5, '#6b4422'); R(9, 12, 1, 1, '#e0b84a'); R(3, 10, 3, 2, '#7ab4ec'); R(11, 10, 2, 2, '#7ab4ec');
    R(11, 2, 2, 4, '#7a7a80');
  },
  sys(R) {    // Zahnrad
    const c = '#a8acb8', d = '#6a6e7a';
    R(5, 3, 6, 10, c); R(3, 5, 10, 6, c); R(7, 1, 2, 2, c); R(7, 13, 2, 2, c); R(1, 7, 2, 2, c); R(13, 7, 2, 2, c);
    R(3, 3, 2, 2, c); R(11, 3, 2, 2, c); R(3, 11, 2, 2, c); R(11, 11, 2, 2, c);
    R(6, 6, 4, 4, d); R(7, 7, 2, 2, '#3d2a1c'); R(5, 3, 6, 1, '#d8dce4');
  }
};
function menuIconURL(k) {
  const c = mkCanvas(16, 16), x = c.getContext('2d');
  MENU_DRAW[k]((a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); });
  addOutline(c, '#140c06'); return c.toDataURL();
}
// Rüstungsteile: Helm, Handschuhe, Hose, Schuhe
Object.assign(ICON_DRAW, {
  helmet(R, o) { const c = o.c, l = shade(c, 0.35), d = shade(c, -0.3);
    if (o.hat) { R(2, 11, 12, 2, c); R(5, 4, 6, 7, c); R(6, 1, 3, 3, c); R(8, 0, 2, 2, c); R(5, 9, 6, 1, '#e8c040'); R(6, 5, 2, 2, l); return; }
    R(3, 4, 10, 8, c); R(4, 3, 8, 1, c); R(5, 2, 6, 1, l); R(4, 4, 3, 3, l); R(3, 11, 10, 2, d);
    if (o.open) { R(5, 8, 6, 4, '#2a1a10'); } else { R(4, 7, 8, 1, '#1a1010'); R(7, 8, 2, 4, d); }
    if (o.plume) { R(8, 0, 2, 3, o.plume); R(10, 0, 2, 1, o.plume); } },
  gloves(R, o) { const c = o.c, l = shade(c, 0.35), d = shade(c, -0.3);
    R(3, 4, 7, 8, c); R(3, 3, 2, 3, c); R(5, 2, 2, 3, c); R(7, 2, 2, 3, c); R(9, 3, 2, 3, c); R(10, 7, 3, 3, c); R(4, 5, 4, 2, l); R(3, 12, 7, 3, d); R(3, 12, 7, 1, l); },
  pants(R, o) { const c = o.c, l = shade(c, 0.3), d = shade(c, -0.3);
    R(3, 2, 10, 4, c); R(3, 2, 10, 1, '#4a2a12'); R(7, 2, 2, 1, '#c8a040'); R(3, 6, 4, 9, c); R(9, 6, 4, 9, c); R(4, 6, 1, 8, l); R(10, 6, 1, 8, l); R(3, 14, 4, 1, d); R(9, 14, 4, 1, d);
    if (o.plate) { R(3, 9, 4, 2, l); R(9, 9, 4, 2, l); } },
  boots(R, o) { const c = o.c, l = shade(c, 0.35), d = shade(c, -0.35);
    R(2, 3, 4, 9, c); R(9, 3, 4, 9, c); R(2, 11, 6, 3, c); R(9, 11, 6, 3, c); R(2, 14, 6, 1, d); R(9, 14, 6, 1, d); R(3, 4, 1, 7, l); R(10, 4, 1, 7, l); R(2, 3, 4, 1, l); R(9, 3, 4, 1, l); }
});
Object.assign(ICON_DEF, {
  lederkappe:['helmet', {c:'#8a5a32', open:true}], eisenhelm:['helmet', {c:'#8a8e9a', open:true}], plattenhelm:['helmet', {c:'#a8acb8', plume:'#c83a3a'}], mithrilhelm:['helmet', {c:'#6ac0e0', plume:'#e8c040'}],
  zauberhut:['helmet', {c:'#3a3aa0', hat:true}], heilerhaube:['helmet', {c:'#e8e0c8', hat:true}],
  lederhandschuhe:['gloves', {c:'#8a5a32'}], kettenhandschuhe:['gloves', {c:'#8a8e9a'}], plattenhandschuhe:['gloves', {c:'#a8acb8'}], mithrilhandschuhe:['gloves', {c:'#6ac0e0'}], jaegerhandschuhe:['gloves', {c:'#4a6a3a'}],
  lederhose:['pants', {c:'#6a4428'}], kettenhose:['pants', {c:'#7a7e8a'}], beinschienen:['pants', {c:'#9a9eaa', plate:true}], mithrilhose:['pants', {c:'#5ab0d0', plate:true}],
  lederstiefel:['boots', {c:'#5a3a1a'}], eisenstiefel:['boots', {c:'#6a6e7a'}], plattenstiefel:['boots', {c:'#9a9eaa'}], mithrilstiefel:['boots', {c:'#4a90b0'}]
});
for (const id of ['lederkappe','eisenhelm','plattenhelm','mithrilhelm','zauberhut','heilerhaube','lederhandschuhe','kettenhandschuhe','plattenhandschuhe','mithrilhandschuhe','jaegerhandschuhe','lederhose','kettenhose','beinschienen','mithrilhose','lederstiefel','eisenstiefel','plattenstiefel','mithrilstiefel'])
  if (ITEMS[id]) { delete ICON_CACHE[id]; delete ICON_URL[id]; ITEMS[id].icon = iconHTML(id); }
