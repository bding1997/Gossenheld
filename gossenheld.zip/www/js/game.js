'use strict';
// ================= SPIELLOGIK =================
const DAY_LEN = 480, SAVE_KEY = 'gossenheld_save_v1', SAVE_VER = 2;
let P = null;
const G = {t:0,time:120,day:1,seed:1337,enemies:[],allies:[],npcMap:{},npcs:[],proj:[],drops:[],fx:[],texts:[],chests:{},dynChests:{},mods:{},
  explored:null,tmp:[],st:null,spawnT:0,bossT:0,evT:30,saveT:0,revealT:0,interT:0,hudT:0,npcT:0,inter:null,running:false,paused:false,region:'',
  shake:0,keys:{},joy:{x:0,y:0},atkHeld:false,scale:4,marks:{}};

// ---------- Grundlagen ----------
function hour() { return (6 + G.time / DAY_LEN * 24) % 24; }
function isNight() { const h = hour(); return h >= 20 || h < 5; }
function clock() { const h = hour(), hh = Math.floor(h), mm = Math.floor((h - hh) * 6) * 10; return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0'); }
function tileAt(x, y) { x = Math.floor(x); y = Math.floor(y); if (!inb(x, y)) return TL.WATER; return WT[idx(x, y)]; }
function regionAt(x, y) { x = Math.floor(x); y = Math.floor(y); if (!inb(x, y)) return 'wiese'; return REGIONS[WR[idx(x, y)]]; }
function walkable(x, y, enemy) {
  const ix = Math.floor(x), iy = Math.floor(y); if (!inb(ix, iy)) return false;
  const i = idx(ix, iy);
  if (!enemy && G.flying && (WG[i] === TL.WATER || WT[i] === TL.LAVA)) return true;   // auf Drachen über Wasser und Lava fliegen
  if (BLOCK[WT[i]]) return false;
  if (enemy) { const r = REGIONS[WR[i]]; if (r === 'stadt' || r === 'dorf' || r === 'neustadt') return false; }
  return true;
}
function canStand(x, y, r, enemy) { return walkable(x - r, y - r * 0.6, enemy) && walkable(x + r, y - r * 0.6, enemy) && walkable(x - r, y + r * 0.3, enemy) && walkable(x + r, y + r * 0.3, enemy); }
function moveEnt(e, dx, dy, enemy) {
  const r = e.r || 0.3; let m = false;
  if (dx && canStand(e.x + dx, e.y, r, enemy)) { e.x += dx; m = true; }
  if (dy && canStand(e.x, e.y + dy, r, enemy)) { e.y += dy; m = true; }
  return m;
}
function inCity() { const r = regionAt(P.x, P.y); return r === 'stadt' || r === 'gosse' || r.startsWith('i_'); }
function curHouse() { const r = regionAt(P.x, P.y); if (!r.startsWith('i_h_')) return null; const h = r.slice(4); return P.houses.includes(h) ? h : null; }
function inHome() { return !!curHouse(); }
function hasFurn(f) { for (const h in P.furn) if (P.furn[h].includes(f)) return true; return false; }
function npcPos(d) { return d.at ? ipos(d.at) : [d.x, d.y]; }
function compHome(id) { const c = COMPS[id]; return c.at ? ipos(c.at) : c.home; }
function locName(x, y) { const r = regionAt(x, y); return (REGION_INFO[r] || {}).name || ''; }
function floatText(x, y, txt, col, big) { G.texts.push({x, y, txt, col, t:0, big}); }
function floatItem(x, y, id, n) { G.texts.push({x, y, txt:'+' + n, col:'#fff', t:0, img:iconCanvas(id)}); }
function burst(x, y, col, n) { for (let i = 0; i < n; i++) { const a = Math.random() * TAU, s = rnd(1, 4); G.fx.push({k:'p', x, y, vx:Math.cos(a) * s, vy:Math.sin(a) * s - 1, life:rnd(0.3, 0.7), col, sz:rnd(1, 2.5)}); } }
function ring(x, y, max, col) { G.fx.push({k:'ring', x, y, r:0.2, max, life:0.4, t:0, col}); }

// ---------- Spieler ----------
function inst(id) { return {id, n:1, up:0, dur:100}; }
function newPlayer(c) {
  const cl = CLASSES[c.cls], rc = RACES[c.race];
  const base = Object.assign({}, cl.base); for (const k in rc.bonus) base[k] += rc.bonus[k];
  let discs = {};
  if (c.cls === 'hybrid') c.discs.forEach(d => { discs[d] = HYBRID_EFF; base[DISC[d].stat] += 2; });
  else discs = Object.assign({}, cl.disc);
  P = {kind:'player', name:c.name, race:c.race, cls:c.cls, gender:c.gender, hair:c.hair, discs, base, lvl:1, xp:0, attrPts:0, skillPts:0,
    hp:1, en:1, x:60.5, y:115.6, dir:1, face:{x:1, y:0}, r:0.28, gold:25, arrows:0, inv:[],
    eq:{waffe:null, helm:null, ruestung:null, handschuhe:null, hose:null, schuhe:null, koecher:null, rucksack:null, schmuck:null}, skills:{}, slots:[null, null, null], prof:{}, learned:{},
    q:{}, dyn:{}, f:{}, rep:{stadt:0, diebe:0, karma:0}, rank:'Keiner', title:'Gossenkind', comp:{}, party:[], pets:[], petActive:-1, mount:-1, mounted:false,
    houses:[], furn:[], storage:[], biz:{}, guild:null, buffs:{}, cds:{}, kills:{}, potion:'heiltrank', lastHit:-99, atkCd:0, invuln:0};
  for (const k in PROFS) { P.prof[k] = {lvl:0, xp:0}; P.learned[k] = !PROFS[k].learn; }
  for (const k in COMPS) P.comp[k] = {aff:0, lover:false, hired:false, talkDay:-1, flirtDay:-1, giftDay:-1, hp:null};
  P.dl = {}; P.avail = {}; P.board = {day:-1, list:[]}; P.track = null; P.furn = {}; P.trainDay = {}; P.v = SAVE_VER;
  P.gold = 15;
  P.eq.rucksack = inst('beutel'); P.eq.waffe = inst('messer'); P.eq.ruestung = inst('lumpen');
  addItem('brot', 2, true);
  const st0 = ipos(['hilde', 3.6, 4.4]); P.x = st0[0]; P.y = st0[1];
  const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
}
function stats() {
  const b = Object.assign({}, P.base);
  for (const s in P.eq) { const e = P.eq[s]; if (e && ITEMS[e.id].bonus) { const bo = ITEMS[e.id].bonus; for (const k in bo) b[k] += bo[k]; } }
  if (P.buffs.held) for (const k in b) b[k] += 3;
  const arm = P.eq.ruestung;
  let def = 0;
  for (const sl of ARMOR_SLOTS) { const a = P.eq[sl]; if (a && ITEMS[a.id]) def += ITEMS[a.id].def * (1 + 0.12 * (a.up || 0)) * (a.dur > 0 ? 1 : 0.5); }
  if (P.eq.schmuck && ITEMS[P.eq.schmuck.id].def) def += ITEMS[P.eq.schmuck.id].def;
  def += b.vit * 0.3; if (P.buffs.segen) def += 10; if (P.buffs.held) def *= 1.2;
  const maxHp = Math.round((30 + b.vit * 7 + P.lvl * 6) * (hasFurn('altar') ? 1.1 : 1));
  const maxEn = Math.round(30 + b.int * 3 + b.wis * 2 + P.lvl * 3);
  return Object.assign(b, {def, maxHp, maxEn, crit:0.05 + b.dex * 0.004, speed:3.6 * (1 + b.dex * 0.004)});
}
function discEff(d) { return P.dl && P.dl[d] ? (P.discs[d] || 0) : 0; }
function canLearnDisc(d) { return !!P.discs[d] && !P.dl[d]; }
function learnDisc(d) {
  P.dl[d] = true;
  for (const id in SKILLS) if (SKILLS[id].d === d && SKILLS[id].lvl === 1 && !P.skills[id]) { P.skills[id] = 1; const f = P.slots.indexOf(null); if (f >= 0) P.slots[f] = id; }
  const gifts = {bogen:[['kurzbogen',1],['koecher_klein',1]], magie:[['knorrstab',1]], heil:[['pilgerstab',1]]}[d] || [];
  gifts.forEach(g => addItem(g[0], g[1]));
  if (d === 'bogen' && !P.eq.koecher) { const i = P.inv.findIndex(x => x.id === 'koecher_klein'); if (i >= 0) equipItem(i); P.arrows = Math.max(P.arrows, 20); }
  toast('🎓 Disziplin erlernt: ' + DISC[d].name + ' – erste Fähigkeit liegt auf einem Schnellknopf.', 'gold'); sfx('levelup');
}
function weaponDef() { return P.eq.waffe ? ITEMS[P.eq.waffe.id] : null; }
function weaponDmg() { const w = P.eq.waffe; if (!w) return 2; return ITEMS[w.id].dmg * (1 + 0.12 * (w.up || 0)) * (w.dur > 0 ? 1 : 0.5); }
function dmgMult() { return (1 + (P.buffs.schrei ? 0.35 : 0) + (P.buffs.held ? 0.2 : 0)) * (P.buffs.fluch ? 0.75 : 1); }
// Schwächungen, die Gegner dem Spieler zufügen
function applyDebuff(k, dur, dps) {
  const neu = !P.buffs[k]; P.buffs[k] = Math.max(P.buffs[k] || 0, dur);
  if (k === 'gift') P.giftDps = Math.max(dps || 0, neu ? 0 : P.giftDps || 0);
  if (neu) toast(k === 'gift' ? '🟢 Du bist vergiftet! (Heiltrank oder Heilung hilft)' : '🟣 Ein Fluch schwächt deine Angriffe!', 'warn');
}
function luck() { return P.eq.schmuck && ITEMS[P.eq.schmuck.id].luck || 0; }
function xpNeed(l) { return Math.floor(80 * Math.pow(l, 1.85)); }
// Erfahrung hängt vom Stufenunterschied ab: schwache Gegner bringen kaum noch etwas
function xpFactor(elvl) { const d = elvl - P.lvl; return d <= -6 ? 0.05 : d <= -4 ? 0.25 : d <= -2 ? 0.6 : 1 + Math.min(4, Math.max(0, d)) * 0.1; }
function lvlGap(e) { return (e.lvl || e.def.lvl || 1) - P.lvl; }
function profNeed(l) { return Math.floor(25 * Math.pow(l + 1, 1.7)); }
// Die Gruppe levelt gemeinsam: Gefährten, Kampftier und Reittier bekommen dieselbe Erfahrung wie du.
// Wer mehr als eine Stufe hinter dir liegt, holt doppelt so schnell auf.
function groupXp(x) {
  if (x <= 0) return;
  for (const id of P.party) { const l = compLvl(id); gainCompXp(id, Math.round(x * (l < P.lvl - 1 ? 2 : 1))); }
  const pets = new Set([P.petActive, P.mount].filter(i => i >= 0 && P.pets[i]));
  for (const pi of pets) gainPetXp(pi, Math.round(x * ((P.pets[pi].lvl || 1) < P.lvl - 1 ? 2 : 1)));
}
function gainXp(v) {
  const m = 1 + (hasFurn('trophaeen') ? 0.05 : 0) + (P.guild ? P.guild.lvl * 0.05 : 0) + (P.buffs.verliebt ? 0.1 : 0);
  P.xp += Math.round(v * m);
  groupXp(Math.round(v * m));
  while (P.xp >= xpNeed(P.lvl) && P.lvl < 50) {
    P.xp -= xpNeed(P.lvl); P.lvl++; P.attrPts += 3; P.skillPts += 1;
    const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
    toast('⭐ Stufe ' + P.lvl + '! +3 Attributpunkte, +1 Fähigkeitspunkt', 'gold'); sfx('levelup');
    ring(P.x, P.y - 0.5, 3, '#ffd75a'); burst(P.x, P.y - 0.6, '#ffe48a', 24);
    syncAllies();
  }
}
function learnProf(id) { P.learned[id] = true; if (P.prof[id].lvl < 1) P.prof[id].lvl = 1; toast('📖 Beruf erlernt: ' + PROFS[id].name, 'gold'); sfx('quest'); }
function profLevelUp(id, n) { const p = P.prof[id]; p.lvl = Math.min(10, p.lvl + n); p.xp = 0; if (PROFS[id].learn) P.learned[id] = true; toast(PROFS[id].icon + ' ' + PROFS[id].name + ' steigt auf Stufe ' + p.lvl + '!', 'gold'); sfx('levelup'); }
function gainProf(id, amt) {
  const p = P.prof[id];
  let m = 1; if (P.race === 'zwerg' && (id === 'schmieden' || id === 'bergbau')) m = 1.5; if (hasFurn('bibliothek')) m *= 1.15;
  if (p.lvl >= 10) return;
  p.xp += amt * m;
  while (p.xp >= profNeed(p.lvl) && p.lvl < 10) { p.xp -= profNeed(p.lvl); p.lvl++; toast(PROFS[id].icon + ' ' + PROFS[id].name + ' Stufe ' + p.lvl + '!', 'gold'); sfx('levelup'); }
}

// ---------- Inventar ----------
function invCap() { return P.eq.rucksack ? ITEMS[P.eq.rucksack.id].slots : 8; }
function quiverCap() { return P.eq.koecher ? ITEMS[P.eq.koecher.id].cap : 0; }
function countItem(id) { let n = 0; for (const s of P.inv) if (s.id === id) n += s.n; return n; }
function addItem(id, n, silent) {
  n = n || 1; const it = ITEMS[id]; if (!it) return false;
  if (it.type === 'ammo') {
    // Pfeilbündel wandern in den Köcher; was nicht passt, kommt in den Rucksack
    let toBag = 0; const cap = quiverCap();
    for (let k = 0; k < n; k++) { if (cap && P.arrows + it.amount <= cap) P.arrows += it.amount; else toBag++; }
    if (toBag) {
      const s = P.inv.find(s => s.id === id);
      if (s) s.n += toBag; else { if (P.inv.length >= invCap()) { if (!silent) toast('🎒 Inventar voll!'); return toBag < n; } P.inv.push({id, n:toBag}); }
      if (!silent) toast(cap ? 'Köcher voll – Pfeile liegen im Rucksack.' : 'Ohne Köcher kannst du keine Pfeile verschießen.');
    }
    return true;
  }
  if (it.stack) {
    const s = P.inv.find(s => s.id === id);
    if (s) s.n += n; else { if (P.inv.length >= invCap()) { if (!silent) toast('🎒 Inventar voll!'); return false; } P.inv.push({id, n}); }
  } else {
    for (let k = 0; k < n; k++) { if (P.inv.length >= invCap()) { if (!silent) toast('🎒 Inventar voll!'); return false; } P.inv.push(inst(id)); }
  }
  questEvent('collect');
  return true;
}
function loadArrows(verbose) {
  const cap = quiverCap(); if (!cap) { if (verbose) toast('Du brauchst einen Köcher.'); return false; }
  let moved = 0;
  while (countItem('pfeile') && P.arrows + ITEMS.pfeile.amount <= cap) { removeItem('pfeile', 1); P.arrows += ITEMS.pfeile.amount; moved++; }
  if (verbose) toast(moved ? 'Köcher nachgefüllt (' + P.arrows + '/' + cap + ').' : 'Köcher ist voll.');
  return moved > 0;
}
function removeItem(id, n) {
  n = n || 1;
  for (let i = P.inv.length - 1; i >= 0 && n > 0; i--) {
    const s = P.inv[i]; if (s.id !== id) continue;
    const take = Math.min(n, s.n); s.n -= take; n -= take; if (s.n <= 0) P.inv.splice(i, 1);
  }
}
const EQ_TYPES = ['waffe', 'helm', 'ruestung', 'handschuhe', 'hose', 'schuhe', 'koecher', 'rucksack', 'schmuck'];
const ARMOR_SLOTS = ['helm', 'ruestung', 'handschuhe', 'hose', 'schuhe'];
function equipItem(i) {
  const s = P.inv[i]; if (!s) return; const it = ITEMS[s.id]; const slot = it.type;
  if (!EQ_TYPES.includes(slot)) return;
  if (slot === 'rucksack') {
    const old = P.eq.rucksack, newCap = it.slots, need = P.inv.length - 1 + (old ? 1 : 0);
    if (need > newCap) { toast('Zu viele Gegenstände für diesen Rucksack.'); return; }
  }
  P.inv.splice(i, 1);
  if (P.eq[slot]) P.inv.push(P.eq[slot]);
  P.eq[slot] = s;
  if (slot === 'koecher' && P.arrows > quiverCap()) { toast('Überzählige Pfeile passen nicht in den Köcher.'); P.arrows = quiverCap(); }
  if (ARMOR_SLOTS.includes(slot)) refreshPlayerSprite();
  toast('Ausgerüstet: ' + it.name);
}
function unequip(slot) {
  const s = P.eq[slot]; if (!s) return;
  if (slot === 'rucksack') { toast('Den Rucksack ersetzt du, indem du einen anderen ausrüstest.'); return; }
  if (P.inv.length >= invCap()) { toast('🎒 Inventar voll!'); return; }
  P.inv.push(s); P.eq[slot] = null;
  if (slot === 'koecher') P.arrows = 0;
  if (ARMOR_SLOTS.includes(slot)) refreshPlayerSprite();
}
function useItem(i) {
  const s = P.inv[i]; if (!s) return; const it = ITEMS[s.id];
  if (it.type === 'ammo') { loadArrows(true); return; }
  if (it.use) { it.use(); return; }
  if (s.id === 'kochset') { placeCampfire(); return; }
  if (s.id === 'reparaturset' || s.id === 'meisterset') { useRepairKit(s.id); return; }
  if (it.type !== 'food') { equipItem(i); return; }
  if ((it.heal || it.mana) && P.potCd > 0) { toast('Noch ' + Math.ceil(P.potCd) + ' s, bevor du wieder etwas zu dir nehmen kannst.'); return; }
  const st = stats();
  sfx(it.id.includes('trank') ? 'heal' : 'eat');
  if (it.heal && it.id.includes('trank') && P.buffs.gift) { delete P.buffs.gift; toast('Das Gift ist neutralisiert.'); }
  if (it.heal) { const h = Math.min(it.heal, st.maxHp - P.hp); P.hp += h; floatText(P.x, P.y - 1.2, '+' + Math.round(h), '#6f6'); }
  if (it.mana) { P.en = Math.min(st.maxEn, P.en + it.mana); floatText(P.x, P.y - 1.4, '+' + it.mana + ' Energie', '#7af'); }
  if (it.buff) { P.buffs[it.buff[0]] = it.buff[1]; toast(it.icon + ' ' + BUFF_NAMES[it.buff[0]]); }
  if (it.heal || it.mana) P.potCd = 5;
  s.n--; if (s.n <= 0) P.inv.splice(i, 1);
}
const BUFF_NAMES = {schrei:'Kriegsschrei: +35 % Schaden', held:'Heldenmahl: Alle Werte +3, +20 % Schaden & Rüstung', satt:'Satt: Leben regeneriert schneller', mut:'Angeheitert: Flirten fällt leichter', verliebt:'Verliebt: +10 % Erfahrung', segen:'Segen: Regeneration & +10 Rüstung'};
function quickPotion() {
  const ids = ['grheiltrank', 'heiltrank', 'eintopf', 'gebraten', 'brot'];
  for (const id of ids) { const i = P.inv.findIndex(s => s.id === id); if (i >= 0) { useItem(i); return; } }
  toast('Keine Heilmittel im Inventar.');
}
function refreshPlayerSprite() { G.pspr = makeHumanoid(playerLook()); }
function playerLook() {
  const rc = RACES[P.race], cl = CLASSES[P.cls], arm = P.eq.ruestung ? P.eq.ruestung.id : 'lumpen';
  const col = sl => P.eq[sl] && ITEMS[P.eq[sl].id] ? ITEMS[P.eq[sl].id].col : null, as = ARMOR_STYLE[arm] || ['cloth'];
  return {skin:rc.skin, hair:P.hair, helm:!!P.eq.helm, helmCol:col('helm') || undefined, outfit:ARMOR_COLOR[arm] || cl.outfit, pants:col('hose') || cl.outfit2, feet:col('schuhe') || undefined, gloves:col('handschuhe') || undefined,
    female:P.gender === 'w', style:as[0], metal:as[1], scales:as[2], trim:'#d8b040', ears:P.race === 'elf', beard:P.race === 'zwerg' && P.gender === 'm', jewel:P.gender === 'w'};
}

// ---------- Quests ----------
function getQ(id) { return QUESTS[id] || P.dyn[id] || (P.board && P.board.list.find(b => b.id === id)); }
function questActive(id) { const s = P.q[id]; return !!(s && !s.done); }
function questDone(id) { const s = P.q && P.q[id]; return !!(s && s.done); }
function curStep(id) { const s = P.q[id]; if (!s || s.done) return null; const q = getQ(id); return q ? q.steps[s.s] : null; }
function stepIs(id, t) { const st = curStep(id); return !!(st && st.t === t); }
function offerQuest(id, silent) {
  if (P.q[id] || P.avail[id]) return; P.avail[id] = true;
  if (!silent) { toast('📜 Neuer Auftrag im Questbuch: ' + getQ(id).name, 'quest'); sfx('quest'); }
}
function acceptQuest(id) {
  delete P.avail[id];
  const bi = P.board.list.findIndex(b => b.id === id);
  if (bi >= 0) { P.dyn[id] = P.board.list[bi]; P.board.list.splice(bi, 1); }
  startQuest(id); P.track = id;
}
function abandonQuest(id) {
  const q = getQ(id); if (!q || q.main) return;
  delete P.q[id];
  if (P.dyn[id]) delete P.dyn[id]; else P.avail[id] = true;
  if (P.track === id) P.track = null;
  toast('Auftrag abgebrochen: ' + q.name);
}
function questOffer(id) {
  return {t:'📜 Auftrag: ' + QUESTS[id].name, q:true, f:() => ({text:QUESTS[id].desc + '<br><br><i>' + QUESTS[id].steps[0].txt + '</i>' + (QUESTS[id].lvl ? '<br><small>Empfohlen ab Stufe ' + QUESTS[id].lvl + '</small>' : ''), opts:[
    {t:'✅ Annehmen', f:() => { offerQuest(id, true); acceptQuest(id); return {text:'Der Auftrag steht jetzt in deinem Questbuch und wird am Bildschirmrand angezeigt.'}; }},
    {t:'📖 Später – im Questbuch notieren', f:() => { offerQuest(id); return {text:'Du kannst den Auftrag jederzeit im Questbuch (📜) annehmen.'}; }}]})};
}
function trackedQuest() {
  if (P.track && questActive(P.track)) return P.track;
  const act = Object.keys(P.q).filter(questActive);
  P.track = act.find(id => getQ(id).main) || act[0] || null; return P.track;
}
function startQuest(id) {
  if (P.q[id]) return; P.q[id] = {s:0, c:0, done:false};
  toast('📜 Quest angenommen: ' + getQ(id).name, 'quest'); sfx('quest'); checkStepAuto(id);
}
function advanceQuest(id, to) {
  const s = P.q[id], q = getQ(id); const old = q.steps[s.s];
  if (old && old.onDone) old.onDone();
  s.s = (to != null ? to : s.s + 1); s.c = 0;
  if (s.s >= q.steps.length) completeQuest(id);
  else { toast('📜 ' + q.steps[s.s].txt, 'quest'); checkStepAuto(id); }
}
function completeQuest(id) {
  const s = P.q[id], q = getQ(id); s.done = true;
  const r = q.reward || {};
  toast('✅ Quest abgeschlossen: ' + q.name, 'gold'); sfx('quest');
  if (r.gold) { P.gold += r.gold; toast('+' + r.gold + ' Gold'); sfx('coin'); }
  if (r.rep) { P.rep.stadt += r.rep; toast('🏰 Ansehen in Aldenmark +' + r.rep); }
  if (r.items) r.items.forEach(it => addItem(it[0], it[1]));
  if (r.prof) for (const k in r.prof) profLevelUp(k, r.prof[k]);
  if (q.onDone) q.onDone();
  if (r.xp) gainXp(r.xp);
  if (P.dyn[id]) { delete P.dyn[id]; delete P.q[id]; }
  if (P.track === id) P.track = null;
  if (q.next) { if (getQ(q.next) && getQ(q.next).main) { startQuest(q.next); P.track = q.next; } else offerQuest(q.next); }
}
function checkStepAuto(id) {
  const st = curStep(id); if (!st) return;
  if (st.t === 'collect' && !st.npc && countItem(st.item) >= st.n) advanceQuest(id);
  else if (st.t === 'goto' && regionAt(P.x, P.y) === st.region) advanceQuest(id);
}
function questEvent(type, arg) {
  if (!P) return;
  for (const id of Object.keys(P.q)) {
    const st = curStep(id); if (!st) continue;
    if (type === 'kill' && st.t === 'kill' && st.e === arg) {
      P.q[id].c++;
      if (P.q[id].c >= st.n) advanceQuest(id); else toast('📜 ' + ENEMIES[arg].name + ': ' + P.q[id].c + '/' + st.n);
    } else if (type === 'collect' || type === 'goto') checkStepAuto(id);
  }
}
function questOpts(npcId) {
  const out = [];
  for (const id of Object.keys(P.q)) {
    const st = curStep(id); if (!st) continue; const q = getQ(id);
    const say = s => typeof s === 'function' ? s() : s;
    if (st.t === 'talk' && st.npc === npcId) out.push({t:'📜 ' + q.name, q:true, f:() => { const tx = say(st.say); advanceQuest(id); return {text:tx}; }});
    if (st.t === 'collect' && st.npc === npcId && countItem(st.item) >= st.n)
      out.push({t:'📜 ' + st.n + '× ' + ITEMS[st.item].name + ' abgeben', q:true, f:() => { removeItem(st.item, st.n); const tx = say(st.say); advanceQuest(id); return {text:tx}; }});
    if (st.t === 'branch') for (const o of st.opts) {
      if (o.npc !== npcId || (o.need && countItem(o.need) < 1)) continue;
      out.push({t:o.label, q:true, f:() => { if (o.fn) o.fn(); advanceQuest(id, o.jump); return {text:o.say}; }});
    }
  }
  return out;
}
function bountyCount() { return Object.keys(P.dyn).length; }
function refreshBoard() {
  if (!questDone('gilde')) return;
  if (P.board.day === G.day && P.board.list.length) return;
  P.board.day = G.day; P.board.list = [];
  const pool = ['ratte','wolf','goblin','eber','bandit','schleim','skelett','baer','troll','soldat','warg','schattenritter'].filter(t => ENEMIES[t].lvl <= P.lvl + 2 && ENEMIES[t].lvl >= P.lvl - 6);
  for (let k = 0; k < 3; k++) {
    const e = pick(pool.length ? pool : ['wolf']), d = ENEMIES[e], n = rint(4, 8);
    P.bountyN = (P.bountyN || 0) + 1;
    P.board.list.push({id:'kopfgeld' + P.bountyN, name:'Kopfgeld: ' + d.name, bounty:true, giver:'Auftragsbrett der Gilde', desc:'Die Gilde zahlt für erlegte ' + d.name + '. Lohn bei Sera abholen.',
      steps:[{t:'kill', e, n, txt:'Erlege ' + n + '× ' + d.name + '.'}, {t:'talk', npc:'sera', txt:'Hol dir dein Kopfgeld bei Sera in der Gilde ab.', say:'„Auftrag erledigt. Hier ist dein Lohn.“'}],
      reward:{xp:Math.round(d.xp * n * 0.7), gold:Math.round(d.xp * n * 0.6 + 20), rep:2}});
  }
}

// ---------- Kampf ----------
// Gefährten und Tiere greifen nur an, wenn du angreifst oder die Gruppe angegriffen wird.
// Tiere, die du gerade zähmen willst (friedlich oder schon geschwächt), lassen sie in Ruhe.
function allyMayAttack(e) {
  if (!e.engaged) return false;
  const tm = e.def.tame;
  if (tm && P.learned.zaehmen && P.prof.zaehmen.lvl + (P.race === 'ork' ? 1 : 0) >= tm.lvl && (e.def.passive || e.hp < e.maxHp * 0.4)) return false;
  return true;
}
function nearestEnemy(x, y, r, filt) {
  let best = null, bd = r;
  for (const e of G.enemies) { if (e.dead || (filt && !filt(e))) continue; if (e.def.passive && !e.flee) continue; const d = dist(x, y, e.x, e.y); if (d < bd) { bd = d; best = e; } }
  return best;
}
function faceTo(e) { const dx = e.x - P.x, dy = e.y - P.y, l = Math.hypot(dx, dy) || 1; P.face = {x:dx / l, y:dy / l}; P.dir = dx < 0 ? -1 : 1; }
function wearWeapon() {
  const w = P.eq.waffe; if (!w) return;
  const before = w.dur; w.dur = Math.max(0, w.dur - 0.25);
  if (before > 20 && w.dur <= 20) toast('⚠️ Deine Waffe ist stark abgenutzt. Repariere sie am Amboss, bei Gunnar oder mit einem Reparaturset!');
  if (before > 0 && w.dur <= 0) toast('💔 Deine Waffe ist beschädigt – nur noch halber Schaden.');
}
function attack() {
  if (P.atkCd > 0 || P.dead || P.work) return;
  const w = weaponDef(), wt = w ? w.wt : 'melee', st = G.st;
  const tgt = nearestEnemy(P.x, P.y, wt === 'melee' ? 2.4 : 9);
  if (tgt) faceTo(tgt);
  const base = weaponDmg();
  const staffNoMagic = wt === 'staff' && !discEff('magie') && !discEff('heil');
  if (wt === 'melee' || staffNoMagic) {
    const eff = discEff('kampf') || 0.6; sfx('swing');
    const dmg = (base + st.str * 0.55) * eff * dmgMult() * (P.race === 'ork' ? 1.1 : 1);
    P.atkCd = 0.45; P.swing = 0.2; let hit = false, hits = 0;
    for (const e of G.enemies) {
      if (e.dead) continue; const d = dist(P.x, P.y, e.x, e.y), reach = 1.4 + 0.3 * e.size;
      if (d > reach) continue;
      const dot = ((e.x - P.x) * P.face.x + (e.y - P.y) * P.face.y) / (d || 1);
      if ((d < 0.8 || dot > 0.25) && hits < 2) { dealDmg(e, dmg, {src:'p', kb:0.35, holy:w && w.holy}); hit = true; hits++; }
    }
    if (hit) wearWeapon();
  } else if (wt === 'bow') {
    if (P.arrows <= 0 && !loadArrows(false)) { toast('Keine Pfeile! Kauf welche oder stell sie her (Holz + Stein).'); P.atkCd = 0.6; return; }
    P.arrows--; sfx('bow');
    const eff = discEff('bogen') || 0.6;
    const dmg = (base + st.dex * 0.55) * eff * dmgMult() * (P.race === 'elf' ? 1.1 : 1);
    shoot(P.x, P.y - 0.5, P.face.x, P.face.y, 'arrow', dmg, 'p', {speed:13, range:10});
    P.atkCd = 0.6; P.swing = 0.15; wearWeapon();
  } else {
    const holyish = discEff('heil') && !discEff('magie'); sfx('magic');
    const eff = discEff('magie') || discEff('heil') || 0.6;
    const dmg = (base + Math.max(st.int, st.wis) * 0.55) * eff * dmgMult();
    shoot(P.x, P.y - 0.5, P.face.x, P.face.y, holyish ? 'holy' : 'bolt', dmg, 'p', {speed:10, range:9, holy:holyish});
    P.atkCd = 0.55; P.swing = 0.15; wearWeapon();
  }
}
function shoot(x, y, dx, dy, kind, dmg, team, o) {
  const l = Math.hypot(dx, dy) || 1, sp = (o && o.speed) || 10;
  G.proj.push(Object.assign({x, y, vx:dx / l * sp, vy:dy / l * sp, kind, dmg, team, life:((o && o.range) || 9) / sp, r:0.35}, o || {}));
}
function dealDmg(e, dmg, o) {
  if (e.dead) return; o = o || {};
  let crit = false;
  if (o.src === 'p' && Math.random() < G.st.crit) { dmg *= 1.75; crit = true; }
  if (o.holy && e.def.undead) dmg *= 2;
  if (o.src !== 'dot') { const g = lvlGap(e); if (g > 0) dmg *= Math.max(0.45, 1 - 0.07 * g); }
  dmg *= rnd(0.9, 1.1); dmg = Math.max(1, Math.round(dmg));
  e.hp -= dmg; e.hitT = 0.15; e.aggro = true; if (o.src !== 'a') e.engaged = true;   // du hast angegriffen → die Gruppe hilft if (o.src !== 'dot') sfx(crit ? 'crit' : 'hit');
  if (e.def.passive) e.flee = 5;
  floatText(e.x + rnd(-0.3, 0.3), e.y - 1.1 * e.size, (crit ? '💥' : '') + dmg, crit ? '#ffcf40' : (o.src === 'dot' ? '#9f6' : '#fff'), crit);
  if (o.kb && !e.boss) { const fx = o.fx != null ? o.fx : P.x, fy = o.fy != null ? o.fy : P.y; const dx = e.x - fx, dy = e.y - fy, l = Math.hypot(dx, dy) || 1; moveEnt(e, dx / l * o.kb, dy / l * o.kb, true); }
  if (e.hp <= 0) killEnemy(e);
}
function killEnemy(e) {
  if (e.dead) return; e.dead = true; const d = e.def;
  gainXp(Math.max(1, Math.round((e.xp || d.xp) * xpFactor(e.lvl))));
  sfx('kill');
  if (d.gold) { const g = Math.round(rint(d.gold[0], d.gold[1]) * Math.min(1.5, e.gm || 1)); if (g > 0) { P.gold += g; floatText(e.x, e.y - 1.5, '+' + g + ' Gold', '#ffd75a'); sfx('coin'); } }
  for (const dr of d.drops || []) if (Math.random() < dr[1] * (1 + luck())) dropItem(e.x, e.y, dr[0], dr[2] || 1);
  for (const qid of Object.keys(P.q)) { const st = curStep(qid); if (st && st.t === 'collect' && st.from === e.type && Math.random() < st.p) dropItem(e.x, e.y, st.item, 1); }
  P.kills[e.type] = (P.kills[e.type] || 0) + 1;
  if (d.boss) { P.f[e.type + 'Tot'] = true; toast('🏆 ' + d.name + ' wurde besiegt!', 'gold'); G.shake = 0.5; }
  burst(e.x, e.y - 0.5, d.col, 14);
  questEvent('kill', e.type);
}
// Beute landet immer auf einem begehbaren Feld (nicht in Wasser, Bäumen oder Mauern)
function dropItem(x, y, id, n) {
  if (!ITEMS[id]) return;
  let px = x + rnd(-0.4, 0.4), py = y + rnd(-0.3, 0.3);
  if (!walkable(px, py)) {
    let best = null, bd = 99;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
      const tx = Math.floor(x) + dx, ty = Math.floor(y) + dy;
      if (!walkable(tx + 0.5, ty + 0.5)) continue;
      const dd = Math.hypot(tx + 0.5 - x, ty + 0.5 - y); if (dd < bd) { bd = dd; best = [tx + 0.5, ty + 0.5]; }
    }
    if (!best) best = [P.x, P.y];
    px = best[0]; py = best[1];
  }
  const same = G.drops.find(d => d.id === id && ITEMS[id].stack && dist(d.x, d.y, px, py) < 0.6);
  if (same) { same.n += n; return; }
  G.drops.push({x:px, y:py, id, n, t:0, z:0, vz:2.2});
}
function tryPickup(d) {
  if (addItem(d.id, d.n, true)) { floatItem(d.x, d.y - 0.6, d.id, d.n); sfx('pickup'); return true; }
  d.wait = 3;
  if (G.t - (G.fullMsg || -9) > 4) { G.fullMsg = G.t; toast('🎒 Inventar voll – ' + ITEMS[d.id].name + ' bleibt liegen.', 'warn'); sfx('fail'); }
  return false;
}
function allyTargets() { const a = G.allies.filter(x => !x.down); if (!P.dead) a.unshift(P); return a; }
function hurt(a, dmg) {
  if (a === P) {
    if (P.invuln > 0 || P.dead) return;
    const red = 100 / (100 + G.st.def * 4);
    dmg = Math.max(1, Math.round(dmg * red * rnd(0.9, 1.1)));
    P.hp -= dmg; P.lastHit = G.t; P.hitT = 0.2; sfx('hurt');
    floatText(P.x, P.y - 1.2, '-' + dmg, '#ff5a4a');
    { const worn = ARMOR_SLOTS.filter(sl => P.eq[sl]); if (worn.length) { const a = P.eq[pick(worn)]; a.dur = Math.max(0, a.dur - 0.4); } }
    if (P.work) P.work = null;
    if (P.hp <= 0) playerDie();
  } else {
    dmg = Math.max(1, Math.round(dmg * 0.85 * (a.def ? 100 / (100 + a.def * 4) : 1)));
    a.hp -= dmg; a.hitT = 0.2; a.lastHit = G.t; floatText(a.x, a.y - 1.1, '-' + dmg, '#ff9a8a');
    if (a.hp <= 0) { a.hp = 0; a.down = true; a.downT = 0; if (a.kind !== 'pet') toast('😵 ' + a.name + ' ist bewusstlos!'); }
  }
}
function healAlly(a, amt) {
  if (a === P) { const m = G.st.maxHp; const h = Math.min(amt, m - P.hp); if (h > 0) { P.hp += h; floatText(P.x, P.y - 1.3, '+' + Math.round(h), '#6f6'); } }
  else if (!a.down) { const h = Math.min(amt, a.maxHp - a.hp); if (h > 0) { a.hp += h; floatText(a.x, a.y - 1.2, '+' + Math.round(h), '#6f6'); } }
}
function playerDie() {
  P.dead = true; P.hp = 0; P.mounted = false; sfx('die');
  showDeath();
}
function respawn() {
  const loss = Math.floor(P.gold * 0.1); P.gold -= loss;
  let pos = ipos(['hilde', 3.5, 3.6]);
  for (const h of P.houses) if ((P.furn[h] || []).includes('bett')) pos = INTERIORS['h_' + h].entry;
  P.x = pos[0]; P.y = pos[1]; P.dead = false;
  const st = stats(); P.hp = st.maxHp * 0.6; P.en = st.maxEn * 0.5;
  G.enemies = G.enemies.filter(e => dist(e.x, e.y, P.x, P.y) > 20);
  G.allies.forEach(a => { a.x = P.x + rnd(-1, 1); a.y = P.y + rnd(0.5, 1); a.down = false; a.hp = a.maxHp * 0.5; });
  toast(loss ? 'Du hast ' + loss + ' Gold verloren.' : 'Du kommst wieder zu dir…');
}

// ---------- Fähigkeiten ----------
function skillPower(sk, id) {
  const st = G.st, w = weaponDef(), wd = weaponDmg(), rank = P.skills[id] || 1;
  let p;
  if (sk.d === 'kampf') p = (w && w.wt === 'melee' ? wd : 4) + st.str * 0.8;
  else if (sk.d === 'magie') p = 5 + st.int * 1.2 + (w && w.wt === 'staff' ? wd * 0.6 : 0);
  else if (sk.d === 'bogen') p = (w && w.wt === 'bow' ? wd : 4) + st.dex * 0.8;
  else p = 5 + st.wis * 1.15 + (w && w.wt === 'staff' ? wd * 0.5 : 0);
  const hb = sk.d === 'heil' && w && w.healBonus ? 1 + w.healBonus : 1;
  return p * discEff(sk.d) * (1 + 0.2 * (rank - 1)) * dmgMult() * hb;
}
// ---------- Was ein Rang bringt ----------
// Jeder Rang: +20 % Wirkung, −6 % Abklingzeit, −4 % Energie; Stärkungen halten länger
const SKILL_FX = {
  wirbel:{m:1.3, l:'Schaden an allen Gegnern im Umkreis'}, ansturm:{m:1.5, l:'Schaden'}, beben:{m:2.2, l:'Schaden + 2 s Betäubung'},
  feuerball:{m:1.6, l:'Flächenschaden'}, frost:{m:1.0, l:'Schaden + Verlangsamung'}, blitz:{m:1.4, l:'Schaden am ersten Ziel'}, meteor:{m:3.0, l:'Einschlagschaden'},
  mehrfach:{m:0.8, l:'Schaden pro Pfeil (5 Pfeile)'}, gift:{m:0.8, l:'Treffer', dot:0.35 * 6}, hagel:{m:2.0, l:'Gesamtschaden im Gebiet'},
  heilung:{m:1.5, l:'Heilung für die Gruppe', heal:true}, licht:{m:1.4, l:'Schaden (doppelt gegen Untote)'},
  schrei:{dur:[10, 2], l:'+35 % Schaden für die Gruppe'}, segen:{dur:[15, 3], l:'Regeneration & +10 Rüstung'}, rolle:{inv:[0.5, 0.1], l:'Unverwundbar beim Ausweichen'}, wunder:{l:'Volle Heilung, belebt Bewusstlose'}
};
function skillRank(id) { return P.skills[id] || 1; }
function skillCost(id) { return Math.max(1, Math.round(SKILLS[id].cost * (1 - 0.04 * (skillRank(id) - 1)))); }
function skillCd(id) { return +(SKILLS[id].cd * (1 - 0.06 * (skillRank(id) - 1))).toFixed(1); }
function skillDur(id) { const f = SKILL_FX[id]; return f && f.dur ? f.dur[0] + f.dur[1] * (skillRank(id) - 1) : 0; }
// Zahlenangabe für das Fähigkeitenmenü (rank = welcher Rang angezeigt wird)
function skillInfo(id, rank) {
  const keep = P.skills[id]; P.skills[id] = rank;
  const sk = SKILLS[id], f = SKILL_FX[id] || {}, st = G.st || stats(); G.st = st;
  let t;
  if (f.m) { const v = Math.round(skillPower(sk, id) * f.m); t = v + ' ' + f.l + (f.dot ? ' + ' + Math.round(skillPower(sk, id) * f.dot) + ' Gift über 6 s' : ''); }
  else if (f.dur) t = f.l + ' für ' + skillDur(id) + ' s';
  else if (f.inv) t = f.l + ' (' + (f.inv[0] + f.inv[1] * (rank - 1)).toFixed(1) + ' s)';
  else t = f.l || '';
  t += ' · ' + skillCost(id) + ' Energie · ' + skillCd(id) + ' s';
  P.skills[id] = keep; return t;
}
function castSkill(slot) {
  const id = P.slots[slot]; if (!id || P.dead || P.work) return;
  const sk = SKILLS[id];
  if ((P.cds[id] || 0) > 0) return;
  if (P.en < skillCost(id)) { toast('Nicht genug Energie.'); return; }
  const needArrow = ['mehrfach', 'gift', 'hagel'].includes(id);
  if (needArrow && P.arrows <= 0) { toast('Keine Pfeile!'); return; }
  if (!P.dl[sk.d]) return;
  const sp = skillPower(sk, id);
  const tgt = nearestEnemy(P.x, P.y, 10); if (tgt) faceTo(tgt);
  const fx = P.face.x, fy = P.face.y;
  switch (id) {
    case 'wirbel': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 2.2) dealDmg(e, sp * 1.3, {src:'p', kb:0.6}); ring(P.x, P.y - 0.3, 2.2, '#ddd'); P.spin = 0.3; break;
    case 'schrei': P.buffs.schrei = skillDur(id); ring(P.x, P.y - 0.5, 4, '#f84'); toast('📣 Kriegsschrei!'); break;
    case 'ansturm': P.dash = {t:0.25, vx:fx * 14, vy:fy * 14, dmg:sp * 1.5, hit:[]}; P.invuln = 0.35; break;
    case 'beben': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 4) { dealDmg(e, sp * 2.2, {src:'p', kb:0.4}); e.stun = 2; } ring(P.x, P.y, 4, '#a86'); G.shake = 0.4; break;
    case 'feuerball': shoot(P.x, P.y - 0.5, fx, fy, 'fire', sp * 1.6, 'p', {speed:9, range:10, aoe:1.6}); break;
    case 'frost': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 3.5) { dealDmg(e, sp, {src:'p'}); e.slow = 4; } ring(P.x, P.y - 0.3, 3.5, '#9df'); break;
    case 'blitz': {
      let cur = tgt; if (!cur) { toast('Kein Ziel in Reichweite.'); return; }
      const hit = [], pts = [[P.x, P.y - 0.6]]; let d = sp * 1.4;
      for (let k = 0; k < 4 && cur; k++) { hit.push(cur); pts.push([cur.x, cur.y - 0.5]); dealDmg(cur, d, {src:'p'}); d *= 0.8; const c = cur; cur = nearestEnemy(c.x, c.y, 4, e => !hit.includes(e)); }
      G.fx.push({k:'line', pts, life:0.25, col:'#bdf'}); break; }
    case 'meteor': { const tx = tgt ? tgt.x : P.x + fx * 4, ty = tgt ? tgt.y : P.y + fy * 4; G.fx.push({k:'meteor', x:tx, y:ty, t:0, life:0.8, dmg:sp * 3}); setTimeout(() => sfx('boom'), 750); break; }
    case 'mehrfach': P.arrows--; for (let k = -2; k <= 2; k++) { const a = Math.atan2(fy, fx) + k * 0.18; shoot(P.x, P.y - 0.5, Math.cos(a), Math.sin(a), 'arrow', sp * 0.8, 'p', {speed:13, range:9}); } break;
    case 'gift': P.arrows--; shoot(P.x, P.y - 0.5, fx, fy, 'poison', sp * 0.8, 'p', {speed:13, range:10, poison:sp * 0.35}); break;
    case 'rolle': P.dash = {t:0.25, vx:-fx * 12, vy:-fy * 12}; P.invuln = 0.5 + 0.1 * (skillRank(id) - 1); break;
    case 'hagel': { P.arrows = Math.max(0, P.arrows - 5); const tx = tgt ? tgt.x : P.x + fx * 4, ty = tgt ? tgt.y : P.y + fy * 4; G.fx.push({k:'rain', x:tx, y:ty, t:0, life:2, tick:0, dmg:sp * 0.45}); break; }
    case 'heilung': { if (P.buffs.gift) delete P.buffs.gift; const h = sp * 1.5; for (const a of allyTargets()) if (dist(P.x, P.y, a.x, a.y) < 8) healAlly(a, h); ring(P.x, P.y - 0.4, 3, '#7f7'); burst(P.x, P.y - 0.6, '#8f8', 10); break; }
    case 'licht': shoot(P.x, P.y - 0.5, fx, fy, 'holy', sp * 1.4, 'p', {speed:11, range:10, holy:true}); break;
    case 'segen': P.buffs.segen = skillDur(id); ring(P.x, P.y - 0.4, 4, '#ffe'); toast('🙏 Segen!'); break;
    case 'wunder': for (const a of G.allies) { a.down = false; a.hp = a.maxHp; } P.hp = G.st.maxHp; ring(P.x, P.y - 0.4, 6, '#fff6b0'); burst(P.x, P.y - 1, '#fff', 30); toast('👼 Wunder!'); break;
  }
  P.en -= skillCost(id); P.cds[id] = skillCd(id);
  sfx({wirbel:'swing', schrei:'roar', ansturm:'swing', beben:'boom', feuerball:'fire', frost:'frost', blitz:'zap', meteor:'fire', mehrfach:'bow', gift:'bow', rolle:'swing', hagel:'bow', heilung:'heal', licht:'holy', segen:'holy', wunder:'heal'}[id]);
}

// ---------- Gegner ----------
function spawnEnemy(type, x, y, o) {
  const d = ENEMIES[type], sz = d.size || 1;
  const hm = d.boss ? 1.3 : 1.75, dm = d.boss ? 1.25 : 1.5;
  // Gegner passen sich der Stufe ihres Gebiets an
  const lvl = (o && o.lvl) || d.lvl, fh = (20 + 12 * lvl) / (20 + 12 * d.lvl), fd = (3 + 1.6 * lvl) / (3 + 1.6 * d.lvl), fx = (6 + 6 * lvl) / (6 + 6 * d.lvl);
  const mhp = Math.round(d.hp * hm * fh);
  const e = Object.assign({kind:'enemy', type, def:d, lvl, xp:Math.max(1, Math.round(d.xp * fx)), gm:fx, x, y, hx:x, hy:y, hp:mhp, maxHp:mhp, dmg:d.dmg * dm * fd, spd:d.spd, r:Math.min(0.45, 0.28 * sz), size:sz,
    cd:rnd(0.5, 1.5), wt:0, wx:0, wy:0, hitT:0, slow:0, stun:0, poison:null, aggro:false, flee:0, special:5, boss:!!d.boss, spr:enemySprite(type)}, o || {});
  G.enemies.push(e); return e;
}
function updEnemy(e, dt) {
  if (e.hitT > 0) e.hitT -= dt;
  if (e.poison) { e.poison.t -= dt; e.pt = (e.pt || 0) + dt; if (e.pt >= 1) { e.pt = 0; dealDmg(e, e.poison.dps, {src:'dot'}); } if (e.poison && e.poison.t <= 0) e.poison = null; if (e.dead) return; }
  if (e.stun > 0) { e.stun -= dt; return; }
  const d = e.def, spd = e.spd * (e.slow > 0 ? 0.5 : 1), en = !e.boss;
  if (e.slow > 0) e.slow -= dt;
  e.cd -= dt; e.moving = false;
  const wander = () => {
    e.wt -= dt;
    if (e.wt <= 0) { e.wt = rnd(1.5, 3.5); const a = Math.random() * TAU; const go = chance(0.6); e.wx = go ? Math.cos(a) : 0; e.wy = go ? Math.sin(a) : 0; if (dist(e.x, e.y, e.hx, e.hy) > 7) { const dx = e.hx - e.x, dy = e.hy - e.y, l = Math.hypot(dx, dy); e.wx = dx / l; e.wy = dy / l; } }
    if (e.wx || e.wy) { if (moveEnt(e, e.wx * spd * 0.35 * dt, e.wy * spd * 0.35 * dt, en)) { e.moving = true; e.dir = e.wx < 0 ? -1 : 1; } else e.wt = 0; }
  };
  if (d.passive) {
    if (e.flee > 0) { e.flee -= dt; const dx = e.x - P.x, dy = e.y - P.y, l = Math.hypot(dx, dy) || 1; if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) { e.moving = true; e.dir = dx < 0 ? -1 : 1; } }
    else wander();
    return;
  }
  // Zu weit vom Zuhause weggelockt: Gegner gibt auf, kehrt um und heilt sich
  if (!e.boss && (e.returning || dist(e.x, e.y, e.hx, e.hy) > 16)) {
    e.returning = true; e.aggro = false; e.wind = 0;
    const hx = e.hx - e.x, hy = e.hy - e.y, hl = Math.hypot(hx, hy);
    if (hl < 1.5) e.returning = false;
    else { moveEnt(e, hx / hl * spd * 1.3 * dt, hy / hl * spd * 1.3 * dt, en); e.moving = true; e.dir = hx < 0 ? -1 : 1; }
    e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.25 * dt);
    if (hl > 30) { e.x = e.hx; e.y = e.hy; e.returning = false; }
    return;
  }
  let t = null, td = e.aggro ? 11 : e.neutral ? 0 : (e.boss ? 9 : 5.5);
  for (const a of allyTargets()) { const dd = dist(e.x, e.y, a.x, a.y); if (dd < td) { td = dd; t = a; } }
  if (!t) { e.aggro = false; wander(); return; }
  // Wird ein Rudeltier angegriffen, kommen die anderen zu Hilfe
  if (e.aggro && !e.calledPack) { e.calledPack = true; for (const o of G.enemies) if (o !== e && o.type === e.type && !o.dead && dist(o.x, o.y, e.x, e.y) < 5) o.aggro = true; }
  const dx = t.x - e.x, dy = t.y - e.y, l = Math.hypot(dx, dy) || 1; e.dir = dx < 0 ? -1 : 1;
  if (e.boss) {
    e.special -= dt;
    if (e.special <= 0) { e.engaged = true;
      e.special = e.type === 'malgor' || e.type === 'wyrm' ? 5 : 7;
      if (e.type === 'graupelz') {
        // heult und ruft ihr Rudel
        e.special = 9; sfx('roar'); ring(e.x, e.y - 0.5, 3, '#ccd');
        if (G.enemies.length < 16) for (let k = 0; k < 2; k++) { const x = e.x + rnd(-2, 2), y = e.y + rnd(-2, 2); if (canStand(x, y, 0.3, true)) spawnEnemy('wolf', x, y, {aggro:true, lvl:6}); }
        toast('🐺 Die Alte Graupelz heult – ihr Rudel kommt!', 'warn');
      } else if (e.type === 'brueckentroll') {
        // stampft auf den Boden
        e.special = 6; ring(e.x, e.y, 2.8, '#a86'); G.shake = 0.3; sfx('boom');
        for (const a of allyTargets()) if (dist(e.x, e.y, a.x, a.y) < 2.8) hurt(a, enemyDmg(e) * 1.2);
      } else {
        const nShots = e.type === 'knochenkoenig' ? 8 : 10;
        for (let k = 0; k < nShots; k++) { const a = k / nShots * TAU; shoot(e.x, e.y - 0.5 * e.size, Math.cos(a), Math.sin(a), d.proj || 'shadow', e.dmg * 0.7, 'e', {speed:6, range:8}); }
        if (e.type === 'knochenkoenig' && G.enemies.length < 16) { const x = e.x + rnd(-2, 2), y = e.y + rnd(-2, 2); if (canStand(x, y, 0.3, true)) spawnEnemy('skelett', x, y, {aggro:true, lvl:8}); }
      }
      if (e.type === 'malgor' && G.enemies.length < 20) for (let k = 0; k < 2; k++) spawnEnemy('schattenritter', e.x + rnd(-2, 2), e.y + rnd(-2, 2), {aggro:true});
    }
  }
  if (d.ranged) {
    if (l > 6) { if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) e.moving = true; }
    else if (l < 2.6 && !e.boss) { if (moveEnt(e, -dx / l * spd * 0.7 * dt, -dy / l * spd * 0.7 * dt, en)) e.moving = true; }
    if (l < 7.5 && e.cd <= 0) { e.engaged = true; shoot(e.x, e.y - 0.5 * e.size, dx, dy, d.proj || 'arrow', enemyDmg(e), 'e', {speed:d.proj === 'arrow' ? 10 : 7, range:9}); e.cd = e.boss ? 1.1 : 1.8; }
  } else {
    const range = 0.75 + 0.35 * e.size;
    if (l > range) { if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) e.moving = true; }
    else if (e.cd <= 0 && !e.wind) { e.wind = 0.38; e.wt2 = t; e.cd = 1.15; e.engaged = true; }
  }
  // Ausholen: Wer rechtzeitig ausweicht, wird nicht getroffen
  if (e.wind) {
    e.wind -= dt;
    if (e.wind <= 0) {
      e.wind = 0; e.atk = 0.2; const tt = e.wt2;
      if (tt && !tt.down && !(tt === P && P.dead) && dist(e.x, e.y, tt.x, tt.y) < 0.75 + 0.35 * e.size + 0.45) { hurt(tt, enemyDmg(e)); if (tt === P && !P.dead && e.type === 'schleim' && chance(0.4)) applyDebuff('gift', 6, Math.max(2, e.dmg * 0.2)); }
    }
  }
  if (e.atk > 0) e.atk -= dt;
}
function enemyDmg(e) { const g = lvlGap(e); return e.dmg * (g > 0 ? Math.min(1.6, 1 + 0.08 * g) : Math.max(0.7, 1 + 0.04 * g)); }
const PACK = {wolf:[2, 3], warg:[2, 3], goblin:[2, 3], bandit:[2, 2], soldat:[2, 3], pirat:[2, 3], krabbe:[2, 2], salamander:[2, 2], legionaer:[2, 3], wuestenraeuber:[2, 3], skorpion:[2, 2], kriegshund:[2, 3]};
function spawnTick() {
  // Rattenviertel: Ratten kommen begrenzt aus den Abflüssen – nicht endlos
  const gc = shiftOld(59, 115);
  if (regionAt(P.x, P.y) === 'gosse' || dist(P.x, P.y, gc[0], gc[1]) < 14) {
    // nur Ratten zählen, die wirklich im Viertel unterwegs sind (nicht die harmlosen auf den Wiesen)
    const rats = G.enemies.filter(e => e.type === 'ratte' && !e.dead && !e.neutral && dist(e.x, e.y, gc[0], gc[1]) < 20).length;
    let max = 0, every = 0;
    if (stepIs('ratten', 'kill')) { const left = curStep('ratten').n - P.q.ratten.c; max = Math.min(2, left); every = rnd(9, 13); }
    else if (isNight()) { max = 1; every = 90; }   // nachts verirrt sich ab und zu eine einzelne Ratte
    G.ratT = (G.ratT || 0) - 1.2;
    if (rats === 0 && max > 0 && G.ratT > 3) G.ratT = 3;   // ist gerade keine Ratte da, kommt die nächste bald
    if (rats < max && G.ratT <= 0) {
      const drains = [[57.5, 113.5], [61.5, 117.5], [55.5, 120.5], [63.5, 112.5]].map(q => shiftOld(q[0], q[1])).filter(d => canStand(d[0], d[1], 0.25, true) && dist(d[0], d[1], P.x, P.y) > 3);
      if (drains.length) { const d = pick(drains); spawnEnemy('ratte', d[0], d[1], {lvl:1}); burst(d[0], d[1] - 0.2, '#5a4a3a', 8); G.ratT = every; }
    }
  }
  G.spawnT2 = (G.spawnT2 || 0) - 1.2; if (G.spawnT2 > 0) return;
  const pz = ZONES[regionAt(P.x, P.y)];
  let near = 0; for (const e of G.enemies) if (!e.boss && dist(e.x, e.y, P.x, P.y) < 24) near++;
  const cap = (pz ? pz.cap : 3) + (isNight() && pz && pz.cap ? 1 : 0); if (near >= cap) return;
  for (let k = 0; k < 12; k++) {
    const a = Math.random() * TAU, r = rnd(11, 17), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
    if (!canStand(x, y, 0.3, true) || !spawnAllowed(x, y)) continue;
    const reg = regionAt(x, y), z = ZONES[reg]; if (!z || !z.mobs.length) continue;
    const tab = isNight() && z.night ? z.mobs.concat(z.night) : z.mobs;
    const ty = wpick(tab); let n = 1;
    if (PACK[ty] && z.pack && chance(z.pack)) n = rint(PACK[ty][0], PACK[ty][1]);
    for (let j = 0; j < n; j++) {
      const sx = x + rnd(-1, 1), sy = y + rnd(-1, 1), ok = canStand(sx, sy, 0.3, true);
      spawnEnemy(ty, ok ? sx : x, ok ? sy : y, {lvl:rint(z.lv[0], z.lv[1]), neutral:!!z.neutral && !ENEMIES[ty].passive});
    }
    G.spawnT2 = rnd(1.5, 3);   // nach jedem Spawn eine Pause, damit nicht ständig Nachschub kommt
    return;
  }
}
// Schutzzone um Städte und Dörfer: dort tauchen keine Gegner auf
function spawnAllowed(x, y) {
  const r = regionAt(x, y); if (REGION_INFO[r] && REGION_INFO[r].safe) return false; if (r === 'gosse' || r === 'stadt' || r === 'dorf') return false;
  if (typeof SOUTH_SAFE !== 'undefined') for (const s of SOUTH_SAFE) if (Math.hypot(x - s[0], y - s[1]) < s[2]) return false;
  const a = placeCenter('alden'), d = placeCenter('dorf');
  return Math.hypot(x - a[0], y - a[1]) > 26 && Math.hypot(x - d[0], y - d[1]) > 15;
}
function bossTick() {
  const want = {};
  for (const id of Object.keys(P.q)) { const st = curStep(id); if (st && st.t === 'kill' && BOSS_POS[st.e]) want[st.e] = true; }
  if (!P.f.wyrmTot) want.wyrm = true;
  for (const b in want) {
    const p = BOSS_POS[b]; if (dist(P.x, P.y, p[0], p[1]) > 22) continue;
    if (G.enemies.some(e => e.type === b && !e.dead)) continue;
    const be = spawnEnemy(b, p[0], p[1]);
    if (b === 'malgor' && P.f.kasimir) { be.maxHp = Math.round(be.maxHp * 0.75); be.hp = be.maxHp; setTimeout(() => toast('🗡️ Dank Kasimirs Hinweis zerschlägst du zuerst die Kristallsäulen – Malgor ist geschwächt!', 'gold'), 1200); }
    toast('☠️ ' + ENEMIES[b].name + ' erscheint!', 'warn'); sfx('roar');
  }
}
function ambushVarek() {
  toast('☠️ „Dachtest du, ein Beutel Gold kauft dir meine Freundschaft?“ – Varek!', 'warn');
  spawnEnemy('varek', P.x + 4, P.y + 2, {aggro:true});
  for (let k = 0; k < 3; k++) spawnEnemy('soldat', P.x + rnd(-4, 4), P.y + rnd(-4, 4), {aggro:true});
}

// ---------- Verbündete (Gefährten & Tiere) ----------
const COMP_START_LVL = {grimm:2, mira:2, kael:4, lyra:5, brann:9, nerina:10, tamsin:20, zahir:21};
function compLvl(id) { const s = P.comp[id]; if (!s.lvl) { s.lvl = COMP_START_LVL[id] || 2; s.xp = 0; } return s.lvl; }
function compStats(id) { const c = COMPS[id], l = compLvl(id); return {maxHp:Math.round(c.hp * (1 + 0.14 * (l - 1))), dmg:c.dmg * (1 + 0.11 * (l - 1))}; }
function compXpNeed(l) { return xpNeed(l); }
function gainCompXp(id, v) {
  const s = P.comp[id]; compLvl(id); if (v <= 0 || s.lvl >= 40) return;
  s.xp = (s.xp || 0) + v;
  while (s.xp >= compXpNeed(s.lvl) && s.lvl < 40) {
    s.xp -= compXpNeed(s.lvl); s.lvl++;
    const a = G.allies.find(x => x.kind === 'comp' && x.id === id);
    toast('⭐ ' + COMPS[id].name + ' erreicht Stufe ' + s.lvl + '!', 'gold');
    if (a) { const st = compStats(id); a.maxHp = st.maxHp; a.hp = st.maxHp; a.dmg = st.dmg; burst(a.x, a.y - 0.6, '#ffe48a', 14); }
  }
}
const COMP_ROLE = {kampf:'Nahkämpfer – geht voran und bindet Gegner', bogen:'Fernkämpfer – schießt aus sicherer Entfernung', magie:'Magier – Flächenzauber aus der zweiten Reihe', heil:'Heilerin – heilt, segnet und reinigt die Gruppe, greift selbst nur schwach an und hält sich zurück'};
function petStats(p) {
  const d = ENEMIES[p.type], zl = P.prof.zaehmen.lvl, l = p.lvl || 1, g = p.gear || {};
  const arm = g.armor ? ITEMS[g.armor.id] : null, sad = g.saddle ? ITEMS[g.saddle.id] : null;
  const tierB = 1 + 0.06 * petTier(l);
  return {maxHp:Math.round(d.hp * 1.3 * (1 + 0.16 * (l - 1)) * (0.9 + 0.04 * zl) * (1 + (arm ? arm.hpB : 0)) * tierB),
    dmg:Math.max(4, d.dmg) * 1.35 * (1 + 0.13 * (l - 1)) * (0.9 + 0.04 * zl) * tierB,
    def:(arm ? arm.def : 0) + (sad && sad.def || 0) + l * 0.4};
}
function petXpNeed(l) { return xpNeed(l); }
function petIndexOf(p) { return P.pets.indexOf(p); }
function gainPetXp(pi, v) {
  const p = P.pets[pi]; if (!p || v <= 0) return;
  const oldTier = petTier(p.lvl);
  p.xp = (p.xp || 0) + v;
  while (p.xp >= petXpNeed(p.lvl) && p.lvl < 30) {
    p.xp -= petXpNeed(p.lvl); p.lvl++;
    toast('🐾 ' + p.name + ' erreicht Stufe ' + p.lvl + '!', 'gold'); sfx('tame');
    if (p.lvl === RIDE_LVL && !p.roles.includes('reit')) toast('🐎 ' + p.name + ' ist jetzt stark genug, um mit Sattel geritten zu werden.', 'gold');
    const a = G.allies.find(x => x.kind === 'pet' && x.pi === pi);
    if (a) { a.hp = petStats(p).maxHp; burst(a.x, a.y - 0.5, '#ffe48a', 16); ring(a.x, a.y - 0.3, 1.6, '#ffd75a'); }
  }
  const nt = petTier(p.lvl);
  if (nt > oldTier) { toast('✨ ' + p.name + ' entwickelt sich: ' + PET_TIERS[nt].name + '! Es sieht jetzt ' + ['', 'vernarbt und wild', 'größer und furchteinflößend', 'legendär'][nt] + ' aus.', 'gold'); sfx('levelup'); }
  syncAllies();
}
const PET_NAMES = ['Rex', 'Schatten', 'Asche', 'Funke', 'Brumm', 'Nebel', 'Wirbel', 'Grimmzahn', 'Donner', 'Fenris', 'Kralle', 'Silberpelz', 'Hauer', 'Sturm', 'Bella', 'Luna'];
// Reiten: immer mit Sattel und ab Tierzähmung 5; Kampftiere zusätzlich ab Tierstufe RIDE_LVL
const RIDE_SKILL = 5;
function rideBlock(p) {
  if (!(p.gear && p.gear.saddle)) return 'braucht einen Sattel';
  if (!P.learned.zaehmen || P.prof.zaehmen.lvl < RIDE_SKILL) return 'Tierzähmung Stufe ' + RIDE_SKILL + ' nötig (du: ' + (P.learned.zaehmen ? P.prof.zaehmen.lvl : 0) + ')';
  if (!p.roles.includes('reit') && (p.lvl || 1) < RIDE_LVL) return 'als Kampftier erst ab Tierstufe ' + RIDE_LVL + ' reitbar';
  return '';
}
function canRide(p) { return !rideBlock(p); }
function mountSpeed(p) {
  const base = p.roles.includes('reit') ? (p.speed || 1.5) : 1.35;
  const sad = p.gear && p.gear.saddle ? ITEMS[p.gear.saddle.id].speed : 0;
  return base * (1 + sad) * (1 + 0.012 * ((p.lvl || 1) - 1));
}
function renamePet(pi, name) {
  const p = P.pets[pi]; if (!p) return;
  name = (name || '').replace(/[<>&"]/g, '').trim().slice(0, 16); if (!name) return;
  p.name = name; syncAllies(); toast('🐾 Dein Tier heißt jetzt ' + name + '.');
}
function equipPet(pi, invIdx) {
  const p = P.pets[pi], s = P.inv[invIdx]; if (!p || !s) return;
  const it = ITEMS[s.id]; if (it.type !== 'tiergear') return;
  if ((p.lvl || 1) < it.minLvl) { toast(p.name + ' braucht Stufe ' + it.minLvl + ' für ' + it.name + '.'); sfx('fail'); return; }
  const slot = it.slot === 'sattel' ? 'saddle' : 'armor';
  p.gear = p.gear || {};
  P.inv.splice(invIdx, 1);
  if (p.gear[slot]) P.inv.push(p.gear[slot]);
  p.gear[slot] = s; sfx('craft');
  toast('🐾 ' + p.name + ' trägt jetzt: ' + it.name + (slot === 'saddle' && !canRide(p) ? ' (reitbar ab Stufe ' + RIDE_LVL + ')' : ''));
  syncAllies();
}
function unequipPet(pi, slot) {
  const p = P.pets[pi]; if (!p || !p.gear || !p.gear[slot]) return;
  if (P.inv.length >= invCap()) { toast('🎒 Inventar voll!'); return; }
  P.inv.push(p.gear[slot]); p.gear[slot] = null;
  if (slot === 'saddle' && P.mount === pi && !canRide(p)) { P.mounted = false; P.mount = -1; }
  syncAllies();
}
function syncAllies() {
  const old = G.allies, out = [];
  P.party.forEach((id, k) => {
    const c = COMPS[id], s = compStats(id), sv = P.comp[id];
    let a = old.find(o => o.kind === 'comp' && o.id === id);
    if (!a) { a = {kind:'comp', id, name:c.name, x:P.x + rnd(-1, 1), y:P.y + 1, r:0.28, cd:0, hitT:0, down:false, size:1, spr:makeHumanoid(c.look), style:{kampf:'melee', bogen:'arrow', magie:'magic', heil:'heal'}[c.cls]}; a.hp = sv.hp != null ? sv.hp : s.maxHp; }
    a.maxHp = s.maxHp; a.dmg = s.dmg; a.lvl = compLvl(id); a.hp = Math.min(a.hp, a.maxHp); a.slot = k; out.push(a);
  });
  if (P.petActive >= 0 && P.pets[P.petActive] && !(P.mounted && P.mount === P.petActive)) {
    const p = P.pets[P.petActive], d = ENEMIES[p.type], s = petStats(p);
    if (p.roles.includes('kampf')) {
      let a = old.find(o => o.kind === 'pet' && o.pi === P.petActive);
      if (!a) { a = {kind:'pet', pi:P.petActive, x:P.x - 1, y:P.y + 0.5, r:0.3, cd:0, hitT:0, down:!!p.down, downT:0, style:'melee'}; a.hp = p.hp != null ? p.hp : s.maxHp; if (a.down) a.hp = 0; }
      a.name = p.name; a.lvl = p.lvl; a.spr = petSprite(p); a.size = petSize(p); a.def = s.def;
      a.maxHp = s.maxHp; a.dmg = s.dmg; a.hp = Math.min(a.hp, a.maxHp); a.slot = P.party.length; out.push(a);
    }
  }
  G.allies = out;
}
function storeAllyHp() { for (const a of G.allies) { if (a.kind === 'comp') P.comp[a.id].hp = a.hp; else if (P.pets[a.pi]) { P.pets[a.pi].hp = a.hp; P.pets[a.pi].down = !!a.down; } } }
const HERBIVORE = {hirsch:1, pferd:1, goldhirsch:1};
function petFoods(p) { return HERBIVORE[p.type] ? ['kraut', 'brot'] : ['fleisch', 'gebraten']; }
function petHeal(id) { return {fleisch:0.45, gebraten:0.8, kraut:0.45, brot:0.6}[id] || 0.4; }
function petHp(pi) { const p = P.pets[pi], a = G.allies.find(x => x.kind === 'pet' && x.pi === pi), s = petStats(p); return {hp:a ? a.hp : (p.hp != null ? p.hp : s.maxHp), max:s.maxHp, down:a ? a.down : !!p.down}; }
// Füttert ein Tier: heilt es oder belebt es wieder (pi = Index in P.pets)
function feedPet(pi) {
  const p = P.pets[pi]; if (!p) return false;
  const a = G.allies.find(x => x.kind === 'pet' && x.pi === pi), st = petHp(pi), hp = st.hp, down = st.down;
  if (!down && hp >= st.max) { toast(p.name + ' ist satt und gesund.'); return false; }
  const food = petFoods(p).find(f => countItem(f));
  if (!food) { toast(p.name + ' braucht ' + petFoods(p).map(f => ITEMS[f].name).join(' oder ') + '.'); sfx('fail'); return false; }
  removeItem(food, 1);
  const nh = down ? st.max * petHeal(food) : Math.min(st.max, hp + st.max * petHeal(food));
  if (a) { a.hp = nh; a.down = false; a.downT = 0; burst(a.x, a.y - 0.5, '#8f8', 12); floatText(a.x, a.y - 1.2, down ? 'Wiederbelebt!' : '+' + Math.round(nh - hp), '#6f6'); }
  p.hp = nh; p.down = false;
  toast(down ? '💚 ' + p.name + ' steht wieder auf!' : '🍖 ' + p.name + ' frisst ' + ITEMS[food].name + '.'); sfx(down ? 'heal' : 'eat');
  gainProf('zaehmen', down ? 12 : 4);
  return true;
}
// Heilerin: bleibt hinter der Gruppe, heilt, segnet, reinigt – greift nur an, wenn sonst nichts zu tun ist
function healerAI(a, dt, sp) {
  a.buffCd = (a.buffCd || 6) - dt; a.healCd = (a.healCd || 0) - dt;
  const lvl = a.lvl || 1, power = (8 + lvl * 3.2) * (P.buffs.held ? 1.2 : 1);
  const pct = t => t === P ? P.hp / G.st.maxHp : t.hp / t.maxHp;
  const enemyNear = nearestEnemy(P.x, P.y, 11);
  // 1) Heilen (Schwerverletzte zuerst)
  if (a.healCd <= 0) {
    const list = allyTargets().filter(t => t !== a && pct(t) < 0.75 && dist(a.x, a.y, t.x, t.y) < 9).sort((x, y) => pct(x) - pct(y));
    if (a.hp / a.maxHp < 0.5) list.unshift(a);
    if (list.length) {
      const t = list[0]; healAlly(t, power * (pct(t) < 0.35 ? 1.6 : 1)); a.healCd = 2.6; a.atk = 0.3;
      burst(t.x, t.y - 0.6, '#8f8', 10); G.fx.push({k:'line', pts:[[a.x, a.y - 0.8], [t.x, t.y - 0.6]], life:0.25, col:'#bfffb0'}); sfx('heal'); return true;
    }
  }
  // 2) Reinigen von Gift und Fluch
  if ((P.buffs.gift || P.buffs.fluch) && a.healCd <= 0 && dist(a.x, a.y, P.x, P.y) < 9) {
    delete P.buffs.gift; delete P.buffs.fluch; a.healCd = 4; burst(P.x, P.y - 0.6, '#fff', 10); toast('✨ ' + a.name + ' reinigt dich.'); sfx('holy'); return true;
  }
  // 3) Segen auf die Gruppe, sobald gekämpft wird
  if (a.buffCd <= 0 && enemyNear) {
    P.buffs.segen = Math.max(P.buffs.segen || 0, 10 + lvl * 0.3); a.buffCd = 24; a.atk = 0.3;
    ring(a.x, a.y - 0.4, 4, '#ffe'); toast('🙏 ' + a.name + ' segnet die Gruppe.'); sfx('holy'); return true;
  }
  // 4) Position: hinter dem Spieler, weg vom nächsten Gegner
  if (enemyNear) {
    const ex = enemyNear.x - P.x, ey = enemyNear.y - P.y, el = Math.hypot(ex, ey) || 1;
    const tx = P.x - ex / el * 3, ty = P.y - ey / el * 3, dx = tx - a.x, dy = ty - a.y, l = Math.hypot(dx, dy);
    if (l > 0.5) { if (moveEnt(a, dx / l * sp * dt, dy / l * sp * dt)) { a.moving = true; a.dir = ex < 0 ? -1 : 1; } }
    // 5) schwacher Lichtstrahl, nur wenn niemand Hilfe braucht
    const t = nearestEnemy(a.x, a.y, 7, allyMayAttack);
    if (t && a.cd <= 0) { const ddx = t.x - a.x, ddy = t.y - a.y; shoot(a.x, a.y - 0.5, ddx, ddy, 'holy', a.dmg * 0.45, 'p', {ally:true, speed:10, range:8, holy:true}); a.cd = 2.8; a.dir = ddx < 0 ? -1 : 1; }
    return true;
  }
  return false;
}
function updAlly(a, dt) {
  if (a.hitT > 0) a.hitT -= dt;
  if (a.down) {
    if (dist(a.x, a.y, P.x, P.y) > 14) { a.x = P.x + rnd(-1, 1); a.y = P.y + rnd(0, 1); }
    if (a.kind === 'pet') { if (!a.toldDown) { a.toldDown = true; toast('🐾 ' + a.name + ' liegt verletzt am Boden – füttere es, um es wiederzubeleben.', 'warn'); } return; }
    a.downT += dt; if (a.downT > 10 && !nearestEnemy(P.x, P.y, 9)) { a.down = false; a.hp = a.maxHp * 0.3; toast(a.name + ' ist wieder auf den Beinen.'); } return;
  }
  a.toldDown = false;
  a.cd -= dt; a.moving = false;
  if (G.t - (a.lastHit || -99) > 5) a.hp = Math.min(a.maxHp, a.hp + a.maxHp * (a.kind === 'pet' ? 0.002 : 0.008) * dt);
  if (P.buffs.segen) a.hp = Math.min(a.maxHp, a.hp + a.maxHp * 0.02 * dt);
  const sp = 4.2 * (P.mounted ? 1.6 : 1), dm = a.dmg * (P.buffs.schrei ? 1.35 : 1);
  const pd = dist(a.x, a.y, P.x, P.y);
  if (pd > 14) { a.x = P.x + rnd(-1, 1); a.y = P.y + rnd(0, 1); return; }
  if (a.style === 'heal') { if (healerAI(a, dt, sp)) return; }
  const t = nearestEnemy(a.x, a.y, 8, e => dist(e.x, e.y, P.x, P.y) < 10 && allyMayAttack(e));
  if (t) {
    const dx = t.x - a.x, dy = t.y - a.y, l = Math.hypot(dx, dy) || 1; a.dir = dx < 0 ? -1 : 1;
    if (a.style === 'melee') {
      if (l > 0.8 + 0.3 * t.size) { if (moveEnt(a, dx / l * sp * dt, dy / l * sp * dt)) a.moving = true; }
      else if (a.cd <= 0) { dealDmg(t, dm, {src:'a', kb:0.2, fx:a.x, fy:a.y}); a.cd = 1.0; a.atk = 0.2; }
    } else {
      if (l > 6) { if (moveEnt(a, dx / l * sp * dt, dy / l * sp * dt)) a.moving = true; }
      else if (a.cd <= 0) { shoot(a.x, a.y - 0.5, dx, dy, a.style === 'arrow' ? 'arrow' : a.style === 'heal' ? 'holy' : 'fire', dm, 'p', {ally:true, speed:11, range:9, holy:a.style === 'heal', aoe:a.style === 'magic' ? 1.2 : 0}); a.cd = 1.3; }
    }
  } else {
    const ang = (a.slot || 0) * 1.3 + 2.2, tx = P.x + Math.cos(ang) * 1.6, ty = P.y + Math.sin(ang) * 1.1;
    const dx = tx - a.x, dy = ty - a.y, l = Math.hypot(dx, dy);
    if (l > 0.4) { if (moveEnt(a, dx / l * Math.min(sp, l * 4) * dt, dy / l * Math.min(sp, l * 4) * dt)) { a.moving = true; a.dir = dx < 0 ? -1 : 1; } }
  }
  if (a.atk > 0) a.atk -= dt;
}
function tryTame(e) {
  const tm = e.def.tame, zl = P.prof.zaehmen.lvl + (P.race === 'ork' ? 1 : 0);
  if (zl < tm.lvl) { toast('Tierzähmung Stufe ' + tm.lvl + ' nötig.'); return; }
  const food = tm.food || 'fleisch';
  if (!countItem(food)) { toast('Du brauchst ' + ITEMS[food].name + ' als Futter.'); return; }
  if (P.pets.length >= 8) { toast('Du hast schon zu viele Tiere.'); return; }
  removeItem(food, 1);
  const ch = clamp(0.35 + 0.08 * zl - 0.04 * tm.lvl + (P.race === 'ork' ? 0.1 : 0), 0.1, 0.9);
  if (Math.random() < ch) {
    e.dead = true; G.enemies.splice(G.enemies.indexOf(e), 1);
    const p = {type:e.type, name:e.def.name, species:e.def.name, lvl:Math.max(1, e.def.lvl - 2), xp:0, roles:tm.roles.slice(), speed:tm.speed || 1, hp:null, gear:{}};
    P.pets.push(p); const pi = P.pets.length - 1;
    if (p.roles.includes('kampf') && P.petActive < 0) P.petActive = pi;
    if (canRide(p) && P.mount < 0) P.mount = pi;
    toast('🐾 ' + e.def.name + ' gezähmt!' + (p.roles.includes('reit') ? ' Reittier verfügbar.' : ''), 'gold');
    burst(e.x, e.y - 0.5, '#fde', 16); sfx('tame'); gainProf('zaehmen', 40 + tm.lvl * 15); gainXp(20 + tm.lvl * 10);
    syncAllies();
    askText('🐾 ' + e.def.name + ' gezähmt!', 'Gib deinem neuen Gefährten einen Namen. (Stufe ' + p.lvl + ' – es wird mit dir stärker und verändert dabei sein Aussehen.)', pick(PET_NAMES), n => renamePet(pi, n));
  } else {
    toast('Das ' + e.def.name + ' schnappt nach dem Futter und reißt sich los!');
    e.aggro = true; if (e.def.passive) e.flee = 5; gainProf('zaehmen', 8);
  }
}
function toggleRide() {
  if (P.mount < 0 || !P.pets[P.mount]) { toast('Du hast kein Reittier. Zähme ein Pferd oder einen Hirsch und leg ihm einen Sattel an.'); return; }
  if (!canRide(P.pets[P.mount])) { toast(P.pets[P.mount].name + ': ' + rideBlock(P.pets[P.mount]) + '.'); P.mounted = false; return; }
  if (P.pets[P.mount].down) { toast(P.pets[P.mount].name + ' ist verletzt. Füttere es zuerst.'); return; }
  P.mounted = !P.mounted; syncAllies();
  toast(P.mounted ? '🐎 Aufgesessen: ' + P.pets[P.mount].name : 'Abgesessen.');
}

// ---------- NPCs ----------
function refreshNpcs() {
  const want = {};
  for (const d of NPC_DEFS) if (!d.cond || d.cond()) want[d.id] = d;
  for (const id in COMPS) { const c = COMPS[id]; if (P.party.includes(id)) continue; if (c.show && !c.show()) continue; const h = compHome(id); want[id] = {id, name:c.name, x:h[0], y:h[1], look:c.look, comp:true, teach:c.teach, shop:c.shop}; }
  for (const t of G.tmp) want[t.id] = t;
  for (const id in G.npcMap) if (!want[id]) delete G.npcMap[id];
  for (const id in want) if (!G.npcMap[id]) { const d = want[id], pp = npcPos(d); G.npcMap[id] = {id, def:d, x:pp[0], y:pp[1], hx:pp[0], hy:pp[1], r:0.25, wt:0, wx:0, wy:0, dir:1, spr:makeHumanoid(d.look)}; }
  G.npcs = Object.values(G.npcMap);
  G.marks = {};
  for (const n of G.npcs) { if (questOpts(n.id).length) G.marks[n.id] = '!'; else if ((n.def.offer && n.def.offer()) || (n.def.trainDisc && canLearnDisc(n.def.trainDisc)) || availFor(n.id).length) G.marks[n.id] = '?'; }
}
function updNpc(n, dt) {
  n.moving = false;
  if (dist(n.x, n.y, P.x, P.y) < 2.5) { n.dir = P.x < n.x ? -1 : 1; return; }
  if (!n.def.wander) return;
  n.wt -= dt;
  if (n.wt <= 0) { n.wt = rnd(2, 5); const a = Math.random() * TAU, go = chance(0.5); n.wx = go ? Math.cos(a) : 0; n.wy = go ? Math.sin(a) : 0; if (dist(n.x, n.y, n.hx, n.hy) > n.def.wander) { const dx = n.hx - n.x, dy = n.hy - n.y, l = Math.hypot(dx, dy); n.wx = dx / l; n.wy = dy / l; } }
  if (n.wx || n.wy) { if (moveEnt(n, n.wx * 0.9 * dt, n.wy * 0.9 * dt)) { n.moving = true; n.dir = n.wx < 0 ? -1 : 1; } else n.wt = 0; }
}
function talkTo(n) {
  const d = n.def;
  const r = d.comp ? compDialog(d.id) : d.talk();
  showNpcDialog(n, r);
}
// offene (noch nicht angenommene) Aufträge, die bei dieser Figur beginnen
function availFor(npcId) {
  return Object.keys(P.avail).filter(id => { const q = QUESTS[id]; if (!q) return false; const st = q.steps[0]; return st.npc === npcId || (st.t === 'branch' && st.opts.some(o => o.npc === npcId)); });
}
function npcOptions(n, r) {
  const d = n.def, opts = questOpts(n.id).concat(r.opts || []);
  for (const id of availFor(n.id)) if (!opts.some(o => o.t.includes(QUESTS[id].name))) opts.push(questOffer(id));
  const shopId = d.shop || (d.comp && COMPS[d.id].shop);
  if (shopId && (!d.shopCond || d.shopCond()) && !(n.angry === G.day)) opts.push({t:'🛒 Handeln', f:() => { closeDialog(); openShop(shopId, n); return 'close'; }});
  if (d.smith) opts.push({t:'⚒️ Verbessern & Reparieren', f:() => { closeDialog(); openShop(shopId, n, 'smith'); return 'close'; }});
  if (d.trainDisc && canLearnDisc(d.trainDisc)) {
    const dd = d.trainDisc, tr = DISC_TRAIN[dd];
    opts.push({t:'🎓 Ausbildung: ' + DISC[dd].name + ' (' + tr.price + ' Gold)', q:true, f:() => {
      if (P.gold < tr.price) return {text:'„Die Ausbildung kostet ' + tr.price + ' Gold. Komm wieder, wenn du es hast.“'};
      P.gold -= tr.price; learnDisc(dd);
      return {text:{kampf:'„Füße schulterbreit, Klinge hoch, nie den Gegner aus den Augen lassen.“ Stundenlang drillt Roderich dich auf dem Übungsplatz.', bogen:'„Atmen. Zielen. Loslassen.“ Wilma schenkt dir deinen ersten Bogen und einen Köcher.', magie:'Thalion legt dir einen knorrigen Stab in die Hand. „Spüre den Strom. Nicht festhalten – lenken.“ Funken tanzen über deine Finger.', heil:'Anselm legt deine Hände um eine Kerze. „Das Licht ist in dir. Teile es.“ Wärme fließt durch dich.'}[dd]};
    }});
  }
  const teaches = typeof d.teach === 'function' ? d.teach() : (d.teach || {});
  for (const pr in teaches) {
    const cap = teaches[pr], p = P.prof[pr];
    if (PROFS[pr].learn && !P.learned[pr]) {
      const price = PROFS[pr].price;
      opts.push({t:'📖 ' + PROFS[pr].name + ' lernen (' + price + ' Gold)', f:() => { if (P.gold < price) return {text:'„Komm wieder, wenn du ' + price + ' Gold hast.“'}; P.gold -= price; learnProf(pr); return {text:'„Pass gut auf…“ Nach einer Stunde Übung hast du den Dreh raus.'}; }});
    } else if (p.lvl < cap) {
      const cost = Math.round(60 * Math.pow(p.lvl + 1, 1.6)), key = pr + '_' + d.id;
      opts.push({t:'🎓 Unterricht: ' + PROFS[pr].name + ' → Stufe ' + (p.lvl + 1) + ' (' + cost + ' Gold)', f:() => {
        if (P.trainDay[key] === G.day) return {text:'„Genug für heute. Lass das sacken – morgen machen wir weiter.“'};
        if (P.gold < cost) return {text:'„Unterricht kostet ' + cost + ' Gold.“'};
        P.gold -= cost; P.trainDay[key] = G.day; profLevelUp(pr, 1);
        return {text:'Ein paar Stunden harter Übung. Du merkst, wie dir die Arbeit leichter von der Hand geht.'};
      }});
    }
  }
  if (!d.guard && !d.comp && d.id !== 'koenig' && !d.tmpNpc) opts.push({t:'👛 Bestehlen', f:() => pickpocket(n)});
  opts.unshift({t:'👋 Tschüss', f:() => 'close'});
  return opts;
}
function pickpocket(n) {
  if (n.picked === G.day) return {text:n.def.name + ' hat heute nichts mehr, was sich zu stehlen lohnt.'};
  n.picked = G.day;
  const lv = P.prof.diebstahl.lvl;
  const ch = clamp(0.2 + (P.learned.diebstahl ? 0.2 : 0) + lv * 0.05 + (isNight() ? 0.05 : 0), 0.1, 0.85);
  if (Math.random() < ch) {
    const g = rint(4, 20) * (n.def.rich || 1) * (1 + lv * 0.2);
    P.gold += Math.round(g); P.rep.karma -= 2; gainProf('diebstahl', 15);
    let extra = '';
    const shop = n.def.shop && SHOPS[n.def.shop];
    if (shop && chance(0.25)) { const it = pick(shop); if (addItem(it, 1, true)) extra = ' und ' + ITEMS[it].name; }
    return {text:'Unbemerkt erbeutest du ' + Math.round(g) + ' Gold' + extra + '.'};
  }
  gainProf('diebstahl', 4); n.angry = G.day;
  return caught(n.def.name + ' packt dein Handgelenk: „Dieb! Wache!“');
}
function caught(msg) {
  if (P.rep.diebe >= 30 && chance(0.35)) return {text:msg + '<br><br>Ein Wachmann eilt herbei – und zwinkert dir zu. „Krummfinger lässt grüßen.“ Er lässt dich laufen.'};
  const fine = Math.min(P.gold, 40 + P.lvl * 15);
  P.gold -= fine; P.rep.stadt -= 8; P.rep.karma -= 3;
  toast('🚨 Erwischt! ' + fine + ' Gold Strafe', 'warn'); sfx('fail');
  return {text:msg + '<br><br>Die Wache verhängt eine Strafe von ' + fine + ' Gold. Dein Ruf in der Stadt sinkt.'};
}

// ---------- Gefährten-Dialoge & Romantik ----------
function hearts(a) { const f = Math.round(a / 20); return '❤️'.repeat(f) + '🤍'.repeat(5 - f); }
function compDialog(id) {
  const c = COMPS[id], s = P.comp[id], inParty = P.party.includes(id);
  const line = s.aff >= 70 ? c.lines[2] : s.aff >= 35 ? c.lines[1] : c.lines[0];
  const text = '<b>' + c.title + '</b> ' + hearts(s.aff) + (s.lover ? ' 💞' : '') + '<br>' + (s.hired || inParty ? line : c.bio);
  const opts = [];
  const canJoin = !c.recruit || c.recruit();
  if (!inParty && canJoin) {
    if (s.hired || !c.cost) opts.push({t:'👥 „Komm mit mir!“', f:() => { if (P.party.length >= 4) return {text:'Deine Gruppe ist voll (max. 4 Gefährten).'}; s.hired = true; P.party.push(id); syncAllies(); refreshNpcs(); return {text:c.name + ' schließt sich dir an.'}; }});
    else opts.push({t:'💰 Anheuern (' + c.cost + ' Gold)', f:() => { if (P.gold < c.cost) return {text:'„' + c.cost + ' Gold. Nicht verhandelbar.“'}; if (P.party.length >= 4) return {text:'Deine Gruppe ist voll (max. 4 Gefährten).'}; P.gold -= c.cost; s.hired = true; P.party.push(id); syncAllies(); refreshNpcs(); return {text:c.name + ' schließt sich dir an.'}; }});
  }
  if (inParty) opts.push({t:'🚪 „Warte hier auf mich.“', f:() => { storeAllyHp(); P.party = P.party.filter(x => x !== id); syncAllies(); refreshNpcs(); const h = compHome(id); return {text:c.name + ' kehrt nach Hause zurück (' + locName(h[0], h[1]) + ').'}; }});
  opts.push({t:'💬 Plaudern', f:() => { if (s.talkDay !== G.day) { s.talkDay = G.day; s.aff = Math.min(100, s.aff + 3); } return {text:pick(c.lines.slice(0, s.aff >= 35 ? 3 : 1))}; }});
  opts.push({t:'😉 Flirten', f:() => {
    if (s.flirtDay === G.day) return {text:'„Für heute reicht’s mit dem Süßholz.“'};
    s.flirtDay = G.day;
    const ch = 0.35 + s.aff / 150 + (P.buffs.mut ? 0.15 : 0) + (P.rep.stadt > 30 ? 0.05 : 0);
    if (Math.random() < ch) { s.aff = Math.min(100, s.aff + 7); return {text:pick(FLIRT_OK).replace(/\{n\}/g, c.name)}; }
    s.aff = Math.max(0, s.aff - 2); return {text:pick(FLIRT_NO).replace(/\{n\}/g, c.name)};
  }});
  opts.push({t:'🎁 Geschenk geben', f:() => giftMenu(id)});
  if (s.aff >= 80 && !s.lover) opts.push({t:'❤️ Gefühle gestehen', f:() => { s.lover = true; toast('💞 Du bist jetzt mit ' + c.name + ' zusammen.', 'gold'); return {text:'„Ich dachte schon, du fragst nie.“ ' + c.name + ' zieht dich in eine lange, warme Umarmung.'}; }});
  if (s.lover) opts.push({t:'🌙 Die Nacht miteinander verbringen', f:() => {
    const r = regionAt(P.x, P.y);
    if (!['stadt', 'gosse', 'dorf'].includes(r) && !r.startsWith('i_')) return {text:'„Hier draußen? Lass uns lieber ein warmes Zimmer suchen – in einer Stadt oder einem Dorf.“'};
    if (!isNight()) return {text:'„Später… wenn es dunkel ist.“ ' + c.name + ' lächelt vielsagend.'};
    closeDialog();
    showScene('🕯️', 'Die Kerzen brennen langsam herunter. ' + c.name + ' und du verbringt die Nacht miteinander – lange Gespräche, leises Lachen und Nähe, die keine Worte braucht.<br><br>Am Morgen wachst du erholt auf.', () => { sleepUntilMorning(); P.buffs.verliebt = DAY_LEN; s.aff = Math.min(100, s.aff + 5); });
    return 'close';
  }});
  return {text, opts};
}
function giftMenu(id) {
  const c = COMPS[id], s = P.comp[id];
  const items = [...new Set(P.inv.map(x => x.id))].filter(i => ITEMS[i].gift || c.likes.includes(i));
  if (!items.length) return {text:'Du hast nichts, was sich als Geschenk eignet (z. B. Blumen, Wein, Bücher, Ringe oder Dinge, die ' + c.name + ' mag).'};
  return {text:'Was möchtest du ' + c.name + ' schenken?', opts:items.map(i => ({t:ITEMS[i].icon + ' ' + ITEMS[i].name, f:() => {
    if (s.giftDay === G.day) return {text:'„Du hast mir heute schon etwas geschenkt. Spar dir was auf.“'};
    s.giftDay = G.day; removeItem(i, 1);
    let g = 4, tx = '„Danke.“';
    if (i === 'ring') { g = 25; tx = c.name + ' starrt den Ring lange an. „Ist das… ernst gemeint?“'; }
    else if (c.likes.includes(i)) { g = 12; tx = '„Woher wusstest du, dass ich das mag?“ ' + c.name + ' strahlt.'; }
    s.aff = Math.min(100, s.aff + g); return {text:tx + ' ' + hearts(s.aff)};
  }}))};
}
function sleepUntilMorning() {
  const target = DAY_LEN * (1 / 24);
  if (G.time > target) { G.time = target; G.day++; newDay(); } else G.time = target;
  const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
  saveGame(true);
}

// ---------- Interaktion & Abbauen ----------
const ACT_TILES = {[TL.ANVIL]:['anvil','Schmieden','⚒️'], [TL.HEARTH]:['hearth','Kochen','🔥'], [TL.CHEST]:['chest','Öffnen','🧰'], [TL.DOOR]:['door','Betreten','🚪'], [TL.BED]:['bed','Schlafen','🛏️'], [TL.HCHEST]:['hchest','Truhe','🧰'], [TL.SLOT]:['slot','Einrichten','🔨'], [TL.BOARD]:['board','Aufträge','📋']};
function findInteract() {
  let best = null, bd = 2.1;
  for (const n of G.npcs) { const d = dist(P.x, P.y, n.x, n.y); if (d < bd) { bd = d; best = {k:'npc', n, label:'Sprechen', icon:'💬'}; } }
  if (best) return best;
  const pet = G.allies.find(a => a.kind === 'pet' && dist(P.x, P.y, a.x, a.y) < 2.2);
  if (pet && pet.down) return {k:'feed', a:pet, label:'Wiederbeleben', icon:'💚'};
  if (P.learned.zaehmen) for (const e of G.enemies) if (!e.dead && e.def.tame && dist(P.x, P.y, e.x, e.y) < 2.3 && (e.def.passive || e.hp < e.maxHp * 0.35)) return {k:'tame', e, label:'Zähmen', icon:'🐾'};
  const px = Math.floor(P.x), py = Math.floor(P.y);
  let bt = null; bd = 1.6;
  for (let y = py - 1; y <= py + 1; y++) for (let x = px - 1; x <= px + 1; x++) {
    if (!inb(x, y)) continue; const t = WT[idx(x, y)];
    if (!HARVEST[t] && !ACT_TILES[t]) continue;
    const d = dist(P.x, P.y - 0.2, x + 0.5, y + 0.5); if (d < bd) { bd = d; bt = {x, y, t}; }
  }
  if (bt) {
    const a = ACT_TILES[bt.t];
    if (a) return {k:a[0], x:bt.x, y:bt.y, label:a[1], icon:a[2]};
    return {k:'tile', x:bt.x, y:bt.y, t:bt.t, label:HARVEST[bt.t].verb, icon:HARVEST[bt.t].tool === 'axt' ? '🪓' : HARVEST[bt.t].tool ? '⛏️' : '🌿'};
  }
  if (pet && pet.hp < pet.maxHp * 0.75) return {k:'feed', a:pet, label:'Füttern', icon:'🍖'};
  return null;
}
// ---------- Häuser & Innenräume ----------
function enterDoor(x, y) {
  const id = DOOR_LINK[idx(x, y)];
  if (!id) { toast('🔒 Verschlossen.'); sfx('lock'); return; }
  if (id.startsWith('h_') && !P.houses.includes(id.slice(2))) { toast('🔒 Verschlossen. Makler Ulrich am Marktplatz verkauft dieses Haus.'); sfx('lock'); return; }
  const I = INTERIORS[id];
  P.mounted = false; syncAllies();
  teleport(I.entry[0], I.entry[1]); sfx('door'); toast('🚪 ' + I.name);
}
function exitInterior() {
  const r = regionAt(P.x, P.y); if (!r.startsWith('i_')) return;
  const I = INTERIORS[r.slice(2)]; teleport(I.exit[0], I.exit[1]); sfx('door');
}
function teleport(x, y) {
  P.x = x; P.y = y; P.work = null; P.dash = null;
  G.allies.forEach((a, k) => { a.x = x + (k % 2 ? 0.6 : -0.6); a.y = y + 0.2; });
  G.proj = []; flashScreen(); G.interT = 0; G.revealT = 0;
}
function applyFurniture() {
  for (const h in HOUSES) {
    const I = INTERIORS['h_' + h], list = P.furn[h] || [];
    HOUSES[h].slots.forEach((sl, k) => { const i = idx(I.x0 + sl[0], I.y0 + sl[1]); const f = list[k]; WT[i] = f ? FURNITURE[f].tile : TL.SLOT; });
  }
}
function slotIndexAt(x, y) {
  const h = curHouse(); if (!h) return -1; const I = INTERIORS['h_' + h];
  return HOUSES[h].slots.findIndex(s => I.x0 + s[0] === x && I.y0 + s[1] === y);
}
function furnishMenu(x, y) {
  const h = curHouse(); if (!h) return;
  const k = slotIndexAt(x, y); if (k < 0) return;
  P.furn[h] = P.furn[h] || [];
  const placed = P.furn[h];
  const free = Object.keys(FURNITURE).filter(f => !placed.includes(f));
  const opts = free.map(f => {
    const F = FURNITURE[f];
    return {t:F.icon + ' ' + F.name + ' (' + F.cost + ' Gold)', f:() => {
      if (P.gold < F.cost) return {text:'Nicht genug Gold.'};
      P.gold -= F.cost; placed[k] = f; applyFurniture(); sfx('craft'); toast(F.icon + ' ' + F.name + ' aufgestellt.');
      return 'close';
    }};
  });
  opts.push({t:'Abbrechen'});
  showDialog('Einrichten', 'Was möchtest du an diese Stelle stellen?<br><small>' + free.map(f => FURNITURE[f].icon + ' ' + FURNITURE[f].name + ': ' + FURNITURE[f].desc).join('<br>') + '</small>', opts);
}
function doAction() {
  if (P.dead) return;
  const it = G.inter; if (!it) return;
  if (it.k === 'npc') talkTo(it.n);
  else if (it.k === 'tame') tryTame(it.e);
  else if (it.k === 'feed') feedPet(it.a.pi);
  else if (it.k === 'chest') openChest(idx(it.x, it.y));
  else if (it.k === 'door') enterDoor(it.x, it.y);
  else if (it.k === 'anvil') { UI.prof = 'schmieden'; UI.sub = 'make'; openPanel('craft'); }
  else if (it.k === 'hearth') { UI.prof = 'kochen'; openPanel('craft'); }
  else if (it.k === 'bed') { if (!inHome() && regionAt(P.x, P.y) !== 'i_hilde') { toast('Das ist nicht dein Bett.'); return; } showDialog('Bett', 'Bis zum Morgen schlafen? (Das Spiel wird gespeichert.)', [{t:'🛏️ Schlafen', f:() => { closeDialog(); showScene('🌙', 'Du schläfst tief und fest bis zum Morgen.', sleepUntilMorning); return 'close'; }}, {t:'Nein'}]); }
  else if (it.k === 'hchest') { sfx('door'); openPanel('inv', 'store'); }
  else if (it.k === 'slot') furnishMenu(it.x, it.y);
  else if (it.k === 'board') { refreshBoard(); openPanel('quest', 'avail'); }
  else if (it.k === 'tile') {
    const h = HARVEST[it.t];
    if (h.tool && !countItem(h.tool)) { toast('Du brauchst eine ' + ITEMS[h.tool].name + '.'); return; }
    if (P.prof[h.prof].lvl < h.lvl) { toast(PROFS[h.prof].name + ' Stufe ' + h.lvl + ' nötig.'); sfx('fail'); return; }
    if (P.mounted) { toast('Erst absitzen.'); return; }
    P.work = {x:it.x, y:it.y, t:0, dur:h.time * (1 - P.prof[h.prof].lvl * 0.04)};
    P.dir = it.x + 0.5 < P.x ? -1 : 1;
  }
}
function finishWork() {
  const w = P.work; P.work = null;
  const i = idx(w.x, w.y), t = WT[i], h = HARVEST[t]; if (!h) return;
  const n = rint(h.n[0], h.n[1]) + Math.floor(P.prof[h.prof].lvl / 4);
  if (!addItem(h.item, n)) return;
  floatItem(w.x + 0.5, w.y, h.item, n);
  if (t !== TL.ROCK && h.tool === 'spitzhacke' && chance(0.5)) addItem('stein', 1, true);
  gainProf(h.prof, 6 + h.lvl * 2); sfx('pickup');
  burst(w.x + 0.5, w.y + 0.3, t === TL.TREE || t === TL.PINE ? '#5a3' : '#999', 8);
  WT[i] = WG[i]; G.mods[i] = {t:WT[i], r:G.day + h.regrow};
}
function openChest(i) {
  const def = G.chests[i];
  if (!def) { WT[i] = WG[i]; return; }
  const loot = () => {
    let msg = [];
    if (def.gold) { const g = Math.round(def.gold * rnd(0.8, 1.2)); P.gold += g; msg.push(g + ' Gold'); }
    for (const l of def.loot) if (addItem(l[0], l[1], true)) msg.push(l[1] + '× ' + ITEMS[l[0]].name);
    if (def.owner === 'baldur' && stepIs('krumm', 'branch') && !countItem('rechnungsbuch')) { addItem('rechnungsbuch', 1, true); msg.push('📒 Rechnungsbuch'); P.f.buchWeg = true; }
    toast('🧰 Gefunden: ' + (msg.join(', ') || 'nichts'), 'gold');
    gainProf('schloss', 10 + def.lock * 10);
    WT[i] = WG[i];
    G.mods[i] = {t:WT[i], r:def.refill ? G.day + 1 : -1};
    if (G.dynChests[i]) delete G.dynChests[i];
    const r = regionAt(P.x, P.y);
    if (def.owner || r === 'stadt' || r === 'dorf') {
      const seen = G.npcs.some(n => !n.def.comp && dist(n.x, n.y, P.x, P.y) < 7);
      if (seen && Math.random() < 0.55 - P.prof.schloss.lvl * 0.04) { const res = caught('„Halt! Was machst du da an fremden Truhen?!“'); showDialog('Stadtwache', res.text, [{t:'Weiter'}]); }
    }
  };
  if (!def.lock) { loot(); return; }
  if (!countItem('dietrich')) { toast('Verschlossen (Schloss Stufe ' + def.lock + '). Du brauchst einen Dietrich.'); return; }
  startLockpick(def.lock, ok => { if (ok) { sfx('unlock'); loot(); } else sfx('fail'); });
}

// ---------- Herstellen ----------
function nearTile(t, r) { const px = Math.floor(P.x), py = Math.floor(P.y); for (let y = py - 2; y <= py + 2; y++) for (let x = px - 2; x <= px + 2; x++) if (inb(x, y) && WT[idx(x, y)] === t && dist(P.x, P.y, x + 0.5, y + 0.5) < r) return true; return false; }
// Lagerfeuer-Set: entzündet vor dir ein Feuer, das bis zum nächsten Morgen brennt
// ---------- Reparatursets für unterwegs ----------
const KIT_LVL = {reparaturset:4, meisterset:7};
function damagedGear(onlyWorn) {
  const out = [];
  for (const sl of ['waffe'].concat(ARMOR_SLOTS)) if (P.eq[sl] && P.eq[sl].dur < 100) out.push(P.eq[sl]);
  if (!onlyWorn) P.inv.forEach(s => { const t = ITEMS[s.id].type; if ((t === 'waffe' || ARMOR_SLOTS.includes(t)) && s.dur < 100) out.push(s); });
  return out;
}
function kitBlock(kit) {
  if (!countItem(kit)) return 'Kein ' + ITEMS[kit].name + ' im Rucksack';
  if (!P.learned.schmieden || P.prof.schmieden.lvl < KIT_LVL[kit]) return ITEMS[kit].name + ' erst ab Schmieden-Stufe ' + KIT_LVL[kit] + ' (du: ' + (P.learned.schmieden ? P.prof.schmieden.lvl : 0) + ')';
  return '';
}
function repairWithKit(s, kit) {
  const b = kitBlock(kit); if (b) { toast(b); sfx('fail'); return false; }
  removeItem(kit, 1); s.dur = 100; gainProf('schmieden', 6);
  toast('🧰 Unterwegs repariert: ' + ITEMS[s.id].name); sfx('craft'); return true;
}
function useRepairKit(kit) {
  const b = kitBlock(kit); if (b) { toast(b); sfx('fail'); return; }
  if (kit === 'meisterset') {
    const list = damagedGear(true); if (!list.length) { toast('Alles Angelegte ist in bestem Zustand.'); return; }
    removeItem(kit, 1); list.forEach(s => s.dur = 100); gainProf('schmieden', 6 + list.length * 3);
    toast('🧰 Alles Angelegte repariert (' + list.length + ' Teile).', 'gold'); sfx('craft'); return;
  }
  const list = damagedGear(false); if (!list.length) { toast('Nichts muss repariert werden.'); return; }
  if (typeof closePanel === 'function' && UI.panel) closePanel();
  showDialog('Reparaturset', 'Was willst du reparieren?', list.map(s => ({t:ITEMS[s.id].icon + ' ' + iname(s) + ' (' + Math.round(s.dur) + ' %)', f:() => { repairWithKit(s, kit); return 'close'; }})).concat([{t:'Abbrechen'}]));
}
function placeCampfire() {
  if (REGION_INFO[regionAt(P.x, P.y)].inside) { toast('Drinnen kannst du kein Feuer machen.'); return; }
  const fx = Math.floor(P.x + (P.dir || 1) * 1.1), fy = Math.floor(P.y - 0.1);
  if (!inb(fx, fy) || BLOCK[WT[idx(fx, fy)]] || WG[idx(fx, fy)] === TL.WATER) { toast('Hier ist kein Platz für ein Feuer.'); return; }
  const i = idx(fx, fy); WT[i] = TL.HEARTH; G.mods[i] = {t:TL.HEARTH, r:G.day + 1};
  burst(fx + 0.5, fy + 0.5, '#ffa030', 12); sfx('fire'); toast('🔥 Du entzündest ein Lagerfeuer. Tritt heran und drücke ✋, um zu kochen.');
}
function hasStation(st) {
  if (!st) return true;
  if (st === 'amboss') return nearTile(TL.ANVIL, 2.6);
  if (st === 'feuer') return nearTile(TL.HEARTH, 2.6);
  return false;
}
// Herstellen hängt vom Berufskönnen ab: Erfolgschance und Meisterstücke
function craftChance(r) { const pl = P.prof[r.prof].lvl; return clamp(0.62 + 0.12 * (pl - r.lvl), 0.3, 0.97); }
function masterChance(r) { const it = ITEMS[r.out]; if (it.type !== 'waffe' && it.type !== 'ruestung') return 0; return clamp(0.03 + 0.06 * (P.prof[r.prof].lvl - r.lvl), 0, 0.45); }
function craftBlock(r) {
  if (r.lvl >= 1 && !P.learned[r.prof]) return 'Beruf nicht erlernt';
  if (P.prof[r.prof].lvl < r.lvl - 1) return 'Benötigt ' + PROFS[r.prof].name + ' Stufe ' + (r.lvl - 1);
  const need = r.prof === 'kochen' ? 'feuer' : 'amboss';   // jedes Rezept braucht seine Werkstatt
  if (!hasStation(need)) return need === 'amboss' ? 'Am Amboss herstellen' : 'An einer Feuerstelle kochen';
  for (const k in r.req) if (countItem(k) < r.req[k]) return 'Material fehlt';
  return '';
}
function canCraft(r) { return !craftBlock(r); }
function craft(r) {
  if (!canCraft(r)) return;
  if (Math.random() > craftChance(r)) {
    for (const k in r.req) removeItem(k, Math.ceil(r.req[k] / 2));
    gainProf(r.prof, 5 + r.lvl * 3);
    toast('💢 Misslungen! Die Hälfte des Materials ist verdorben. (Übung macht den Meister)', 'warn'); sfx('fail'); return;
  }
  for (const k in r.req) removeItem(k, r.req[k]);
  if (!addItem(r.out, r.n || 1)) { for (const k in r.req) addItem(k, r.req[k], true); return; }
  let master = false;
  if (Math.random() < masterChance(r)) { const last = P.inv[P.inv.length - 1]; if (last && last.id === r.out) { last.up = (last.up || 0) + 1; master = true; } }
  gainProf(r.prof, 10 + r.lvl * 6);
  toast((master ? '🌟 Meisterstück! ' : '🔨 Hergestellt: ') + ITEMS[r.out].name + (master ? ' +1' : ''), master ? 'gold' : ''); sfx('craft');
}
function upgradeCost(s, self) {
  const nu = (s.up || 0) + 1;
  const mats = [null, {eisenbarren:1}, {eisenbarren:2, silberbarren:1}, {eisenbarren:3, silberbarren:2}, {mithrilbarren:2, kristall:1}, {mithrilbarren:3, kristall:2}][nu];
  return {nu, mats, gold:self ? 0 : Math.ceil(ITEMS[s.id].val * 0.4 * nu + 20 * nu)};
}
function doUpgrade(s, self) {
  const c = upgradeCost(s, self);
  if (c.nu > (self ? 5 : 3)) return;
  if (self && (P.prof.schmieden.lvl < c.nu * 2 || !hasStation('amboss') || !P.learned.schmieden)) return;
  if (P.gold < c.gold) { toast('Nicht genug Gold.'); return; }
  for (const k in c.mats) if (countItem(k) < c.mats[k]) { toast('Material fehlt: ' + ITEMS[k].name); return; }
  for (const k in c.mats) removeItem(k, c.mats[k]);
  P.gold -= c.gold; s.up = c.nu; s.dur = 100;
  if (self) gainProf('schmieden', 30 * c.nu);
  toast('⚒️ ' + ITEMS[s.id].name + ' +' + s.up + '!', 'gold'); sfx('craft');
}
// Material für die eigene Reparatur: Leder für Leder/Stoff, Silber für Mithril/Drachen, sonst Eisen
function repairMat(s) { const id = s.id; if (/leder|lumpen|robe|haube|hut|jaeger/.test(id)) return 'leder'; if (/mithril|drachen/.test(id)) return 'silberbarren'; return 'eisenbarren'; }
function repairCost(s) { return Math.ceil((100 - s.dur) / 100 * ITEMS[s.id].val * 0.3) + 3; }
function doRepair(s, self) {
  if (self) {
    const m = repairMat(s);
    if (!hasStation('amboss')) { toast('Dafür brauchst du einen Amboss.'); return; }
    if (!P.learned.schmieden || P.prof.schmieden.lvl < 2) { toast('Selbst reparieren kannst du ab Schmieden-Stufe 2.'); return; }
    if (!countItem(m)) { toast('Du brauchst 1× ' + ITEMS[m].name + '.'); return; }
    removeItem(m, 1); gainProf('schmieden', 12);
  }
  else { const c = repairCost(s); if (P.gold < c) { toast('Nicht genug Gold.'); return; } P.gold -= c; }
  s.dur = 100; toast('🔧 Repariert: ' + ITEMS[s.id].name); sfx('craft');
}

// ---------- Handel ----------
function priceMod() { return (P.race === 'mensch' ? 0.1 : 0) + clamp(P.rep.stadt, 0, 100) * 0.002; }
function buyPrice(id) { return Math.max(1, Math.ceil(ITEMS[id].val * (1.15 - priceMod()))); }
function sellPrice(s, fence) { const it = ITEMS[s.id]; if (it.type === 'quest') return 0; let v = it.val * (1 + 0.3 * (s.up || 0)); if (s.dur != null && s.dur < 50) v *= 0.6; return Math.max(1, Math.floor(v * ((fence ? 0.55 : 0.35) + priceMod() * 0.5))); }

// ---------- Besitz, Betriebe, Gilde ----------
function bizIncome(id) { const b = BUSINESSES[id], l = P.biz[id].lvl; return Math.round(b.income * (1 + 0.5 * (l - 1))); }
function repOk(req, thiefAlt) { return P.rep.stadt >= req || (thiefAlt && P.rep.diebe >= 30); }
function buyHouse(id) { const h = HOUSES[id]; if (P.houses.includes(id) || P.gold < h.cost || !repOk(h.rep)) return; P.gold -= h.cost; P.houses.push(id); P.furn[id] = []; toast('🏠 Gekauft: ' + h.name + '. Betritt das Haus, um es einzurichten.', 'gold'); sfx('coin'); }
function buyBiz(id) { const b = BUSINESSES[id]; if (P.biz[id] || P.gold < b.cost || !repOk(b.rep, b.thief)) return; P.gold -= b.cost; P.biz[id] = {lvl:1, total:0}; toast(b.icon + ' Dir gehört jetzt: ' + b.name, 'gold'); P.rep.stadt += 3; sfx('coin'); }
function upgradeBiz(id) { const b = BUSINESSES[id], s = P.biz[id]; if (!s || s.lvl >= 5) return; const c = b.upCost * s.lvl; if (P.gold < c) return; P.gold -= c; s.lvl++; toast(b.icon + ' Ausgebaut auf Stufe ' + s.lvl); sfx('craft'); }
function foundGuild(name) { if (P.guild || P.gold < 3000 || !questDone('goblins') || P.rep.stadt < GUILD_REP) return; P.gold -= 3000; P.guild = {name:name || 'Gilde der Gosse', lvl:1, members:0}; toast('🛡️ Gilde gegründet: ' + P.guild.name, 'gold'); P.rep.stadt += 10; sfx('levelup'); }
function guildMax() { return P.guild ? P.guild.lvl * 4 : 0; }
function recruitMember() { if (!P.guild || P.guild.members >= guildMax() || P.gold < 150) return; P.gold -= 150; P.guild.members++; toast('🛡️ Neues Gildenmitglied angeworben.'); }
function upgradeGuild() { if (!P.guild || P.guild.lvl >= 5) return; const c = 2500 * P.guild.lvl; if (P.gold < c) return; P.gold -= c; P.guild.lvl++; toast('🛡️ Gilde auf Stufe ' + P.guild.lvl + '! +5 % Erfahrung', 'gold'); }

// ---------- Tageswechsel & Ereignisse ----------
function newDay() {
  for (const k in G.mods) { const m = G.mods[k]; if (m.r >= 0 && m.r <= G.day) { WT[k] = WT0[k]; delete G.mods[k]; } }
  G.tmp = G.tmp.filter(t => t.expires > G.day);
  let inc = 0; const notes = [];
  inc += estateDaily(notes);   // Betriebe, Personal, Erweiterungen, Gilde (estate.js)
  if (hasFurn('fass')) addItem('bier', 1, true);
  refreshBoard();
  if (inc) { P.gold += inc; toast('🌅 Tag ' + G.day + ': Einnahmen ' + (inc > 0 ? '+' : '') + inc + ' Gold', 'gold'); notes.forEach(n => toast(n)); }
  else { toast('🌅 Tag ' + G.day + ' bricht an.'); notes.forEach(n => toast(n)); }
  for (const k in P.buffs) if (k === 'verliebt') {} // läuft eigenständig ab
  refreshNpcs();
}
function freeSpot(rmin, rmax) {
  for (let k = 0; k < 30; k++) { const a = Math.random() * TAU, r = rnd(rmin, rmax), x = Math.floor(P.x + Math.cos(a) * r), y = Math.floor(P.y + Math.sin(a) * r); if (inb(x, y) && !BLOCK[WT[idx(x, y)]] && !REGION_INFO[regionAt(x, y)].safe) return [x, y]; }
  return null;
}
const EVENTS = [
  {w:2, fn() {
    const s = freeSpot(4, 7); if (!s) return;
    G.tmp.push({id:'zeb', name:'Fahrender Händler Zeb', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, shop:'zeb', look:{skin:'#c89070', hair:'#e8e8e8', outfit:'#8a3a8a', beard:true},
      talk() { return {text:'„Seltene Ware aus fernen Ländern! Nur heute, nur hier, nur für dich!“'}; }});
    refreshNpcs(); toast('🐴 Ein fahrender Händler hat in der Nähe sein Lager aufgeschlagen!', 'quest'); }},
  {w:3, fn() {
    const z = ZONES[regionAt(P.x, P.y)]; if (!z || z.neutral || !z.mobs.length) return;
    const foes = z.mobs.filter(m => !ENEMIES[m[0]].passive); if (!foes.length) return;
    const type = wpick(foes), n = rint(2, 3);
    for (let k = 0; k < n; k++) { const s = freeSpot(6, 9); if (s && spawnAllowed(s[0], s[1])) spawnEnemy(type, s[0] + 0.5, s[1] + 0.5, {aggro:true, lvl:rint(z.lv[0], z.lv[1])}); }
    toast('⚠️ Hinterhalt!', 'warn'); }},
  {w:2, fn() {
    const s = freeSpot(5, 9); if (!s) return; const i = idx(s[0], s[1]);
    const pool = [['heiltrank',2],['grheiltrank',1],['kristall',2],['silberbarren',2],['dietrich',3],['wein',1],['ring',1],['buch',1],['leder',4],['mithrilerz',2]];
    const def = {lock:rint(1, 3), gold:rint(20, 60) * Math.max(1, P.lvl / 3), loot:[pick(pool), pick(pool)]};
    WT[i] = TL.CHEST; G.chests[i] = def; G.dynChests[i] = def; G.mods[i] = {t:TL.CHEST, r:-1};
    toast('✨ Etwas glitzert im Gras… eine versteckte Truhe!', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(6, 10); if (!s) return;
    for (let k = 0; k < 5; k++) { const x = s[0] + rint(-1, 1), y = s[1] + rint(-1, 1); if (!inb(x, y) || BLOCK[WT[idx(x, y)]]) continue; const i = idx(x, y); WT[i] = chance(0.5) ? TL.MITHRIL : TL.CRYSTAL; G.mods[i] = {t:WT[i], r:-1}; }
    G.shake = 0.5; burst(s[0], s[1], '#fc6', 30);
    toast('☄️ Eine Sternschnuppe schlägt in der Nähe ein! Im Krater glitzern seltene Erze.', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(3, 6); if (!s) return; const rd = pick(RIDDLES);
    G.tmp.push({id:'fremder', name:'Verhüllter Fremder', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#b8a090', hair:'#2a2a3a', outfit:'#2a2a3a', helm:true},
      talk() {
        if (this.done) return {text:'Der Fremde ist nur noch ein Schatten im Nebel.'};
        return {text:'„Beantworte mein Rätsel, und ich belohne dich.“<br><br>' + rd.q, opts:rd.a.map((a, k) => ({t:a, f:() => {
          this.done = true; G.tmp = G.tmp.filter(t => t.id !== 'fremder'); setTimeout(refreshNpcs, 50);
          if (k === rd.c) { if (chance(0.5)) { P.skillPts++; return {text:'„Klug.“ Er berührt deine Stirn – du fühlst neues Wissen. (+1 Fähigkeitspunkt)'}; } P.attrPts += 2; return {text:'„Richtig.“ Wärme durchströmt dich. (+2 Attributpunkte)'}; }
          const l = Math.min(P.gold, 25); P.gold -= l; return {text:'„Falsch.“ Er lacht – und mit ihm verschwinden ' + l + ' Gold aus deinem Beutel.'};
        }}))};
      }});
    refreshNpcs(); toast('🌫️ Eine verhüllte Gestalt beobachtet dich…', 'quest'); }},
  {w:1, fn() { const s = freeSpot(9, 13); if (!s) return; spawnEnemy('goldhirsch', s[0] + 0.5, s[1] + 0.5); toast('🦌 Ein goldener Schimmer zwischen den Bäumen…', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(3, 6); if (!s) return;
    G.tmp.push({id:'reisender', name:'Verletzter Reisender', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e0b090', hair:'#6a4a2a', outfit:'#6a6a4a'},
      talk() {
        if (this.done) return {text:'„Danke nochmal, Fremder!“'};
        return {text:'„Bitte… Banditen… hast du einen Heiltrank?“', opts:[
          {t:'🧪 Heiltrank geben', f:() => { if (!countItem('heiltrank')) return {text:'Du hast keinen Heiltrank.'}; removeItem('heiltrank', 1); this.done = true; P.rep.karma += 5; const g = rint(60, 150); P.gold += g; return {text:'Er trinkt gierig. „Du hast mir das Leben gerettet! Nimm das – ' + g + ' Gold. Ich bin Kaufmann, ich zahle meine Schulden.“'}; }},
          {t:'Weitergehen', f:() => { P.rep.karma -= 2; this.done = true; return 'close'; }}]};
      }});
    refreshNpcs(); toast('🆘 Jemand ruft um Hilfe!', 'quest'); }}
];
function randomEvent() { const e = wpick(EVENTS.concat(STORY_EVENTS).map(x => [x, x.w])); e.fn(); }

// ---------- Speichern ----------
const TRANSIENT = new Set(['work', 'dash', 'swing', 'spin', 'hitT', 'dead', 'moving']);
function packBits(a) { let s = ''; for (let i = 0; i < a.length; i += 8) { let b = 0; for (let k = 0; k < 8; k++) if (a[i + k]) b |= 1 << k; s += String.fromCharCode(b); } return btoa(s); }
function unpackBits(str, n) { const s = atob(str), a = new Uint8Array(n); for (let i = 0; i < s.length; i++) { const b = s.charCodeAt(i); for (let k = 0; k < 8; k++) if (b & (1 << k)) a[i * 8 + k] = 1; } return a; }
function saveGame(silent) {
  if (!P || P.dead) return;
  storeAllyHp();
  const data = {v:SAVE_VER, mw:MW, wh:WORLD_H, seed:G.seed, day:G.day, time:G.time, mods:G.mods, dyn:G.dynChests, ex:packBits(G.explored), P:JSON.parse(JSON.stringify(P, (k, v) => TRANSIENT.has(k) ? undefined : v))};
  try {
    const old = localStorage.getItem(SAVE_KEY); if (old) localStorage.setItem(SAVE_KEY + '_bak', old);   // Sicherheitskopie des vorigen Stands
    localStorage.setItem(SAVE_KEY, JSON.stringify(data)); if (!silent) toast('💾 Gespeichert');
  } catch (e) { toast('Speichern fehlgeschlagen'); }
}
// Ergänzt Spielstände älterer Versionen um alles, was neu dazugekommen ist,
// und entfernt Dinge, die es nicht mehr gibt – so bleiben Spielstände nach Updates erhalten.
function migratePlayer(p) {
  const def = {skills:{}, slots:[null, null, null], q:{}, dyn:{}, f:{}, rep:{stadt:0, diebe:0, karma:0}, rank:'Keiner', title:'Gossenkind', comp:{}, party:[], pets:[], petActive:-1, mount:-1, mounted:false,
    houses:[], furn:{}, storage:[], biz:{}, guild:null, buffs:{}, cds:{}, kills:{}, dl:{}, avail:{}, board:{day:-1, list:[]}, trainDay:{}, arrows:0, attrPts:0, skillPts:0, gold:0, lvl:1, xp:0,
    eq:{waffe:null, helm:null, ruestung:null, handschuhe:null, hose:null, schuhe:null, koecher:null, rucksack:null, schmuck:null}, inv:[], prof:{}, learned:{}, discs:{}, base:{str:5, dex:5, int:5, vit:5, wis:5}, potion:'heiltrank'};
  for (const k in def) if (p[k] === undefined || p[k] === null && def[k] !== null) p[k] = JSON.parse(JSON.stringify(def[k]));
  for (const k in def.rep) if (p.rep[k] == null) p.rep[k] = 0;
  for (const k in def.eq) if (p.eq[k] === undefined) p.eq[k] = null;
  for (const k in PROFS) { if (!p.prof[k]) p.prof[k] = {lvl:0, xp:0}; if (p.learned[k] == null) p.learned[k] = !PROFS[k].learn; }
  for (const k in COMPS) if (!p.comp[k]) p.comp[k] = {aff:0, lover:false, hired:false, talkDay:-1, flirtDay:-1, giftDay:-1, hp:null};
  while (p.slots.length < 3) p.slots.push(null);
  p.slots = p.slots.map(s => s && SKILLS[s] ? s : null);
  for (const s in p.skills) if (!SKILLS[s]) delete p.skills[s];
  // Gegenstände, die es nicht mehr gibt, verschwinden statt das Spiel abstürzen zu lassen
  const okItem = s => s && ITEMS[s.id];
  p.inv = p.inv.filter(okItem); p.storage = p.storage.filter(okItem);
  for (const k in p.eq) if (p.eq[k] && !ITEMS[p.eq[k].id]) p.eq[k] = null;
  p.pets = p.pets.filter(pt => ENEMIES[pt.type]);
  if (p.petActive >= p.pets.length) p.petActive = -1; if (p.mount >= p.pets.length) { p.mount = -1; p.mounted = false; }
  p.party = p.party.filter(id => COMPS[id]);
  for (const id in p.q) if (!QUESTS[id] && !p.dyn[id]) delete p.q[id];
  for (const id in p.avail) if (!QUESTS[id]) delete p.avail[id];
  for (const h of p.houses) if (!p.furn[h]) p.furn[h] = [];
  // wartende Hauptquests direkt starten (z. B. Krummfingers Angebot)
  for (const id in p.avail) if (QUESTS[id] && QUESTS[id].main && !p.q[id]) { delete p.avail[id]; p.q[id] = {s:0, c:0, done:false}; }
  for (const id in p.biz) if (!BUSINESSES[id]) delete p.biz[id];
  // neue Kapitel: abgeschlossene Hauptquests starten ihre Fortsetzung
  for (const id in p.q) { const q = QUESTS[id]; if (p.q[id].done && q && q.main && q.next && QUESTS[q.next] && !p.q[q.next]) p.q[q.next] = {s:0, c:0, done:false}; }
  return p;
}
function exportSave() { saveGame(true); try { return btoa(unescape(encodeURIComponent(localStorage.getItem(SAVE_KEY) || ''))); } catch (e) { return ''; } }
function importSave(code) {
  let raw; try { raw = decodeURIComponent(escape(atob(code.trim()))); JSON.parse(raw); } catch (e) { return false; }
  try { const old = localStorage.getItem(SAVE_KEY); if (old) localStorage.setItem(SAVE_KEY + '_bak', old); localStorage.setItem(SAVE_KEY, raw); loadGame(raw); return true; } catch (e) { return false; }
}
function hasBackup() { try { return !!localStorage.getItem(SAVE_KEY + '_bak'); } catch (e) { return false; } }
function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
function loadGame(raw) {
  const data = JSON.parse(raw || localStorage.getItem(SAVE_KEY));
  G.seed = data.seed; genWorld(G.seed);
  if (typeof remapSave === 'function') remapSave(data);   // Welt wurde breiter: alte Felder umrechnen
  G.day = data.day; G.time = data.time;
  const sameWorld = data.mw === MW;
  G.mods = sameWorld ? data.mods || {} : {};
  for (const k in G.mods) WT[k] = G.mods[k].t;
  G.dynChests = sameWorld ? data.dyn || {} : {}; for (const k in G.dynChests) G.chests[k] = G.dynChests[k];
  G.explored = sameWorld ? unpackBits(data.ex, MW * MH) : new Uint8Array(MW * MH);
  P = data.P;
  // Welt wurde nach Süden erweitert: Oberwelt bleibt gleich, Innenräume rücken nach unten
  const oldH = data.wh || 256;
  if (sameWorld && oldH !== WORLD_H) {
    const lim = MW * Math.min(oldH, WORLD_H);
    for (const k in G.mods) if (+k >= lim) { WT[k] = WT0[k]; delete G.mods[k]; }
    for (const k in G.dynChests) if (+k >= lim) { delete G.dynChests[k]; delete G.chests[k]; }
    G.explored.fill(0, lim);
    if (P.y >= oldH) P.y += WORLD_H - oldH;
    setTimeout(() => toast('🌊 Die Welt ist gewachsen: Im Süden warten Salzmarsch, Sturmküste, Möwenhafen und die Aschelande!', 'quest'), 900);
  }
  if (!sameWorld) { const h = ipos(['hilde', 3.6, 4.4]); P.x = h[0]; P.y = h[1]; P.mounted = false; setTimeout(() => toast('🗺️ Die Welt ist größer geworden – du wachst in Hildes Hütte auf.', 'quest'), 500); } P.atkCd = 0; P.invuln = 0; P.lastHit = -99;
  // ältere Spielstände übernehmen
  if (!P.dl) { P.dl = {}; for (const d in P.discs) P.dl[d] = true; }
  if (!P.avail) P.avail = {}; if (!P.board) P.board = {day:-1, list:[]}; if (!P.trainDay) P.trainDay = {};
  if (Array.isArray(P.furn)) { const old = P.furn; P.furn = {}; P.houses.forEach((h, k) => P.furn[h] = k === 0 ? old.slice(0, HOUSES[h].slots.length) : []); }
  if (!P.furn) P.furn = {};
  migratePlayer(P);
  P.v = SAVE_VER; P.potCd = 0;
  for (const pt of P.pets) { if (!pt.lvl) pt.lvl = Math.max(1, ENEMIES[pt.type].lvl - 2); if (pt.xp == null) pt.xp = 0; if (!pt.gear) pt.gear = {}; if (!pt.species) pt.species = ENEMIES[pt.type].name; }
  for (const k in PROFS) if (!P.prof[k]) { P.prof[k] = {lvl:0, xp:0}; P.learned[k] = !PROFS[k].learn; }
  startWorld();
}
function startNewGame(cfg) {
  G.seed = 1337; genWorld(G.seed); G.mods = {}; G.dynChests = {}; G.day = 1; G.time = 60;
  G.explored = new Uint8Array(MW * MH);
  newPlayer(cfg);
  startWorld();
  showStory('Das Rattenviertel', 'Kalter Regen tropft durch das Dach. Du wachst in Mutter Hildes Hütte auf – im Rattenviertel von Aldenmark, wo die Armen, die Diebe und die Vergessenen hausen.<br><br>Alles, was du besitzt, ist ein rostiges Messer und zerlumpte Kleidung. Kämpfen, Zaubern, Heilen – all das musst du erst bei Lehrmeistern lernen.<br><br><i>Sprich mit Mutter Hilde (dem <b>?</b> über ihrem Kopf).</i>');
}
function startWorld() {
  G.enemies = []; G.proj = []; G.drops = []; G.fx = []; G.texts = []; G.npcMap = {}; G.tmp = []; G.allies = [];
  applyFurniture(); refreshBoard();
  refreshPlayerSprite(); buildMapCanvas(); syncAllies(); refreshNpcs();
  G.region = regionAt(P.x, P.y); G.running = true; G.paused = false;
  showGameUI();
}
