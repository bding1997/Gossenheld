'use strict';
// ================= SPIELLOGIK =================
const DAY_LEN = 480, SAVE_KEY = 'gossenheld_save_v1';
let P = null;
const G = {t:0,time:120,day:1,seed:1337,enemies:[],allies:[],npcMap:{},npcs:[],proj:[],drops:[],fx:[],texts:[],chests:{},dynChests:{},mods:{},
  explored:null,tmp:[],st:null,spawnT:0,bossT:0,evT:30,saveT:0,revealT:0,interT:0,hudT:0,npcT:0,inter:null,running:false,paused:false,region:'',
  shake:0,keys:{},joy:{x:0,y:0},atkHeld:false,scale:4,marks:{}};

// ---------- Grundlagen ----------
function hour() { return (6 + G.time / DAY_LEN * 24) % 24; }
function isNight() { const h = hour(); return h >= 20 || h < 5; }
function clock() { const h = hour(), hh = Math.floor(h), mm = Math.floor((h - hh) * 6) * 10; return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0'); }
function tileAt(x, y) { x = Math.floor(x); y = Math.floor(y); if (!inb(x, y)) return TL.WATER; return WT[idx(x, y)]; }
function regionAt(x, y) { x = Math.floor(x); y = Math.floor(y); if (!inb(x, y)) return 'wiese'; return REGIONS[WR[idx(x, y)]]; }
function walkable(x, y, enemy) {
  const ix = Math.floor(x), iy = Math.floor(y); if (!inb(ix, iy)) return false;
  const i = idx(ix, iy); if (BLOCK[WT[i]]) return false;
  if (enemy) { const r = REGIONS[WR[i]]; if (r === 'stadt' || r === 'dorf') return false; }
  return true;
}
function canStand(x, y, r, enemy) { return walkable(x - r, y - r * 0.6, enemy) && walkable(x + r, y - r * 0.6, enemy) && walkable(x - r, y + r * 0.3, enemy) && walkable(x + r, y + r * 0.3, enemy); }
function moveEnt(e, dx, dy, enemy) {
  const r = e.r || 0.3; let m = false;
  if (dx && canStand(e.x + dx, e.y, r, enemy)) { e.x += dx; m = true; }
  if (dy && canStand(e.x, e.y + dy, r, enemy)) { e.y += dy; m = true; }
  return m;
}
function inCity() { const r = regionAt(P.x, P.y); return r === 'stadt' || r === 'gosse'; }
function inHome() { return P.houses.length > 0 && inCity(); }
function floatText(x, y, txt, col, big) { G.texts.push({x, y, txt, col, t:0, big}); }
function burst(x, y, col, n) { for (let i = 0; i < n; i++) { const a = Math.random() * TAU, s = rnd(1, 4); G.fx.push({k:'p', x, y, vx:Math.cos(a) * s, vy:Math.sin(a) * s - 1, life:rnd(0.3, 0.7), col, sz:rnd(1, 2.5)}); } }
function ring(x, y, max, col) { G.fx.push({k:'ring', x, y, r:0.2, max, life:0.4, t:0, col}); }

// ---------- Spieler ----------
function inst(id) { return {id, n:1, up:0, dur:100}; }
function newPlayer(c) {
  const cl = CLASSES[c.cls], rc = RACES[c.race];
  const base = Object.assign({}, cl.base); for (const k in rc.bonus) base[k] += rc.bonus[k];
  let discs = {};
  if (c.cls === 'hybrid') c.discs.forEach(d => { discs[d] = HYBRID_EFF; base[DISC[d].stat] += 2; });
  else discs = Object.assign({}, cl.disc);
  P = {kind:'player', name:c.name, race:c.race, cls:c.cls, gender:c.gender, hair:c.hair, discs, base, lvl:1, xp:0, attrPts:0, skillPts:0,
    hp:1, en:1, x:60.5, y:115.6, dir:1, face:{x:1, y:0}, r:0.28, gold:25, arrows:0, inv:[],
    eq:{waffe:null, ruestung:null, koecher:null, rucksack:null, schmuck:null}, skills:{}, slots:[null, null, null], prof:{}, learned:{},
    q:{}, dyn:{}, f:{}, rep:{stadt:0, diebe:0, karma:0}, rank:'Keiner', title:'Gossenkind', comp:{}, party:[], pets:[], petActive:-1, mount:-1, mounted:false,
    houses:[], furn:[], storage:[], biz:{}, guild:null, buffs:{}, cds:{}, kills:{}, potion:'heiltrank', lastHit:-99, atkCd:0, invuln:0};
  for (const k in PROFS) { P.prof[k] = {lvl:0, xp:0}; P.learned[k] = !PROFS[k].learn; }
  for (const k in COMPS) P.comp[k] = {aff:0, lover:false, hired:false, talkDay:-1, flirtDay:-1, giftDay:-1, hp:null};
  const ds = Object.keys(discs);
  P.eq.rucksack = inst('beutel');
  P.eq.waffe = inst(c.cls === 'hybrid' ? HYB_WEAPON[ds[0]] : cl.start.waffe);
  P.eq.ruestung = inst((cl.start && cl.start.ruestung) || 'lumpen');
  if (discs.bogen) { P.eq.koecher = inst('koecher_klein'); P.arrows = 30; }
  if (c.cls === 'hybrid' && ds[1]) { addItem(HYB_WEAPON[ds[1]]); if (ds[1] === 'bogen') { addItem('koecher_klein'); } }
  addItem('axt'); addItem('brot', 2); addItem('heiltrank', 1);
  let si = 0;
  for (const d of ds) for (const id in SKILLS) if (SKILLS[id].d === d && SKILLS[id].lvl === 1) { P.skills[id] = 1; P.slots[si++] = id; }
  const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
}
function stats() {
  const b = Object.assign({}, P.base);
  for (const s in P.eq) { const e = P.eq[s]; if (e && ITEMS[e.id].bonus) { const bo = ITEMS[e.id].bonus; for (const k in bo) b[k] += bo[k]; } }
  if (P.buffs.held) for (const k in b) b[k] += 3;
  const arm = P.eq.ruestung;
  let def = arm ? ITEMS[arm.id].def * (1 + 0.12 * (arm.up || 0)) * (arm.dur > 0 ? 1 : 0.5) : 0;
  if (P.eq.schmuck && ITEMS[P.eq.schmuck.id].def) def += ITEMS[P.eq.schmuck.id].def;
  def += b.vit * 0.3; if (P.buffs.segen) def += 10; if (P.buffs.held) def *= 1.2;
  const maxHp = Math.round((40 + b.vit * 9 + P.lvl * 7) * (P.furn.includes('altar') ? 1.1 : 1));
  const maxEn = Math.round(30 + b.int * 3 + b.wis * 2 + P.lvl * 3);
  return Object.assign(b, {def, maxHp, maxEn, crit:0.05 + b.dex * 0.004, speed:3.6 * (1 + b.dex * 0.004)});
}
function discEff(d) { return P.discs[d] || 0; }
function weaponDef() { return P.eq.waffe ? ITEMS[P.eq.waffe.id] : null; }
function weaponDmg() { const w = P.eq.waffe; if (!w) return 2; return ITEMS[w.id].dmg * (1 + 0.12 * (w.up || 0)) * (w.dur > 0 ? 1 : 0.5); }
function dmgMult() { return 1 + (P.buffs.schrei ? 0.35 : 0) + (P.buffs.held ? 0.2 : 0); }
function luck() { return P.eq.schmuck && ITEMS[P.eq.schmuck.id].luck || 0; }
function xpNeed(l) { return Math.floor(60 * Math.pow(l, 1.7)); }
function profNeed(l) { return Math.floor(25 * Math.pow(l + 1, 1.7)); }
function gainXp(v) {
  const m = 1 + (P.furn.includes('trophaeen') ? 0.05 : 0) + (P.guild ? P.guild.lvl * 0.05 : 0) + (P.buffs.verliebt ? 0.1 : 0);
  P.xp += Math.round(v * m);
  while (P.xp >= xpNeed(P.lvl) && P.lvl < 50) {
    P.xp -= xpNeed(P.lvl); P.lvl++; P.attrPts += 3; P.skillPts += 1;
    const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
    toast('⭐ Stufe ' + P.lvl + '! +3 Attributpunkte, +1 Fähigkeitspunkt', 'gold');
    ring(P.x, P.y - 0.5, 3, '#ffd75a'); burst(P.x, P.y - 0.6, '#ffe48a', 24);
    syncAllies();
  }
}
function learnProf(id) { P.learned[id] = true; if (P.prof[id].lvl < 1) P.prof[id].lvl = 1; toast('📖 Beruf erlernt: ' + PROFS[id].name, 'gold'); }
function gainProf(id, amt) {
  const p = P.prof[id];
  let m = 1; if (P.race === 'zwerg' && (id === 'schmieden' || id === 'bergbau')) m = 1.5; if (P.furn.includes('bibliothek')) m *= 1.15;
  if (p.lvl >= 10) return;
  p.xp += amt * m;
  while (p.xp >= profNeed(p.lvl) && p.lvl < 10) { p.xp -= profNeed(p.lvl); p.lvl++; toast(PROFS[id].icon + ' ' + PROFS[id].name + ' Stufe ' + p.lvl + '!', 'gold'); }
}

// ---------- Inventar ----------
function invCap() { return P.eq.rucksack ? ITEMS[P.eq.rucksack.id].slots : 8; }
function quiverCap() { return P.eq.koecher ? ITEMS[P.eq.koecher.id].cap : 0; }
function countItem(id) { let n = 0; for (const s of P.inv) if (s.id === id) n += s.n; return n; }
function addItem(id, n, silent) {
  n = n || 1; const it = ITEMS[id]; if (!it) return false;
  if (it.type === 'ammo') {
    const cap = quiverCap(); if (!cap) { if (!silent) toast('Du brauchst einen Köcher für Pfeile.'); return false; }
    const before = P.arrows; P.arrows = Math.min(cap, P.arrows + it.amount * n);
    if (P.arrows - before < it.amount * n && !silent) toast('Köcher voll (' + cap + ')');
    return P.arrows > before;
  }
  if (it.stack) {
    const s = P.inv.find(s => s.id === id);
    if (s) s.n += n; else { if (P.inv.length >= invCap()) { if (!silent) toast('🎒 Inventar voll!'); return false; } P.inv.push({id, n}); }
  } else {
    for (let k = 0; k < n; k++) { if (P.inv.length >= invCap()) { if (!silent) toast('🎒 Inventar voll!'); return false; } P.inv.push(inst(id)); }
  }
  questEvent('collect');
  return true;
}
function removeItem(id, n) {
  n = n || 1;
  for (let i = P.inv.length - 1; i >= 0 && n > 0; i--) {
    const s = P.inv[i]; if (s.id !== id) continue;
    const take = Math.min(n, s.n); s.n -= take; n -= take; if (s.n <= 0) P.inv.splice(i, 1);
  }
}
const EQ_TYPES = ['waffe', 'ruestung', 'koecher', 'rucksack', 'schmuck'];
function equipItem(i) {
  const s = P.inv[i]; if (!s) return; const it = ITEMS[s.id]; const slot = it.type;
  if (!EQ_TYPES.includes(slot)) return;
  if (slot === 'rucksack') {
    const old = P.eq.rucksack, newCap = it.slots, need = P.inv.length - 1 + (old ? 1 : 0);
    if (need > newCap) { toast('Zu viele Gegenstände für diesen Rucksack.'); return; }
  }
  P.inv.splice(i, 1);
  if (P.eq[slot]) P.inv.push(P.eq[slot]);
  P.eq[slot] = s;
  if (slot === 'koecher' && P.arrows > quiverCap()) { toast('Überzählige Pfeile passen nicht in den Köcher.'); P.arrows = quiverCap(); }
  if (slot === 'ruestung') refreshPlayerSprite();
  toast('Ausgerüstet: ' + it.name);
}
function unequip(slot) {
  const s = P.eq[slot]; if (!s) return;
  if (slot === 'rucksack') { toast('Den Rucksack ersetzt du, indem du einen anderen ausrüstest.'); return; }
  if (P.inv.length >= invCap()) { toast('🎒 Inventar voll!'); return; }
  P.inv.push(s); P.eq[slot] = null;
  if (slot === 'koecher') P.arrows = 0;
  if (slot === 'ruestung') refreshPlayerSprite();
}
function useItem(i) {
  const s = P.inv[i]; if (!s) return; const it = ITEMS[s.id];
  if (it.type !== 'food') { equipItem(i); return; }
  const st = stats();
  if (it.heal) { const h = Math.min(it.heal, st.maxHp - P.hp); P.hp += h; floatText(P.x, P.y - 1.2, '+' + Math.round(h), '#6f6'); }
  if (it.mana) { P.en = Math.min(st.maxEn, P.en + it.mana); floatText(P.x, P.y - 1.4, '+' + it.mana + ' Energie', '#7af'); }
  if (it.buff) { P.buffs[it.buff[0]] = it.buff[1]; toast(it.icon + ' ' + BUFF_NAMES[it.buff[0]]); }
  s.n--; if (s.n <= 0) P.inv.splice(i, 1);
}
const BUFF_NAMES = {schrei:'Kriegsschrei: +35 % Schaden', held:'Heldenmahl: Alle Werte +3, +20 % Schaden & Rüstung', satt:'Satt: Leben regeneriert schneller', mut:'Angeheitert: Flirten fällt leichter', verliebt:'Verliebt: +10 % Erfahrung', segen:'Segen: Regeneration & +10 Rüstung'};
function quickPotion() {
  const ids = ['grheiltrank', 'heiltrank', 'eintopf', 'gebraten', 'brot'];
  for (const id of ids) { const i = P.inv.findIndex(s => s.id === id); if (i >= 0) { useItem(i); return; } }
  toast('Keine Heilmittel im Inventar.');
}
function refreshPlayerSprite() { G.pspr = makeHumanoid(playerLook()); }
function playerLook() {
  const rc = RACES[P.race], cl = CLASSES[P.cls], arm = P.eq.ruestung ? P.eq.ruestung.id : 'lumpen';
  return {skin:rc.skin, hair:P.hair, outfit:ARMOR_COLOR[arm] || cl.outfit, pants:cl.outfit2, longHair:P.gender === 'w', ears:P.race === 'elf', beard:P.race === 'zwerg' && P.gender === 'm'};
}

// ---------- Quests ----------
function getQ(id) { return QUESTS[id] || P.dyn[id]; }
function questActive(id) { const s = P.q[id]; return !!(s && !s.done); }
function questDone(id) { const s = P.q && P.q[id]; return !!(s && s.done); }
function curStep(id) { const s = P.q[id]; if (!s || s.done) return null; const q = getQ(id); return q ? q.steps[s.s] : null; }
function stepIs(id, t) { const st = curStep(id); return !!(st && st.t === t); }
function startQuest(id) {
  if (P.q[id]) return; P.q[id] = {s:0, c:0, done:false};
  toast('📜 Neue Quest: ' + getQ(id).name, 'quest'); checkStepAuto(id);
}
function advanceQuest(id, to) {
  const s = P.q[id], q = getQ(id); const old = q.steps[s.s];
  if (old && old.onDone) old.onDone();
  s.s = (to != null ? to : s.s + 1); s.c = 0;
  if (s.s >= q.steps.length) completeQuest(id);
  else { toast('📜 ' + q.steps[s.s].txt, 'quest'); checkStepAuto(id); }
}
function completeQuest(id) {
  const s = P.q[id], q = getQ(id); s.done = true;
  const r = q.reward || {};
  toast('✅ Quest abgeschlossen: ' + q.name, 'gold');
  if (r.gold) { P.gold += r.gold; toast('+' + r.gold + ' Gold'); }
  if (r.items) r.items.forEach(it => addItem(it[0], it[1]));
  if (q.onDone) q.onDone();
  if (r.xp) gainXp(r.xp);
  if (P.dyn[id]) { delete P.dyn[id]; delete P.q[id]; }
  if (q.next) startQuest(q.next);
}
function checkStepAuto(id) {
  const st = curStep(id); if (!st) return;
  if (st.t === 'collect' && !st.npc && countItem(st.item) >= st.n) advanceQuest(id);
  else if (st.t === 'goto' && regionAt(P.x, P.y) === st.region) advanceQuest(id);
}
function questEvent(type, arg) {
  if (!P) return;
  for (const id of Object.keys(P.q)) {
    const st = curStep(id); if (!st) continue;
    if (type === 'kill' && st.t === 'kill' && st.e === arg) {
      P.q[id].c++;
      if (P.q[id].c >= st.n) advanceQuest(id); else toast('📜 ' + ENEMIES[arg].name + ': ' + P.q[id].c + '/' + st.n);
    } else if (type === 'collect' || type === 'goto') checkStepAuto(id);
  }
}
function questOpts(npcId) {
  const out = [];
  for (const id of Object.keys(P.q)) {
    const st = curStep(id); if (!st) continue; const q = getQ(id);
    const say = s => typeof s === 'function' ? s() : s;
    if (st.t === 'talk' && st.npc === npcId) out.push({t:'📜 ' + q.name, q:true, f:() => { const tx = say(st.say); advanceQuest(id); return {text:tx}; }});
    if (st.t === 'collect' && st.npc === npcId && countItem(st.item) >= st.n)
      out.push({t:'📜 ' + st.n + '× ' + ITEMS[st.item].name + ' abgeben', q:true, f:() => { removeItem(st.item, st.n); const tx = say(st.say); advanceQuest(id); return {text:tx}; }});
    if (st.t === 'branch') for (const o of st.opts) {
      if (o.npc !== npcId || (o.need && countItem(o.need) < 1)) continue;
      out.push({t:o.label, q:true, f:() => { if (o.fn) o.fn(); advanceQuest(id, o.jump); return {text:o.say}; }});
    }
  }
  return out;
}
function bountyActive() { return Object.keys(P.dyn).length > 0; }
function newBounty() {
  const pool = ['ratte','wolf','goblin','eber','bandit','schleim','skelett','baer','troll','soldat','warg','schattenritter'].filter(t => ENEMIES[t].lvl <= P.lvl + 2 && ENEMIES[t].lvl >= P.lvl - 6);
  const e = pick(pool.length ? pool : ['wolf']), d = ENEMIES[e], n = rint(4, 8);
  P.bountyN = (P.bountyN || 0) + 1;
  const id = 'kopfgeld' + P.bountyN;
  P.dyn[id] = {name:'Kopfgeld: ' + d.name, steps:[{t:'kill', e, n, txt:'Erlege ' + n + '× ' + d.name + '.'}, {t:'talk', npc:'sera', txt:'Hol dir dein Kopfgeld bei Sera ab.', say:'„Auftrag erledigt. Hier ist dein Lohn.“'}],
    reward:{xp:Math.round(d.xp * n * 0.7), gold:Math.round(d.xp * n * 0.6 + 20)}};
  startQuest(id);
  return {text:'„' + n + '× ' + d.name + '. Die Belohnung ist ordentlich. Komm zurück, wenn’s erledigt ist.“'};
}

// ---------- Kampf ----------
function nearestEnemy(x, y, r, filt) {
  let best = null, bd = r;
  for (const e of G.enemies) { if (e.dead || (filt && !filt(e))) continue; if (e.def.passive && !e.flee) continue; const d = dist(x, y, e.x, e.y); if (d < bd) { bd = d; best = e; } }
  return best;
}
function faceTo(e) { const dx = e.x - P.x, dy = e.y - P.y, l = Math.hypot(dx, dy) || 1; P.face = {x:dx / l, y:dy / l}; P.dir = dx < 0 ? -1 : 1; }
function wearWeapon() {
  const w = P.eq.waffe; if (!w) return;
  const before = w.dur; w.dur = Math.max(0, w.dur - 0.25);
  if (before > 20 && w.dur <= 20) toast('⚠️ Deine Waffe ist stark abgenutzt. Lass sie reparieren!');
  if (before > 0 && w.dur <= 0) toast('💔 Deine Waffe ist beschädigt – nur noch halber Schaden.');
}
function attack() {
  if (P.atkCd > 0 || P.dead || P.work) return;
  const w = weaponDef(), wt = w ? w.wt : 'melee', st = G.st;
  const tgt = nearestEnemy(P.x, P.y, wt === 'melee' ? 2.4 : 9);
  if (tgt) faceTo(tgt);
  const base = weaponDmg();
  if (wt === 'melee') {
    const eff = discEff('kampf') || 0.6;
    const dmg = (base + st.str * 0.9) * eff * dmgMult() * (P.race === 'ork' ? 1.1 : 1);
    P.atkCd = 0.45; P.swing = 0.2; let hit = false;
    for (const e of G.enemies) {
      if (e.dead) continue; const d = dist(P.x, P.y, e.x, e.y), reach = 1.4 + 0.3 * e.size;
      if (d > reach) continue;
      const dot = ((e.x - P.x) * P.face.x + (e.y - P.y) * P.face.y) / (d || 1);
      if (d < 0.8 || dot > 0.25) { dealDmg(e, dmg, {src:'p', kb:0.35, holy:w && w.holy}); hit = true; }
    }
    if (hit) wearWeapon();
  } else if (wt === 'bow') {
    if (P.arrows <= 0) { toast('Keine Pfeile! Kauf welche oder stell sie her (Holz + Stein).'); P.atkCd = 0.6; return; }
    P.arrows--;
    const eff = discEff('bogen') || 0.6;
    const dmg = (base + st.dex * 0.9) * eff * dmgMult() * (P.race === 'elf' ? 1.1 : 1);
    shoot(P.x, P.y - 0.5, P.face.x, P.face.y, 'arrow', dmg, 'p', {speed:13, range:10});
    P.atkCd = 0.6; P.swing = 0.15; wearWeapon();
  } else {
    const holyish = P.discs.heil && !P.discs.magie;
    const eff = discEff('magie') || discEff('heil') || 0.6;
    const dmg = (base + Math.max(st.int, st.wis) * 0.9) * eff * dmgMult();
    shoot(P.x, P.y - 0.5, P.face.x, P.face.y, holyish ? 'holy' : 'bolt', dmg, 'p', {speed:10, range:9, holy:holyish});
    P.atkCd = 0.55; P.swing = 0.15; wearWeapon();
  }
}
function shoot(x, y, dx, dy, kind, dmg, team, o) {
  const l = Math.hypot(dx, dy) || 1, sp = (o && o.speed) || 10;
  G.proj.push(Object.assign({x, y, vx:dx / l * sp, vy:dy / l * sp, kind, dmg, team, life:((o && o.range) || 9) / sp, r:0.35}, o || {}));
}
function dealDmg(e, dmg, o) {
  if (e.dead) return; o = o || {};
  let crit = false;
  if (o.src === 'p' && Math.random() < G.st.crit) { dmg *= 1.75; crit = true; }
  if (o.holy && e.def.undead) dmg *= 2;
  dmg *= rnd(0.9, 1.1); dmg = Math.max(1, Math.round(dmg));
  e.hp -= dmg; e.hitT = 0.15; e.aggro = true;
  if (e.def.passive) e.flee = 5;
  floatText(e.x + rnd(-0.3, 0.3), e.y - 1.1 * e.size, (crit ? '💥' : '') + dmg, crit ? '#ffcf40' : (o.src === 'dot' ? '#9f6' : '#fff'), crit);
  if (o.kb && !e.boss) { const fx = o.fx != null ? o.fx : P.x, fy = o.fy != null ? o.fy : P.y; const dx = e.x - fx, dy = e.y - fy, l = Math.hypot(dx, dy) || 1; moveEnt(e, dx / l * o.kb, dy / l * o.kb, true); }
  if (e.hp <= 0) killEnemy(e);
}
function killEnemy(e) {
  if (e.dead) return; e.dead = true; const d = e.def;
  gainXp(d.xp);
  if (d.gold) { const g = rint(d.gold[0], d.gold[1]); if (g > 0) { P.gold += g; floatText(e.x, e.y - 1.5, '+' + g + ' Gold', '#ffd75a'); } }
  for (const dr of d.drops || []) if (Math.random() < dr[1] * (1 + luck())) G.drops.push({x:e.x + rnd(-0.4, 0.4), y:e.y + rnd(-0.3, 0.3), id:dr[0], n:dr[2] || 1, t:0});
  for (const qid of Object.keys(P.q)) { const st = curStep(qid); if (st && st.t === 'collect' && st.from === e.type && Math.random() < st.p) G.drops.push({x:e.x, y:e.y, id:st.item, n:1, t:0}); }
  P.kills[e.type] = (P.kills[e.type] || 0) + 1;
  if (d.boss) { P.f[e.type + 'Tot'] = true; toast('🏆 ' + d.name + ' wurde besiegt!', 'gold'); G.shake = 0.5; }
  burst(e.x, e.y - 0.5, d.col, 14);
  questEvent('kill', e.type);
}
function allyTargets() { const a = G.allies.filter(x => !x.down); if (!P.dead) a.unshift(P); return a; }
function hurt(a, dmg) {
  if (a === P) {
    if (P.invuln > 0 || P.dead) return;
    const red = 100 / (100 + G.st.def * 4);
    dmg = Math.max(1, Math.round(dmg * red * rnd(0.9, 1.1)));
    P.hp -= dmg; P.lastHit = G.t; P.hitT = 0.2;
    floatText(P.x, P.y - 1.2, '-' + dmg, '#ff5a4a');
    if (P.eq.ruestung) P.eq.ruestung.dur = Math.max(0, P.eq.ruestung.dur - 0.4);
    if (P.work) P.work = null;
    if (P.hp <= 0) playerDie();
  } else {
    dmg = Math.max(1, Math.round(dmg * 0.85));
    a.hp -= dmg; a.hitT = 0.2; floatText(a.x, a.y - 1.1, '-' + dmg, '#ff9a8a');
    if (a.hp <= 0) { a.hp = 0; a.down = true; a.downT = 0; toast('😵 ' + a.name + ' ist bewusstlos!'); }
  }
}
function healAlly(a, amt) {
  if (a === P) { const m = G.st.maxHp; const h = Math.min(amt, m - P.hp); if (h > 0) { P.hp += h; floatText(P.x, P.y - 1.3, '+' + Math.round(h), '#6f6'); } }
  else if (!a.down) { const h = Math.min(amt, a.maxHp - a.hp); if (h > 0) { a.hp += h; floatText(a.x, a.y - 1.2, '+' + Math.round(h), '#6f6'); } }
}
function playerDie() {
  P.dead = true; P.hp = 0; P.mounted = false;
  showDeath();
}
function respawn() {
  const loss = Math.floor(P.gold * 0.1); P.gold -= loss;
  let pos = [60.5, 114.6];
  if (P.furn.includes('bett') && P.houses.length) { const h = P.houses[P.houses.length - 1]; pos = HOUSES[h].pos; }
  P.x = pos[0]; P.y = pos[1]; P.dead = false;
  const st = stats(); P.hp = st.maxHp * 0.6; P.en = st.maxEn * 0.5;
  G.enemies = G.enemies.filter(e => dist(e.x, e.y, P.x, P.y) > 20);
  G.allies.forEach(a => { a.x = P.x + rnd(-1, 1); a.y = P.y + rnd(0.5, 1); a.down = false; a.hp = a.maxHp * 0.5; });
  toast(loss ? 'Du hast ' + loss + ' Gold verloren.' : 'Du kommst wieder zu dir…');
}

// ---------- Fähigkeiten ----------
function skillPower(sk, id) {
  const st = G.st, w = weaponDef(), wd = weaponDmg(), rank = P.skills[id] || 1;
  let p;
  if (sk.d === 'kampf') p = (w && w.wt === 'melee' ? wd : 4) + st.str * 1.2;
  else if (sk.d === 'magie') p = 6 + st.int * 1.8 + (w && w.wt === 'staff' ? wd * 0.6 : 0);
  else if (sk.d === 'bogen') p = (w && w.wt === 'bow' ? wd : 4) + st.dex * 1.2;
  else p = 6 + st.wis * 1.7 + (w && w.wt === 'staff' ? wd * 0.5 : 0);
  const hb = sk.d === 'heil' && w && w.healBonus ? 1 + w.healBonus : 1;
  return p * discEff(sk.d) * (1 + 0.2 * (rank - 1)) * dmgMult() * hb;
}
function castSkill(slot) {
  const id = P.slots[slot]; if (!id || P.dead || P.work) return;
  const sk = SKILLS[id];
  if ((P.cds[id] || 0) > 0) return;
  if (P.en < sk.cost) { toast('Nicht genug Energie.'); return; }
  const needArrow = ['mehrfach', 'gift', 'hagel'].includes(id);
  if (needArrow && P.arrows <= 0) { toast('Keine Pfeile!'); return; }
  const sp = skillPower(sk, id);
  const tgt = nearestEnemy(P.x, P.y, 10); if (tgt) faceTo(tgt);
  const fx = P.face.x, fy = P.face.y;
  switch (id) {
    case 'wirbel': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 2.2) dealDmg(e, sp * 1.3, {src:'p', kb:0.6}); ring(P.x, P.y - 0.3, 2.2, '#ddd'); P.spin = 0.3; break;
    case 'schrei': P.buffs.schrei = 10; ring(P.x, P.y - 0.5, 4, '#f84'); toast('📣 Kriegsschrei!'); break;
    case 'ansturm': P.dash = {t:0.25, vx:fx * 14, vy:fy * 14, dmg:sp * 1.5, hit:[]}; P.invuln = 0.35; break;
    case 'beben': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 4) { dealDmg(e, sp * 2.2, {src:'p', kb:0.4}); e.stun = 2; } ring(P.x, P.y, 4, '#a86'); G.shake = 0.4; break;
    case 'feuerball': shoot(P.x, P.y - 0.5, fx, fy, 'fire', sp * 1.6, 'p', {speed:9, range:10, aoe:1.6}); break;
    case 'frost': for (const e of G.enemies) if (!e.dead && dist(P.x, P.y, e.x, e.y) < 3.5) { dealDmg(e, sp, {src:'p'}); e.slow = 4; } ring(P.x, P.y - 0.3, 3.5, '#9df'); break;
    case 'blitz': {
      let cur = tgt; if (!cur) { toast('Kein Ziel in Reichweite.'); return; }
      const hit = [], pts = [[P.x, P.y - 0.6]]; let d = sp * 1.4;
      for (let k = 0; k < 4 && cur; k++) { hit.push(cur); pts.push([cur.x, cur.y - 0.5]); dealDmg(cur, d, {src:'p'}); d *= 0.8; const c = cur; cur = nearestEnemy(c.x, c.y, 4, e => !hit.includes(e)); }
      G.fx.push({k:'line', pts, life:0.25, col:'#bdf'}); break; }
    case 'meteor': { const tx = tgt ? tgt.x : P.x + fx * 4, ty = tgt ? tgt.y : P.y + fy * 4; G.fx.push({k:'meteor', x:tx, y:ty, t:0, life:0.8, dmg:sp * 3}); break; }
    case 'mehrfach': P.arrows--; for (let k = -2; k <= 2; k++) { const a = Math.atan2(fy, fx) + k * 0.18; shoot(P.x, P.y - 0.5, Math.cos(a), Math.sin(a), 'arrow', sp * 0.8, 'p', {speed:13, range:9}); } break;
    case 'gift': P.arrows--; shoot(P.x, P.y - 0.5, fx, fy, 'poison', sp * 0.8, 'p', {speed:13, range:10, poison:sp * 0.35}); break;
    case 'rolle': P.dash = {t:0.25, vx:-fx * 12, vy:-fy * 12}; P.invuln = 0.5; break;
    case 'hagel': { P.arrows = Math.max(0, P.arrows - 5); const tx = tgt ? tgt.x : P.x + fx * 4, ty = tgt ? tgt.y : P.y + fy * 4; G.fx.push({k:'rain', x:tx, y:ty, t:0, life:2, tick:0, dmg:sp * 0.45}); break; }
    case 'heilung': { const h = sp * 1.5; for (const a of allyTargets()) if (dist(P.x, P.y, a.x, a.y) < 8) healAlly(a, h); ring(P.x, P.y - 0.4, 3, '#7f7'); burst(P.x, P.y - 0.6, '#8f8', 10); break; }
    case 'licht': shoot(P.x, P.y - 0.5, fx, fy, 'holy', sp * 1.4, 'p', {speed:11, range:10, holy:true}); break;
    case 'segen': P.buffs.segen = 15; ring(P.x, P.y - 0.4, 4, '#ffe'); toast('🙏 Segen!'); break;
    case 'wunder': for (const a of G.allies) { a.down = false; a.hp = a.maxHp; } P.hp = G.st.maxHp; ring(P.x, P.y - 0.4, 6, '#fff6b0'); burst(P.x, P.y - 1, '#fff', 30); toast('👼 Wunder!'); break;
  }
  P.en -= sk.cost; P.cds[id] = sk.cd;
}

// ---------- Gegner ----------
function spawnEnemy(type, x, y, o) {
  const d = ENEMIES[type], sz = d.size || 1;
  const e = Object.assign({kind:'enemy', type, def:d, x, y, hx:x, hy:y, hp:d.hp, maxHp:d.hp, dmg:d.dmg, spd:d.spd, r:Math.min(0.45, 0.28 * sz), size:sz,
    cd:rnd(0.5, 1.5), wt:0, wx:0, wy:0, hitT:0, slow:0, stun:0, poison:null, aggro:false, flee:0, special:5, boss:!!d.boss, spr:enemySprite(type)}, o || {});
  G.enemies.push(e); return e;
}
function updEnemy(e, dt) {
  if (e.hitT > 0) e.hitT -= dt;
  if (e.poison) { e.poison.t -= dt; e.pt = (e.pt || 0) + dt; if (e.pt >= 1) { e.pt = 0; dealDmg(e, e.poison.dps, {src:'dot'}); } if (e.poison && e.poison.t <= 0) e.poison = null; if (e.dead) return; }
  if (e.stun > 0) { e.stun -= dt; return; }
  const d = e.def, spd = e.spd * (e.slow > 0 ? 0.5 : 1), en = !e.boss;
  if (e.slow > 0) e.slow -= dt;
  e.cd -= dt; e.moving = false;
  const wander = () => {
    e.wt -= dt;
    if (e.wt <= 0) { e.wt = rnd(1.5, 3.5); const a = Math.random() * TAU; const go = chance(0.6); e.wx = go ? Math.cos(a) : 0; e.wy = go ? Math.sin(a) : 0; if (dist(e.x, e.y, e.hx, e.hy) > 7) { const dx = e.hx - e.x, dy = e.hy - e.y, l = Math.hypot(dx, dy); e.wx = dx / l; e.wy = dy / l; } }
    if (e.wx || e.wy) { if (moveEnt(e, e.wx * spd * 0.35 * dt, e.wy * spd * 0.35 * dt, en)) { e.moving = true; e.dir = e.wx < 0 ? -1 : 1; } else e.wt = 0; }
  };
  if (d.passive) {
    if (e.flee > 0) { e.flee -= dt; const dx = e.x - P.x, dy = e.y - P.y, l = Math.hypot(dx, dy) || 1; if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) { e.moving = true; e.dir = dx < 0 ? -1 : 1; } }
    else wander();
    return;
  }
  let t = null, td = e.aggro ? 12 : (e.boss ? 9 : 6);
  for (const a of allyTargets()) { const dd = dist(e.x, e.y, a.x, a.y); if (dd < td) { td = dd; t = a; } }
  if (!t) { e.aggro = false; wander(); return; }
  const dx = t.x - e.x, dy = t.y - e.y, l = Math.hypot(dx, dy) || 1; e.dir = dx < 0 ? -1 : 1;
  if (e.boss) {
    e.special -= dt;
    if (e.special <= 0) {
      e.special = e.type === 'malgor' || e.type === 'wyrm' ? 5 : 7;
      for (let k = 0; k < 10; k++) { const a = k / 10 * TAU; shoot(e.x, e.y - 0.5 * e.size, Math.cos(a), Math.sin(a), d.proj || 'shadow', e.dmg * 0.7, 'e', {speed:6, range:8}); }
      if (e.type === 'malgor' && G.enemies.length < 20) for (let k = 0; k < 2; k++) spawnEnemy('schattenritter', e.x + rnd(-2, 2), e.y + rnd(-2, 2), {aggro:true});
    }
  }
  if (d.ranged) {
    if (l > 6) { if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) e.moving = true; }
    else if (l < 2.6 && !e.boss) { if (moveEnt(e, -dx / l * spd * 0.7 * dt, -dy / l * spd * 0.7 * dt, en)) e.moving = true; }
    if (l < 7.5 && e.cd <= 0) { shoot(e.x, e.y - 0.5 * e.size, dx, dy, d.proj || 'arrow', e.dmg, 'e', {speed:d.proj === 'arrow' ? 10 : 7, range:9}); e.cd = e.boss ? 1.1 : 1.8; }
  } else {
    const range = 0.75 + 0.35 * e.size;
    if (l > range) { if (moveEnt(e, dx / l * spd * dt, dy / l * spd * dt, en)) e.moving = true; }
    else if (e.cd <= 0) { hurt(t, e.dmg); e.cd = 1.1; e.atk = 0.2; }
  }
  if (e.atk > 0) e.atk -= dt;
}
function spawnTick() {
  let near = 0; for (const e of G.enemies) if (dist(e.x, e.y, P.x, P.y) < 30) near++;
  const cap = isNight() ? 9 : 7; if (near >= cap) return;
  for (let k = 0; k < 10; k++) {
    const a = Math.random() * TAU, r = rnd(11, 18), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
    if (!canStand(x, y, 0.3, true)) continue;
    const reg = regionAt(x, y); let tab = SPAWNS[reg]; if (!tab) continue;
    if (isNight() && NIGHT_EXTRA[reg]) tab = tab.concat(NIGHT_EXTRA[reg]);
    if (!tab.length) continue;
    if (reg === 'gosse' && P.f.krummFeind && isNight() && chance(0.3)) { spawnEnemy('bandit', x, y); return; }
    spawnEnemy(wpick(tab), x, y); return;
  }
}
function bossTick() {
  const want = {};
  for (const id of Object.keys(P.q)) { const st = curStep(id); if (st && st.t === 'kill' && BOSS_POS[st.e]) want[st.e] = true; }
  if (!P.f.wyrmTot) want.wyrm = true;
  for (const b in want) {
    const p = BOSS_POS[b]; if (dist(P.x, P.y, p[0], p[1]) > 22) continue;
    if (G.enemies.some(e => e.type === b && !e.dead)) continue;
    spawnEnemy(b, p[0], p[1]); toast('☠️ ' + ENEMIES[b].name + ' erscheint!', 'warn');
  }
}
function ambushVarek() {
  toast('☠️ „Dachtest du, ein Beutel Gold kauft dir meine Freundschaft?“ – Varek!', 'warn');
  spawnEnemy('varek', P.x + 4, P.y + 2, {aggro:true});
  for (let k = 0; k < 3; k++) spawnEnemy('soldat', P.x + rnd(-4, 4), P.y + rnd(-4, 4), {aggro:true});
}

// ---------- Verbündete (Gefährten & Tiere) ----------
function compStats(id) { const c = COMPS[id], m = 1 + 0.12 * (P.lvl - 1); return {maxHp:Math.round(c.hp * m), dmg:c.dmg * (1 + 0.1 * (P.lvl - 1))}; }
function petStats(p) { const d = ENEMIES[p.type], zl = P.prof.zaehmen.lvl; return {maxHp:Math.round(d.hp * (0.8 + 0.1 * zl) * (1 + 0.05 * (P.lvl - 1))), dmg:Math.max(4, d.dmg) * (0.8 + 0.08 * zl) * (1 + 0.04 * (P.lvl - 1))}; }
function syncAllies() {
  const old = G.allies, out = [];
  P.party.forEach((id, k) => {
    const c = COMPS[id], s = compStats(id), sv = P.comp[id];
    let a = old.find(o => o.kind === 'comp' && o.id === id);
    if (!a) { a = {kind:'comp', id, name:c.name, x:P.x + rnd(-1, 1), y:P.y + 1, r:0.28, cd:0, hitT:0, down:false, size:1, spr:makeHumanoid(c.look), style:{kampf:'melee', bogen:'arrow', magie:'magic', heil:'heal'}[c.cls]}; a.hp = sv.hp != null ? sv.hp : s.maxHp; }
    a.maxHp = s.maxHp; a.dmg = s.dmg; a.hp = Math.min(a.hp, a.maxHp); a.slot = k; out.push(a);
  });
  if (P.petActive >= 0 && P.pets[P.petActive] && !(P.mounted && P.mount === P.petActive)) {
    const p = P.pets[P.petActive], d = ENEMIES[p.type], s = petStats(p);
    if (p.roles.includes('kampf')) {
      let a = old.find(o => o.kind === 'pet' && o.pi === P.petActive);
      if (!a) { a = {kind:'pet', pi:P.petActive, name:p.name, x:P.x - 1, y:P.y + 0.5, r:0.3, cd:0, hitT:0, down:false, size:d.size || 1, spr:enemySprite(p.type), style:'melee'}; a.hp = p.hp != null ? p.hp : s.maxHp; }
      a.maxHp = s.maxHp; a.dmg = s.dmg; a.hp = Math.min(a.hp, a.maxHp); a.slot = P.party.length; out.push(a);
    }
  }
  G.allies = out;
}
function storeAllyHp() { for (const a of G.allies) { if (a.kind === 'comp') P.comp[a.id].hp = a.hp; else if (P.pets[a.pi]) P.pets[a.pi].hp = a.hp; } }
function updAlly(a, dt) {
  if (a.hitT > 0) a.hitT -= dt;
  if (a.down) { a.downT += dt; if (a.downT > 10 && !nearestEnemy(P.x, P.y, 9)) { a.down = false; a.hp = a.maxHp * 0.3; toast(a.name + ' ist wieder auf den Beinen.'); } return; }
  a.cd -= dt; a.moving = false;
  if (G.t - (a.lastHit || -99) > 5) a.hp = Math.min(a.maxHp, a.hp + a.maxHp * 0.01 * dt);
  if (P.buffs.segen) a.hp = Math.min(a.maxHp, a.hp + a.maxHp * 0.02 * dt);
  const sp = 4.2 * (P.mounted ? 1.6 : 1), dm = a.dmg * (P.buffs.schrei ? 1.35 : 1);
  const pd = dist(a.x, a.y, P.x, P.y);
  if (pd > 14) { a.x = P.x + rnd(-1, 1); a.y = P.y + rnd(0, 1); return; }
  if (a.style === 'heal' && a.cd <= 0) {
    const hurtA = allyTargets().find(t => (t === P ? P.hp / G.st.maxHp : t.hp / t.maxHp) < 0.6 && dist(a.x, a.y, t.x, t.y) < 8);
    if (hurtA) { healAlly(hurtA, dm * 2.5); a.cd = 3.5; burst(hurtA.x, hurtA.y - 0.6, '#8f8', 8); return; }
  }
  const t = nearestEnemy(a.x, a.y, 8, e => dist(e.x, e.y, P.x, P.y) < 10);
  if (t) {
    const dx = t.x - a.x, dy = t.y - a.y, l = Math.hypot(dx, dy) || 1; a.dir = dx < 0 ? -1 : 1;
    if (a.style === 'melee') {
      if (l > 0.8 + 0.3 * t.size) { if (moveEnt(a, dx / l * sp * dt, dy / l * sp * dt)) a.moving = true; }
      else if (a.cd <= 0) { dealDmg(t, dm, {src:'a', kb:0.2, fx:a.x, fy:a.y}); a.cd = 1.0; a.atk = 0.2; }
    } else {
      if (l > 6) { if (moveEnt(a, dx / l * sp * dt, dy / l * sp * dt)) a.moving = true; }
      else if (a.cd <= 0) { shoot(a.x, a.y - 0.5, dx, dy, a.style === 'arrow' ? 'arrow' : a.style === 'heal' ? 'holy' : 'fire', dm, 'p', {speed:11, range:9, holy:a.style === 'heal', aoe:a.style === 'magic' ? 1.2 : 0}); a.cd = 1.3; }
    }
  } else {
    const ang = (a.slot || 0) * 1.3 + 2.2, tx = P.x + Math.cos(ang) * 1.6, ty = P.y + Math.sin(ang) * 1.1;
    const dx = tx - a.x, dy = ty - a.y, l = Math.hypot(dx, dy);
    if (l > 0.4) { if (moveEnt(a, dx / l * Math.min(sp, l * 4) * dt, dy / l * Math.min(sp, l * 4) * dt)) { a.moving = true; a.dir = dx < 0 ? -1 : 1; } }
  }
  if (a.atk > 0) a.atk -= dt;
}
function tryTame(e) {
  const tm = e.def.tame, zl = P.prof.zaehmen.lvl + (P.race === 'ork' ? 1 : 0);
  if (zl < tm.lvl) { toast('Tierzähmung Stufe ' + tm.lvl + ' nötig.'); return; }
  const food = tm.food || 'fleisch';
  if (!countItem(food)) { toast('Du brauchst ' + ITEMS[food].name + ' als Futter.'); return; }
  if (P.pets.length >= 8) { toast('Du hast schon zu viele Tiere.'); return; }
  removeItem(food, 1);
  const ch = clamp(0.35 + 0.08 * zl - 0.04 * tm.lvl + (P.race === 'ork' ? 0.1 : 0), 0.1, 0.9);
  if (Math.random() < ch) {
    e.dead = true; G.enemies.splice(G.enemies.indexOf(e), 1);
    const p = {type:e.type, name:e.def.name, roles:tm.roles.slice(), speed:tm.speed || 1, hp:null};
    P.pets.push(p); const pi = P.pets.length - 1;
    if (p.roles.includes('kampf') && P.petActive < 0) P.petActive = pi;
    if (p.roles.includes('reit') && P.mount < 0) P.mount = pi;
    toast('🐾 ' + e.def.name + ' gezähmt!' + (p.roles.includes('reit') ? ' Reittier verfügbar.' : ''), 'gold');
    burst(e.x, e.y - 0.5, '#fde', 16); gainProf('zaehmen', 40 + tm.lvl * 15); gainXp(20 + tm.lvl * 10);
    syncAllies();
  } else {
    toast('Das ' + e.def.name + ' schnappt nach dem Futter und reißt sich los!');
    e.aggro = true; if (e.def.passive) e.flee = 5; gainProf('zaehmen', 8);
  }
}
function toggleRide() {
  if (P.mount < 0 || !P.pets[P.mount]) { toast('Du hast kein Reittier. Zähme ein Pferd, einen Hirsch, Bären oder Warg.'); return; }
  P.mounted = !P.mounted; syncAllies();
  toast(P.mounted ? '🐎 Aufgesessen: ' + P.pets[P.mount].name : 'Abgesessen.');
}

// ---------- NPCs ----------
function refreshNpcs() {
  const want = {};
  for (const d of NPC_DEFS) if (!d.cond || d.cond()) want[d.id] = d;
  for (const id in COMPS) { const c = COMPS[id]; if (P.party.includes(id)) continue; if (c.show && !c.show()) continue; want[id] = {id, name:c.name, x:c.home[0], y:c.home[1], look:c.look, comp:true}; }
  for (const t of G.tmp) want[t.id] = t;
  for (const id in G.npcMap) if (!want[id]) delete G.npcMap[id];
  for (const id in want) if (!G.npcMap[id]) { const d = want[id]; G.npcMap[id] = {id, def:d, x:d.x, y:d.y, hx:d.x, hy:d.y, r:0.25, wt:0, wx:0, wy:0, dir:1, spr:makeHumanoid(d.look)}; }
  G.npcs = Object.values(G.npcMap);
  G.marks = {};
  for (const n of G.npcs) { if (questOpts(n.id).length) G.marks[n.id] = '!'; else if (n.def.offer && n.def.offer()) G.marks[n.id] = '?'; }
}
function updNpc(n, dt) {
  n.moving = false;
  if (dist(n.x, n.y, P.x, P.y) < 2.5) { n.dir = P.x < n.x ? -1 : 1; return; }
  if (!n.def.wander) return;
  n.wt -= dt;
  if (n.wt <= 0) { n.wt = rnd(2, 5); const a = Math.random() * TAU, go = chance(0.5); n.wx = go ? Math.cos(a) : 0; n.wy = go ? Math.sin(a) : 0; if (dist(n.x, n.y, n.hx, n.hy) > n.def.wander) { const dx = n.hx - n.x, dy = n.hy - n.y, l = Math.hypot(dx, dy); n.wx = dx / l; n.wy = dy / l; } }
  if (n.wx || n.wy) { if (moveEnt(n, n.wx * 0.9 * dt, n.wy * 0.9 * dt)) { n.moving = true; n.dir = n.wx < 0 ? -1 : 1; } else n.wt = 0; }
}
function talkTo(n) {
  const d = n.def;
  const r = d.comp ? compDialog(d.id) : d.talk();
  showNpcDialog(n, r);
}
function npcOptions(n, r) {
  const d = n.def, opts = questOpts(n.id).concat(r.opts || []);
  const shopId = d.shop || (d.comp && COMPS[d.id].shop);
  if (shopId && (!d.shopCond || d.shopCond()) && !(n.angry === G.day)) opts.push({t:'🛒 Handeln', f:() => { closeDialog(); openShop(shopId, n); return 'close'; }});
  if (d.smith) opts.push({t:'⚒️ Verbessern & Reparieren', f:() => { closeDialog(); openShop(shopId, n, 'smith'); return 'close'; }});
  const teaches = typeof d.teaches === 'function' ? d.teaches() : (d.teaches || []);
  for (const pr of teaches) if (!P.learned[pr]) {
    const price = PROFS[pr].price;
    opts.push({t:'📖 ' + PROFS[pr].name + ' lernen (' + price + ' Gold)', f:() => { if (P.gold < price) return {text:'„Komm wieder, wenn du ' + price + ' Gold hast.“'}; P.gold -= price; learnProf(pr); return {text:'„Pass gut auf…“ Nach einer Stunde Übung hast du den Dreh raus.'}; }});
  }
  if (!d.guard && !d.comp && d.id !== 'koenig' && !d.tmpNpc) opts.push({t:'👛 Bestehlen', f:() => pickpocket(n)});
  opts.push({t:'👋 Tschüss', f:() => 'close'});
  return opts;
}
function pickpocket(n) {
  if (n.picked === G.day) return {text:n.def.name + ' hat heute nichts mehr, was sich zu stehlen lohnt.'};
  n.picked = G.day;
  const lv = P.prof.diebstahl.lvl;
  const ch = clamp(0.2 + (P.learned.diebstahl ? 0.2 : 0) + lv * 0.05 + (isNight() ? 0.05 : 0), 0.1, 0.85);
  if (Math.random() < ch) {
    const g = rint(4, 20) * (n.def.rich || 1) * (1 + lv * 0.2);
    P.gold += Math.round(g); P.rep.karma -= 2; gainProf('diebstahl', 15);
    let extra = '';
    const shop = n.def.shop && SHOPS[n.def.shop];
    if (shop && chance(0.25)) { const it = pick(shop); if (addItem(it, 1, true)) extra = ' und ' + ITEMS[it].name; }
    return {text:'Unbemerkt erbeutest du ' + Math.round(g) + ' Gold' + extra + '.'};
  }
  gainProf('diebstahl', 4); n.angry = G.day;
  return caught(n.def.name + ' packt dein Handgelenk: „Dieb! Wache!“');
}
function caught(msg) {
  if (P.rep.diebe >= 30 && chance(0.35)) return {text:msg + '<br><br>Ein Wachmann eilt herbei – und zwinkert dir zu. „Krummfinger lässt grüßen.“ Er lässt dich laufen.'};
  const fine = Math.min(P.gold, 40 + P.lvl * 15);
  P.gold -= fine; P.rep.stadt -= 8; P.rep.karma -= 3;
  toast('🚨 Erwischt! ' + fine + ' Gold Strafe', 'warn');
  return {text:msg + '<br><br>Die Wache verhängt eine Strafe von ' + fine + ' Gold. Dein Ruf in der Stadt sinkt.'};
}

// ---------- Gefährten-Dialoge & Romantik ----------
function hearts(a) { const f = Math.round(a / 20); return '❤️'.repeat(f) + '🤍'.repeat(5 - f); }
function compDialog(id) {
  const c = COMPS[id], s = P.comp[id], inParty = P.party.includes(id);
  const line = s.aff >= 70 ? c.lines[2] : s.aff >= 35 ? c.lines[1] : c.lines[0];
  const text = '<b>' + c.title + '</b> ' + hearts(s.aff) + (s.lover ? ' 💞' : '') + '<br>' + (s.hired || inParty ? line : c.bio);
  const opts = [];
  const canJoin = !c.recruit || c.recruit();
  if (!inParty && canJoin) {
    if (s.hired || !c.cost) opts.push({t:'👥 „Komm mit mir!“', f:() => { if (P.party.length >= 4) return {text:'Deine Gruppe ist voll (max. 4 Gefährten).'}; s.hired = true; P.party.push(id); syncAllies(); refreshNpcs(); return {text:c.name + ' schließt sich dir an.'}; }});
    else opts.push({t:'💰 Anheuern (' + c.cost + ' Gold)', f:() => { if (P.gold < c.cost) return {text:'„' + c.cost + ' Gold. Nicht verhandelbar.“'}; if (P.party.length >= 4) return {text:'Deine Gruppe ist voll (max. 4 Gefährten).'}; P.gold -= c.cost; s.hired = true; P.party.push(id); syncAllies(); refreshNpcs(); return {text:c.name + ' schließt sich dir an.'}; }});
  }
  if (inParty) opts.push({t:'🚪 „Warte hier auf mich.“', f:() => { storeAllyHp(); P.party = P.party.filter(x => x !== id); syncAllies(); refreshNpcs(); return {text:c.name + ' kehrt nach Hause zurück (' + (REGION_INFO[regionAt(c.home[0], c.home[1])].name) + ').'}; }});
  opts.push({t:'💬 Plaudern', f:() => { if (s.talkDay !== G.day) { s.talkDay = G.day; s.aff = Math.min(100, s.aff + 3); } return {text:pick(c.lines.slice(0, s.aff >= 35 ? 3 : 1))}; }});
  opts.push({t:'😉 Flirten', f:() => {
    if (s.flirtDay === G.day) return {text:'„Für heute reicht’s mit dem Süßholz.“'};
    s.flirtDay = G.day;
    const ch = 0.35 + s.aff / 150 + (P.buffs.mut ? 0.15 : 0) + (P.rep.stadt > 30 ? 0.05 : 0);
    if (Math.random() < ch) { s.aff = Math.min(100, s.aff + 7); return {text:pick(FLIRT_OK).replace(/\{n\}/g, c.name)}; }
    s.aff = Math.max(0, s.aff - 2); return {text:pick(FLIRT_NO).replace(/\{n\}/g, c.name)};
  }});
  opts.push({t:'🎁 Geschenk geben', f:() => giftMenu(id)});
  if (s.aff >= 80 && !s.lover) opts.push({t:'❤️ Gefühle gestehen', f:() => { s.lover = true; toast('💞 Du bist jetzt mit ' + c.name + ' zusammen.', 'gold'); return {text:'„Ich dachte schon, du fragst nie.“ ' + c.name + ' zieht dich in eine lange, warme Umarmung.'}; }});
  if (s.lover) opts.push({t:'🌙 Die Nacht miteinander verbringen', f:() => {
    const r = regionAt(P.x, P.y);
    if (!['stadt', 'gosse', 'dorf'].includes(r)) return {text:'„Hier draußen? Lass uns lieber ein warmes Zimmer suchen – in einer Stadt oder einem Dorf.“'};
    if (!isNight()) return {text:'„Später… wenn es dunkel ist.“ ' + c.name + ' lächelt vielsagend.'};
    closeDialog();
    showScene('🕯️', 'Die Kerzen brennen langsam herunter. ' + c.name + ' und du verbringt die Nacht miteinander – lange Gespräche, leises Lachen und Nähe, die keine Worte braucht.<br><br>Am Morgen wachst du erholt auf.', () => { sleepUntilMorning(); P.buffs.verliebt = DAY_LEN; s.aff = Math.min(100, s.aff + 5); });
    return 'close';
  }});
  if (id === 'grimm' && P.f.krummFeind && !P.learned.schloss) opts.push({t:'🗝️ Schlösserknacken lernen (150 Gold)', f:() => { if (P.gold < 150) return {text:'„150. Ich bin kein Wohltäter.“'}; P.gold -= 150; learnProf('schloss'); return {text:'„Krummfinger war nicht der einzige, der das kann.“'}; }});
  return {text, opts};
}
function giftMenu(id) {
  const c = COMPS[id], s = P.comp[id];
  const items = [...new Set(P.inv.map(x => x.id))].filter(i => ITEMS[i].gift || c.likes.includes(i));
  if (!items.length) return {text:'Du hast nichts, was sich als Geschenk eignet (z. B. Blumen, Wein, Bücher, Ringe oder Dinge, die ' + c.name + ' mag).'};
  return {text:'Was möchtest du ' + c.name + ' schenken?', opts:items.map(i => ({t:ITEMS[i].icon + ' ' + ITEMS[i].name, f:() => {
    if (s.giftDay === G.day) return {text:'„Du hast mir heute schon etwas geschenkt. Spar dir was auf.“'};
    s.giftDay = G.day; removeItem(i, 1);
    let g = 4, tx = '„Danke.“';
    if (i === 'ring') { g = 25; tx = c.name + ' starrt den Ring lange an. „Ist das… ernst gemeint?“'; }
    else if (c.likes.includes(i)) { g = 12; tx = '„Woher wusstest du, dass ich das mag?“ ' + c.name + ' strahlt.'; }
    s.aff = Math.min(100, s.aff + g); return {text:tx + ' ' + hearts(s.aff)};
  }}))};
}
function sleepUntilMorning() {
  const target = DAY_LEN * (1 / 24);
  if (G.time > target) { G.time = target; G.day++; newDay(); } else G.time = target;
  const st = stats(); P.hp = st.maxHp; P.en = st.maxEn;
  saveGame(true);
}

// ---------- Interaktion & Abbauen ----------
function findInteract() {
  let best = null, bd = 1.7;
  for (const n of G.npcs) { const d = dist(P.x, P.y, n.x, n.y); if (d < bd) { bd = d; best = {k:'npc', n, label:'Sprechen', icon:'💬'}; } }
  if (best) return best;
  if (P.learned.zaehmen) for (const e of G.enemies) if (!e.dead && e.def.tame && dist(P.x, P.y, e.x, e.y) < 2.3 && (e.def.passive || e.hp < e.maxHp * 0.35)) return {k:'tame', e, label:'Zähmen', icon:'🐾'};
  const px = Math.floor(P.x), py = Math.floor(P.y);
  let bt = null; bd = 1.5;
  for (let y = py - 1; y <= py + 1; y++) for (let x = px - 1; x <= px + 1; x++) {
    if (!inb(x, y)) continue; const t = WT[idx(x, y)];
    if (!HARVEST[t] && t !== TL.CHEST) continue;
    const d = dist(P.x, P.y - 0.2, x + 0.5, y + 0.5); if (d < bd) { bd = d; bt = {x, y, t}; }
  }
  if (bt) {
    if (bt.t === TL.CHEST) return {k:'chest', x:bt.x, y:bt.y, label:'Öffnen', icon:'🧰'};
    return {k:'tile', x:bt.x, y:bt.y, t:bt.t, label:HARVEST[bt.t].verb, icon:HARVEST[bt.t].tool === 'axt' ? '🪓' : HARVEST[bt.t].tool ? '⛏️' : '🌿'};
  }
  return null;
}
function doAction() {
  if (P.dead) return;
  const it = G.inter; if (!it) return;
  if (it.k === 'npc') talkTo(it.n);
  else if (it.k === 'tame') tryTame(it.e);
  else if (it.k === 'chest') openChest(idx(it.x, it.y));
  else if (it.k === 'tile') {
    const h = HARVEST[it.t];
    if (h.tool && !countItem(h.tool)) { toast('Du brauchst eine ' + ITEMS[h.tool].name + '.'); return; }
    if (P.prof[h.prof].lvl < h.lvl) { toast(PROFS[h.prof].name + ' Stufe ' + h.lvl + ' nötig.'); return; }
    if (P.mounted) { toast('Erst absitzen.'); return; }
    P.work = {x:it.x, y:it.y, t:0, dur:h.time * (1 - P.prof[h.prof].lvl * 0.04)};
    P.dir = it.x + 0.5 < P.x ? -1 : 1;
  }
}
function finishWork() {
  const w = P.work; P.work = null;
  const i = idx(w.x, w.y), t = WT[i], h = HARVEST[t]; if (!h) return;
  const n = rint(h.n[0], h.n[1]) + Math.floor(P.prof[h.prof].lvl / 4);
  if (!addItem(h.item, n)) return;
  floatText(w.x + 0.5, w.y, '+' + n + ' ' + ITEMS[h.item].icon, '#fff');
  if (t !== TL.ROCK && h.tool === 'spitzhacke' && chance(0.5)) addItem('stein', 1, true);
  gainProf(h.prof, 6 + h.lvl * 2);
  burst(w.x + 0.5, w.y + 0.3, t === TL.TREE || t === TL.PINE ? '#5a3' : '#999', 8);
  WT[i] = WG[i]; G.mods[i] = {t:WT[i], r:G.day + h.regrow};
}
function openChest(i) {
  const def = G.chests[i];
  if (!def) { WT[i] = WG[i]; return; }
  const loot = () => {
    let msg = [];
    if (def.gold) { const g = Math.round(def.gold * rnd(0.8, 1.2)); P.gold += g; msg.push(g + ' Gold'); }
    for (const l of def.loot) if (addItem(l[0], l[1], true)) msg.push(l[1] + '× ' + ITEMS[l[0]].name);
    if (def.owner === 'baldur' && stepIs('krumm', 'branch') && !countItem('rechnungsbuch')) { addItem('rechnungsbuch', 1, true); msg.push('📒 Rechnungsbuch'); P.f.buchWeg = true; }
    toast('🧰 Gefunden: ' + (msg.join(', ') || 'nichts'), 'gold');
    gainProf('schloss', 10 + def.lock * 10);
    WT[i] = WG[i];
    G.mods[i] = {t:WT[i], r:def.refill ? G.day + 1 : -1};
    if (G.dynChests[i]) delete G.dynChests[i];
    const r = regionAt(P.x, P.y);
    if (def.owner || r === 'stadt' || r === 'dorf') {
      const seen = G.npcs.some(n => !n.def.comp && dist(n.x, n.y, P.x, P.y) < 7);
      if (seen && Math.random() < 0.55 - P.prof.schloss.lvl * 0.04) { const res = caught('„Halt! Was machst du da an fremden Truhen?!“'); showDialog('Stadtwache', res.text, [{t:'Weiter'}]); }
    }
  };
  if (!def.lock) { loot(); return; }
  if (!countItem('dietrich')) { toast('Verschlossen (Schloss Stufe ' + def.lock + '). Du brauchst einen Dietrich.'); return; }
  startLockpick(def.lock, ok => { if (ok) loot(); });
}

// ---------- Herstellen ----------
function nearTile(t, r) { const px = Math.floor(P.x), py = Math.floor(P.y); for (let y = py - 2; y <= py + 2; y++) for (let x = px - 2; x <= px + 2; x++) if (inb(x, y) && WT[idx(x, y)] === t && dist(P.x, P.y, x + 0.5, y + 0.5) < r) return true; return false; }
function hasStation(st) {
  if (!st) return true;
  if (st === 'amboss') return nearTile(TL.ANVIL, 2.6) || (P.furn.includes('amboss') && inHome());
  if (st === 'feuer') return nearTile(TL.HEARTH, 2.6) || countItem('kochset') > 0 || (P.furn.includes('herd') && inHome());
  return false;
}
function canCraft(r) {
  if (r.lvl >= 1 && !P.learned[r.prof]) return false;
  if (P.prof[r.prof].lvl < r.lvl) return false;
  if (!hasStation(r.st)) return false;
  for (const k in r.req) if (countItem(k) < r.req[k]) return false;
  return true;
}
function craft(r) {
  if (!canCraft(r)) return;
  for (const k in r.req) removeItem(k, r.req[k]);
  if (!addItem(r.out, r.n || 1)) { for (const k in r.req) addItem(k, r.req[k], true); return; }
  gainProf(r.prof, 10 + r.lvl * 6);
  toast('🔨 Hergestellt: ' + ITEMS[r.out].name);
}
function upgradeCost(s, self) {
  const nu = (s.up || 0) + 1;
  const mats = [null, {eisenbarren:1}, {eisenbarren:2, silberbarren:1}, {eisenbarren:3, silberbarren:2}, {mithrilbarren:2, kristall:1}, {mithrilbarren:3, kristall:2}][nu];
  return {nu, mats, gold:self ? 0 : Math.ceil(ITEMS[s.id].val * 0.4 * nu + 20 * nu)};
}
function doUpgrade(s, self) {
  const c = upgradeCost(s, self);
  if (c.nu > (self ? 5 : 3)) return;
  if (self && (P.prof.schmieden.lvl < c.nu * 2 || !hasStation('amboss') || !P.learned.schmieden)) return;
  if (P.gold < c.gold) { toast('Nicht genug Gold.'); return; }
  for (const k in c.mats) if (countItem(k) < c.mats[k]) { toast('Material fehlt: ' + ITEMS[k].name); return; }
  for (const k in c.mats) removeItem(k, c.mats[k]);
  P.gold -= c.gold; s.up = c.nu; s.dur = 100;
  if (self) gainProf('schmieden', 30 * c.nu);
  toast('⚒️ ' + ITEMS[s.id].name + ' +' + s.up + '!', 'gold');
}
function repairCost(s) { return Math.ceil((100 - s.dur) / 100 * ITEMS[s.id].val * 0.3) + 3; }
function doRepair(s, self) {
  if (self) { if (!countItem('eisenbarren')) { toast('Du brauchst einen Eisenbarren.'); return; } removeItem('eisenbarren', 1); gainProf('schmieden', 8); }
  else { const c = repairCost(s); if (P.gold < c) { toast('Nicht genug Gold.'); return; } P.gold -= c; }
  s.dur = 100; toast('🔧 Repariert: ' + ITEMS[s.id].name);
}

// ---------- Handel ----------
function priceMod() { return (P.race === 'mensch' ? 0.1 : 0) + clamp(P.rep.stadt, 0, 100) * 0.002; }
function buyPrice(id) { return Math.max(1, Math.ceil(ITEMS[id].val * (1.15 - priceMod()))); }
function sellPrice(s, fence) { const it = ITEMS[s.id]; if (it.type === 'quest') return 0; let v = it.val * (1 + 0.3 * (s.up || 0)); if (s.dur != null && s.dur < 50) v *= 0.6; return Math.max(1, Math.floor(v * ((fence ? 0.55 : 0.35) + priceMod() * 0.5))); }

// ---------- Besitz, Betriebe, Gilde ----------
function bizIncome(id) { const b = BUSINESSES[id], l = P.biz[id].lvl; return Math.round(b.income * (1 + 0.5 * (l - 1))); }
function buyHouse(id) { const h = HOUSES[id]; if (P.houses.includes(id) || P.gold < h.cost) return; P.gold -= h.cost; P.houses.push(id); toast('🏠 Gekauft: ' + h.name, 'gold'); if (!P.furn.includes('bett')) { P.furn.push('bett'); toast('Ein Bett ist schon drin.'); } }
function furnSlots() { let s = 0; for (const h of P.houses) s = Math.max(s, HOUSES[h].slots); return s; }
function buyFurn(id) { const f = FURNITURE[id]; if (P.furn.includes(id) || P.gold < f.cost || P.furn.length >= furnSlots()) return; P.gold -= f.cost; P.furn.push(id); toast(f.icon + ' ' + f.name + ' eingerichtet.'); }
function buyBiz(id) { const b = BUSINESSES[id]; if (P.biz[id] || P.gold < b.cost) return; P.gold -= b.cost; P.biz[id] = {lvl:1, total:0}; toast(b.icon + ' Dir gehört jetzt: ' + b.name, 'gold'); P.rep.stadt += 3; }
function upgradeBiz(id) { const b = BUSINESSES[id], s = P.biz[id]; if (!s || s.lvl >= 5) return; const c = b.upCost * s.lvl; if (P.gold < c) return; P.gold -= c; s.lvl++; toast(b.icon + ' Ausgebaut auf Stufe ' + s.lvl); }
function foundGuild(name) { if (P.guild || P.gold < 3000 || !questDone('goblins')) return; P.gold -= 3000; P.guild = {name:name || 'Gilde der Gosse', lvl:1, members:0}; toast('🛡️ Gilde gegründet: ' + P.guild.name, 'gold'); P.rep.stadt += 10; }
function guildMax() { return P.guild ? P.guild.lvl * 4 : 0; }
function recruitMember() { if (!P.guild || P.guild.members >= guildMax() || P.gold < 150) return; P.gold -= 150; P.guild.members++; toast('🛡️ Neues Gildenmitglied angeworben.'); }
function upgradeGuild() { if (!P.guild || P.guild.lvl >= 5) return; const c = 2500 * P.guild.lvl; if (P.gold < c) return; P.gold -= c; P.guild.lvl++; toast('🛡️ Gilde auf Stufe ' + P.guild.lvl + '! +5 % Erfahrung', 'gold'); }

// ---------- Tageswechsel & Ereignisse ----------
function newDay() {
  for (const k in G.mods) { const m = G.mods[k]; if (m.r >= 0 && m.r <= G.day) { WT[k] = WT0[k]; delete G.mods[k]; } }
  G.tmp = G.tmp.filter(t => t.expires > G.day);
  let inc = 0; const notes = [];
  for (const id in P.biz) { let v = bizIncome(id); if (chance(0.12)) { const good = chance(0.5); const d = Math.round(v * rnd(0.5, 1)); v += good ? d : -d; notes.push(BUSINESSES[id].icon + (good ? ' Glückstag! ' : ' Ärger (Schlägerei, Diebstahl…) ') + (good ? '+' : '-') + d); } P.biz[id].total += v; inc += v; }
  if (P.guild && P.guild.members) { const g = P.guild.members * 12 * P.guild.lvl; inc += g; for (let k = 0; k < Math.floor(P.guild.members / 2); k++) addItem(pick(['eisenerz', 'fell', 'kraut', 'leder', 'holz', 'kristall']), 1, true); }
  if (inc) { P.gold += inc; toast('🌅 Tag ' + G.day + ': Einnahmen ' + (inc > 0 ? '+' : '') + inc + ' Gold', 'gold'); notes.forEach(n => toast(n)); }
  else toast('🌅 Tag ' + G.day + ' bricht an.');
  for (const k in P.buffs) if (k === 'verliebt') {} // läuft eigenständig ab
  refreshNpcs();
}
function freeSpot(rmin, rmax) {
  for (let k = 0; k < 30; k++) { const a = Math.random() * TAU, r = rnd(rmin, rmax), x = Math.floor(P.x + Math.cos(a) * r), y = Math.floor(P.y + Math.sin(a) * r); if (inb(x, y) && !BLOCK[WT[idx(x, y)]] && !REGION_INFO[regionAt(x, y)].safe) return [x, y]; }
  return null;
}
const EVENTS = [
  {w:2, fn() {
    const s = freeSpot(4, 7); if (!s) return;
    G.tmp.push({id:'zeb', name:'Fahrender Händler Zeb', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, shop:'zeb', look:{skin:'#c89070', hair:'#e8e8e8', outfit:'#8a3a8a', beard:true},
      talk() { return {text:'„Seltene Ware aus fernen Ländern! Nur heute, nur hier, nur für dich!“'}; }});
    refreshNpcs(); toast('🐴 Ein fahrender Händler hat in der Nähe sein Lager aufgeschlagen!', 'quest'); }},
  {w:3, fn() {
    const type = P.lvl >= 12 ? 'soldat' : P.lvl >= 9 ? 'troll' : 'bandit';
    const n = type === 'troll' ? 2 : rint(3, 4);
    for (let k = 0; k < n; k++) { const s = freeSpot(5, 8); if (s) spawnEnemy(k === 0 && type === 'bandit' ? 'bandit_bogen' : type, s[0] + 0.5, s[1] + 0.5, {aggro:true}); }
    toast('⚠️ Hinterhalt!', 'warn'); }},
  {w:2, fn() {
    const s = freeSpot(5, 9); if (!s) return; const i = idx(s[0], s[1]);
    const pool = [['heiltrank',2],['grheiltrank',1],['kristall',2],['silberbarren',2],['dietrich',3],['wein',1],['ring',1],['buch',1],['leder',4],['mithrilerz',2]];
    const def = {lock:rint(1, 3), gold:rint(20, 60) * Math.max(1, P.lvl / 3), loot:[pick(pool), pick(pool)]};
    WT[i] = TL.CHEST; G.chests[i] = def; G.dynChests[i] = def; G.mods[i] = {t:TL.CHEST, r:-1};
    toast('✨ Etwas glitzert im Gras… eine versteckte Truhe!', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(6, 10); if (!s) return;
    for (let k = 0; k < 5; k++) { const x = s[0] + rint(-1, 1), y = s[1] + rint(-1, 1); if (!inb(x, y) || BLOCK[WT[idx(x, y)]]) continue; const i = idx(x, y); WT[i] = chance(0.5) ? TL.MITHRIL : TL.CRYSTAL; G.mods[i] = {t:WT[i], r:-1}; }
    G.shake = 0.5; burst(s[0], s[1], '#fc6', 30);
    toast('☄️ Eine Sternschnuppe schlägt in der Nähe ein! Im Krater glitzern seltene Erze.', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(3, 6); if (!s) return; const rd = pick(RIDDLES);
    G.tmp.push({id:'fremder', name:'Verhüllter Fremder', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#b8a090', hair:'#2a2a3a', outfit:'#2a2a3a', helm:true},
      talk() {
        if (this.done) return {text:'Der Fremde ist nur noch ein Schatten im Nebel.'};
        return {text:'„Beantworte mein Rätsel, und ich belohne dich.“<br><br>' + rd.q, opts:rd.a.map((a, k) => ({t:a, f:() => {
          this.done = true; G.tmp = G.tmp.filter(t => t.id !== 'fremder'); setTimeout(refreshNpcs, 50);
          if (k === rd.c) { if (chance(0.5)) { P.skillPts++; return {text:'„Klug.“ Er berührt deine Stirn – du fühlst neues Wissen. (+1 Fähigkeitspunkt)'}; } P.attrPts += 2; return {text:'„Richtig.“ Wärme durchströmt dich. (+2 Attributpunkte)'}; }
          const l = Math.min(P.gold, 25); P.gold -= l; return {text:'„Falsch.“ Er lacht – und mit ihm verschwinden ' + l + ' Gold aus deinem Beutel.'};
        }}))};
      }});
    refreshNpcs(); toast('🌫️ Eine verhüllte Gestalt beobachtet dich…', 'quest'); }},
  {w:1, fn() { const s = freeSpot(9, 13); if (!s) return; spawnEnemy('goldhirsch', s[0] + 0.5, s[1] + 0.5); toast('🦌 Ein goldener Schimmer zwischen den Bäumen…', 'quest'); }},
  {w:1, fn() {
    const s = freeSpot(3, 6); if (!s) return;
    G.tmp.push({id:'reisender', name:'Verletzter Reisender', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e0b090', hair:'#6a4a2a', outfit:'#6a6a4a'},
      talk() {
        if (this.done) return {text:'„Danke nochmal, Fremder!“'};
        return {text:'„Bitte… Banditen… hast du einen Heiltrank?“', opts:[
          {t:'🧪 Heiltrank geben', f:() => { if (!countItem('heiltrank')) return {text:'Du hast keinen Heiltrank.'}; removeItem('heiltrank', 1); this.done = true; P.rep.karma += 5; const g = rint(60, 150); P.gold += g; return {text:'Er trinkt gierig. „Du hast mir das Leben gerettet! Nimm das – ' + g + ' Gold. Ich bin Kaufmann, ich zahle meine Schulden.“'}; }},
          {t:'Weitergehen', f:() => { P.rep.karma -= 2; this.done = true; return 'close'; }}]};
      }});
    refreshNpcs(); toast('🆘 Jemand ruft um Hilfe!', 'quest'); }}
];
function randomEvent() { const e = wpick(EVENTS.map(x => [x, x.w])); e.fn(); }

// ---------- Speichern ----------
const TRANSIENT = new Set(['work', 'dash', 'swing', 'spin', 'hitT', 'dead', 'moving']);
function packBits(a) { let s = ''; for (let i = 0; i < a.length; i += 8) { let b = 0; for (let k = 0; k < 8; k++) if (a[i + k]) b |= 1 << k; s += String.fromCharCode(b); } return btoa(s); }
function unpackBits(str, n) { const s = atob(str), a = new Uint8Array(n); for (let i = 0; i < s.length; i++) { const b = s.charCodeAt(i); for (let k = 0; k < 8; k++) if (b & (1 << k)) a[i * 8 + k] = 1; } return a; }
function saveGame(silent) {
  if (!P || P.dead) return;
  storeAllyHp();
  const data = {v:1, seed:G.seed, day:G.day, time:G.time, mods:G.mods, dyn:G.dynChests, ex:packBits(G.explored), P:JSON.parse(JSON.stringify(P, (k, v) => TRANSIENT.has(k) ? undefined : v))};
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(data)); if (!silent) toast('💾 Gespeichert'); } catch (e) { toast('Speichern fehlgeschlagen'); }
}
function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
function loadGame() {
  const data = JSON.parse(localStorage.getItem(SAVE_KEY));
  G.seed = data.seed; genWorld(G.seed);
  G.day = data.day; G.time = data.time; G.mods = data.mods || {};
  for (const k in G.mods) WT[k] = G.mods[k].t;
  G.dynChests = data.dyn || {}; for (const k in G.dynChests) G.chests[k] = G.dynChests[k];
  G.explored = unpackBits(data.ex, MW * MH);
  P = data.P; P.atkCd = 0; P.invuln = 0; P.lastHit = -99;
  for (const k in PROFS) if (!P.prof[k]) { P.prof[k] = {lvl:0, xp:0}; P.learned[k] = !PROFS[k].learn; }
  startWorld();
}
function startNewGame(cfg) {
  G.seed = 1337; genWorld(G.seed); G.mods = {}; G.dynChests = {}; G.day = 1; G.time = 60;
  G.explored = new Uint8Array(MW * MH);
  newPlayer(cfg);
  startWorld();
  showStory('Das Rattenviertel', 'Kalter Regen tropft durch das Dach. Du wachst auf einem Strohsack auf – im Rattenviertel von Aldenmark, wo die Armen, die Diebe und die Vergessenen hausen.<br><br>Mutter Hilde hat dich als Kind von der Straße geholt. Heute beginnt der Tag, an dem du mehr wirst als ein Kind der Gosse.<br><br><i>Sprich mit Mutter Hilde (mit dem <b>!</b> über dem Kopf).</i>');
}
function startWorld() {
  G.enemies = []; G.proj = []; G.drops = []; G.fx = []; G.texts = []; G.npcMap = {}; G.tmp = []; G.allies = [];
  refreshPlayerSprite(); buildMapCanvas(); syncAllies(); refreshNpcs();
  G.region = regionAt(P.x, P.y); G.running = true; G.paused = false;
  showGameUI();
}
