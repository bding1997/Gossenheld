'use strict';
// ================= BESITZ: NEUSTADT, BETRIEBE MIT PERSONAL, GILDENHALLE & GILDENMISSIONEN =================
// Gekaufte Betriebe und die Gildenhalle stehen als echte Gebäude in der Neustadt nördlich von Aldenmark.
// Sie wachsen mit jeder Ausbaustufe, bekommen Personal, Erweiterungen und Gäste – und die Neustadt wächst mit.

// ---------- Kacheln ----------
Object.assign(TL, {LOTSIGN:57, GBOARD:58});
BLOCK[57] = 1; PSOLID[57] = 1; BLOCK[58] = 1; PSOLID[58] = 1;
TILE_COLORS[57] = '#a07040'; TILE_COLORS[58] = '#8a5a2a';
ACT_TILES[TL.LOTSIGN] = ['lot', 'Bauplatz', '🪧'];
ACT_TILES[TL.GBOARD] = ['gboard', 'Missionen', '📜'];
const _drawTileEast = drawTile;
drawTile = function (t, v) {
  if (t === TL.GBOARD) {
    const c = _drawTileEast(TL.BOARD, v), x = c.getContext('2d');
    x.fillStyle = '#2a4a8a'; x.fillRect(6, 3, 4, 5); x.fillStyle = '#e8c040'; x.fillRect(7, 4, 2, 2); x.fillRect(6, 8, 1, 1); x.fillRect(9, 8, 1, 1);
    return c;
  }
  if (t !== TL.LOTSIGN) return _drawTileEast(t, v);
  const c = mkCanvas(16, 16), x = c.getContext('2d'), R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  speck(x, 16, 16, '#5b9b3d', ['#68ad47', '#4f8c35'], 0.25, 57);
  R(7, 8, 2, 8, '#5a3a1a'); R(2, 2, 12, 7, '#a07040'); R(2, 2, 12, 1, '#c8945a'); R(2, 8, 12, 1, '#6a4422');
  R(4, 4, 8, 1, '#3a2410'); R(4, 6, 5, 1, '#3a2410'); R(11, 5, 2, 2, '#c83a3a');
  addOutline(c, '#1a140e'); return c;
};

// ---------- Neustadt ----------
RIDX.neustadt = REGIONS.length; REGIONS.push('neustadt');
REGION_INFO.neustadt = {name:'Neustadt von Aldenmark', c:[134, 128], safe:true};
SOUTH_SAFE.push([134, 138, 28]);
const NS = {x0:110, x1:158, y0:125, y1:150};
const LOTS = {
  taverne:{door:[118, 136], v:0, max:[8, 5]}, werkstatt:{door:[130, 136], v:1, max:[8, 5]},
  freudenhaus:{door:[118, 146], v:3, max:[8, 5]}, kontor:{door:[130, 146], v:2, max:[8, 5]},
  bank:{door:[150, 136], v:0, max:[8, 5]}, gilde:{door:[150, 146], v:1, max:[10, 6]}
};
const LOT_SIZE = [[5, 3], [6, 3], [6, 4], [7, 4], [8, 5]], GUILD_SIZE = [[6, 4], [7, 4], [8, 5], [9, 5], [10, 6]];
function neustadtGen() {
  for (let y = NS.y0; y <= NS.y1; y++) for (let x = NS.x0; x <= NS.x1; x++) {
    if (!inb(x, y)) continue; const i = idx(x, y);
    if (WG[i] === TL.WATER || [TL.WALL, TL.FLOOR, TL.ROOF, TL.DOOR].includes(WT[i])) continue;
    WR[i] = RIDX.neustadt;
    if (WT[i] !== TL.PATH && WG[i] !== TL.PATH) { WG[i] = WT[i] = TL.GRASS; }
  }
  for (let x = NS.x0 + 2; x <= NS.x1 - 2; x++) for (const y of [137, 138, 147, 148]) if (WG[idx(x, y)] !== TL.WATER) { WG[idx(x, y)] = WT[idx(x, y)] = TL.PATH; }
  for (let y = 130; y <= 148; y++) { WG[idx(124, y)] = WT[idx(124, y)] = TL.PATH; WG[idx(144, y)] = WT[idx(144, y)] = TL.PATH; }
  for (let y = 139; y <= 150; y++) for (const x of [138, 139, 140]) { WG[idx(x, y)] = WT[idx(x, y)] = TL.PATH; }
}
const _worldExtrasEast = worldExtras;
worldExtras = function () { _worldExtrasEast(); neustadtGen(); };
// Wächst mit dir: Stufen der Neustadt
const TOWN_STAGES = [
  {min:0, name:'Brachland', txt:'Ein paar Bauplätze vor dem Nordtor.'},
  {min:2, name:'Siedlung', txt:'Die ersten Häuser stehen. Ein Brunnen wird gegraben.'},
  {min:6, name:'Neustadt', txt:'Händler bauen Marktstände auf. Bürger ziehen her.'},
  {min:11, name:'Marktviertel', txt:'Ein belebter Markt. Die Leute reden über dich.'},
  {min:17, name:'Handelsstadt', txt:'Ein Springbrunnen, Gärten, Musik auf den Straßen.'},
  {min:24, name:'Prachtviertel', txt:'Das schönste Viertel von Aldenmark – und es trägt deinen Namen.'}
];
function townScore() {
  if (!P) return 0;
  let s = 0;
  for (const id in P.biz) { const b = P.biz[id]; s += b.lvl + Object.keys(b.staff || {}).length * 0.5 + Object.keys(b.ext || {}).length; }
  if (P.guild) s += P.guild.lvl * 2 + Object.keys(P.guild.staff || {}).length * 0.5;
  return s;
}
function townStage() { const s = townScore(); let k = 0; TOWN_STAGES.forEach((t, i) => { if (s >= t.min) k = i; }); return k; }
const TOWN_DECOR = [
  {s:1, t:TL.WATER, at:[[143, 140]]}, {s:1, t:TL.FLOWER, at:[[123, 139], [125, 139], [143, 139], [145, 139], [112, 139], [136, 139]]},
  {s:2, tent:[112, 128, 3, 2, '#c83a3a'], }, {s:2, tent:[133, 128, 3, 2, '#3a8a5a']}, {s:2, t:TL.BARREL, at:[[115, 130], [136, 130]]},
  {s:3, tent:[146, 127, 3, 2, '#3a5a9a']}, {s:3, tent:[152, 127, 3, 2, '#e8c040']}, {s:3, t:TL.TROPHY, at:[[143, 131]]}, {s:3, t:TL.HEARTH, at:[[143, 134]]},
  {s:4, t:TL.WATER, at:[[127, 139], [128, 139]]}, {s:4, t:TL.FLOWER, at:[[126, 140], [129, 140], [112, 149], [156, 149], [156, 139]]}, {s:4, t:TL.TREE, at:[[111, 132], [111, 144], [157, 132]]},
  {s:5, tent:[118, 127, 4, 2, '#8a2a6a', {flag:'#e8c040'}]}, {s:5, t:TL.TROPHY, at:[[121, 139], [147, 139]]}, {s:5, t:TL.FLOWER, at:[[115, 139], [133, 139], [151, 139], [155, 128]]}
];

// ---------- Betriebe: Personal & Erweiterungen ----------
const STAFF = {
  taverne:{wirt:{name:'Wirt Gustav', icon:'🍺', bonus:0.25, cost:200, wage:12, lvl:1, txt:'Zapft, rechnet, wirft Raufbolde raus.'}, kellnerin:{name:'Kellnerin Lotte', icon:'🍽️', bonus:0.2, cost:150, wage:8, lvl:2, txt:'Schneller als jeder Durst.'},
    koch:{name:'Koch Bruno', icon:'🍲', bonus:0.25, cost:250, wage:12, lvl:3, txt:'Sein Eintopf ist stadtbekannt.'}, barde:{name:'Bardin Melisande', icon:'🎶', bonus:0.15, cost:300, wage:15, lvl:4, rep:0.3, txt:'Singt Lieder über deine Heldentaten. Bringt Ansehen.'}},
  werkstatt:{geselle:{name:'Geselle Jörg', icon:'🔨', bonus:0.25, cost:200, wage:12, lvl:1, txt:'Fleißig und kaum betrunken.'}, lehrling:{name:'Lehrling Fritzi', icon:'🧒', bonus:0.15, cost:100, wage:5, lvl:2, txt:'Lernt schnell, verliert oft Nägel.'},
    meisterin:{name:'Meisterin Brunhilde', icon:'⚒️', bonus:0.3, cost:400, wage:18, lvl:3, txt:'Repariert alles, was ein Ende hat.'}, haendler:{name:'Händler Kuno', icon:'💬', bonus:0.2, cost:250, wage:10, lvl:4, txt:'Verkauft die Waren bis nach Eichenrast.'}},
  freudenhaus:{gastgeberin:{name:'Madame Rosalind', icon:'🌹', bonus:0.3, cost:350, wage:16, lvl:1, txt:'Elegant, diskret, unbezahlbar.'}, tuersteher:{name:'Türsteher Grob', icon:'💪', bonus:0.1, cost:200, wage:10, lvl:2, guard:true, txt:'Verhindert Ärger – keine schlechten Tage mehr.'},
    musikerin:{name:'Lautenspielerin Ivy', icon:'🎻', bonus:0.2, cost:250, wage:12, lvl:3, txt:'Ihre Musik füllt jeden Abend die Säle.'}, koechin:{name:'Köchin Odette', icon:'🍷', bonus:0.15, cost:200, wage:10, lvl:4, txt:'Feine Häppchen und schwerer Wein.'}},
  kontor:{schreiber:{name:'Schreiber Albrecht', icon:'✒️', bonus:0.2, cost:250, wage:12, lvl:1, txt:'Führt die Bücher. Fast immer korrekt.'}, haendlerin:{name:'Händlerin Yara', icon:'⚖️', bonus:0.25, cost:350, wage:15, lvl:2, txt:'Feilscht, bis der Gegner weint.'},
    kapitaenin:{name:'Kapitänin Salvia', icon:'⚓', bonus:0.35, cost:600, wage:25, lvl:3, txt:'Bringt Waren über das Meer – von Möwenhafen bis Qarim.'}, wache:{name:'Wächter Holger', icon:'🛡️', bonus:0.1, cost:200, wage:10, lvl:4, guard:true, txt:'Bewacht das Lager. Keine Diebstähle mehr.'}},
  bank:{kassierer:{name:'Kassierer Emmerich', icon:'🪙', bonus:0.2, cost:300, wage:14, lvl:1, txt:'Zählt Münzen im Schlaf.'}, buchhalterin:{name:'Buchhalterin Agathe', icon:'📒', bonus:0.25, cost:400, wage:18, lvl:2, txt:'Findet jeden fehlenden Heller.'},
    tresorwache:{name:'Tresorwächter Bolko', icon:'🔒', bonus:0.1, cost:300, wage:14, lvl:3, guard:true, txt:'Keine Einbrüche, keine Verluste.'}, geldverleiher:{name:'Geldverleiher Silas', icon:'💰', bonus:0.35, cost:800, wage:30, lvl:4, txt:'Verleiht Geld zu Zinsen, die man lieber nicht ausspricht.'}}
};
const EXT = {
  taverne:{gaestezimmer:{name:'Gästezimmer', icon:'🛏️', cost:1500, bonus:0.25, lvl:2, txt:'Reisende übernachten bei dir. Du darfst hier auch schlafen.'}, weinkeller:{name:'Weinkeller', icon:'🍷', cost:1200, bonus:0.1, lvl:2, item:'wein', txt:'+10 % und jeden Morgen eine Flasche Wein.'}, buehne:{name:'Bühne', icon:'🎭', cost:1800, bonus:0.15, lvl:3, rep:0.3, txt:'Gaukler und Barden. Bringt Ansehen.'}},
  werkstatt:{amboss2:{name:'Zweiter Amboss', icon:'⚒️', cost:1400, bonus:0.2, lvl:2, txt:'Mehr Aufträge – und du kannst ihn selbst benutzen.'}, lager:{name:'Materiallager', icon:'📦', cost:1600, bonus:0.15, lvl:3, item:'eisenbarren', txt:'+15 % und jeden Morgen ein Eisenbarren.'}, ofen:{name:'Schmelzofen', icon:'🔥', cost:2200, bonus:0.2, lvl:4, item:'silberbarren', txt:'+20 % und jeden Morgen ein Silberbarren.'}},
  freudenhaus:{badehaus:{name:'Badehaus', icon:'🛁', cost:2000, bonus:0.25, lvl:2, txt:'Warmes Wasser, duftende Öle.'}, salon:{name:'Spielsalon', icon:'🎲', cost:1800, bonus:0.2, lvl:3, txt:'Karten, Würfel und gedämpfte Stimmen.'}, garten:{name:'Gartenpavillon', icon:'🌸', cost:1500, bonus:0.15, lvl:4, txt:'Laternen und Rosen.'}},
  kontor:{lagerhalle:{name:'Lagerhalle', icon:'🏚️', cost:2500, bonus:0.2, lvl:2, item:'rand', txt:'+20 % und jeden Morgen eine Handelsware.'}, schiff:{name:'Eigenes Handelsschiff', icon:'⛵', cost:5000, bonus:0.35, lvl:3, txt:'Fernhandel über das Meer.'}, gewuerz:{name:'Gewürzstand', icon:'🌶️', cost:1800, bonus:0.15, lvl:4, txt:'Pfeffer und Zimt aus Qarim.'}},
  bank:{tresor:{name:'Großer Tresor', icon:'🏦', cost:4000, bonus:0.2, lvl:2, txt:'Mehr Einlagen, mehr Zinsen.'}, wechselstube:{name:'Wechselstube', icon:'💱', cost:3000, bonus:0.15, lvl:3, txt:'Tauscht Münzen aus Morvath und Qarim.'}, filiale:{name:'Filiale in Möwenhafen', icon:'🏛️', cost:7000, bonus:0.35, lvl:5, txt:'Die Bank expandiert an die Küste.'}}
};
const RAND_GOODS = ['leder', 'kraut', 'eisenbarren', 'holz', 'perle', 'rum', 'dattel', 'kristall'];
// Innenräume: [x, y, Kachel, Bedingung (Zahl = Ausbaustufe, 'e:x' = Erweiterung)]
const LAYOUT = {
  taverne:{w:14, h:9, floor:TL.WOOD, items:[[1, 3, 'C', 1], [2, 3, 'C', 1], [3, 3, 'C', 1], [4, 3, 'C', 1], [1, 2, 'S', 1], [12, 2, 'H', 1], [6, 4, 'T', 1], [9, 4, 'T', 2], [6, 6, 'T', 3], [9, 6, 'T', 4], [11, 4, 'T', 5],
    [1, 6, 'B', 'e:weinkeller'], [2, 6, 'B', 'e:weinkeller'], [11, 6, 'K', 'e:buehne'], [12, 6, 'K', 'e:buehne'], [11, 7, 'K', 'e:buehne'], [12, 7, 'K', 'e:buehne'], [7, 2, 'Z', 'e:gaestezimmer'], [8, 2, 'Z', 'e:gaestezimmer'], [9, 2, 'Z', 'e:gaestezimmer']],
    staff:{wirt:[2.5, 2.6], kellnerin:[7.5, 5.6], koch:[11.5, 3.6], barde:[11.6, 6.6]}, guests:[[5.6, 4.6], [10.4, 4.6], [5.6, 6.6], [10.4, 6.6], [3.5, 5.6]]},
  werkstatt:{w:12, h:8, floor:TL.FLOOR, items:[[2, 3, 'A', 1], [1, 2, 'S', 1], [5, 3, 'T', 1], [10, 6, 'B', 2], [10, 2, 'S', 3], [8, 4, 'T', 4], [7, 2, 'S', 5], [2, 5, 'A', 'e:amboss2'], [8, 6, 'B', 'e:lager'], [9, 6, 'B', 'e:lager'], [4, 2, 'H', 'e:ofen']],
    staff:{geselle:[3.5, 3.6], lehrling:[5.5, 4.6], meisterin:[3.4, 5.6], haendler:[8.5, 5.4]}, guests:[[7.5, 3.6], [6.5, 5.6], [9.5, 4.6], [4.5, 5.9], [6.5, 2.8]]},
  freudenhaus:{w:12, h:8, floor:TL.WOOD, items:[[5, 4, 'K', 1], [6, 4, 'K', 1], [5, 5, 'K', 1], [6, 5, 'K', 1], [2, 3, 'T', 1], [10, 2, 'S', 2], [1, 2, 'S', 3], [9, 3, 'T', 4], [3, 2, 'X', 5],
    [8, 5, 'W', 'e:badehaus'], [9, 5, 'W', 'e:badehaus'], [8, 6, 'W', 'e:badehaus'], [9, 6, 'W', 'e:badehaus'], [10, 4, 'T', 'e:salon'], [1, 6, 'F', 'e:garten'], [10, 6, 'F', 'e:garten'], [2, 6, 'F', 'e:garten']],
    staff:{gastgeberin:[3.5, 3.6], tuersteher:[4.5, 6.3], musikerin:[9.5, 4.2], koechin:[1.5, 4.6]}, guests:[[5.5, 3.4], [7.5, 4.6], [2.5, 5.6], [7.5, 2.8], [3.6, 4.8]]},
  kontor:{w:12, h:8, floor:TL.WOOD, items:[[2, 3, 'C', 1], [3, 3, 'C', 1], [4, 3, 'C', 1], [5, 3, 'C', 1], [1, 2, 'S', 1], [10, 6, 'B', 2], [9, 6, 'B', 2], [10, 2, 'S', 3], [7, 4, 'T', 4], [10, 4, 'X', 5],
    [1, 6, 'B', 'e:lagerhalle'], [2, 6, 'B', 'e:lagerhalle'], [3, 6, 'B', 'e:lagerhalle'], [7, 2, 'X', 'e:schiff'], [8, 5, 'T', 'e:gewuerz']],
    staff:{schreiber:[3.5, 2.6], haendlerin:[6.5, 5.6], kapitaenin:[8.5, 3.6], wache:[10.5, 5.0]}, guests:[[4.5, 4.6], [7.5, 5.8], [2.5, 5.0], [9.5, 3.6], [5.5, 5.9]]},
  bank:{w:12, h:8, floor:TL.FLOOR, items:[[3, 3, 'C', 1], [4, 3, 'C', 1], [5, 3, 'C', 1], [6, 3, 'C', 1], [7, 3, 'C', 1], [8, 3, 'C', 1], [1, 2, 'S', 1], [10, 2, 'X', 2], [5, 5, 'K', 3], [6, 5, 'K', 3], [2, 5, 'T', 4], [1, 2, 'S', 5],
    [10, 4, 'S', 'e:tresor'], [10, 5, 'S', 'e:tresor'], [9, 6, 'T', 'e:wechselstube'], [2, 2, 'X', 'e:filiale']],
    staff:{kassierer:[4.5, 2.6], buchhalterin:[7.5, 2.6], tresorwache:[10.5, 6.2], geldverleiher:[2.5, 6.0]}, guests:[[4.5, 4.6], [7.5, 4.6], [5.5, 6.0], [8.5, 5.0], [3.5, 5.9]]}
};
const LT = {C:TL.COUNTER, S:TL.SHELF, H:TL.HEARTH, T:TL.TABLE, B:TL.BARREL, K:TL.CARPET, Z:TL.BED, A:TL.ANVIL, X:TL.TROPHY, W:TL.WATER, F:TL.FLOWER};
// Gildenhalle: 11 Zimmer (6 oben, 5 unten), Halle in der Mitte
const GUILD_ROOMS = [0, 1, 2, 3, 4, 5].map(k => ({x:1 + k * 4, y:2, top:true})).concat([0, 1, 2, 4, 5].map(k => ({x:1 + k * 4, y:10, top:false})));
const GUILD_ROOMS_BY_LVL = [4, 6, 8, 10, 11];
const GUILD_STAFF = {
  verwalterin:{name:'Verwalterin Henrike', icon:'📜', cost:400, wage:15, lvl:1, txt:'Treibt die Beiträge ein: +50 % Gildenbeiträge.'},
  ausbilder:{name:'Ausbilder Waldemar', icon:'🗡️', cost:600, wage:20, lvl:2, txt:'Drillt die Mitglieder: +50 % Erfahrung auf Missionen.'},
  spaeherin:{name:'Späherin Kira', icon:'🦅', cost:700, wage:20, lvl:3, txt:'Findet bessere Aufträge: +1 Mission, +6 % Erfolg.'},
  heilerin:{name:'Heilerin Fenja', icon:'💚', cost:500, wage:15, lvl:2, txt:'Verletzte Mitglieder sind doppelt so schnell wieder fit.'}
};
const GUILD_STAFF_POS = {verwalterin:[3.5, 7.6], ausbilder:[8.5, 7.6], spaeherin:[15.5, 6.8], heilerin:[21.5, 7.6]};
const GUILD_REP_NEED = [0, 25, 70, 150, 280];
function guildRooms() { return P.guild ? GUILD_ROOMS_BY_LVL[P.guild.lvl - 1] : 0; }

function estateInteriors() {
  for (const id in LAYOUT) { const L = LAYOUT[id]; makeInterior('e_' + id, BUSINESSES[id].name, L.w, L.h, [LOTS[id].door[0], LOTS[id].door[1], 1], L.floor); }
  makeInterior('e_gilde', 'Gildenhalle', 26, 14, [LOTS.gilde.door[0], LOTS.gilde.door[1], 1], TL.WOOD, o => {
    for (let x = 1; x <= 24; x++) { o(x, 5, TL.IWALL); o(x, 9, TL.IWALL); }
    for (const r of GUILD_ROOMS) if (r.x + 3 <= 24) for (let y = r.y; y < r.y + 3; y++) o(r.x + 3, y, TL.IWALL);
    for (let y = 10; y <= 12; y++) { o(12, y, TL.IWALL); o(16, y, TL.IWALL); }
    for (let x = 13; x <= 15; x++) o(x, 9, TL.WOOD);
    o(2, 6, TL.GBOARD); o(6, 6, TL.TROPHY); o(22, 6, TL.HEARTH); o(17, 7, TL.TABLE); o(19, 7, TL.TABLE); o(12, 7, TL.CARPET); o(13, 7, TL.CARPET); o(14, 7, TL.CARPET);
  });
}
const _southInteriorsEast = southInteriors;
southInteriors = function () { _southInteriorsEast(); estateInteriors(); };

// ---------- Spielstand-Erweiterung ----------
function estateLvl(id) { if (id === 'gilde') return P.guild ? P.guild.lvl : 0; return P.biz[id] ? P.biz[id].lvl : 0; }
const M_NAMES = {m:['Arno', 'Bertolt', 'Cedric', 'Dankwart', 'Eckbert', 'Falk', 'Gero', 'Hartmut', 'Ivo', 'Jost', 'Konrad', 'Lennart', 'Magnus', 'Nils', 'Ortwin', 'Rasmus', 'Sigurd', 'Tankred', 'Ulf', 'Volker', 'Wido'],
  w:['Adela', 'Brida', 'Clara', 'Dagny', 'Elske', 'Frida', 'Gesa', 'Hedwig', 'Ilka', 'Jorunn', 'Kunigunde', 'Linnea', 'Mechthild', 'Nele', 'Ottilie', 'Runa', 'Svea', 'Thea', 'Ute', 'Wiebke', 'Yrsa']};
const M_CLS = {kampf:{name:'Kämpfer', icon:'⚔️', aff:'kampf', style:'chain'}, jagd:{name:'Jäger', icon:'🏹', aff:'jagd', style:'leather'}, arkan:{name:'Magier', icon:'🔮', aff:'arkan', style:'robe'},
  hilfe:{name:'Heiler', icon:'✨', aff:'hilfe', style:'robe'}, schatten:{name:'Schurke', icon:'🗝️', aff:'schatten', style:'leather'}};
const COMP_AFF = {kampf:'kampf', bogen:'jagd', magie:'arkan', heil:'hilfe'};
function newMember() {
  const g = P.guild, fem = chance(0.5), cls = pick(Object.keys(M_CLS));
  const skins = ['#f0c8a8', '#e3b48f', '#d8a070', '#b8845a', '#8a5a3a'], hairs = ['#2a1a1a', '#5a3a1a', '#c8702a', '#e8d070', '#8a8a8a', '#1a1a2a', '#a03a1a'];
  const outfits = ['#3a5a8a', '#6a3a2a', '#3a6a3a', '#5a3a6a', '#7a6a3a', '#2a4a4a', '#8a2a2a'];
  const look = {skin:pick(skins), hair:pick(hairs), outfit:pick(outfits), female:fem, longHair:fem && chance(0.8), beard:!fem && chance(0.4), style:M_CLS[cls].style, trim:'#c8a040', helmCol:cls === 'kampf' && chance(0.5) ? '#8a8e9a' : undefined};
  return {id:'m' + (g.nextId++), name:pick(M_NAMES[fem ? 'w' : 'm']), cls, lvl:Math.max(1, g.lvl * 2 + rint(-1, 2)), xp:0, look, state:'home', until:0, missions:0};
}
function fixGuild(g) {
  if (!g) return;
  if (typeof g.members === 'number') { const n = g.members; g.members = []; g.nextId = 1; g.lvl = g.lvl || 1; for (let k = 0; k < Math.min(n, GUILD_ROOMS_BY_LVL[g.lvl - 1]); k++) g.members.push(null); }
  Object.assign(g, Object.assign({residents:[], rep:0, gold:0, staff:{}, board:{day:-1, list:[]}, active:[], nextId:1, done:0}, g));
  if (g.members.some(m => !m)) { const tmp = P.guild; P.guild = g; g.members = g.members.map(m => m || newMember()); P.guild = tmp; }
}
const _migrateEstate = migratePlayer;
migratePlayer = function (p) {
  const r = _migrateEstate(p);
  for (const id in p.biz) { p.biz[id].staff = p.biz[id].staff || {}; p.biz[id].ext = p.biz[id].ext || {}; }
  if (p.guild) { const tmp = P; P = p; fixGuild(p.guild); P = tmp; }
  G.estateDirty = true;
  return r;
};
const _genWorldEstate = genWorld;
genWorld = function (s) { const r = _genWorldEstate(s); G.estateDirty = true; return r; };

// ---------- Gebäude & Innenräume der Neustadt aufbauen ----------
function applyEstate() {
  if (!P || !INTERIORS.e_gilde || !P.biz) return;
  G.estateDirty = false;
  const touched = [], put = (x, y, t, g) => { if (!inb(x, y)) return; const i = idx(x, y); if (g != null) WG[i] = g; WT[i] = t; WT0[i] = t; touched.push(i); };
  for (let k = BUILDINGS.length - 1; k >= 0; k--) if (BUILDINGS[k].estate) BUILDINGS.splice(k, 1);
  const stage = townStage();
  // Bauplätze & Gebäude
  for (const id in LOTS) {
    const L = LOTS[id], [dx, dy] = L.door, [mw, mh] = L.max, lx0 = dx - (mw >> 1);
    for (let y = dy - mh + 1; y <= dy; y++) for (let x = lx0; x < lx0 + mw; x++) put(x, y, TL.GRASS, TL.GRASS);
    const lvl = estateLvl(id);
    if (lvl) {
      const [w, h] = (id === 'gilde' ? GUILD_SIZE : LOT_SIZE)[lvl - 1], x0 = dx - (w >> 1), y0 = dy - h + 1;
      building(x0, y0, w, h, L.v, (id === 'gilde' || id === 'bank') && lvl >= 4 ? TL.WALL : undefined);
      BUILDINGS[BUILDINGS.length - 1].estate = id;
      for (let y = y0; y <= dy; y++) for (let x = x0; x < x0 + w; x++) { const i = idx(x, y); WT0[i] = WT[i]; touched.push(i); }
    } else {
      put(dx, dy, TL.LOTSIGN);
      for (const [cx, cy] of [[lx0, dy - mh + 1], [lx0 + mw - 1, dy - mh + 1], [lx0, dy], [lx0 + mw - 1, dy]]) put(cx, cy, TL.FENCE);
    }
  }
  // Stadtschmuck je nach Stufe
  for (const d of TOWN_DECOR) {
    const on = stage >= d.s;
    if (d.tent) { const [x, y, w, h, col, ex] = d.tent; for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) put(xx, yy, TL.GRASS, TL.GRASS); if (on) { eastTent(x, y, w, h, col, Object.assign({estate:'deko'}, ex || {})); for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) WT0[idx(xx, yy)] = WT[idx(xx, yy)]; } }
    else for (const [x, y] of d.at) { if (d.t === TL.WATER) put(x, y, on ? TL.WATER : TL.GRASS, on ? TL.WATER : TL.GRASS); else put(x, y, on ? d.t : TL.GRASS, TL.GRASS); }
  }
  // Einrichtung der Betriebe
  for (const id in LAYOUT) {
    const I = INTERIORS['e_' + id], L = LAYOUT[id], b = P.biz[id];
    for (const [x, y, k, req] of L.items) {
      const ok = b && (typeof req === 'number' ? b.lvl >= req : b.ext[req.slice(2)]);
      put(I.x0 + x, I.y0 + y, ok ? LT[k] : L.floor, k === 'W' && ok ? TL.WATER : L.floor);
    }
  }
  // Zimmer der Gildenhalle
  { const I = INTERIORS.e_gilde, n = guildRooms();
    GUILD_ROOMS.forEach((r, k) => {
      const open = k < n, wy = r.top ? 5 : 9;
      for (let y = r.y; y < r.y + 3; y++) for (let x = r.x; x < r.x + 3; x++) put(I.x0 + x, I.y0 + y, open ? TL.WOOD : TL.IWALL, open ? TL.WOOD : TL.IWALL);
      put(I.x0 + r.x + 1, I.y0 + wy, open ? TL.WOOD : TL.IWALL, open ? TL.WOOD : TL.IWALL);
      if (open) { put(I.x0 + r.x, I.y0 + r.y + (r.top ? 0 : 2), TL.BED); put(I.x0 + r.x + 2, I.y0 + r.y + (r.top ? 0 : 2), k % 2 ? TL.SHELF : TL.TABLE); }
    }); }
  if (G.mapImg) { for (const i of touched) if (i < MW * WORLD_H && G.explored[i]) setMapPx(i); G.mapDirty = true; }
  for (const k in G.npcMap) if (/^(st_|gm_|gast_|bg_|gs_)/.test(k) || COMPS[k]) delete G.npcMap[k];
  if (G.stageSeen != null && stage > G.stageSeen) toast('🏘️ Die Neustadt wächst: ' + TOWN_STAGES[stage].name + '! ' + TOWN_STAGES[stage].txt, 'gold');
  G.stageSeen = stage; P.townStage = stage;
  refreshNpcs();
}

// ---------- Figuren: Personal, Gäste, Bürger, Gildenmitglieder ----------
const GUEST_LOOKS = [{skin:'#e8c0a0', hair:'#5a3a1a', outfit:'#4a6a8a', beard:true, style:'cloth'}, {skin:'#f0d0b8', hair:'#c8702a', outfit:'#8a3a5a', longHair:true, female:true, style:'cloth'},
  {skin:'#c8946a', hair:'#2a1a1a', outfit:'#5a5a3a', style:'leather'}, {skin:'#e3b48f', hair:'#e8d070', outfit:'#3a7a5a', longHair:true, female:true, style:'royal', trim:'#c8a040'},
  {skin:'#d8a070', hair:'#8a8a8a', outfit:'#6a4a2a', beard:true, bald:true, style:'cloth'}];
const GUEST_LINES = {
  taverne:['„Das Bier hier ist besser als im Goldenen Krug. Sag’s nicht weiter.“', '„Noch eine Runde! Auf den Besitzer!“', '„Hast du gehört? Der Besitzer soll aus der Gosse stammen. Respekt.“'],
  werkstatt:['„Mein Pflug ist wieder wie neu. Gute Arbeit hier.“', '„Ich warte auf mein Schwert. Seit drei Tagen. Aber es wird schön!“'],
  freudenhaus:['„Diskretion, mein Freund. Du hast mich nie gesehen.“', '„Die Musik heute Abend ist himmlisch.“'],
  kontor:['„Zimt aus Qarim, zum halben Preis! Unglaublich.“', '„Ich investiere in Salz. Salz geht immer.“'],
  bank:['„Mein Erspartes ist hier sicherer als unter der Matratze.“', '„Zinsen… so ein schönes Wort.“']
};
for (const id in STAFF) for (const role in STAFF[id]) {
  const s = STAFF[id][role], k = Object.keys(STAFF[id]).indexOf(role);
  NPC_DEFS.push({id:'st_' + id + '_' + role, name:s.name, at:['e_' + id].concat(LAYOUT[id].staff[role]), look:Object.assign({}, GUEST_LOOKS[(k * 2 + id.length) % 5], {outfit:['#7a2a2a', '#2a5a7a', '#5a7a2a', '#6a2a6a'][k]}),
    cond:() => P.biz[id] && P.biz[id].staff[role],
    talk() { const b = P.biz[id]; return {text:'„' + s.txt + '“<br><br>' + BUSINESSES[id].icon + ' Heute erwarteter Gewinn: <b>' + bizIncome(id) + ' Gold</b> · Stufe ' + b.lvl, opts:[{t:'📋 Betrieb verwalten', f:() => { closeDialog(); UI.focus = id; openPanel('estate', 'biz'); return 'close'; }}, {t:'Tschüss'}]}; }});
}
for (const id in LAYOUT) LAYOUT[id].guests.forEach((g, k) => NPC_DEFS.push({id:'gast_' + id + '_' + k, name:'Gast', at:['e_' + id, g[0], g[1]], look:GUEST_LOOKS[(k + id.length) % 5],
  cond:() => P.biz[id] && P.biz[id].lvl > k, talk() { return {text:pick(GUEST_LINES[id])}; }}));
const CITIZENS = [
  {s:1, name:'Bäuerin Trude', x:127.5, y:141.6, lines:['„Früher war hier nur Wiese. Jetzt gibt es sogar einen Brunnen!“']},
  {s:2, name:'Marktfrau Hanne', x:113.5, y:131.0, lines:['„Frische Rüben! Na gut, gestrige Rüben. Aber gute!“']},
  {s:2, name:'Zimmermann Edgar', x:135.5, y:141.6, lines:['„Ich baue hier von früh bis spät. Gutes Geld, ehrliche Arbeit.“']},
  {s:3, name:'Händler Ruprecht', x:148.5, y:130.0, lines:['„Die Neustadt ist der beste Markt im Reich. Und die Steuern sind niedrig!“']},
  {s:3, name:'Straßenkind Pip', x:141.5, y:142.6, wander:3, lines:['„Bist du der aus der Gosse, dem das alles gehört? Wenn ich groß bin, will ich so werden wie du!“']},
  {s:4, name:'Gärtnerin Elfriede', x:126.5, y:141.6, lines:['„Die Rosen am Brunnen habe ich gepflanzt. Hübsch, nicht?“']},
  {s:4, name:'Straßenmusiker Fips', x:146.5, y:140.6, lines:['„♪ Es war einmal ein Gossenkind… ♪ Das Lied handelt von dir!“']},
  {s:5, name:'Ratsherr Winfried', x:120.5, y:129.6, lines:['„Der Stadtrat möchte dir danken. Die Neustadt ist das Juwel von Aldenmark.“']}
];
CITIZENS.forEach((c, k) => NPC_DEFS.push({id:'bg_' + k, name:c.name, x:c.x, y:c.y, wander:c.wander || 2, look:GUEST_LOOKS[(k * 3) % 5], cond:() => P && townStage() >= c.s, talk() { return {text:pick(c.lines)}; }}));
for (const role in GUILD_STAFF) {
  const s = GUILD_STAFF[role];
  NPC_DEFS.push({id:'gs_' + role, name:s.name, at:['e_gilde'].concat(GUILD_STAFF_POS[role]), look:Object.assign({}, GUEST_LOOKS[role.length % 5], {outfit:'#2a4a8a', trim:'#e8c040'}),
    cond:() => P.guild && P.guild.staff[role], talk() { return {text:'„' + s.txt + '“', opts:[{t:'🛡️ Gilde verwalten', f:() => { closeDialog(); openPanel('estate', 'guild'); return 'close'; }}, {t:'Tschüss'}]}; }});
}
// Wer wohnt in welchem Zimmer?
function roomOcc() {
  if (!P || !P.guild) return [];
  const g = P.guild, out = [];
  for (const id of g.residents) out.push({kind:'c', id});
  for (const m of g.members) out.push({kind:'m', m});
  return out.slice(0, guildRooms());
}
function roomPos(k) { const r = GUILD_ROOMS[k]; return ipos(['e_gilde', r.x + 1.5, r.y + (r.top ? 1.6 : 0.9)]); }
GUILD_ROOMS.forEach((r, k) => NPC_DEFS.push({id:'gm_' + k,
  get name() { const o = roomOcc()[k]; return o && o.m ? o.m.name : ''; },
  get look() { const o = roomOcc()[k]; return o && o.m ? o.m.look : GUEST_LOOKS[0]; },
  get at() { const r2 = GUILD_ROOMS[k]; return ['e_gilde', r2.x + 1.5, r2.y + (r2.top ? 1.6 : 0.9)]; },
  cond:() => { const o = roomOcc()[k]; return !!(o && o.kind === 'm' && o.m.state !== 'mission'); },
  talk() {
    const m = roomOcc()[k].m, c = M_CLS[m.cls];
    return {text:'<b>' + m.name + '</b> – ' + c.icon + ' ' + c.name + ', Stufe ' + m.lvl + (m.state === 'verletzt' ? ' (verletzt)' : '') + '<br>' + pick(['„Wann geht’s los? Ich will raus!“', '„Mein Zimmer ist klein, aber es ist meins. Danke dafür.“', '„Ich habe von deinen Taten gehört. Ich folge dir überallhin.“', '„Die Gilde ist wie eine Familie. Eine laute, streitsüchtige Familie.“']) + '<br><br>Missionen: ' + m.missions,
      opts:[{t:'📜 Zur Missionstafel', f:() => { closeDialog(); UI.gsub = 'missions'; openPanel('estate', 'guild'); return 'close'; }}, {t:'Tschüss'}]};
  }}));
// Gefährten können in der Gildenhalle wohnen
const _compHomeEstate = compHome;
compHome = function (id) {
  if (P && P.guild && P.guild.residents.includes(id) && estateLvl('gilde')) { const k = roomOcc().findIndex(o => o.kind === 'c' && o.id === id); if (k >= 0) return roomPos(k); }
  return _compHomeEstate(id);
};
function onMission(uid) { return P.guild && P.guild.active.some(a => a.units.includes(uid)); }
for (const id in COMPS) { const c = COMPS[id], sh = c.show; c.show = () => (!sh || sh()) && !onMission('c:' + id); }
const _compDialogEstate = compDialog;
compDialog = function (id) {
  const d = _compDialogEstate(id), g = P.guild, s = P.comp[id];
  if (g && estateLvl('gilde') && s.hired) {
    const res = g.residents.includes(id);
    if (!res && roomOcc().length < guildRooms()) d.opts.splice(1, 0, {t:'🛡️ „Zieh in die Gildenhalle.“', f:() => { g.residents.push(id); G.estateDirty = true; return {text:COMPS[id].name + ' bezieht ein Zimmer in der Gildenhalle von „' + g.name + '“. Von dort kannst du ' + (COMPS[id].name.endsWith('a') ? 'sie' : 'ihn') + ' auch auf Gildenmissionen schicken.'}; }});
    else if (!res) d.opts.splice(1, 0, {t:'🛡️ Gildenhalle (alle Zimmer belegt)', f:() => ({text:'In der Gildenhalle ist kein Zimmer mehr frei. Baue die Gilde aus oder entlasse ein Mitglied.'})});
    if (res) d.opts.splice(1, 0, {t:'🏠 „Zieh zurück in deine alte Heimat.“', f:() => { g.residents = g.residents.filter(x => x !== id); G.estateDirty = true; return {text:COMPS[id].name + ' packt die Sachen und zieht zurück.'}; }});
  }
  return d;
};

// ---------- Einnahmen ----------
function bizStaffBonus(id) { const b = P.biz[id]; let s = 0, w = 0; for (const r in b.staff) { s += STAFF[id][r].bonus; w += STAFF[id][r].wage; } for (const e in b.ext) s += EXT[id][e].bonus; return {s, w}; }
bizIncome = function (id) {
  const z = BUSINESSES[id], b = P.biz[id]; if (!b) return 0;
  const {s, w} = bizStaffBonus(id);
  return Math.round(z.income * (1 + 0.5 * (b.lvl - 1)) * (1 + s + 0.05 * townStage()) - w);
};
function estateDaily(notes) {
  let inc = 0;
  for (const id in P.biz) {
    const b = P.biz[id]; let v = bizIncome(id);
    const guard = Object.keys(b.staff).some(r => STAFF[id][r].guard);
    if (chance(0.12)) { const good = guard || chance(0.5), d = Math.round(Math.abs(v) * rnd(0.5, 1)); v += good ? d : -d; notes.push(BUSINESSES[id].icon + (good ? ' Glückstag! +' : ' Ärger (Schlägerei, Diebstahl…) -') + d); }
    b.total += v; inc += v;
    for (const e in b.ext) { const x = EXT[id][e]; if (x.item) addItem(x.item === 'rand' ? pick(RAND_GOODS) : x.item, 1, true); if (x.rep) P.rep.stadt += x.rep; }
    for (const r in b.staff) if (STAFF[id][r].rep) P.rep.stadt += STAFF[id][r].rep;
  }
  const g = P.guild;
  if (g) {
    const home = g.members.filter(m => m.state !== 'mission').length;
    let dues = Math.round(home * 4 * g.lvl * (g.staff.verwalterin ? 1.5 : 1)), wages = 0;
    for (const r in g.staff) wages += GUILD_STAFF[r].wage;
    g.gold = Math.max(0, g.gold + dues - wages);
    if (dues) notes.push('🛡️ Gildenbeiträge: +' + dues + ' Gold in die Gildenkasse' + (wages ? ' (Löhne −' + wages + ')' : ''));
    g.board.day = -1; guildBoard();
  }
  G.estateDirty = true;
  return inc;
}

// ---------- Gildenmissionen ----------
const MISSION_T = [
  {type:'kampf', names:['Goblinnest ausräuchern', 'Banditenlager zerschlagen', 'Wolfsrudel vertreiben', 'Untote in der Krypta', 'Trollbrücke freikämpfen', 'Legionsspäher abfangen'], txt:'Kampferfahrene Mitglieder sind hier im Vorteil.'},
  {type:'jagd', names:['Seltene Felle beschaffen', 'Wildschweinplage im Kornfeld', 'Den Weißen Hirsch aufspüren', 'Riesenkrabben am Strand jagen', 'Wyvernfährte verfolgen'], txt:'Jäger finden die Spuren schneller.'},
  {type:'arkan', names:['Verfluchtes Amulett untersuchen', 'Magische Anomalie im Sumpf', 'Alte Runen entziffern', 'Irrlichter bannen', 'Kristallader vermessen'], txt:'Hier braucht es magisches Wissen.'},
  {type:'hilfe', names:['Fieber in Eichenrast', 'Verletzte Händler versorgen', 'Brunnen segnen', 'Flüchtlinge aus Morvath betreuen', 'Krankenlager in Möwenhafen'], txt:'Heiler sind hier unersetzlich.'},
  {type:'schatten', names:['Schmugglerring auffliegen lassen', 'Gestohlene Urkunde zurückholen', 'Spion in der Stadtwache entlarven', 'Ein Lösegeld überbringen', 'Hehlerware sicherstellen'], txt:'Leise Füße und flinke Finger gefragt.'}
];
const M_TYPE_NAME = {kampf:'⚔️ Kampf', jagd:'🏹 Jagd', arkan:'🔮 Magie', hilfe:'✨ Hilfe', schatten:'🗝️ Schatten'};
const MISSION_LOOT = [['grheiltrank', 1], ['silberbarren', 6], ['perle', 8], ['kristall', 8], ['mithrilbarren', 14], ['schattenkristall', 16], ['jungschuppe', 20], ['buch', 4], ['ring', 10], ['glueckstaler', 12]];
function nowT() { return G.day * DAY_LEN + G.time; }
function guildBoard() {
  const g = P.guild; if (!g) return [];
  if (g.board.day === G.day && g.board.list.length) return g.board.list;
  const n = 3 + Math.floor(g.lvl / 2) + (g.staff.spaeherin ? 1 : 0), list = [];
  for (let k = 0; k < n; k++) {
    const T = pick(MISSION_T), L = clamp(Math.round(g.lvl * 3 + P.lvl * 0.4 + rnd(-2, 3)), 1, 35), rec = rint(1, Math.min(4, 1 + g.lvl));
    const loot = MISSION_LOOT.filter(l => l[1] <= L + 2);
    list.push({mid:G.day + '_' + k, name:pick(T.names), type:T.type, txt:T.txt, L, rec, hours:3 + rec * 2 + rint(0, 6),
      gold:Math.round(L * rec * rnd(22, 36)), rep:Math.max(1, Math.round(L * rec * 0.35)), item:chance(0.6) && loot.length ? pick(loot)[0] : null});
  }
  g.board = {day:G.day, list}; return list;
}
function unitInfo(uid) {
  if (uid.startsWith('c:')) { const id = uid.slice(2); return {name:COMPS[id].name, lvl:compLvl(id), aff:COMP_AFF[COMPS[id].cls], icon:'👤', comp:true}; }
  const m = P.guild.members.find(x => x.id === uid); return m ? {name:m.name, lvl:m.lvl, aff:M_CLS[m.cls].aff, icon:M_CLS[m.cls].icon, m} : null;
}
function unitPower(uid, type) { const u = unitInfo(uid); if (!u) return 0; return u.lvl * (u.comp ? 1.3 : 1) * (u.aff === type ? 1.4 : 1); }
function missionChance(ms, units) {
  const pw = units.reduce((s, u) => s + unitPower(u, ms.type), 0), diff = ms.L * ms.rec;
  return clamp(0.2 + 0.65 * pw / diff + (P.guild.staff.spaeherin ? 0.06 : 0), 0.05, 0.97);
}
function freeUnits() {
  const g = P.guild, out = [];
  for (const id of g.residents) if (!P.party.includes(id) && !onMission('c:' + id)) out.push('c:' + id);
  for (const m of g.members) if (m.state === 'home') out.push(m.id);
  return out;
}
function sendMission(ms, units) {
  const g = P.guild; if (!units.length) return;
  const ch = missionChance(ms, units);
  g.active.push({mid:ms.mid, name:ms.name, type:ms.type, L:ms.L, units:units.slice(), end:nowT() + ms.hours / 24 * DAY_LEN, chance:ch, gold:ms.gold, rep:ms.rep, item:ms.item, hours:ms.hours});
  g.board.list = g.board.list.filter(x => x.mid !== ms.mid);
  for (const u of units) { const i = unitInfo(u); if (i.m) i.m.state = 'mission'; }
  toast('📜 ' + units.length + ' Mitglied' + (units.length > 1 ? 'er brechen' : ' bricht') + ' auf: „' + ms.name + '“ (Erfolg ca. ' + Math.round(ch * 100) + ' %)', 'quest'); sfx('quest');
  G.estateDirty = true;
}
function finishMission(a) {
  const g = P.guild, ok = Math.random() < a.chance, names = a.units.map(u => (unitInfo(u) || {}).name).filter(Boolean).join(', ');
  const xpMul = g.staff.ausbilder ? 1.5 : 1;
  for (const u of a.units) {
    const i = unitInfo(u); if (!i) continue;
    if (i.m) { i.m.missions++; i.m.xp += Math.round(a.L * (ok ? 25 : 8) * xpMul); while (i.m.xp >= i.m.lvl * 100) { i.m.xp -= i.m.lvl * 100; i.m.lvl++; toast('⬆️ ' + i.m.name + ' erreicht Stufe ' + i.m.lvl + '!'); }
      i.m.state = ok ? 'home' : 'verletzt'; i.m.until = nowT() + (g.staff.heilerin ? 6 : 12) / 24 * DAY_LEN; }
    else gainCompXp(u.slice(2), Math.round(a.L * (ok ? 60 : 20) * xpMul));
  }
  if (ok) {
    const crit = Math.random() < 0.15;
    g.gold += Math.round(a.gold * (crit ? 1.5 : 1)); g.rep += a.rep; g.done++; P.rep.stadt += a.rep * 0.1;
    if (a.item) addItem(a.item, 1, true);
    showDialog('📜 Mission erfüllt' + (crit ? ' – glänzend!' : ''), '<b>„' + a.name + '“</b><br>' + names + ' kehren erfolgreich zurück.<br><br>💰 +' + Math.round(a.gold * (crit ? 1.5 : 1)) + ' Gold in die Gildenkasse<br>🛡️ +' + a.rep + ' Gildenansehen' + (a.item ? '<br>🎁 ' + ITEMS[a.item].name : ''), [{t:'Hervorragend'}]);
    sfx('levelup');
  } else {
    g.rep += 1;
    showDialog('📜 Mission gescheitert', '<b>„' + a.name + '“</b><br>' + names + ' kehren erschöpft und mit leeren Händen zurück. Die Mitglieder sind eine Weile verletzt.<br><br>Tipp: Schick mehr oder stärkere Mitglieder – passende Klassen bringen viel.', [{t:'Beim nächsten Mal'}]);
    sfx('fail');
  }
  G.estateDirty = true;
}
function estateTick(dt) {
  if (!P) return;
  if (G.estateDirty) applyEstate();
  const g = P.guild; if (!g) return;
  G.missionT = (G.missionT || 0) - dt; if (G.missionT > 0) return; G.missionT = 1;
  const now = nowT();
  for (const m of g.members) if (m.state === 'verletzt' && m.until <= now) { m.state = 'home'; G.estateDirty = true; }
  const done = g.active.filter(a => a.end <= now);
  if (done.length && (UI.panel || !$('dialog').classList.contains('hidden'))) return;   // Fenster offen: kurz warten
  g.active = g.active.filter(a => a.end > now);
  done.forEach(finishMission);
}
const _eastTickEstate = eastTick;
eastTick = function (dt) { _eastTickEstate(dt); estateTick(dt); };

// ---------- Kaufen, Ausbauen, Personal ----------
const _buyBizEstate = buyBiz, _upgradeBizEstate = upgradeBiz;
buyBiz = function (id) { const had = !!P.biz[id]; _buyBizEstate(id); if (!had && P.biz[id]) { P.biz[id].staff = {}; P.biz[id].ext = {}; G.estateDirty = true; toast('🏗️ Dein Gebäude steht jetzt in der Neustadt (nördlich vor dem Tor von Aldenmark)!', 'gold'); } };
upgradeBiz = function (id) { const l = P.biz[id] && P.biz[id].lvl; _upgradeBizEstate(id); if (P.biz[id] && P.biz[id].lvl !== l) G.estateDirty = true; };
function hireStaff(id, role) { const s = STAFF[id][role], b = P.biz[id]; if (!b || b.staff[role] || b.lvl < s.lvl || P.gold < s.cost) return; P.gold -= s.cost; b.staff[role] = true; toast(s.icon + ' ' + s.name + ' arbeitet jetzt für dich.', 'gold'); sfx('coin'); G.estateDirty = true; }
function fireStaff(id, role) { delete P.biz[id].staff[role]; toast(STAFF[id][role].name + ' wurde entlassen.'); G.estateDirty = true; }
function buildExt(id, e) { const x = EXT[id][e], b = P.biz[id]; if (!b || b.ext[e] || b.lvl < x.lvl || P.gold < x.cost) return; P.gold -= x.cost; b.ext[e] = true; toast('🏗️ Ausgebaut: ' + x.name, 'gold'); sfx('craft'); G.estateDirty = true; }
foundGuild = function (name) {
  if (P.guild || P.gold < 3000 || !questDone('goblins') || P.rep.stadt < GUILD_REP) return;
  P.gold -= 3000; P.guild = {name:name || 'Gilde der Gosse', lvl:1, members:[]}; fixGuild(P.guild);
  toast('🛡️ Gilde gegründet: ' + P.guild.name + ' – die Gildenhalle steht in der Neustadt!', 'gold'); P.rep.stadt += 10; sfx('levelup'); G.estateDirty = true;
};
guildMax = function () { return guildRooms(); };
function recruitCost() { return 150 * (P.guild ? P.guild.lvl : 1); }
recruitMember = function () {
  const g = P.guild; if (!g || roomOcc().length >= guildRooms() || P.gold < recruitCost()) return;
  P.gold -= recruitCost(); const m = newMember(); g.members.push(m);
  toast('🛡️ ' + m.name + ' (' + M_CLS[m.cls].name + ', Stufe ' + m.lvl + ') tritt der Gilde bei und bezieht ein Zimmer.', 'gold'); G.estateDirty = true;
};
function guildUpCost() { return 2500 * P.guild.lvl; }
upgradeGuild = function () {
  const g = P.guild; if (!g || g.lvl >= 5) return; const c = guildUpCost();
  if (g.rep < GUILD_REP_NEED[g.lvl] || P.gold + g.gold < c) return;
  const fromKasse = Math.min(g.gold, c); g.gold -= fromKasse; P.gold -= c - fromKasse; g.lvl++;
  toast('🛡️ Gildenhalle ausgebaut – Stufe ' + g.lvl + '! Jetzt ' + guildRooms() + ' Zimmer.', 'gold'); sfx('levelup'); G.estateDirty = true;
};
function hireGuildStaff(role) { const s = GUILD_STAFF[role], g = P.guild; if (!g || g.staff[role] || g.lvl < s.lvl || P.gold < s.cost) return; P.gold -= s.cost; g.staff[role] = true; toast(s.icon + ' ' + s.name + ' arbeitet jetzt für die Gilde.', 'gold'); G.estateDirty = true; }

// ---------- Aktionen: Bauplatz-Schild, Missionstafel, Schlafen ----------
const _doActionEstate = doAction;
doAction = function () {
  const it = G.inter;
  if (it && it.k === 'lot') {
    const id = Object.keys(LOTS).find(k => LOTS[k].door[0] === it.x && LOTS[k].door[1] === it.y) || 'taverne';
    if (id === 'gilde') { openPanel('estate', 'guild'); return; }
    UI.focus = id; openPanel('estate', 'biz'); return;
  }
  if (it && it.k === 'gboard') { UI.gsub = 'missions'; openPanel('estate', 'guild'); return; }
  if (it && it.k === 'bed' && /^i_e_(gilde|taverne)$/.test(regionAt(P.x, P.y))) { showDialog('Bett', 'Bis zum Morgen schlafen? (Das Spiel wird gespeichert.)', [{t:'Schlafen', f:() => { closeDialog(); sleepUntilMorning(); return 'close'; }}, {t:'Abbrechen'}]); return; }
  return _doActionEstate();
};
const _inCityEstate = inCity;
inCity = function () { return _inCityEstate() || regionAt(P.x, P.y) === 'neustadt'; };

// ---------- Oberfläche: Besitz-Fenster ----------
const _renderEstateOld = renderEstate;
PANELS.estate.tabs = [['house', '🏠 Häuser'], ['biz', '💰 Betriebe'], ['guild', '🛡️ Gilde'], ['town', '🏘️ Neustadt']];
PANELS.estate.render = function (b, tab) {
  if (tab === 'house') return _renderEstateOld(b, 'house');
  if (tab === 'town') return renderTown(b);
  if (tab === 'biz') return renderBizNew(b);
  return renderGuildNew(b);
};
function subTabs(b, list, cur, set) { const bar = el('div', 'subtabs'); bar.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 8px'; list.forEach(([k, l]) => bar.appendChild(btn(l, () => { set(k); renderPanel(); }, 'tab' + (cur === k ? ' on' : '')))); b.appendChild(bar); }
function canTrade() { const r = regionAt(P.x, P.y); return inCity() || r.startsWith('i_e_'); }
function renderTown(b) {
  const st = townStage(), sc = townScore(), nx = TOWN_STAGES[st + 1];
  b.appendChild(row('🏘️', 'Neustadt – ' + TOWN_STAGES[st].name, TOWN_STAGES[st].txt + '<br>Wachstum: ' + Math.round(sc * 10) / 10 + (nx ? ' · nächste Stufe „' + nx.name + '“ ab ' + nx.min : ' · höchste Stufe erreicht!') + '<br>Bonus für alle Betriebe: +' + st * 5 + ' % Gewinn'));
  b.appendChild(el('p', 'hint', 'Die Neustadt liegt direkt vor dem Nordtor von Aldenmark. Jeder Betrieb, jede Ausbaustufe, jede Erweiterung, jedes Personal und deine Gilde lassen sie wachsen: Brunnen, Marktstände, Gärten und neue Bürger kommen dazu – und alle Betriebe verdienen mehr.'));
  TOWN_STAGES.forEach((t, i) => b.appendChild(row(i <= st ? '✅' : '⬜', t.name + ' (ab ' + t.min + ')', t.txt)));
  b.appendChild(el('p', 'hint', 'So wächst die Neustadt: Betriebsstufe +1 · Erweiterung +1 · Personal +0,5 · Gildenstufe +2'));
}
function renderBizNew(b) {
  const here = canTrade();
  b.appendChild(el('p', 'hint' + (here ? '' : ' warn'), 'Deine Betriebe stehen als Gebäude in der Neustadt (vor dem Nordtor). Personal und Erweiterungen erhöhen den Gewinn, Ausbaustufen lassen das Gebäude wachsen. Löhne werden täglich vom Gewinn abgezogen.' + (here ? '' : ' Kaufen und Ausbauen geht nur in Aldenmark, in der Neustadt oder in deinen Betrieben.')));
  const ids = Object.keys(BUSINESSES); if (UI.focus && ids.includes(UI.focus)) { ids.splice(ids.indexOf(UI.focus), 1); ids.unshift(UI.focus); }
  for (const id of ids) {
    const z = BUSINESSES[id], s = P.biz[id], ok = repOk(z.rep, z.thief);
    if (!s) { b.appendChild(row(z.icon, z.name, z.desc + '<br>' + fmt(z.cost) + ' Gold · ca. ' + z.income + ' Gold/Tag · Ansehen ' + z.rep + (ok ? ' ✓' : ' ✗'), [btn('Kaufen', () => { buyBiz(id); renderPanel(); }, 'gold', !here || P.gold < z.cost || !ok)])); continue; }
    const {s:bon, w} = bizStaffBonus(id), up = z.upCost * s.lvl;
    b.appendChild(row(z.icon, z.name + ' – Stufe ' + s.lvl + '/5', '<b>+' + bizIncome(id) + ' Gold/Tag</b> · Bonus +' + Math.round(bon * 100) + ' % · Löhne ' + w + ' · bisher ' + fmt(s.total) + ' Gold',
      s.lvl < 5 ? [btn('🏗️ Ausbauen (' + fmt(up) + ')', () => { upgradeBiz(id); renderPanel(); }, 'gold', !here || P.gold < up)] : [], 'head'));
    for (const r in STAFF[id]) {
      const st = STAFF[id][r], has = s.staff[r];
      b.appendChild(row(st.icon, '　' + st.name + (has ? ' ✓' : ''), st.txt + ' · +' + Math.round(st.bonus * 100) + ' % · Lohn ' + st.wage + '/Tag' + (s.lvl < st.lvl ? ' · ab Stufe ' + st.lvl : ''),
        has ? [btn('Entlassen', () => { fireStaff(id, r); renderPanel(); })] : [btn('Einstellen (' + st.cost + ')', () => { hireStaff(id, r); renderPanel(); }, 'gold', !here || s.lvl < st.lvl || P.gold < st.cost)], 'sub'));
    }
    for (const e in EXT[id]) {
      const x = EXT[id][e], has = s.ext[e];
      b.appendChild(row(x.icon, '　' + x.name + (has ? ' ✓' : ''), x.txt + (has ? '' : ' · ' + fmt(x.cost) + ' Gold') + (s.lvl < x.lvl ? ' · ab Stufe ' + x.lvl : ''),
        has ? [] : [btn('Bauen', () => { buildExt(id, e); renderPanel(); }, 'gold', !here || s.lvl < x.lvl || P.gold < x.cost)], 'sub'));
    }
  }
  UI.focus = null;
}
function renderGuildNew(b) {
  const g = P.guild, here = canTrade();
  if (!g) {
    const rs = Math.floor(P.rep.stadt);
    const req = [['Gildenrang Silber (Quest „Goblinplage“)', questDone('goblins')], ['Ansehen ' + GUILD_REP + ' in Aldenmark (du: ' + rs + ')', P.rep.stadt >= GUILD_REP], ['3.000 Gold', P.gold >= 3000]];
    b.appendChild(el('p', 'hint', 'Gründe deine eigene Gilde. In der Neustadt entsteht eine Gildenhalle mit einem Zimmer für jedes Mitglied. Schick Mitglieder und Gefährten auf Gildenmissionen – das bringt der Gilde Ansehen und Reichtum.'));
    req.forEach(r => b.appendChild(row(r[1] ? '✅' : '❌', r[0], '')));
    const inp = el('input', 'inp'); inp.placeholder = 'Name deiner Gilde'; inp.maxLength = 28; b.appendChild(inp);
    b.appendChild(btn('Gilde gründen', () => { foundGuild(inp.value.trim()); renderPanel(); }, 'gold', !req.every(r => r[1]) || !here));
    return;
  }
  const sub = UI.gsub || 'overview';
  subTabs(b, [['overview', '🛡️ Übersicht'], ['members', '👥 Mitglieder'], ['missions', '📜 Missionen'], ['staff', '🧑‍💼 Personal']], sub, k => UI.gsub = k);
  if (sub === 'overview') {
    const need = GUILD_REP_NEED[g.lvl], c = g.lvl < 5 ? guildUpCost() : 0;
    b.appendChild(row('🛡️', g.name + ' – Stufe ' + g.lvl + '/5', 'Gildenansehen <b>' + Math.floor(g.rep) + '</b> · Gildenkasse <b>' + fmt(g.gold) + ' Gold</b><br>Zimmer ' + roomOcc().length + '/' + guildRooms() + ' belegt · ' + g.done + ' Missionen erfüllt · +' + g.lvl * 5 + ' % Erfahrung für dich', [], 'head'));
    b.appendChild(btn('💰 Gildenkasse abheben (' + fmt(g.gold) + ')', () => { P.gold += g.gold; g.gold = 0; sfx('coin'); renderPanel(); }, 'gold', !g.gold));
    if (g.lvl < 5) b.appendChild(row('🏗️', 'Gildenhalle ausbauen → Stufe ' + (g.lvl + 1), fmt(c) + ' Gold (zuerst aus der Gildenkasse) · benötigt Gildenansehen ' + need + (g.rep >= need ? ' ✓' : ' ✗') + '<br>Mehr Zimmer (' + GUILD_ROOMS_BY_LVL[g.lvl] + '), größeres Gebäude, mehr Missionen', [btn('Ausbauen', () => { upgradeGuild(); renderPanel(); }, 'gold', !here || g.rep < need || P.gold + g.gold < c)]));
    b.appendChild(el('p', 'hint', 'Die Gildenhalle steht in der Neustadt. Mitglieder wohnen dort in ihren Zimmern. Gefährten kannst du im Gespräch bitten, in die Gildenhalle zu ziehen – dann kannst du auch sie auf Missionen schicken, solange sie nicht in deiner Gruppe sind. Mitglieder zahlen täglich Beiträge in die Gildenkasse.'));
  } else if (sub === 'members') {
    b.appendChild(btn('➕ Mitglied anwerben (' + recruitCost() + ' Gold)', () => { recruitMember(); renderPanel(); }, 'gold', !here || roomOcc().length >= guildRooms() || P.gold < recruitCost()));
    if (roomOcc().length >= guildRooms()) b.appendChild(el('p', 'hint warn', 'Alle Zimmer sind belegt. Baue die Gildenhalle aus, um mehr Mitglieder aufzunehmen.'));
    for (const id of g.residents) b.appendChild(row('👤', COMPS[id].name + ' – Gefährte, Stufe ' + compLvl(id), P.party.includes(id) ? 'Gerade in deiner Gruppe unterwegs' : onMission('c:' + id) ? '📜 Auf Mission' : '🏠 Wohnt in der Gildenhalle'));
    for (const m of g.members) {
      const c = M_CLS[m.cls], st = m.state === 'mission' ? '📜 Auf Mission' : m.state === 'verletzt' ? '🤕 Verletzt (erholt sich)' : '🏠 In der Gildenhalle';
      b.appendChild(row(c.icon, m.name + ' – ' + c.name + ', Stufe ' + m.lvl, st + ' · ' + m.missions + ' Missionen · EP ' + m.xp + '/' + m.lvl * 100,
        m.state === 'mission' ? [] : [btn('Entlassen', () => { g.members = g.members.filter(x => x !== m); G.estateDirty = true; renderPanel(); })]));
    }
  } else if (sub === 'missions') {
    const list = guildBoard(), free = freeUnits();
    if (g.active.length) {
      b.appendChild(el('p', 'hint', '<b>Unterwegs</b>'));
      for (const a of g.active) { const h = Math.max(0, (a.end - nowT()) / DAY_LEN * 24); b.appendChild(row('⏳', a.name, a.units.map(u => (unitInfo(u) || {}).name).join(', ') + ' · zurück in ca. ' + (h >= 1 ? Math.ceil(h) + ' Std.' : 'weniger als 1 Std.') + ' · Erfolg ca. ' + Math.round(a.chance * 100) + ' %')); }
    }
    b.appendChild(el('p', 'hint', '<b>Missionstafel</b> – wähle eine Mission, dann die Mitglieder. Passende Klassen zählen 40 % mehr. (Frei: ' + free.length + ')'));
    if (!list.length) b.appendChild(el('p', 'hint', 'Heute gibt es keine Aufträge mehr. Morgen hängen neue an der Tafel.'));
    const sel = UI.msel && list.find(x => x.mid === UI.msel.mid) ? UI.msel : null;
    for (const ms of list) {
      const open = sel && sel.mid === ms.mid;
      b.appendChild(row(M_TYPE_NAME[ms.type].split(' ')[0], ms.name + ' (Stufe ' + ms.L + ')', M_TYPE_NAME[ms.type] + ' · empfohlen ' + ms.rec + ' Mitglied' + (ms.rec > 1 ? 'er' : '') + ' · ' + ms.hours + ' Std.<br>Belohnung: ' + ms.gold + ' Gold, +' + ms.rep + ' Gildenansehen' + (ms.item ? ', ' + ITEMS[ms.item].name : '') + '<br><i>' + ms.txt + '</i>',
        [btn(open ? 'Schließen' : 'Auswählen', () => { UI.msel = open ? null : {mid:ms.mid, units:[]}; renderPanel(); }, open ? '' : 'gold')], open ? 'head' : ''));
      if (open) {
        const box = el('div', 'msel'); box.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 6px 12px';
        if (!free.length) box.appendChild(el('span', 'hint', 'Niemand ist frei. Wirb Mitglieder an oder lass Gefährten in der Gildenhalle wohnen.'));
        for (const u of free) {
          const i = unitInfo(u), on = sel.units.includes(u);
          box.appendChild(btn((on ? '✅ ' : '') + i.icon + ' ' + i.name + ' St.' + i.lvl + (i.aff === ms.type ? ' ★' : ''), () => { if (on) sel.units = sel.units.filter(x => x !== u); else if (sel.units.length < 4) sel.units.push(u); renderPanel(); }, on ? 'gold' : ''));
        }
        b.appendChild(box);
        const ch = sel.units.length ? missionChance(ms, sel.units) : 0;
        b.appendChild(btn('🚩 Aussenden' + (sel.units.length ? ' – Erfolg ca. ' + Math.round(ch * 100) + ' %' : ''), () => { sendMission(ms, sel.units); UI.msel = null; renderPanel(); }, 'gold', !sel.units.length));
      }
    }
  } else {
    b.appendChild(el('p', 'hint', 'Personal der Gildenhalle. Löhne werden täglich aus der Gildenkasse bezahlt.'));
    for (const r in GUILD_STAFF) {
      const s = GUILD_STAFF[r], has = g.staff[r];
      b.appendChild(row(s.icon, s.name + (has ? ' ✓' : ''), s.txt + ' · Lohn ' + s.wage + '/Tag' + (g.lvl < s.lvl ? ' · ab Gildenstufe ' + s.lvl : ''),
        has ? [btn('Entlassen', () => { delete g.staff[r]; G.estateDirty = true; renderPanel(); })] : [btn('Einstellen (' + s.cost + ')', () => { hireGuildStaff(r); renderPanel(); }, 'gold', !here || g.lvl < s.lvl || P.gold < s.cost)]));
    }
  }
}
