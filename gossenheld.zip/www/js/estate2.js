'use strict';
// ================= BESITZ II: Gefährten parken, Neustadt wächst in die Stadt, Ladenschilder, übersichtliche Menüs =================

// ---------- Gefährten: in der Gildenhalle lassen oder nach Hause schicken ----------
function compLeaveParty(id) { if (!P.party.includes(id)) return; storeAllyHp(); P.party = P.party.filter(x => x !== id); syncAllies(); }
function compToGuild(id) {
  const g = P.guild; if (!g || !estateLvl('gilde')) return false;
  if (!g.residents.includes(id)) { if (roomOcc().length >= guildRooms()) { toast('In der Gildenhalle ist kein Zimmer frei.'); return false; } g.residents.push(id); }
  compLeaveParty(id); G.estateDirty = true;
  toast('🛡️ ' + COMPS[id].name + ' wartet jetzt in der Gildenhalle (Neustadt).', 'gold'); return true;
}
function compMoveOut(id) { const g = P.guild; if (!g) return; g.residents = g.residents.filter(x => x !== id); G.estateDirty = true; toast('🏠 ' + COMPS[id].name + ' zieht zurück in die alte Heimat.'); }
function compSendHome(id) { compLeaveParty(id); G.estateDirty = true; toast('🏠 ' + COMPS[id].name + ' wartet jetzt zu Hause.'); }
function compNear(id) { const h = compHome(id); return dist(P.x, P.y, h[0], h[1]) < 9; }
function compCall(id) {
  if (P.party.length >= 4) { toast('Deine Gruppe ist voll (max. 4 Gefährten).'); return; }
  if (onMission('c:' + id)) { toast(COMPS[id].name + ' ist auf einer Gildenmission.'); return; }
  P.party.push(id); syncAllies(); G.estateDirty = true; toast('👥 ' + COMPS[id].name + ' schließt sich dir an.', 'gold');
}
const _renderPartyOld = PANELS.party.render;
PANELS.party.render = function (b, tab) {
  if (tab !== 'comp') return _renderPartyOld(b, tab);
  const hall = P.guild && estateLvl('gilde');
  b.appendChild(el('div', 'banner ok', '👥 Du musst nicht alle Gefährten mitnehmen! Schick sie nach Hause' + (hall ? ' oder in deine Gildenhalle' : '') + ' – dort warten sie' + (hall ? ' und können auf Gildenmissionen gehen' : '') + '. Abholen kannst du sie, wenn du in ihrer Nähe bist.'));
  b.appendChild(el('h3', '', 'In deiner Gruppe (' + P.party.length + '/4)'));
  if (!P.party.length) b.appendChild(el('p', 'hint', 'Du reist allein.'));
  for (const id of P.party) {
    const c = COMPS[id], a = G.allies.find(x => x.id === id), s = P.comp[id], lv = compLvl(id), st = compStats(id);
    b.appendChild(row(compPic(id), c.name + ' <small>· ' + c.title + ' · Stufe ' + lv + '</small>',
      '<i>' + COMP_ROLE[c.cls] + '</i> · ' + (a ? (a.down ? 'Bewusstlos' : 'Leben ' + Math.round(a.hp) + '/' + a.maxHp) : '') + (c.cls === 'heil' ? ' · Heilkraft ' + Math.round(8 + lv * 3.2) : ' · Schaden ' + Math.round(st.dmg)) +
      '<br>Erfahrung <span class="pbar"><i style="width:' + Math.round((s.xp || 0) / compXpNeed(lv) * 100) + '%"></i></span> ' + hearts(s.aff) + (s.lover ? ' 💞' : ''),
      [btn('💬', () => { closePanel(); showNpcDialog({id, def:{id, name:c.name, comp:true}}, compDialog(id)); }),
       hall ? btn('🛡️ Gildenhalle', () => { compToGuild(id); renderPanel(); }, 'gold') : null,
       btn('🏠 Heim', () => { compSendHome(id); renderPanel(); })].filter(Boolean)));
  }
  const away = Object.keys(COMPS).filter(id => !P.party.includes(id) && P.comp[id].hired);
  if (away.length) {
    b.appendChild(el('h3', '', 'Wartend'));
    for (const id of away) {
      const h = compHome(id), res = P.guild && P.guild.residents.includes(id), mis = onMission('c:' + id), near = compNear(id);
      const where = mis ? '📜 Auf Gildenmission' : (res && hall ? '🛡️ Gildenhalle' : '🏠 ' + locName(h[0], h[1]));
      const bt = [];
      if (!mis && near) bt.push(btn('👥 Mitnehmen', () => { compCall(id); renderPanel(); }, 'gold', P.party.length >= 4));
      if (hall && !res && !mis) bt.push(btn('🛡️ Einziehen', () => { compToGuild(id); renderPanel(); }));
      if (res && !mis) bt.push(btn('🏠 Ausziehen', () => { compMoveOut(id); renderPanel(); }));
      b.appendChild(row(compPic(id), COMPS[id].name + ' <small>· Stufe ' + compLvl(id) + '</small>', where + (near || mis ? '' : '<br><small>Zum Mitnehmen hingehen und ansprechen</small>'), bt));
    }
  }
};
function compPic(id) { const pic = el('canvas', 'petpic'); pic.width = 16; pic.height = 24; pic.getContext('2d').drawImage(makeHumanoid(COMPS[id].look)[0], 0, 0); return '<img class="pix" src="' + pic.toDataURL() + '">'; }
// Im Gespräch: auch aus der Gruppe heraus in die Gildenhalle schicken
const _compDialogE2 = compDialog;
compDialog = function (id) {
  const d = _compDialogE2(id);
  if (P.party.includes(id) && P.guild && estateLvl('gilde')) d.opts.splice(Math.max(0, d.opts.length - 1), 0, {t:'🛡️ „Warte in der Gildenhalle auf mich.“', f:() => { compToGuild(id); return {text:'„Alles klar. Ich halte die Gildenhalle warm.“'}; }});
  return d;
};

// ---------- Die Neustadt wächst in die Stadt hinein ----------
// Stufe 1–2: Palisade · ab 3: Stadtmauer mit Toren, neues Tor in der alten Nordmauer, Stadtwachen
// ab 4: gepflasterte Straßen · Stufe 5: die alte Nordmauer wird abgerissen – ein Aldenmark
const NS_OPEN3 = [120, 121, 122, 132, 133, 134, 135, 136];
const NS_OPEN5 = [114, 115, 116, 117, 118, 119, 139, 140];
function nsBorder() {
  const out = [];
  for (let x = NS.x0; x <= NS.x1; x++) out.push([x, NS.y0]);
  for (let y = NS.y0 + 1; y <= NS.y1; y++) { out.push([NS.x0, y]); out.push([NS.x1, y]); }
  for (let x = NS.x0 + 1; x < NS.x1; x++) if (x < 113 || x > 141) out.push([x, NS.y1]);
  return out;
}
function townIntegrate() {
  const st = townStage(), touched = [];
  const put = (x, y, t, g) => { if (!inb(x, y)) return; const i = idx(x, y); if (g != null) WG[i] = g; WT[i] = t; WT0[i] = t; touched.push(i); };
  for (const [x, y] of nsBorder()) {
    const i = idx(x, y); if (WG[i] === TL.WATER) continue;
    const gate = WG[i] === TL.PATH || WG[i] === TL.FLOOR || [137, 138, 147, 148].includes(y) && (x === NS.x0 || x === NS.x1);
    if (gate) { if (st >= 1) put(x, y, st >= 4 ? TL.FLOOR : TL.PATH, st >= 4 ? TL.FLOOR : TL.PATH); continue; }
    put(x, y, st >= 3 ? TL.WALL : st >= 1 ? TL.FENCE : WG[i], null);
  }
  for (const x of NS_OPEN3) put(x, 151, st >= 3 ? TL.PATH : TL.WALL, st >= 3 ? TL.PATH : TL.WALL);
  for (const x of NS_OPEN5) put(x, 151, st >= 5 ? TL.PATH : TL.WALL, st >= 5 ? TL.PATH : TL.WALL);
  // Straßen pflastern
  for (let y = NS.y0 + 1; y < NS.y1 + 1; y++) for (let x = NS.x0 + 1; x < NS.x1; x++) {
    const i = idx(x, y); if (REGIONS[WR[i]] !== 'neustadt') continue;
    if (st >= 4 && WG[i] === TL.PATH && WT[i] === TL.PATH) put(x, y, TL.FLOOR, TL.FLOOR);
    else if (st < 4 && WG[i] === TL.FLOOR && WT[i] === TL.FLOOR && G.nsPaved && G.nsPaved.has(i)) put(x, y, TL.PATH, TL.PATH);
  }
  G.nsPaved = new Set(); for (let y = NS.y0 + 1; y <= NS.y1; y++) for (let x = NS.x0 + 1; x < NS.x1; x++) { const i = idx(x, y); if (WG[i] === TL.FLOOR && REGIONS[WR[i]] === 'neustadt') G.nsPaved.add(i); }
  REGION_INFO.neustadt.name = st >= 5 ? 'Aldenmark – Prachtviertel' : st >= 3 ? 'Aldenmark – Neustadt' : 'Neustadt vor Aldenmark';
  if (G.mapImg) { for (const i of touched) if (G.explored[i]) setMapPx(i); G.mapDirty = true; }
}
NPC_DEFS.push(
  {id:'bg_wache1', name:'Stadtwache', x:122.5, y:150.4, look:{skin:'#e0b090', hair:'#6a4a2a', outfit:'#2a4a8a', style:'chain', helmCol:'#8a8e9a'}, cond:() => P && townStage() >= 3,
    talk() { return {text:townStage() >= 5 ? '„Früher stand hier die Nordmauer. Jetzt ist die Neustadt einfach… Aldenmark.“' : '„Das neue Tor zur Neustadt. Der Rat hat es auf deinen Wunsch hin bauen lassen, heißt es.“'}; }},
  {id:'bg_wache2', name:'Stadtwache', x:140.5, y:126.4, look:{skin:'#c8946a', hair:'#2a1a1a', outfit:'#2a4a8a', style:'chain', helmCol:'#8a8e9a'}, cond:() => P && townStage() >= 3,
    talk() { return {text:'„Nordtor der Neustadt. Ruhig heute. Ruhig ist gut.“'}; }}
);

// ---------- Schilder & Fassaden: Läden erkennt man von außen ----------
const SIGN_DRAW = {
  mug(R) { R(3, 3, 6, 6, '#e8b030'); R(3, 2, 6, 2, '#ffffff'); R(9, 4, 2, 4, '#c8901a'); R(10, 5, 1, 2, '#6a4422'); R(4, 4, 1, 4, '#f8d860'); },
  anvil(R) { R(2, 4, 9, 2, '#5a5a62'); R(1, 4, 2, 1, '#5a5a62'); R(4, 6, 5, 2, '#4a4a52'); R(3, 8, 7, 1, '#3a3a42'); R(3, 3, 7, 1, '#8a8a92'); },
  hammer(R) { R(3, 2, 7, 3, '#7a7a84'); R(3, 2, 7, 1, '#a8a8b0'); R(6, 5, 2, 5, '#8a5a2a'); },
  bag(R) { R(3, 4, 7, 6, '#a8743c'); R(4, 3, 5, 1, '#a8743c'); R(5, 2, 3, 1, '#6a4422'); R(4, 5, 2, 2, '#c8945a'); R(6, 6, 2, 1, '#e8c040'); },
  holy(R) { R(5, 1, 2, 9, '#e8c040'); R(2, 4, 8, 2, '#e8c040'); R(5, 4, 2, 2, '#fff8c0'); },
  sword(R) { for (let k = 0; k < 7; k++) R(3 + k, 8 - k, 1, 1, '#d8dce8'); R(2, 7, 3, 1, '#c8a040'); R(2, 9, 1, 1, '#6a4422'); },
  book(R) { R(2, 2, 8, 7, '#8a2a2a'); R(3, 3, 6, 5, '#a83a3a'); R(9, 2, 1, 7, '#e8e0c8'); R(4, 4, 3, 1, '#e8c040'); },
  rose(R) { R(4, 2, 4, 4, '#c8203a'); R(5, 3, 2, 2, '#f04a6a'); R(5, 6, 1, 4, '#3a8a3a'); R(6, 7, 2, 1, '#4aa04a'); R(3, 8, 2, 1, '#4aa04a'); },
  coin(R) { R(2, 6, 4, 3, '#e8c040'); R(2, 6, 4, 1, '#fff0a0'); R(6, 3, 4, 6, '#e8c040'); R(6, 3, 4, 1, '#fff0a0'); R(7, 5, 2, 2, '#a8801a'); },
  scales(R) { R(5, 1, 2, 8, '#8a6a3a'); R(1, 2, 10, 1, '#8a6a3a'); R(0, 4, 4, 2, '#e8c040'); R(8, 4, 4, 2, '#e8c040'); R(3, 9, 6, 1, '#6a4a2a'); },
  shield(R, o) { R(2, 1, 8, 6, o.c || '#2a4a8a'); R(3, 7, 6, 1, o.c || '#2a4a8a'); R(4, 8, 4, 1, o.c || '#2a4a8a'); R(5, 2, 2, 5, '#e8c040'); R(3, 3, 6, 1, '#e8c040'); }
};
const _houseCanvasE2 = houseCanvas, DECO_CACHE = {};
houseCanvas = function (b) {
  if (!b.deco) return _houseCanvasE2(b);
  const key = [b.w, b.h, b.v, b.wall ? 1 : 0, b.door, b.tower ? 1 : 0, b.dark ? 1 : 0, JSON.stringify(b.deco)].join('|');
  if (DECO_CACHE[key]) return DECO_CACHE[key];
  const base = _houseCanvasE2(b), d = b.deco, W = base.width, H = base.height;
  const c = mkCanvas(W, H), x = c.getContext('2d'); x.drawImage(base, 0, 0);
  const R = (a, y, w, h, col) => { x.fillStyle = col; x.fillRect(a, y, w, h); };
  const dx = b.door * 16, wallTop = b.wall ? H - 34 : H - 18;
  if (d.awning && !b.wall) for (let a = 1; a < W - 1; a++) { if (a >= dx && a < dx + 16) continue; R(a, wallTop + 1, 1, 4, Math.floor(a / 4) % 2 ? d.awning : '#f0e8d8'); R(a, wallTop + 5, 1, 1, (a % 4 < 2) ? shade(d.awning, -0.3) : 'rgba(0,0,0,0)'); }
  if (d.columns) for (const px of [dx - 5, dx + 18]) if (px > 0 && px < W - 3) { R(px, wallTop - 2, 4, H - wallTop - 2, '#e8e4dc'); R(px, wallTop - 2, 4, 1, '#ffffff'); R(px + 3, wallTop - 1, 1, H - wallTop - 3, '#b8b4ac'); R(px - 1, wallTop - 3, 6, 2, '#d8d4cc'); }
  if (d.banners) for (const bx of [Math.round(W * 0.22), Math.round(W * 0.78) - 6]) { R(bx, wallTop - 14, 6, 14, d.banners); R(bx, wallTop - 14, 6, 2, '#e8c040'); R(bx + 2, wallTop - 9, 2, 3, '#e8c040'); R(bx, wallTop, 2, 2, d.banners); R(bx + 4, wallTop, 2, 2, d.banners); }
  if (d.lantern) { const lx = dx - 4; if (lx > 2) { R(lx, wallTop - 1, 1, 4, '#3a2a1a'); R(lx - 2, wallTop + 3, 5, 6, '#c8203a'); R(lx - 1, wallTop + 4, 3, 4, '#ff8080'); R(lx - 2, wallTop + 9, 5, 1, '#3a2a1a'); } }
  if (d.props === 'barrels' && dx >= 20) { for (const px of [dx - 20, dx - 12]) { R(px, H - 11, 8, 9, '#8a5a2a'); R(px, H - 9, 8, 1, '#5a5a62'); R(px, H - 5, 8, 1, '#5a5a62'); R(px + 1, H - 11, 6, 1, '#a8743c'); } }
  if (d.props === 'anvil' && W - dx > 34) { const px = dx + 22; R(px, H - 9, 10, 3, '#5a5a62'); R(px + 3, H - 6, 4, 3, '#4a4a52'); R(px + 1, H - 3, 8, 1, '#3a3a42'); R(px, H - 9, 10, 1, '#8a8a92'); }
  if (d.props === 'crates' && dx >= 20) { R(dx - 20, H - 12, 10, 10, '#a8743c'); R(dx - 20, H - 12, 10, 1, '#c8945a'); R(dx - 15, H - 12, 1, 10, '#6a4422'); R(dx - 11, H - 8, 7, 6, '#8a6a3a'); R(dx - 11, H - 8, 7, 1, '#a8845a'); }
  if (d.props === 'flowers') for (let a = 2; a < W - 2; a += 5) { if (a >= dx - 2 && a < dx + 18) continue; R(a, H - 6, 4, 2, '#3a7a3a'); R(a + 1, H - 7, 2, 1, a % 3 ? '#e85a9a' : '#f04a6a'); }
  if (d.sign && SIGN_DRAW[d.sign]) {
    let sx = dx + 18; if (sx + 14 > W) sx = dx - 16; if (sx < 0) sx = Math.min(W - 14, dx + 2);
    const sy = wallTop - 15;
    R(sx - 1, sy - 2, 16, 2, '#3a2a1a'); R(sx + 2, sy, 1, 2, '#3a2a1a'); R(sx + 11, sy, 1, 2, '#3a2a1a');
    R(sx, sy + 2, 14, 12, '#5a3a1a'); R(sx + 1, sy + 3, 12, 10, d.board || '#d8b878'); R(sx + 1, sy + 3, 12, 1, '#f0d8a0');
    const ox = sx + 1, oy = sy + 3; SIGN_DRAW[d.sign]((a, y2, w, h, col) => R(ox + a, oy + y2, Math.min(w, 12 - a), Math.min(h, 10 - y2), col), d);
  }
  DECO_CACHE[key] = c; return c;
};
const ESTATE_DECO = {
  taverne:{sign:'mug', props:'barrels'}, werkstatt:{sign:'hammer', props:'anvil'}, freudenhaus:{sign:'rose', lantern:true, props:'flowers', board:'#e8c8d0'},
  kontor:{sign:'scales', awning:'#3a6a9a', props:'crates'}, bank:{sign:'coin', columns:true, board:'#e8e0c0'}, gilde:{sign:'shield', banners:'#2a4a8a'}
};
const TOWN_DECO = {laden:{sign:'bag', awning:'#3a7a4a'}, schmiede:{sign:'anvil', props:'anvil'}, taverne:{sign:'mug', props:'barrels'}, tempel:{sign:'holy', board:'#f0e8d0'}, gilde:{sign:'sword', banners:'#8a2a2a'},
  akademie:{sign:'book', banners:'#4a2a8a'}, moewe:{sign:'mug', props:'barrels'}, rabenkrug:{sign:'mug'}, bibliothek:{sign:'book'}};
function decorateTown() {
  for (const b of BUILDINGS) {
    if (b.estate && ESTATE_DECO[b.estate]) { b.deco = Object.assign({}, ESTATE_DECO[b.estate]); if (b.estate === 'gilde' && P && P.guild) b.deco.banners = '#2a4a8a'; continue; }
    if (b.tent || b.ship || b.tower) continue;
    const id = DOOR_LINK[idx(b.x + (b.door || 0), b.y + b.h - 1)];
    if (id && TOWN_DECO[id]) b.deco = TOWN_DECO[id];
  }
}
const _estateInteriorsE2 = estateInteriors;
estateInteriors = function () { _estateInteriorsE2(); decorateTown(); };
const _applyEstateE2 = applyEstate;
applyEstate = function () { _applyEstateE2(); if (!P || !P.biz) return; townIntegrate(); decorateTown(); refreshNpcs(); };

// ---------- Übersichtliches Besitz-Fenster ----------
function sec(b, t) { b.appendChild(el('div', 'esec', t)); }
function statGrid(b, items) { const g = el('div', 'egrid'); for (const [ic, label, val] of items) g.appendChild(el('div', 'ebox', '<span>' + ic + '</span><b>' + val + '</b><small>' + label + '</small>')); b.appendChild(g); }
function stars(n, max) { return '<span class="estars">' + '★'.repeat(n) + '<i>' + '★'.repeat(max - n) + '</i></span>'; }
function whereHint(b) { if (!canTrade()) b.appendChild(el('div', 'banner no', '📍 Kaufen, Ausbauen und Einstellen geht nur in Aldenmark, in der Neustadt oder in deinen eigenen Gebäuden.')); }
function renderHousesNew(b) {
  const here = inCity() && !regionAt(P.x, P.y).startsWith('i_h_');
  statGrid(b, [['🏠', 'Häuser', P.houses.length + '/' + Object.keys(HOUSES).length], ['⭐', 'Ansehen', Math.floor(P.rep.stadt)], ['💰', 'Gold', fmt(P.gold)]]);
  if (!here) b.appendChild(el('div', 'banner no', '📍 Häuser kaufst du in Aldenmark oder im Rattenviertel.'));
  const own = Object.keys(HOUSES).filter(id => P.houses.includes(id)), shop = Object.keys(HOUSES).filter(id => !P.houses.includes(id));
  sec(b, '🔑 Deine Häuser');
  if (!own.length) b.appendChild(el('p', 'hint', 'Du besitzt noch kein Haus.'));
  for (const id of own) {
    const h = HOUSES[id], f = (P.furn[id] || []).filter(Boolean), I = INTERIORS['h_' + id];
    b.appendChild(row(h.icon, h.name, (I ? '📍 ' + locName(I.exit[0], I.exit[1]) + '<br>' : '') + '🪑 Einrichtung ' + f.length + '/' + h.slots.length + (f.length ? ': ' + f.map(x => FURNITURE[x].icon).join(' ') : '') + '<br><small>Einrichten: Haus betreten und an den markierten Plätzen ✋ drücken.</small>'));
  }
  sec(b, '🏷️ Zu verkaufen');
  for (const id of shop) {
    const h = HOUSES[id], ok = repOk(h.rep);
    b.appendChild(row(h.icon, h.name + ' · ' + fmt(h.cost) + ' Gold', h.slots.length + ' Möbelplätze · Ansehen ' + h.rep + (ok ? ' ✓' : ' ✗'), [btn('Kaufen', () => { buyHouse(id); renderPanel(); }, 'gold', !here || P.gold < h.cost || !ok)], ok ? '' : 'dim'));
  }
}
function renderBizList(b) {
  const owned = Object.keys(P.biz), total = owned.reduce((s, id) => s + bizIncome(id), 0);
  statGrid(b, [['🏪', 'Betriebe', owned.length + '/' + Object.keys(BUSINESSES).length], ['💰', 'Gewinn pro Tag', '+' + fmt(total)], ['🏘️', 'Neustadt', TOWN_STAGES[townStage()].name]]);
  whereHint(b);
  if (owned.length) sec(b, '🏪 Deine Betriebe');
  for (const id of owned) {
    const z = BUSINESSES[id], s = P.biz[id];
    b.appendChild(row(z.icon, z.name + ' ' + stars(s.lvl, 5), '+' + bizIncome(id) + ' Gold/Tag · 👥 ' + Object.keys(s.staff).length + '/4 Personal · 🔨 ' + Object.keys(s.ext).length + '/3 Ausbauten', [btn('Verwalten ›', () => { UI.bizSel = id; renderPanel(); }, 'gold')]));
  }
  const free = Object.keys(BUSINESSES).filter(id => !P.biz[id]);
  if (free.length) sec(b, '🪧 Freie Bauplätze in der Neustadt');
  for (const id of free) {
    const z = BUSINESSES[id], ok = repOk(z.rep, z.thief);
    b.appendChild(row(z.icon, z.name + ' · ' + fmt(z.cost) + ' Gold', z.desc + '<br>ca. ' + z.income + ' Gold/Tag · Ansehen ' + z.rep + (ok ? ' ✓' : ' ✗'), [btn('Kaufen', () => { buyBiz(id); UI.bizSel = P.biz[id] ? id : null; renderPanel(); }, 'gold', !canTrade() || P.gold < z.cost || !ok)], ok ? '' : 'dim'));
  }
}
function renderBizDetail(b, id) {
  const z = BUSINESSES[id], s = P.biz[id], here = canTrade(), {s:bon, w} = bizStaffBonus(id), up = z.upCost * s.lvl;
  b.appendChild(btn('‹ Alle Betriebe', () => { UI.bizSel = null; renderPanel(); }));
  b.appendChild(el('div', 'etitle', z.icon + ' ' + z.name + ' ' + stars(s.lvl, 5)));
  statGrid(b, [['💰', 'Gewinn/Tag', '+' + bizIncome(id)], ['📈', 'Bonus', '+' + Math.round((bon + 0.05 * townStage()) * 100) + ' %'], ['💸', 'Löhne/Tag', w], ['🏦', 'Bisher verdient', fmt(s.total)]]);
  whereHint(b);
  sec(b, '🏗️ Gebäude');
  b.appendChild(row('🏗️', s.lvl < 5 ? 'Ausbauen auf Stufe ' + (s.lvl + 1) : 'Voll ausgebaut', s.lvl < 5 ? fmt(up) + ' Gold · größeres Gebäude, mehr Gäste, +50 % Grundgewinn' : 'Prächtiger geht es nicht.', s.lvl < 5 ? [btn('Ausbauen', () => { upgradeBiz(id); renderPanel(); }, 'gold', !here || P.gold < up)] : []));
  sec(b, '👥 Personal');
  for (const r in STAFF[id]) {
    const st = STAFF[id][r], has = s.staff[r], lock = s.lvl < st.lvl;
    b.appendChild(row(st.icon, st.name + (has ? ' <span class="eok">angestellt</span>' : ''), st.txt + '<br>+' + Math.round(st.bonus * 100) + ' % Gewinn · Lohn ' + st.wage + '/Tag' + (lock ? ' · <b>ab Stufe ' + st.lvl + '</b>' : ''),
      has ? [btn('Entlassen', () => { fireStaff(id, r); renderPanel(); })] : [btn('Einstellen · ' + st.cost, () => { hireStaff(id, r); renderPanel(); }, 'gold', !here || lock || P.gold < st.cost)], lock && !has ? 'dim' : ''));
  }
  sec(b, '🔨 Erweiterungen');
  for (const e in EXT[id]) {
    const x = EXT[id][e], has = s.ext[e], lock = s.lvl < x.lvl;
    b.appendChild(row(x.icon, x.name + (has ? ' <span class="eok">gebaut</span>' : ''), x.txt + (has ? '' : '<br>' + fmt(x.cost) + ' Gold') + (lock && !has ? ' · <b>ab Stufe ' + x.lvl + '</b>' : ''),
      has ? [] : [btn('Bauen', () => { buildExt(id, e); renderPanel(); }, 'gold', !here || lock || P.gold < x.cost)], lock && !has ? 'dim' : ''));
  }
}
function renderGuildClear(b) {
  const g = P.guild, here = canTrade();
  if (!g) return renderGuildNew(b);
  const sub = UI.gsub || 'overview', need = GUILD_REP_NEED[g.lvl] || 0, prev = GUILD_REP_NEED[g.lvl - 1] || 0;
  b.appendChild(el('div', 'etitle', '🛡️ ' + g.name + ' ' + stars(g.lvl, 5)));
  statGrid(b, [['⭐', 'Gildenansehen', Math.floor(g.rep) + (g.lvl < 5 ? ' / ' + need : '')], ['💰', 'Gildenkasse', fmt(g.gold)], ['🛏️', 'Zimmer belegt', roomOcc().length + '/' + guildRooms()], ['📜', 'Missionen', g.active.length + ' unterwegs']]);
  if (g.lvl < 5) b.appendChild(el('div', 'hint', 'Bis Gildenstufe ' + (g.lvl + 1) + ': <span class="pbar big"><i style="width:' + clamp(Math.round((g.rep - prev) / Math.max(1, need - prev) * 100), 0, 100) + '%"></i></span>'));
  subTabs(b, [['overview', '🏛️ Halle'], ['members', '👥 Mitglieder'], ['missions', '📜 Missionen' + (g.active.length ? ' (' + g.active.length + ')' : '')]], sub === 'staff' ? 'overview' : sub, k => UI.gsub = k);
  if (sub === 'overview' || sub === 'staff') {
    whereHint(b);
    sec(b, '💰 Gildenkasse');
    b.appendChild(row('💰', fmt(g.gold) + ' Gold', 'Beiträge der Mitglieder und Belohnungen aus Missionen landen hier.', [btn('Abheben', () => { P.gold += g.gold; g.gold = 0; sfx('coin'); renderPanel(); }, 'gold', !g.gold)]));
    sec(b, '🏗️ Gildenhalle');
    const c = g.lvl < 5 ? guildUpCost() : 0;
    b.appendChild(row('🏗️', g.lvl < 5 ? 'Ausbauen auf Stufe ' + (g.lvl + 1) : 'Voll ausgebaut', g.lvl < 5 ? fmt(c) + ' Gold (zuerst aus der Kasse) · Ansehen ' + need + (g.rep >= need ? ' ✓' : ' ✗') + '<br>→ ' + GUILD_ROOMS_BY_LVL[g.lvl] + ' Zimmer, größere Halle, mehr Missionen' : 'Die prächtigste Gildenhalle im Reich. +' + g.lvl * 5 + ' % Erfahrung für dich.',
      g.lvl < 5 ? [btn('Ausbauen', () => { upgradeGuild(); renderPanel(); }, 'gold', !here || g.rep < need || P.gold + g.gold < c)] : []));
    sec(b, '🧑‍💼 Personal (Lohn aus der Gildenkasse)');
    for (const r in GUILD_STAFF) {
      const s = GUILD_STAFF[r], has = g.staff[r], lock = g.lvl < s.lvl;
      b.appendChild(row(s.icon, s.name + (has ? ' <span class="eok">angestellt</span>' : ''), s.txt + ' · Lohn ' + s.wage + '/Tag' + (lock && !has ? ' · <b>ab Gildenstufe ' + s.lvl + '</b>' : ''),
        has ? [btn('Entlassen', () => { delete g.staff[r]; G.estateDirty = true; renderPanel(); })] : [btn('Einstellen · ' + s.cost, () => { hireGuildStaff(r); renderPanel(); }, 'gold', !here || lock || P.gold < s.cost)], lock && !has ? 'dim' : ''));
    }
  } else if (sub === 'members') {
    const full = roomOcc().length >= guildRooms();
    b.appendChild(row('➕', 'Neues Mitglied anwerben', recruitCost() + ' Gold · bekommt ein eigenes Zimmer' + (full ? ' · <b>alle Zimmer belegt – Halle ausbauen</b>' : ''), [btn('Anwerben', () => { recruitMember(); renderPanel(); }, 'gold', !here || full || P.gold < recruitCost())]));
    sec(b, '👥 Mitglieder (' + g.members.length + ')');
    const grid = el('div', 'emgrid');
    for (const m of g.members) {
      const c = M_CLS[m.cls], st = m.state === 'mission' ? '📜 unterwegs' : m.state === 'verletzt' ? '🤕 verletzt' : '🏠 daheim';
      const pic = el('canvas'); pic.width = 16; pic.height = 24; pic.getContext('2d').drawImage(makeHumanoid(m.look)[0], 0, 0);
      const card = el('div', 'emcard ' + m.state, '<img class="pix" src="' + pic.toDataURL() + '"><b>' + m.name + '</b><small>' + c.icon + ' ' + c.name + ' · St. ' + m.lvl + '</small><small>' + st + ' · ' + m.missions + ' Missionen</small>');
      if (m.state !== 'mission') card.appendChild(btn('Entlassen', () => { showDialog('Mitglied entlassen', m.name + ' wirklich aus der Gilde entlassen?', [{t:'Ja, entlassen', f:() => { g.members = g.members.filter(x => x !== m); G.estateDirty = true; setTimeout(renderPanel, 0); return 'close'; }}, {t:'Abbrechen'}]); }));
      grid.appendChild(card);
    }
    b.appendChild(grid);
    sec(b, '🧑‍🤝‍🧑 Gefährten in der Halle (' + g.residents.length + ')');
    b.appendChild(el('p', 'hint', 'Gefährten ziehen über das Gruppen-Fenster (👥) oder im Gespräch ein. Wer in der Halle wohnt und nicht in deiner Gruppe ist, kann auf Missionen.'));
    for (const id of g.residents) b.appendChild(row(compPic(id), COMPS[id].name + ' · Stufe ' + compLvl(id), P.party.includes(id) ? '👥 in deiner Gruppe' : onMission('c:' + id) ? '📜 auf Mission' : '🏠 wartet in der Halle', [btn('Ausziehen', () => { compMoveOut(id); renderPanel(); })]));
  } else {
    const list = guildBoard(), free = freeUnits();
    if (g.active.length) {
      sec(b, '⏳ Unterwegs');
      for (const a of g.active) { const h = Math.max(0, (a.end - nowT()) / DAY_LEN * 24); b.appendChild(row(M_TYPE_NAME[a.type].split(' ')[0], a.name, a.units.map(u => (unitInfo(u) || {}).name).join(', ') + '<br>zurück in ' + (h >= 1 ? 'ca. ' + Math.ceil(h) + ' Std.' : 'unter 1 Std.') + ' · Erfolg ' + Math.round(a.chance * 100) + ' %')); }
    }
    sec(b, '📜 Missionstafel · ' + free.length + ' frei');
    if (!list.length) b.appendChild(el('p', 'hint', 'Heute keine Aufträge mehr – morgen früh hängen neue an der Tafel.'));
    const sel = UI.msel && list.find(x => x.mid === UI.msel.mid) ? UI.msel : null;
    for (const ms of list) {
      const open = sel && sel.mid === ms.mid;
      b.appendChild(row(M_TYPE_NAME[ms.type].split(' ')[0], ms.name + ' <small>· Stufe ' + ms.L + '</small>', M_TYPE_NAME[ms.type] + ' · ' + ms.rec + ' empfohlen · ' + ms.hours + ' Std.<br>💰 ' + ms.gold + ' · ⭐ +' + ms.rep + (ms.item ? ' · 🎁 ' + ITEMS[ms.item].name : ''),
        [btn(open ? '✕' : 'Wählen', () => { UI.msel = open ? null : {mid:ms.mid, units:[]}; renderPanel(); }, open ? '' : 'gold')], open ? 'main' : ''));
      if (!open) continue;
      const box = el('div', 'emsel');
      box.appendChild(el('div', 'hint', 'Wer geht mit? (max. 4 · ★ = passende Klasse, zählt 40 % mehr)'));
      if (!free.length) box.appendChild(el('div', 'hint warn', 'Niemand ist frei. Wirb Mitglieder an oder lass Gefährten in der Halle wohnen.'));
      const chips = el('div', 'echips');
      for (const u of free) { const i = unitInfo(u), on = sel.units.includes(u); chips.appendChild(btn((on ? '✅ ' : '') + i.icon + ' ' + i.name + ' ' + i.lvl + (i.aff === ms.type ? ' ★' : ''), () => { if (on) sel.units = sel.units.filter(x => x !== u); else if (sel.units.length < 4) sel.units.push(u); renderPanel(); }, on ? 'gold' : '')); }
      box.appendChild(chips);
      const ch = sel.units.length ? missionChance(ms, sel.units) : 0;
      if (sel.units.length) box.appendChild(el('div', 'hint', 'Erfolgschance: <span class="pbar big"><i style="width:' + Math.round(ch * 100) + '%;background:' + (ch > 0.7 ? '#5aa040' : ch > 0.4 ? '#d8a830' : '#c84a3a') + '"></i></span> ' + Math.round(ch * 100) + ' %'));
      box.appendChild(btn('🚩 Aussenden', () => { sendMission(ms, sel.units); UI.msel = null; renderPanel(); }, 'gold', !sel.units.length));
      b.appendChild(box);
    }
  }
}
PANELS.estate.render = function (b, tab) {
  if (tab === 'house') return renderHousesNew(b);
  if (tab === 'town') return renderTown(b);
  if (tab === 'biz') { if (UI.focus && P.biz[UI.focus]) { UI.bizSel = UI.focus; UI.focus = null; } return UI.bizSel && P.biz[UI.bizSel] ? renderBizDetail(b, UI.bizSel) : renderBizList(b); }
  return renderGuildClear(b);
};
// Beim Öffnen des Besitz-Fensters wieder bei der Übersicht beginnen
const _openPanelE2 = openPanel;
openPanel = function (type, tab) { if (type === 'estate' && !UI.focus) UI.bizSel = null; return _openPanelE2(type, tab); };
