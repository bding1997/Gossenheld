'use strict';
// ================= SPIELDATEN =================
const DISC = {
  kampf:{name:'Kampf',icon:'⚔️',stat:'str'}, magie:{name:'Magie',icon:'🔥',stat:'int'},
  bogen:{name:'Bogen',icon:'🏹',stat:'dex'}, heil:{name:'Heilung',icon:'✨',stat:'wis'}
};
const STAT_NAMES = {str:'Stärke',dex:'Geschick',int:'Intelligenz',vit:'Vitalität',wis:'Weisheit'};
const STAT_DESC = {str:'Nahkampfschaden',dex:'Bogenschaden, Kritische Treffer, Tempo',int:'Zauberschaden, Energie',vit:'Lebenspunkte, Rüstung',wis:'Heilung, Energie-Regeneration'};
const RACES = {
  mensch:{name:'Mensch',bonus:{str:1,dex:1,int:1,vit:1,wis:1},skin:'#e9b896',desc:'Vielseitig und zäh. +1 auf alle Werte.',trait:'Händlerblut: 10 % bessere Preise.'},
  elf:{name:'Elf',bonus:{dex:3,int:2,vit:-1},skin:'#f3d6bb',desc:'Flink, scharfäugig, magiebegabt.',trait:'Adlerauge: +10 % Bogenschaden, größere Sicht beim Erkunden.'},
  zwerg:{name:'Zwerg',bonus:{str:2,vit:3,dex:-1},skin:'#dba27c',desc:'Stur, robust, geboren am Amboss.',trait:'Schmiedeblut: +50 % Erfahrung in Schmieden & Bergbau.'},
  ork:{name:'Halbork',bonus:{str:4,vit:2,int:-2},skin:'#86a85c',desc:'Wild, stark, unterschätzt.',trait:'Wildes Blut: +10 % Nahkampfschaden, zähmt Tiere leichter.'}
};
const HYBRID_EFF = 0.8;
const CLASSES = {
  krieger:{name:'Krieger',disc:{kampf:1},base:{str:7,dex:3,int:1,vit:6,wis:2},outfit:'#8a2d2d',outfit2:'#4a3a2a',start:{waffe:'messer'},desc:'Meister des Nahkampfs. Viel Leben, harte Schläge.'},
  magier:{name:'Magier',disc:{magie:1},base:{str:2,dex:3,int:8,vit:3,wis:4},outfit:'#3a4a9a',outfit2:'#2a2a4a',start:{waffe:'knorrstab',ruestung:'robe'},desc:'Zerstörerische Zauber aus sicherer Entfernung.'},
  bogen:{name:'Bogenschütze',disc:{bogen:1},base:{str:3,dex:8,int:2,vit:4,wis:2},outfit:'#3f6a35',outfit2:'#4a3a2a',start:{waffe:'kurzbogen'},desc:'Präzise Schüsse aus der Distanz. Braucht Pfeile im Köcher.'},
  heiler:{name:'Heiler',disc:{heil:1},base:{str:2,dex:2,int:4,vit:4,wis:8},outfit:'#d8d0b0',outfit2:'#8a7a4a',start:{waffe:'pilgerstab',ruestung:'robe'},desc:'Hält sich und die Gruppe am Leben, straft mit heiligem Licht.'},
  hybrid:{name:'Hybrid',disc:null,base:{str:4,dex:4,int:4,vit:5,wis:3},outfit:'#6a4a8a',outfit2:'#3a2a3a',desc:'Wähle zwei Disziplinen frei – z. B. Kampfmagier. In beiden mit 80 % Wirkung etwas schwächer als die Spezialisten, dafür flexibel.'}
};
const HYB_WEAPON = {kampf:'messer', magie:'knorrstab', bogen:'kurzbogen', heil:'pilgerstab'};
const SKILLS = {
  wirbel:{d:'kampf',name:'Wirbelschlag',icon:'🌀',lvl:1,cost:12,cd:4,desc:'Trifft alle Gegner um dich herum.'},
  schrei:{d:'kampf',name:'Kriegsschrei',icon:'📣',lvl:3,cost:15,cd:18,desc:'+35 % Schaden für dich und deine Gruppe (10 s).'},
  ansturm:{d:'kampf',name:'Ansturm',icon:'💨',lvl:6,cost:14,cd:6,desc:'Stürmt vorwärts, trifft und schleudert Gegner weg.'},
  beben:{d:'kampf',name:'Erdbeben',icon:'💥',lvl:10,cost:30,cd:14,desc:'Gewaltiger Flächenschaden, betäubt Gegner 2 s.'},
  feuerball:{d:'magie',name:'Feuerball',icon:'🔥',lvl:1,cost:10,cd:1.6,desc:'Explodierendes Geschoss mit Flächenschaden.'},
  frost:{d:'magie',name:'Frostnova',icon:'❄️',lvl:3,cost:16,cd:8,desc:'Schaden um dich herum, verlangsamt Gegner.'},
  blitz:{d:'magie',name:'Kettenblitz',icon:'⚡',lvl:6,cost:18,cd:4,desc:'Springt auf bis zu 4 Gegner über.'},
  meteor:{d:'magie',name:'Meteor',icon:'☄️',lvl:10,cost:35,cd:15,desc:'Ein Meteor schlägt beim nächsten Gegner ein.'},
  mehrfach:{d:'bogen',name:'Mehrfachschuss',icon:'🎯',lvl:1,cost:10,cd:3,desc:'5 Pfeile im Fächer (verbraucht 1 Pfeil).'},
  gift:{d:'bogen',name:'Giftpfeil',icon:'☠️',lvl:3,cost:12,cd:5,desc:'Vergiftet das Ziel – Schaden über Zeit.'},
  rolle:{d:'bogen',name:'Ausweichrolle',icon:'🤸',lvl:6,cost:8,cd:5,desc:'Rolle zurück, kurz unverwundbar.'},
  hagel:{d:'bogen',name:'Pfeilhagel',icon:'🌧️',lvl:10,cost:30,cd:14,desc:'Pfeile regnen 2 s lang auf ein Gebiet.'},
  heilung:{d:'heil',name:'Heilung',icon:'💚',lvl:1,cost:14,cd:3,desc:'Heilt dich und alle Gefährten in der Nähe.'},
  licht:{d:'heil',name:'Heiliges Licht',icon:'🌟',lvl:3,cost:10,cd:2,desc:'Lichtgeschoss, doppelter Schaden gegen Untote.'},
  segen:{d:'heil',name:'Segen',icon:'🙏',lvl:6,cost:20,cd:20,desc:'Gruppe regeneriert Leben und erhält +10 Rüstung (15 s).'},
  wunder:{d:'heil',name:'Wunder',icon:'👼',lvl:10,cost:40,cd:40,desc:'Volle Heilung der Gruppe, belebt Bewusstlose.'}
};
const PROFS = {
  holz:{name:'Holzfällen',icon:'🪓',learn:false},
  bergbau:{name:'Bergbau',icon:'⛏️',learn:false},
  sammeln:{name:'Kräuterkunde',icon:'🌿',learn:false},
  schmieden:{name:'Schmieden & Handwerk',icon:'🔨',learn:true,price:150},
  kochen:{name:'Kochen & Alchemie',icon:'🍲',learn:true,price:80},
  schloss:{name:'Schlösserknacken',icon:'🗝️',learn:true,price:100},
  diebstahl:{name:'Taschendiebstahl',icon:'👛',learn:true,price:120},
  zaehmen:{name:'Tierzähmung',icon:'🐺',learn:true,price:120}
};
// ---------- Gegenstände ----------
const ITEMS = {};
function defI(id, o) { ITEMS[id] = Object.assign({id, stack:false, val:1, type:'mat'}, o); }
[['holz','Holz','🪵',2],['stein','Stein','🪨',2],['eisenerz','Eisenerz','🟤',6],['silbererz','Silbererz','⚪',15],['mithrilerz','Mithrilerz','🔷',45],
 ['eisenbarren','Eisenbarren','🔩',16],['silberbarren','Silberbarren','🥈',40],['mithrilbarren','Mithrilbarren','💠',150],
 ['kristall','Magiekristall','💎',35],['schattenkristall','Schattenkristall','🔮',60],['kraut','Heilkraut','🌿',4],['pilz','Waldpilz','🍄',4],
 ['fleisch','Rohes Fleisch','🥩',5],['fell','Fell','🐾',8],['leder','Leder','🟫',14],['knochen','Knochen','🦴',3],['schuppe','Drachenschuppe','🐉',300]
].forEach(a => defI(a[0], {name:a[1], icon:a[2], val:a[3], stack:true}));
defI('blume', {name:'Wildblume', icon:'🌸', val:3, stack:true, gift:true});
defI('wein', {name:'Elfenwein', icon:'🍷', val:25, stack:true, gift:true});
defI('buch', {name:'Altes Buch', icon:'📕', val:30, stack:true, gift:true});
defI('ring', {name:'Silberring', icon:'💍', val:150, stack:true, gift:true});
defI('rechnungsbuch', {name:'Baldurs Rechnungsbuch', icon:'📒', val:0, type:'quest', stack:true});
defI('brot', {name:'Brot', icon:'🍞', val:4, type:'food', heal:20, stack:true});
defI('bier', {name:'Bier', icon:'🍺', val:5, type:'food', heal:8, buff:['mut',120], stack:true, gift:true});
defI('gebraten', {name:'Gebratenes Fleisch', icon:'🍖', val:12, type:'food', heal:35, stack:true});
defI('eintopf', {name:'Waldeintopf', icon:'🍲', val:30, type:'food', heal:80, buff:['satt',180], stack:true});
defI('festmahl', {name:'Heldenmahl', icon:'🍗', val:90, type:'food', heal:999, buff:['held',300], stack:true});
defI('heiltrank', {name:'Heiltrank', icon:'🧪', val:25, type:'food', heal:70, stack:true});
defI('grheiltrank', {name:'Großer Heiltrank', icon:'⚗️', val:80, type:'food', heal:220, stack:true});
defI('manatrank', {name:'Energietrank', icon:'💧', val:30, type:'food', mana:60, stack:true});
defI('pfeile', {name:'Pfeile (20 Stück)', icon:'🪶', val:8, type:'ammo', amount:20, stack:true});
defI('axt', {name:'Axt', icon:'🪓', val:20, type:'tool'});
defI('spitzhacke', {name:'Spitzhacke', icon:'⛏️', val:40, type:'tool'});
defI('kochset', {name:'Kochgeschirr', icon:'🍳', val:35, type:'tool'});
defI('dietrich', {name:'Dietrich', icon:'🗝️', val:10, type:'tool', stack:true});
function W(id, name, icon, wt, dmg, val, ex) { defI(id, Object.assign({name, icon, type:'waffe', wt, dmg, val}, ex || {})); }
W('messer','Rostiges Messer','🔪','melee',4,5); W('kurzschwert','Kurzschwert','🗡️','melee',8,45); W('eisenschwert','Eisenschwert','⚔️','melee',14,130);
W('kriegsaxt','Kriegsaxt','🪓','melee',18,260); W('silberschwert','Silberklinge','⚔️','melee',23,420,{holy:true}); W('mithrilklinge','Mithrilklinge','⚔️','melee',34,1300);
W('drachentoeter','Drachentöter','🗡️','melee',48,4000);
W('kurzbogen','Kurzbogen','🏹','bow',6,30); W('langbogen','Langbogen','🏹','bow',12,160); W('elfenbogen','Elfenbogen','🏹','bow',21,520); W('mithrilbogen','Mithrilbogen','🏹','bow',33,1500);
W('knorrstab','Knorriger Stab','🪄','staff',5,20); W('pilgerstab','Pilgerstab','🪄','staff',5,20,{healBonus:0.2}); W('kristallstab','Kristallstab','🪄','staff',13,190);
W('arkanstab','Arkanstab','🪄','staff',23,650); W('sternenstab','Sternenstab','🪄','staff',34,1600,{healBonus:0.2});
function A(id, name, icon, def, val, ex) { defI(id, Object.assign({name, icon, type:'ruestung', def, val}, ex || {})); }
A('lumpen','Zerlumpte Kleidung','👕',1,1); A('robe','Leinenrobe','🥻',2,25,{bonus:{int:1,wis:1}}); A('lederruestung','Lederrüstung','🦺',5,70);
A('magierrobe','Magierrobe','🥻',5,320,{bonus:{int:4,wis:3}}); A('kettenhemd','Kettenhemd','🥋',9,240); A('plattenruestung','Plattenrüstung','🛡️',15,650);
A('mithrilruestung','Mithrilrüstung','🛡️',23,2100); A('drachenruestung','Drachenschuppenpanzer','🐲',32,6000,{bonus:{vit:5}});
defI('koecher_klein', {name:'Kleiner Köcher', icon:'🎯', type:'koecher', cap:30, val:10});
defI('koecher', {name:'Lederköcher', icon:'🎯', type:'koecher', cap:60, val:60});
defI('koecher_gross', {name:'Großer Köcher', icon:'🎯', type:'koecher', cap:120, val:200});
defI('elfenkoecher', {name:'Elfenköcher', icon:'🎯', type:'koecher', cap:220, val:600});
defI('beutel', {name:'Stoffbeutel', icon:'👝', type:'rucksack', slots:12, val:5});
defI('rucksack', {name:'Lederrucksack', icon:'🎒', type:'rucksack', slots:20, val:80});
defI('grosser_rucksack', {name:'Großer Rucksack', icon:'🎒', type:'rucksack', slots:28, val:250});
defI('packtasche', {name:'Abenteurer-Packtasche', icon:'🎒', type:'rucksack', slots:36, val:700});
defI('dimensionsbeutel', {name:'Dimensionsbeutel', icon:'🌌', type:'rucksack', slots:50, val:2500});
defI('amulett', {name:'Schutzamulett der Hexe', icon:'🧿', type:'schmuck', bonus:{vit:4,wis:4}, def:4, val:500});
defI('glueckstaler', {name:'Glückstaler', icon:'🪙', type:'schmuck', bonus:{dex:3}, luck:0.15, val:300});
defI('koenigssiegel', {name:'Königssiegel', icon:'👑', type:'schmuck', bonus:{str:3,dex:3,int:3,vit:3,wis:3}, val:2000});
const ARMOR_COLOR = {lumpen:'#7a6a58', lederruestung:'#7a5432', kettenhemd:'#8a8c98', plattenruestung:'#a8aab8', mithrilruestung:'#7ac8e0', drachenruestung:'#9a2a1a', magierrobe:'#33339a'};
// ---------- Rezepte ----------
const RECIPES = [
  {out:'leder',req:{fell:1},prof:'schmieden',lvl:0},
  {out:'pfeile',req:{holz:2,stein:1},prof:'schmieden',lvl:0},
  {out:'gebraten',req:{fleisch:1},prof:'kochen',lvl:0,st:'feuer'},
  {out:'heiltrank',req:{kraut:3},prof:'kochen',lvl:1,st:'feuer'},
  {out:'eintopf',req:{fleisch:1,pilz:2,kraut:1},prof:'kochen',lvl:2,st:'feuer'},
  {out:'manatrank',req:{kraut:2,kristall:1},prof:'kochen',lvl:3,st:'feuer'},
  {out:'grheiltrank',req:{heiltrank:2,pilz:2},prof:'kochen',lvl:5,st:'feuer'},
  {out:'festmahl',req:{gebraten:2,eintopf:1,wein:1},prof:'kochen',lvl:7,st:'feuer'},
  {out:'eisenbarren',req:{eisenerz:2},prof:'schmieden',lvl:1,st:'amboss'},
  {out:'silberbarren',req:{silbererz:2},prof:'schmieden',lvl:3,st:'amboss'},
  {out:'mithrilbarren',req:{mithrilerz:3},prof:'schmieden',lvl:6,st:'amboss'},
  {out:'dietrich',n:3,req:{eisenbarren:1},prof:'schmieden',lvl:1,st:'amboss'},
  {out:'kochset',req:{eisenbarren:2},prof:'schmieden',lvl:1,st:'amboss'},
  {out:'spitzhacke',req:{eisenbarren:2,holz:2},prof:'schmieden',lvl:1,st:'amboss'},
  {out:'lederruestung',req:{leder:4},prof:'schmieden',lvl:1},
  {out:'koecher',req:{leder:3},prof:'schmieden',lvl:1},
  {out:'rucksack',req:{leder:4},prof:'schmieden',lvl:1},
  {out:'kurzschwert',req:{eisenbarren:2,holz:1},prof:'schmieden',lvl:1,st:'amboss'},
  {out:'eisenschwert',req:{eisenbarren:3,holz:1},prof:'schmieden',lvl:2,st:'amboss'},
  {out:'langbogen',req:{holz:5,leder:2},prof:'schmieden',lvl:2},
  {out:'kettenhemd',req:{eisenbarren:5},prof:'schmieden',lvl:3,st:'amboss'},
  {out:'kristallstab',req:{holz:2,kristall:2},prof:'schmieden',lvl:3},
  {out:'grosser_rucksack',req:{leder:8,eisenbarren:1},prof:'schmieden',lvl:3},
  {out:'koecher_gross',req:{leder:6,silberbarren:1},prof:'schmieden',lvl:4,st:'amboss'},
  {out:'ring',req:{silberbarren:1,kristall:1},prof:'schmieden',lvl:4,st:'amboss'},
  {out:'silberschwert',req:{silberbarren:3,eisenbarren:2},prof:'schmieden',lvl:5,st:'amboss'},
  {out:'elfenbogen',req:{holz:6,silberbarren:2,leder:2},prof:'schmieden',lvl:5},
  {out:'plattenruestung',req:{eisenbarren:6,silberbarren:2},prof:'schmieden',lvl:6,st:'amboss'},
  {out:'arkanstab',req:{kristall:3,silberbarren:2,schattenkristall:1},prof:'schmieden',lvl:6},
  {out:'packtasche',req:{leder:12,silberbarren:2},prof:'schmieden',lvl:6},
  {out:'elfenkoecher',req:{leder:8,mithrilbarren:1},prof:'schmieden',lvl:7},
  {out:'mithrilklinge',req:{mithrilbarren:3,kristall:1},prof:'schmieden',lvl:8,st:'amboss'},
  {out:'mithrilbogen',req:{mithrilbarren:2,kristall:2,leder:3},prof:'schmieden',lvl:8,st:'amboss'},
  {out:'sternenstab',req:{mithrilbarren:2,kristall:4},prof:'schmieden',lvl:8,st:'amboss'},
  {out:'mithrilruestung',req:{mithrilbarren:5},prof:'schmieden',lvl:9,st:'amboss'},
  {out:'dimensionsbeutel',req:{kristall:5,mithrilbarren:2,leder:10},prof:'schmieden',lvl:9},
  {out:'drachenruestung',req:{schuppe:5,mithrilbarren:3},prof:'schmieden',lvl:10,st:'amboss'},
  {out:'drachentoeter',req:{schuppe:3,mithrilbarren:4},prof:'schmieden',lvl:10,st:'amboss'}
];
// ---------- Gegner ----------
const ENEMIES = {
  ratte:{name:'Riesenratte',shape:'quad',size:0.7,col:'#6e5d50',hp:14,dmg:3,spd:2.3,xp:7,gold:[0,3],drops:[['fleisch',0.25]],lvl:1},
  wolf:{name:'Wolf',shape:'quad',size:1,col:'#7d7d85',hp:34,dmg:6,spd:3.2,xp:16,drops:[['fell',0.7],['fleisch',0.5]],lvl:3,tame:{lvl:1,roles:['kampf']}},
  eber:{name:'Wildschwein',shape:'quad',size:0.95,col:'#5c4030',hp:46,dmg:8,spd:2.6,xp:20,drops:[['fleisch',0.9],['leder',0.3]],lvl:4,tame:{lvl:2,roles:['kampf']}},
  hirsch:{name:'Hirsch',shape:'quad',size:1.1,col:'#a8743c',col2:'#e8dcc0',antler:true,hp:30,dmg:0,spd:3.6,xp:10,drops:[['fleisch',1],['fell',0.6]],lvl:2,passive:true,tame:{lvl:2,roles:['reit'],speed:1.6,food:'kraut'}},
  pferd:{name:'Wildpferd',shape:'quad',size:1.25,col:'#6b4a2a',col2:'#2a1a0a',mane:true,hp:40,dmg:0,spd:3.8,xp:12,drops:[['fell',0.5]],lvl:3,passive:true,tame:{lvl:3,roles:['reit'],speed:1.8,food:'kraut'}},
  goldhirsch:{name:'Goldener Hirsch',shape:'quad',size:1.2,col:'#e8c040',col2:'#fff3a0',antler:true,hp:60,dmg:0,spd:4,xp:80,drops:[],lvl:6,passive:true,tame:{lvl:1,roles:['reit'],speed:2.2,food:'kraut'}},
  goblin:{name:'Goblin',shape:'hum',col:'#5d8a3a',outfit:'#6b4a2a',ears:true,bald:true,hp:38,dmg:7,spd:2.5,xp:22,gold:[2,9],drops:[['eisenerz',0.2],['kurzschwert',0.03],['dietrich',0.1]],lvl:4},
  goblinboss:{name:'Häuptling Grisk',shape:'hum',size:1.5,col:'#4d7a2a',outfit:'#8a2a2a',ears:true,helm:true,hair:'#9a9aa0',hp:320,dmg:14,spd:2.4,xp:250,gold:[60,90],drops:[['glueckstaler',1]],lvl:7,boss:true},
  bandit:{name:'Bandit',shape:'hum',col:'#e0b090',outfit:'#4a4a4a',hair:'#2a1a1a',hp:58,dmg:9,spd:2.7,xp:30,gold:[8,25],drops:[['dietrich',0.25],['heiltrank',0.15],['bier',0.2]],lvl:5},
  bandit_bogen:{name:'Banditenschütze',shape:'hum',col:'#e0b090',outfit:'#3a5a3a',hair:'#5a3a1a',hp:44,dmg:8,spd:2.6,xp:30,gold:[8,25],drops:[['pfeile',0.4]],lvl:5,ranged:true,proj:'arrow'},
  baer:{name:'Bär',shape:'quad',size:1.45,col:'#4a3220',hp:110,dmg:15,spd:2.6,xp:55,drops:[['fell',1],['fleisch',1],['leder',0.4]],lvl:8,tame:{lvl:5,roles:['kampf','reit'],speed:1.5}},
  skelett:{name:'Skelett',shape:'hum',col:'#e8e4d8',outfit:'#9a9488',bald:true,eye:'#c03030',hp:64,dmg:11,spd:2.3,xp:40,gold:[3,15],drops:[['knochen',0.8],['buch',0.05]],lvl:8,undead:true},
  schleim:{name:'Sumpfschleim',shape:'slime',col:'#5a8a4a',hp:58,dmg:10,spd:1.8,xp:38,drops:[['kraut',0.4]],lvl:7},
  troll:{name:'Bergtroll',shape:'hum',size:1.6,col:'#7a8a9a',outfit:'#5a4a3a',bald:true,hp:190,dmg:20,spd:2.1,xp:95,gold:[10,40],drops:[['silbererz',0.6],['kristall',0.3]],lvl:11},
  soldat:{name:'Morvath-Soldat',shape:'hum',col:'#c9a890',outfit:'#3a2030',helm:true,hair:'#4a4a54',hp:140,dmg:18,spd:2.6,xp:110,gold:[15,45],drops:[['eisenbarren',0.4],['grheiltrank',0.1]],lvl:13},
  soldat_bogen:{name:'Morvath-Armbrustschütze',shape:'hum',col:'#c9a890',outfit:'#2a2a3a',helm:true,hair:'#4a4a54',hp:110,dmg:16,spd:2.5,xp:110,gold:[15,40],drops:[['pfeile',0.5]],lvl:13,ranged:true,proj:'arrow'},
  warg:{name:'Warg',shape:'quad',size:1.3,col:'#2a2228',hp:130,dmg:19,spd:3.4,xp:100,drops:[['fell',1],['fleisch',0.8]],lvl:13,tame:{lvl:7,roles:['kampf','reit'],speed:1.8}},
  schattenritter:{name:'Schattenritter',shape:'hum',size:1.2,col:'#3a3a4a',outfit:'#1a1020',helm:true,hair:'#2a2a34',eye:'#a040f0',hp:260,dmg:26,spd:2.5,xp:200,gold:[30,80],drops:[['schattenkristall',0.5],['mithrilerz',0.4]],lvl:16,undead:true},
  varek:{name:'Gesandter Varek',shape:'hum',size:1.2,col:'#e0c0a0',outfit:'#4a1a3a',hair:'#1a1a1a',hp:520,dmg:22,spd:2.8,xp:600,gold:[200,300],drops:[],lvl:12,boss:true,ranged:true,proj:'shadow'},
  hexe:{name:'Morla die Sumpfhexe',shape:'hum',size:1.1,col:'#a0c090',outfit:'#2a4a2a',hair:'#2a2a2a',hp:600,dmg:24,spd:2.4,xp:700,gold:[100,200],drops:[['arkanstab',1]],lvl:14,boss:true,ranged:true,proj:'shadow'},
  malgor:{name:'Schattenfürst Malgor',shape:'hum',size:2,col:'#6a5a7a',outfit:'#120818',helm:true,hair:'#3a1a4a',eye:'#f04040',hp:2200,dmg:36,spd:2.4,xp:4000,gold:[1000,1500],drops:[],lvl:20,boss:true,ranged:true,proj:'shadow',undead:true},
  wyrm:{name:'Aschewyrm',shape:'quad',size:2.6,col:'#8a2a1a',col2:'#ffb030',wings:true,hp:3500,dmg:48,spd:2.2,xp:6000,gold:[2000,3000],drops:[['schuppe',1,6]],lvl:25,boss:true,ranged:true,proj:'fire'}
};
const SPAWNS = {
  gosse:[['ratte',1]], wald:[['wolf',3],['goblin',2],['eber',2],['hirsch',2]], goblinlager:[['goblin',1]],
  wiese:[['eber',2],['hirsch',2],['pferd',2],['wolf',1],['bandit',1]], lager:[['bandit',3],['bandit_bogen',2]], ruinen:[['skelett',1]],
  berge:[['wolf',2],['baer',2],['troll',1]], mine:[['troll',1]], sumpf:[['schleim',3],['skelett',1]], hexe:[['schleim',1]],
  morvath:[['soldat',3],['soldat_bogen',2],['warg',2],['schattenritter',1]], festung:[['soldat',2],['schattenritter',2]], hort:[]
};
const NIGHT_EXTRA = {wiese:[['skelett',1],['wolf',2]], wald:[['wolf',2],['skelett',1]], gosse:[['bandit',1]]};
const BOSS_POS = {goblinboss:[20,28.5], varek:[84.5,96.6], hexe:[130.5,86.6], malgor:[139.5,144.5], wyrm:[142.5,12.5]};
// ---------- Besitz ----------
const HOUSES = {
  huette:{name:'Hütte im Rattenviertel',icon:'🛖',cost:400,slots:2,pos:[60.5,116.5]},
  stadthaus:{name:'Stadthaus in Aldenmark',icon:'🏠',cost:2500,slots:4,pos:[82.5,101.5]},
  anwesen:{name:'Anwesen am Burgberg',icon:'🏰',cost:9000,slots:7,pos:[82.5,96.5]}
};
const FURNITURE = {
  bett:{name:'Bett',icon:'🛏️',cost:80,desc:'Schlafen bis zum Morgen, speichern, Wiederbelebungspunkt.'},
  truhe:{name:'Truhe',icon:'🧰',cost:120,desc:'Lager für 30 Gegenstände.'},
  herd:{name:'Herd',icon:'🔥',cost:200,desc:'Kochen in deinem Zuhause.'},
  amboss:{name:'Amboss',icon:'⚒️',cost:400,desc:'Schmieden in deinem Zuhause.'},
  trophaeen:{name:'Trophäenwand',icon:'🦌',cost:600,desc:'+5 % Erfahrung.'},
  altar:{name:'Hausaltar',icon:'🕯️',cost:700,desc:'+10 % maximales Leben.'},
  bibliothek:{name:'Bibliothek',icon:'📚',cost:900,desc:'+15 % Berufserfahrung.'}
};
const BUSINESSES = {
  taverne:{name:'Taverne „Zum Goldenen Krug“',icon:'🍺',cost:2000,income:70,upCost:1200,desc:'Bier, Eintopf und Klatsch. Bringt zuverlässig Münzen.'},
  werkstatt:{name:'Handwerkerwerkstatt',icon:'🔨',cost:3000,income:100,upCost:1800,desc:'Gesellen reparieren Werkzeug für die halbe Stadt.'},
  freudenhaus:{name:'Freudenhaus „Rote Laterne“',icon:'🏮',cost:4000,income:140,upCost:2500,desc:'Diskret, teuer, immer gut besucht.'},
  kontor:{name:'Handelskontor',icon:'📦',cost:6000,income:200,upCost:3500,desc:'Fernhandel mit Gewürzen und Tuch.'},
  bank:{name:'Bank von Aldenmark',icon:'🏦',cost:12000,income:380,upCost:7000,desc:'Geld vermehrt sich am besten von selbst.'}
};
// ---------- Läden ----------
const SHOPS = {
  baldur:['brot','heiltrank','manatrank','pfeile','dietrich','axt','spitzhacke','kochset','fleisch','wein','buch','beutel','rucksack','koecher','koecher_klein','kurzschwert','kurzbogen','knorrstab','lederruestung'],
  gunnar:['eisenbarren','kurzschwert','eisenschwert','kriegsaxt','langbogen','lederruestung','kettenhemd','plattenruestung','spitzhacke','axt','dietrich','koecher_gross','grosser_rucksack'],
  rosa:['brot','bier','wein','gebraten','eintopf','heiltrank'],
  mira:['heiltrank','grheiltrank','manatrank','robe','magierrobe','kristallstab','pilgerstab'],
  krumm:['dietrich','heiltrank','glueckstaler'],
  wilma:['fleisch','fell','leder','langbogen','koecher','pfeile','kraut'],
  brann:['eisenerz','silbererz','eisenbarren','silberbarren','mithrilbarren','spitzhacke'],
  morla:['grheiltrank','manatrank','kristall','schattenkristall','arkanstab'],
  zeb:['elfenbogen','arkanstab','packtasche','koecher_gross','grheiltrank','mithrilbarren','kristall','festmahl','ring','silberschwert']
};
const RUMORS = [
  '„In den Ruinen von Valdrin im Westen sollen noch Schätze der alten Könige liegen. Und Untote, die darüber wachen.“',
  '„Hoch oben im Nordosten der Eisenzahn-Berge schläft der Aschewyrm. Wer ihn bezwingt, wird in Liedern unsterblich.“',
  '„Manchmal zeigt sich in den Wiesen ein goldener Hirsch. Wer ihn zähmt, reitet schneller als der Wind.“',
  '„Die Banditen im Südwesten horten ihre Beute in einer Truhe mitten im Lager.“',
  '„Wildpferde grasen in den Goldwiesen. Die Jägerin Wilma in Eichenrast lehrt, wie man Tiere zähmt.“',
  '„In der Zwergenmine Tiefgrund gibt es Silber. Und leider auch Trolle.“',
  '„Im Nebelsumpf lebt eine Hexe. Manche sagen, sie hilft Reisenden. Andere sagen, sie kocht sie.“',
  '„Wer genug Gold hat, sollte mit Makler Ulrich reden. Eine eigene Taverne – das wär was!“',
  '„Nachts kriechen Skelette aus der Erde. Bleib auf den Straßen, wenn es dunkel ist.“',
  '„Jenseits des Flusses im Südosten beginnt Morvath. Schattenfürst Malgor sammelt dort ein Heer.“',
  '„Ein Kristall, ein paar Kräuter und ein Feuer – mehr braucht ein guter Alchemist nicht für einen Energietrank.“',
  '„Sternschnuppen bringen Glück. Und manchmal Mithril, wenn man weiß, wo sie einschlagen.“'
];
const RIDDLES = [
  {q:'„Ich habe Städte, aber keine Häuser. Wälder, aber keine Bäume. Wasser, aber keine Fische. Was bin ich?“', a:['Eine Karte','Ein Traum','Ein Spiegel'], c:0},
  {q:'„Je mehr du davon machst, desto mehr lässt du hinter dir.“', a:['Gold','Schritte','Feinde'], c:1},
  {q:'„Es gehört dir, doch andere benutzen es viel öfter als du.“', a:['Dein Schwert','Dein Name','Dein Haus'], c:1},
  {q:'„Ich spreche ohne Mund und höre ohne Ohren. Ich habe keinen Körper, doch ich erwache mit dem Wind.“', a:['Ein Geist','Ein Echo','Eine Flöte'], c:1},
  {q:'„Was wird nasser, je mehr es trocknet?“', a:['Ein Handtuch','Ein Fluss','Ein Schwamm im Feuer'], c:0}
];
// ---------- Gefährten ----------
const COMPS = {
  grimm:{name:'Grimm',title:'Halbork-Söldner',cls:'kampf',hp:95,dmg:9,home:[63.5,116.6],cost:150,look:{skin:'#86a85c',hair:'#2a2a2a',outfit:'#5a4a3a'},likes:['fleisch','bier','gebraten'],
    bio:'„Grimm. Söldner. Ich kämpfe für Gold – oder für Leute, die ich mag. Meistens für Gold.“',
    lines:['„Red nicht so viel. Kämpf lieber.“','„Du bist zäher, als du aussiehst. Das mag ich.“','„Wenn dir jemand wehtut, reiß ich ihm den Arm ab. Nur damit du’s weißt.“']},
  mira:{name:'Mira',title:'Priesterin des Lichts',cls:'heil',hp:70,dmg:6,home:[78.5,106.6],cost:250,look:{skin:'#f0c8a8',hair:'#e8c860',outfit:'#e8e0c8',longHair:true},likes:['blume','buch','wein'],shop:'mira',
    bio:'„Das Licht verlangt, dass ich helfe, wo ich kann. Aber… insgeheim sehne ich mich nach Abenteuer.“',
    lines:['„Möge das Licht deinen Weg erhellen.“','„Weißt du, mit dir unterwegs zu sein… es fühlt sich richtig an.“','„Ich habe gebetet, dass du heil zurückkommst. Jedes Mal.“']},
  kael:{name:'Kael',title:'Wandermagier',cls:'magie',hp:60,dmg:12,home:[74.5,107.6],cost:400,look:{skin:'#c8946a',hair:'#1a1a3a',outfit:'#3a3a8a'},likes:['buch','kristall','wein'],
    bio:'„Ich studiere die Sterne – und gelegentlich die Leute, die mich anstarren.“',
    lines:['„Faszinierend. Nein, nicht du. Der Kristall da.“','„Du bist interessanter als jedes Buch, das ich je gelesen habe. Und ich habe viele gelesen.“','„Die Sterne sagen, wir gehören zusammen. Ich habe nachgerechnet. Zweimal.“']},
  lyra:{name:'Lyra',title:'Elfenjägerin',cls:'bogen',hp:75,dmg:11,home:[39.5,55.5],cost:0,look:{skin:'#f3d6bb',hair:'#e8d77a',outfit:'#3f6a35',longHair:true,ears:true},likes:['blume','wein','ring'],
    bio:'„Der Wald hat mir alles beigebracht. Du hast Eichenrast gerettet – ich folge dir, wenn du mich lässt.“',
    lines:['„Hörst du das? Nein? Menschen…“','„Bei dir vergesse ich manchmal, auf den Wald zu lauschen.“','„Für eine Elfe ist ein Menschenleben kurz. Ich will jeden Tag davon mit dir verbringen.“'],
    show:() => questDone('goblins')},
  brann:{name:'Brann',title:'Zwergenkrieger',cls:'kampf',hp:130,dmg:12,home:[116.5,27.6],cost:0,look:{skin:'#dba27c',hair:'#a34a1f',outfit:'#5a5a6a',beard:true},likes:['bier','silberbarren','mithrilbarren'],shop:'brann',
    bio:'„Brann Eisenfaust, Sohn des Durin… eines Durin jedenfalls. Es gibt viele.“',
    lines:['„Aye.“','„Du würdest einen passablen Zwerg abgeben. Das ist das größte Kompliment, das ich kenne.“','„Mein Bart, meine Axt und du. Mehr brauch ich nicht.“'],
    recruit:() => questDone('spuren')}
};
const FLIRT_OK = ['{n} lacht und wird ein wenig rot. „Du bist unmöglich… sprich ruhig weiter.“','{n} hält deinem Blick einen Moment länger stand als nötig.','„Ach ja? Das sagst du bestimmt zu allen.“ Aber {n} lächelt.','{n} stupst dich an der Schulter. „Pass auf, sonst glaub ich dir das noch.“'];
const FLIRT_NO = ['{n} verdreht die Augen. „Netter Versuch.“','„Nicht jetzt.“ {n} wendet sich ab.','{n} sieht dich verwirrt an. Das ging wohl daneben.','{n} schnaubt. „Übst du das vor dem Spiegel?“'];
// ---------- Quests ----------
const QUESTS = {
  ratten:{name:'Ratten im Rattenviertel',main:true,steps:[
    {t:'kill',e:'ratte',n:5,txt:'Erschlage 5 Riesenratten im Rattenviertel.'},
    {t:'talk',npc:'hilde',txt:'Kehre zu Mutter Hilde zurück.',say:'„Du hast es geschafft! Hier, ein paar Münzen und zwei Tränke – mehr hab ich nicht. Und… Krummfinger hat nach dir gefragt. Sei vorsichtig mit dem.“'}],
    reward:{xp:80,gold:20,items:[['heiltrank',2]]},next:'krumm'},
  krumm:{name:'Krummfingers Angebot',main:true,steps:[
    {t:'talk',npc:'krumm',txt:'Sprich mit Krummfinger im Rattenviertel.',say:'„Mutter Hilde schuldet mir Geld. Viel Geld. Machen wir’s einfach: Händler Baldur am Markt von Aldenmark hat ein Rechnungsbuch in der Truhe neben seinem Laden. Bring es mir, und Hildes Schulden sind vergessen. Oder… lauf zur Wache. Wenn du dich traust.“'},
    {t:'branch',txt:'Stiehl Baldurs Rechnungsbuch aus der Truhe neben seinem Laden und bring es Krummfinger – ODER melde Krummfinger bei Hauptmann Roderich am Südtor.',opts:[
      {npc:'krumm',need:'rechnungsbuch',label:'📒 Rechnungsbuch übergeben',say:'„Ha! Wusste ich’s doch. Du hast Talent. Willkommen in der Familie – und ich schenk dir was: Ab jetzt weißt du, wie man Schlösser öffnet.“',
        fn:() => { removeItem('rechnungsbuch', 1); P.f.diebespfad = true; P.rep.diebe += 30; P.rep.karma -= 10; learnProf('schloss'); P.gold += 60; }},
      {npc:'roderich',label:'⚖️ Krummfinger melden',say:'„Krummfinger, sagst du? Der alte Hund… Gut, dass du zu mir gekommen bist. Das Gesetz braucht Leute wie dich. Nimm diese Rüstung. Und meide nachts das Rattenviertel – er wird das nicht vergessen.“',
        fn:() => { if (countItem('rechnungsbuch')) removeItem('rechnungsbuch', 1); P.f.krummFeind = true; P.rep.stadt += 20; P.rep.karma += 15; addItem('lederruestung', 1); }}]},
    {t:'talk',npc:'sera',txt:'Melde dich bei Gildenmeisterin Sera in der Abenteurergilde (Aldenmark, Südosten des Platzes).',say:'„Noch ein hungriges Gesicht aus der Gosse? Hmpf. Jeder fängt irgendwo an. Zeig mir, was du kannst, dann reden wir über eine Aufnahme.“'}],
    reward:{xp:150,gold:30},next:'gilde'},
  gilde:{name:'Die Prüfung der Gilde',main:true,steps:[
    {t:'kill',e:'wolf',n:4,txt:'Erlege 4 Wölfe im Grünwald (nordwestlich der Stadt).'},
    {t:'collect',item:'fell',n:3,npc:'sera',txt:'Bring Sera 3 Felle.',say:'„Saubere Arbeit. Willkommen in der Abenteurergilde – Rang Kupfer. Bei mir bekommst du jetzt Kopfgeld-Aufträge.“'}],
    reward:{xp:250,gold:80},onDone:() => { P.rank = 'Kupfer'; },next:'goblins'},
  goblins:{name:'Goblinplage',main:true,steps:[
    {t:'talk',npc:'sera',txt:'Sprich mit Sera über einen neuen Auftrag.',say:'„Das Dorf Eichenrast im Grünwald bittet um Hilfe. Goblins plündern ihre Felder. Geh zur Dorfältesten Edda.“'},
    {t:'talk',npc:'edda',txt:'Reise nach Eichenrast (Nordwesten) und sprich mit der Dorfältesten Edda.',say:'„Den Göttern sei Dank! Die Goblins haben ihr Lager weiter im Nordwesten. Ihr Häuptling Grisk ist gerissen – erst wenn seine Krieger fallen, zeigt er sich.“'},
    {t:'kill',e:'goblin',n:6,txt:'Töte 6 Goblins.'},
    {t:'kill',e:'goblinboss',n:1,txt:'Besiege Häuptling Grisk im Goblinlager.'},
    {t:'talk',npc:'edda',txt:'Berichte Edda vom Sieg.',say:'„Du hast uns gerettet! Seltsam nur… Grisk trug einen Dolch mit dem Wappen von Morvath. Zeig das Sera. Und Lyra, unsere beste Jägerin, möchte dich begleiten – sie wartet am Dorfplatz.“'}],
    reward:{xp:500,gold:180},onDone:() => { P.rank = 'Silber'; P.rep.stadt += 10; toast('🏅 Gildenrang: Silber', 'gold'); },next:'spuren'},
  spuren:{name:'Spuren aus Morvath',main:true,steps:[
    {t:'talk',npc:'sera',txt:'Zeige Sera den Morvath-Dolch.',say:'„Morvath-Stahl… bei Goblins? Das gefällt mir nicht. Die Zwerge der Mine Tiefgrund (Nordosten, hinter der Brücke) handeln mit Waffen. Finde Brann, er weiß mehr.“'},
    {t:'goto',region:'mine',txt:'Reise zur Zwergenmine Tiefgrund im Nordosten.'},
    {t:'talk',npc:'brann',txt:'Sprich mit Brann.',say:'„Morvath? Aye, deren Händler kaufen jedes Eisen, das sie kriegen. Aber erst müssen die Trolle weg, die meine Mine belagern! Hilf mir, dann helf ich dir.“'},
    {t:'kill',e:'troll',n:3,txt:'Besiege 3 Bergtrolle in den Eisenzahn-Bergen.'},
    {t:'talk',npc:'brann',txt:'Kehre zu Brann zurück.',say:'„Bei meinem Bart, du kämpfst wie ein Zwerg! Die Morvath-Händler zahlen mit Gold, das Malgors Siegel trägt – sie rüsten zum Krieg. Das muss der König erfahren. Und ich komm mit, wenn du willst.“'}],
    reward:{xp:900,gold:300,items:[['silberbarren',2]]},next:'audienz'},
  audienz:{name:'Audienz beim König',main:true,steps:[
    {t:'talk',npc:'koenig',txt:'Berichte König Aldric vor der Burg von Aldenmark.',say:'„Morvath rüstet zum Krieg? Und das erfahre ich von einem Kind der Gosse… verzeih, von einer Heldin, einem Helden der Gilde. Ein Gesandter Morvaths weilt in meiner Burg – Varek. Stell ihn zur Rede.“'},
    {t:'branch',txt:'Stelle den Gesandten Varek im Burghof (rechts neben der Burg) zur Rede.',opts:[
      {npc:'varek',label:'⚔️ „Du bist ein Spion!“',say:'„Klug. Zu klug. Dann stirb eben hier!“'},
      {npc:'varek',label:'💰 Bestechung annehmen (1000 Gold)',say:'„Eine weise Wahl. Ein Beutel Gold für dein Schweigen. Wir sehen uns… vielleicht.“',
        fn:() => { P.gold += 1000; P.f.verrat = true; P.rep.karma -= 40; },jump:3}]},
    {t:'kill',e:'varek',n:1,txt:'Besiege Varek!'},
    {t:'talk',npc:'koenig',txt:'Kehre zum König zurück.',say:() => P.f.verrat ?
      '„Varek ist… verschwunden? Nun. Ich ernenne dich dennoch zum Ritter von Aldenmark. Enttäusche mich nicht.“' :
      '„Der Spion ist besiegt. Knie nieder – ich ernenne dich zum Ritter von Aldenmark! Nimm mein Siegel als Zeichen meines Vertrauens.“'}],
    reward:{xp:1500,gold:500},onDone:() => { P.rank = 'Gold'; P.title = 'Ritter von Aldenmark'; P.rep.stadt += 20; if (!P.f.verrat) addItem('koenigssiegel', 1); },next:'sumpf'},
  sumpf:{name:'Die Schatten im Nebel',main:true,steps:[
    {t:'talk',npc:'koenig',txt:'Hör dir den nächsten Auftrag des Königs an.',say:'„Unsere Späher berichten von Schattenkristallen aus dem Nebelsumpf. Malgor nutzt sie für dunkle Magie. Finde heraus, wer sie ihm liefert.“'},
    {t:'goto',region:'sumpf',txt:'Reise in den Nebelsumpf östlich des Flusses.'},
    {t:'collect',item:'schattenkristall',n:3,from:'schleim',p:0.45,txt:'Sammle 3 Schattenkristalle von Sumpfschleimen.'},
    {t:'branch',txt:'Konfrontiere die Hexe Morla an ihrer Hütte im Sumpf.',opts:[
      {npc:'morla',label:'🤝 Ihr vertrauen',say:'„Ich liefere Malgor nichts, Kind. Er zwingt meine Schwestern dazu. Nimm dieses Amulett – es schützt vor seiner Schattenmagie. Und komm wieder, wenn du Tränke brauchst.“',
        fn:() => { removeItem('schattenkristall', 3); addItem('amulett', 1); P.rep.karma += 10; P.f.hexeFreund = true; },jump:5},
      {npc:'morla',label:'🔥 „Du dienst Malgor!“',say:'„Narr! Dann werden deine Knochen meinen Garten düngen!“'}]},
    {t:'kill',e:'hexe',n:1,txt:'Besiege Morla die Sumpfhexe.'},
    {t:'talk',npc:'koenig',txt:'Berichte dem König.',say:'„Gut gemacht. Die Zeit ist gekommen. Wir tragen den Krieg nach Morvath – und du führst die Vorhut.“'}],
    reward:{xp:2500,gold:800},next:'krieg'},
  krieg:{name:'Krieg gegen Morvath',main:true,steps:[
    {t:'goto',region:'morvath',txt:'Überquere den Fluss im Südosten und dringe ins Reich Morvath ein.',onDone:() => { if (P.f.verrat) ambushVarek(); }},
    {t:'kill',e:'soldat',n:8,txt:'Besiege 8 Morvath-Soldaten.'},
    {t:'goto',region:'festung',txt:'Stürme die Festung Schwarzfels (Südosten, Tor im Norden).'},
    {t:'kill',e:'malgor',n:1,txt:'Besiege Schattenfürst Malgor!'},
    {t:'talk',npc:'koenig',txt:'Kehre als Held nach Aldenmark zurück.',say:'„Ganz Aldenmark singt deinen Namen! Aus der Gosse zum Retter des Reiches. Die Tore meiner Burg stehen dir immer offen – Held von Aldenmark.“'}],
    reward:{xp:6000,gold:5000},onDone:() => { P.f.sieg = true; P.title = 'Held von Aldenmark'; P.rep.stadt += 40; showStory('🏆 Sieg!', 'Schattenfürst Malgor ist gefallen. Aus dem Kind der Gosse wurde der Held von Aldenmark.<br><br>Die Welt bleibt offen: Der Aschewyrm schläft noch in den Bergen, deine Betriebe wollen wachsen, deine Gilde braucht eine Führung – und vielleicht wartet jemand auf dich.'); }},
  pilze:{name:'Rosas Pilzeintopf',steps:[{t:'collect',item:'pilz',n:6,npc:'rosa',txt:'Bring Wirtin Rosa 6 Waldpilze (wachsen im Grünwald).',say:'„Wunderbar! Weißt du was? Ich bring dir das Kochen bei – umsonst.“'}],reward:{xp:120,gold:40},onDone:() => learnProf('kochen')},
  erz:{name:'Erz für Gunnar',steps:[{t:'collect',item:'eisenerz',n:8,npc:'gunnar',txt:'Bring Schmied Gunnar 8 Eisenerz (Felsen mit braunen Adern, v. a. in den Bergen).',say:'„Gutes Erz! Komm her, ich zeig dir, wie man einen Hammer hält.“'}],reward:{xp:150,gold:50},onDone:() => learnProf('schmieden')},
  woelfe:{name:'Wilmas Wolfsproblem',steps:[{t:'kill',e:'wolf',n:5,txt:'Erlege 5 Wölfe für die Jägerin Wilma.'},{t:'talk',npc:'wilma',txt:'Kehre zu Wilma in Eichenrast zurück.',say:'„Du hast ein Gespür für Tiere – auch wenn du sie erschlägst. Ich zeig dir, wie man sie zähmt. Schwäche ein Tier, dann biete ihm Futter an. Hier, etwas Fleisch als Köder.“'}],reward:{xp:200,gold:40,items:[['fleisch',5]]},onDone:() => learnProf('zaehmen')}
};
// ---------- NPCs ----------
const CITIZEN_LINES = ['„Schönes Wetter heute, nicht?“','„Die Steuern steigen schon wieder.“','„Pass auf deinen Geldbeutel auf – im Rattenviertel klauen sie dir die Zähne aus dem Mund.“','„Hast du die Wirtin Rosa schon kennengelernt? Ihr Eintopf ist legendär.“','„Der König ist alt geworden. Man sagt, Morvath wartet nur auf eine Schwäche.“','„Ich hab gehört, Schmied Gunnar sucht jemanden, der ihm Erz bringt.“'];
function repLine() {
  if (P.f.sieg) return '„Du bist es! Der Held von Aldenmark! Darf ich… darf ich dich anfassen?“';
  if (P.rep.stadt >= 40) return '„Ah, du bist doch die Person aus den Geschichten! Es ist mir eine Ehre.“';
  if (P.rep.stadt <= -20) return '„Bleib mir vom Leib, Gauner. Ich ruf die Wache.“';
  return pick(CITIZEN_LINES);
}
const NPC_DEFS = [
  {id:'hilde',name:'Mutter Hilde',x:59.5,y:112.6,look:{skin:'#e3b48f',hair:'#d4d4d4',outfit:'#6b5a48',longHair:true},
    offer:() => !P.q.ratten,
    talk() {
      if (!P.q.ratten) return {text:'„Da bist du ja, Kind! Die Riesenratten haben schon wieder unser letztes Brot gefressen. Nimm, was du hast, und erschlag ein paar von ihnen. Fünf sollten reichen, um ihnen Respekt beizubringen.“',opts:[{t:'„Ich kümmere mich darum.“',f:() => { startQuest('ratten'); }}]};
      if (P.f.sieg) return {text:'„Der Held von Aldenmark… in meiner schäbigen Hütte. Ich hab immer gewusst, dass mehr in dir steckt als Hunger und Dreck.“'};
      if (P.rep.karma <= -30) return {text:'„Man erzählt sich Dinge über dich, Kind. Dinge, die mir das Herz schwer machen. Vergiss nicht, wer dich aufgezogen hat.“'};
      return {text:pick(['„Iss was, du bist ganz dünn.“','„Pass auf dich auf da draußen. Die Welt ist größer als das Rattenviertel – und gefährlicher.“','„Wenn du mal reich bist, kauf mir ein Haus mit einem richtigen Dach, ja?“'])};
    }},
  {id:'krumm',name:'Krummfinger',x:55.5,y:111.6,look:{skin:'#d8a880',hair:'#3a2a2a',outfit:'#2e2e38'},shop:'krumm',fence:true,shopCond:() => !!P.f.diebespfad,
    teaches:() => P.f.diebespfad ? ['schloss','diebstahl'] : [],
    talk() {
      if (P.f.krummFeind) return {text:'„Sieh an. Die kleine Ratte, die zur Wache gerannt ist. Du hast Mut, dich hier blicken zu lassen. Verschwinde.“'};
      if (P.f.diebespfad) return {text:pick(['„Mein liebster Lehrling! Hast du was für mich? Ich zahl gut – und stelle keine Fragen.“','„Die Wachen sind Idioten. Und Idioten kann man bestechen. Merk dir das.“'])};
      return {text:'„Hm. Mutter Hildes Findelkind. Hunger macht mutig – das gefällt mir.“'};
    }},
  {id:'bettler',name:'Alter Bettler',x:62.5,y:111.6,look:{skin:'#c8a080',hair:'#8a8a8a',outfit:'#5a5040',beard:true},
    talk() {
      return {text:pick(['„Eine Münze für einen alten Soldaten?“','„Ich war mal Ritter, weißt du. Dann kam der Wein.“']),opts:[
        {t:'🪙 5 Gold geben',f:() => { if (P.gold < 5) return {text:'Du hast nicht genug Gold.'}; P.gold -= 5; P.rep.karma += 2; if (chance(0.25)) { return {text:'„Danke… Hör zu: ' + pick(RUMORS).replace(/^„|“$/g, '') + '“'}; } return {text:'„Die Götter mögen es dir vergelten.“'}; }}]};
    }},
  {id:'baldur',name:'Händler Baldur',x:70.5,y:97.6,look:{skin:'#e8b896',hair:'#8a6a3a',outfit:'#8a6a2a',beard:true},shop:'baldur',rich:3,
    talk() {
      if (P.f.buchWeg && !P.f.buchGesagt) { P.f.buchGesagt = true; return {text:'„Irgendein Lump hat mein Rechnungsbuch gestohlen! Wenn ich den erwische…“ Er mustert dich misstrauisch.'}; }
      return {text:pick(['„Willkommen! Bei Baldur gibt’s alles, was ein Abenteurer braucht – fast alles.“','„Pfeile, Tränke, Werkzeug. Nur bitte nicht anschreiben lassen.“'])};
    }},
  {id:'gunnar',name:'Schmied Gunnar',x:89.5,y:97.6,look:{skin:'#d89a70',hair:'#2a2a2a',outfit:'#5a4030',bald:true,beard:true},shop:'gunnar',smith:true,teaches:['schmieden'],rich:2,
    offer:() => !P.q.erz && !P.learned.schmieden,
    talk() {
      const o = [];
      if (!P.q.erz && !P.learned.schmieden) o.push({t:'„Brauchst du Hilfe?“',f:() => { startQuest('erz'); return {text:'„Bring mir 8 Eisenerz, dann bring ich dir das Schmieden bei. Ohne Lehrgeld.“'}; }});
      return {text:pick(['„Ein gutes Schwert ist wie ein guter Freund – es lässt dich nicht im Stich, wenn du es pflegst.“','„Am Amboss draußen kannst du selbst schmieden, wenn du weißt wie.“']),opts:o};
    }},
  {id:'rosa',name:'Wirtin Rosa',x:71.5,y:106.6,look:{skin:'#f0c0a0',hair:'#b8302a',outfit:'#7a3a5a',longHair:true},shop:'rosa',teaches:['kochen'],rich:2,
    offer:() => !P.q.pilze && !P.learned.kochen,
    talk() {
      const o = [{t:'👂 Gerüchte hören',f:() => ({text:pick(RUMORS)})}];
      if (!P.q.pilze && !P.learned.kochen) o.push({t:'„Kann ich dir helfen?“',f:() => { startQuest('pilze'); return {text:'„Bring mir 6 Waldpilze aus dem Grünwald. Dann zeig ich dir, wie man richtig kocht.“'}; }});
      return {text:pick(['„Willkommen im Lahmen Esel! Setz dich, iss was.“','„Hier hört man alles, wenn man lang genug zuhört.“']),opts:o};
    }},
  {id:'sera',name:'Gildenmeisterin Sera',x:87.5,y:106.6,look:{skin:'#c88a60',hair:'#1a1a1a',outfit:'#5a3a2a',longHair:true},
    offer:() => questDone('gilde') && !bountyActive(),
    talk() {
      const o = [];
      if (questDone('gilde') && !bountyActive()) o.push({t:'📋 Kopfgeld-Auftrag annehmen',f:() => newBounty()});
      if (questDone('goblins') && !P.guild) o.push({t:'🛡️ Eigene Gilde gründen…',f:() => { closeDialog(); openPanel('estate', 'guild'); return 'close'; }});
      let tx = P.rank === 'Keiner' ? '„Die Abenteurergilde nimmt nicht jeden. Beweise dich.“' : '„Rang ' + P.rank + '. Nicht schlecht für ein Kind der Gosse.“';
      return {text:tx,opts:o};
    }},
  {id:'roderich',name:'Hauptmann Roderich',x:80.5,y:108.6,look:{skin:'#e0b090',hair:'#9a9aa4',outfit:'#4a5a8a',helm:true,beard:true},
    talk() {
      if (P.f.diebespfad && P.rep.stadt < 0) return {text:'„Ich hab ein Auge auf dich, Gossenratte.“'};
      if (P.f.krummFeind) return {text:'„Seit du Krummfinger gemeldet hast, ist es ruhiger im Viertel. Danke.“'};
      return {text:'„Ruhe und Ordnung. Mehr verlange ich nicht.“'};
    }},
  {id:'ulrich',name:'Makler Ulrich',x:82.5,y:99.6,look:{skin:'#e8c0a0',hair:'#6a5a4a',outfit:'#2a4a3a'},
    talk() {
      return {text:'„Häuser, Betriebe, Grundstücke! Wer in Aldenmark etwas besitzen will, kommt zu Ulrich.“',opts:[
        {t:'🏠 Immobilien & Betriebe ansehen',f:() => { closeDialog(); openPanel('estate'); return 'close'; }}]};
    }},
  {id:'koenig',name:'König Aldric',x:80.5,y:94.7,look:{skin:'#e8c0a0',hair:'#e8c040',outfit:'#7a1a2a',beard:true,helm:true},
    talk() {
      if (!P.q.audienz) return {text:'„Wer wagt es… ach, ein Bittsteller. Komm wieder, wenn dein Name in Aldenmark etwas bedeutet.“'};
      if (P.f.sieg) return {text:'„Mein Held! Aldenmark steht in deiner Schuld.“'};
      return {text:'„Das Reich braucht dich.“'};
    }},
  {id:'varek',name:'Gesandter Varek',x:84.5,y:96.6,look:{skin:'#e0c0a0',hair:'#1a1a1a',outfit:'#4a1a3a'},cond:() => stepIs('audienz', 'branch'),
    talk() { return {text:'„Ah, das neue Schoßhündchen des Königs. Was willst du?“'}; }},
  {id:'edda',name:'Dorfälteste Edda',x:34.5,y:55.6,look:{skin:'#e0b090',hair:'#c8c8c8',outfit:'#5a6a3a',longHair:true},
    talk() { return {text:questDone('goblins') ? '„Eichenrast wird dir nie vergessen, was du getan hast.“' : '„Willkommen in Eichenrast. Wir sind einfache Leute.“'}; }},
  {id:'wilma',name:'Jägerin Wilma',x:31.5,y:57.6,look:{skin:'#d8a070',hair:'#7a3a1a',outfit:'#4a5a2a',longHair:true},shop:'wilma',teaches:['zaehmen'],
    offer:() => !P.q.woelfe && !P.learned.zaehmen,
    talk() {
      const o = [];
      if (!P.q.woelfe && !P.learned.zaehmen) o.push({t:'„Was liegt an?“',f:() => { startQuest('woelfe'); return {text:'„Die Wölfe reißen unsere Schafe. Erleg fünf, dann zeig ich dir, wie man ihre Brüder zähmt.“'}; }});
      return {text:'„Tiere spüren, was du fühlst. Bleib ruhig, sei geduldig – und hab immer Futter dabei.“',opts:o};
    }},
  {id:'morla',name:'Morla die Hexe',x:130.5,y:85.7,look:{skin:'#a0c090',hair:'#2a2a2a',outfit:'#2a4a2a',longHair:true},shop:'morla',shopCond:() => !!P.f.hexeFreund,
    cond:() => !P.f.hexeTot && !stepIs('sumpf', 'kill'),
    talk() { return {text:P.f.hexeFreund ? '„Ah, mein mutiges Kind. Tränke gefällig?“' : '„Wer stapft da durch meinen Sumpf? Sprich, oder geh.“'}; }},
  {id:'wache1',name:'Stadtwache',x:89.5,y:89.7,guard:true,look:{skin:'#e0b090',hair:'#9a9aa4',outfit:'#4a5a8a',helm:true},talk() { return {text:repLine()}; }},
  {id:'wache2',name:'Stadtwache',x:67.6,y:98.6,guard:true,look:{skin:'#c89070',hair:'#9a9aa4',outfit:'#4a5a8a',helm:true},talk() { return {text:repLine()}; }},
  {id:'wache3',name:'Stadtwache',x:92.5,y:101.6,guard:true,look:{skin:'#e8c0a0',hair:'#9a9aa4',outfit:'#4a5a8a',helm:true},talk() { return {text:repLine()}; }},
  {id:'buerger1',name:'Bürgerin',x:76.5,y:100.5,wander:4,rich:1,look:{skin:'#f0c8a8',hair:'#6a3a1a',outfit:'#5a7a9a',longHair:true},talk() { return {text:repLine()}; }},
  {id:'buerger2',name:'Bürger',x:85.5,y:101.5,wander:4,rich:2,look:{skin:'#d8a070',hair:'#2a2a2a',outfit:'#8a6a3a'},talk() { return {text:repLine()}; }},
  {id:'buerger3',name:'Händlerin',x:73.5,y:101.5,wander:3,rich:3,look:{skin:'#e8b896',hair:'#d8c060',outfit:'#9a3a5a',longHair:true},talk() { return {text:repLine()}; }},
  {id:'bauer',name:'Bauer Jost',x:36.5,y:59.6,wander:3,rich:1,look:{skin:'#d8a070',hair:'#8a6a3a',outfit:'#6a7a3a'},talk() { return {text:pick(['„Ohne die Goblins wär’s hier das Paradies.“','„Die Elfe Lyra schießt einem Eichhörnchen auf hundert Schritt das Auge aus.“'])}; }}
];
