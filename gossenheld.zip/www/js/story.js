'use strict';
// ================= STORY & NEBENQUESTS =================
// Neue Orte, Figuren, Quests und Ereignisse. Positionen in der großen Welt (Felder).

// ---------- Gegenstände ----------
defI('medaillon', {name:'Hildes Medaillon', icon:'🏅', val:0, type:'quest', stack:true});
defI('liebesbrief', {name:'Josts Liebesbrief', icon:'💌', val:0, type:'quest', stack:true});
defI('geheimbrief', {name:'Versiegelter Geheimbrief', icon:'✉️', val:0, type:'quest', stack:true});
defI('valdrinring', {name:'Ring von Valdrin', icon:'💍', type:'schmuck', bonus:{str:2, dex:2, int:2, vit:2, wis:2}, def:3, luck:0.1, val:1200});

// ---------- Elite-Gegner ----------
Object.assign(ENEMIES, {
  graupelz:{name:'Alte Graupelz', shape:'quad', size:1.5, col:'#9a9aa4', hp:230, dmg:13, spd:3.3, xp:260, gold:[20, 40], drops:[['fell', 1, 3]], lvl:8, boss:true},
  brueckentroll:{name:'Brückentroll Grunz', shape:'hum', size:1.7, col:'#6a8a6a', outfit:'#4a3a2a', bald:true, hp:380, dmg:18, spd:2.0, xp:420, gold:[80, 140], drops:[['silbererz', 1, 3]], lvl:10, boss:true},
  knochenkoenig:{name:'Der Knochenkönig', shape:'hum', size:1.5, col:'#e8e4d8', outfit:'#4a2a5a', helm:true, hair:'#c8a040', eye:'#40f0ff', hp:420, dmg:16, spd:2.3, xp:500, gold:[60, 100], drops:[], lvl:10, boss:true, undead:true, ranged:true, proj:'shadow'}
});
ANIMAL_LOOK.graupelz = ['wolf', {spikes:true, eye:'#f0d040'}];
BOSS_POS.graupelz = [30.5, 220.5];
BOSS_POS.brueckentroll = [160.5, 151.5];
BOSS_POS.knochenkoenig = shiftOld(28.5, 97.6);

// ---------- Lager in der Wildnis ----------
const CAMPS = [
  {fire:[52, 235], extra:[[49, 234, TL.BARREL], [55, 234, TL.BARREL]]},       // Jägerlager in der Weiten Heide
  {fire:[71, 23], extra:[[69, 22, TL.TABLE], [74, 22, TL.SHELF]]},              // Oswins Hütte im Dunkelforst
  {fire:null, extra:[[155, 156, TL.BARREL], [156, 156, TL.FENCE]]},              // Zollstelle an der Ostbrücke
  {fire:[153, 191], extra:[]}                                                     // Kasimirs Versteck an der Grenzbrücke
];
function worldExtras() {
  for (const c of CAMPS) {
    const cx = c.fire ? c.fire[0] : c.extra[0][0], cy = c.fire ? c.fire[1] : c.extra[0][1];
    for (let y = cy - 3; y <= cy + 3; y++) for (let x = cx - 3; x <= cx + 3; x++) {
      if (!inb(x, y) || Math.hypot(x - cx, y - cy) > 3.2) continue;
      const i = idx(x, y); if (WG[i] !== TL.WATER && WG[i] !== TL.BRIDGE) WT[i] = WG[i];
    }
    if (c.fire) setO(c.fire[0], c.fire[1], TL.HEARTH);
    for (const e of c.extra) setO(e[0], e[1], e[2]);
  }
  nudgePositions();
}
// Figuren und Bosse, die auf einem blockierten Feld stehen würden, ein Stück verschieben
function nudgeTo(x, y, enemy) {
  if (walkable(x, y, enemy)) return [x, y];
  for (let r = 1; r <= 7; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const nx = Math.floor(x) + dx + 0.5, ny = Math.floor(y) + dy + 0.6;
    if (walkable(nx, ny, enemy) && walkable(nx, ny - 0.4, enemy)) return [nx, ny];
  }
  return [x, y];
}
function nudgePositions() {
  for (const d of NPC_DEFS) if (d.x != null) { const q = nudgeTo(d.x, d.y); d.x = q[0]; d.y = q[1]; }
  for (const id in COMPS) if (COMPS[id].home) COMPS[id].home = nudgeTo(COMPS[id].home[0], COMPS[id].home[1]);
  for (const b in BOSS_POS) BOSS_POS[b] = nudgeTo(BOSS_POS[b][0], BOSS_POS[b][1], true);
}

// ---------- Quest-Hilfen ----------
const QUEST_REQ = {
  brief:() => true,
  bruder:() => questDone('ratten'),
  fest:() => questDone('goblins'),
  graupelz:() => true,
  einsiedler:() => true,
  spaeher:() => questDone('einsiedler'),
  herkunft:() => questDone('gilde'),
  brueckentroll:() => true,
  deserteur:() => questDone('spuren') || P.lvl >= 9,
  kristallherz:() => questDone('spuren') || P.lvl >= 10
};
function canOffer(id) { return !P.q[id] && !P.avail[id] && (!QUEST_REQ[id] || QUEST_REQ[id]()); }
// macht aus einer Figur einen Auftraggeber (behält deren bisherige Gespräche)
function giver(def, quests, lines) {
  const bt = def.talk, bo = def.offer;
  def.offer = () => (bo && bo()) || quests.some(canOffer);
  def.talk = function () {
    const r = bt ? bt.call(this) : {text:pick(lines)};
    const offers = quests.filter(canOffer).map(questOffer);
    if (offers.length) r.opts = (r.opts || []).concat(offers);
    return r;
  };
  return def;
}
// Figuren reagieren auf das, was du getan hast
function react(id, list) {
  const d = NPC_DEFS.find(n => n.id === id); if (!d) return;
  const bt = d.talk;
  d.talk = function () {
    const r = bt.call(this), hit = list.filter(l => l[0]());
    if (hit.length && !(r.opts || []).some(o => o.q) && chance(0.6)) r.text = pick(hit)[1];
    return r;
  };
}

// ---------- Neue Figuren ----------
const S_ALD = (x, y) => shiftOld(x, y);
NPC_DEFS.push(
  giver({id:'elsa', name:'Elsa die Weberin', x:S_ALD(74.5, 108.4)[0], y:S_ALD(74.5, 108.4)[1], wander:2, rich:2, look:{skin:'#f0c8a8', hair:'#c8702a', outfit:'#6a8a5a', longHair:true},
    talk() {
      if (questDone('bruder')) return {text:P.f.tomLuege ? '„Ich zünde jeden Abend eine Kerze für Tom an.“ Sie lächelt traurig.' : '„Tom hilft mir jetzt am Webstuhl. Er stellt sich furchtbar an – aber er ist zu Hause.“'};
      if (questActive('bruder')) return {text:'„Bitte… finde Tom. Er wollte in der Weiten Heide Fallen stellen, weit im Südwesten.“'};
      return {text:'„Entschuldige… du siehst aus, als könntest du mit einem Schwert umgehen.“'};
    }}, ['bruder']),
  {id:'tom', name:'Tom der Fallensteller', x:50.5, y:236.6, look:{skin:'#e0b090', hair:'#8a5a2a', outfit:'#6a5a3a'},
    cond:() => questActive('bruder') && P.q.bruder.s <= 2,
    talk() { return {text:P.q.bruder.s === 2 ? '„Da hinten sind sie! Die Banditen! Bitte…“' : '„Wer bist du? Hat dich… Elsa geschickt?“ Er sieht abgemagert aus und zuckt bei jedem Geräusch zusammen.'}; }},
  {id:'tom_stadt', name:'Tom', x:S_ALD(76.5, 108.5)[0], y:S_ALD(76.5, 108.5)[1], wander:2, look:{skin:'#e0b090', hair:'#8a5a2a', outfit:'#7a6a4a'},
    cond:() => questDone('bruder') && !P.f.tomLuege,
    talk() { return {text:pick(['„Ohne dich wäre ich in der Heide verrottet. Wenn du was brauchst – frag.“', '„Elsa redet nur noch von dir. Ehrlich, es nervt ein bisschen.“'])}; }},
  giver({id:'ragnar', name:'Jäger Ragnar', x:54.5, y:236.6, look:{skin:'#d8a070', hair:'#c8c8c8', outfit:'#5a4a2a', beard:true}, shop:'wilma', teach:{zaehmen:7},
    talk() {
      if (questDone('graupelz')) return {text:'„Seit Graupelz tot ist, jagen die Rudel wieder wie gewöhnliche Wölfe. Die Heide ist dir was schuldig.“'};
      return {text:'„Die Weite Heide ist kein Spielplatz. Hier draußen frisst dich alles, was größer ist als du.“'};
    }}, ['graupelz']),
  giver({id:'oswin', name:'Einsiedler Oswin', x:73.5, y:24.6, look:{skin:'#e0c0a0', hair:'#e8e8e8', outfit:'#4a5a3a', beard:true, bald:true}, teach:{sammeln:8, kochen:7},
    talk() {
      if (questDone('spaeher')) return {text:pick(['„Die Schatten werden länger, Kind. Aber du wirfst selbst einen.“', '„Valdrin fiel, weil niemand hinsah. Du siehst hin. Das ist schon viel.“'])};
      return {text:'„Ein Besucher? Hier? Setz dich ans Feuer. Aber fass die Pilze nicht an.“'};
    }}, ['einsiedler', 'spaeher']),
  giver({id:'fritz', name:'Zöllner Fritz', x:157.5, y:157.6, look:{skin:'#e8b896', hair:'#6a4a2a', outfit:'#5a6a8a'},
    talk() {
      if (questDone('brueckentroll')) return {text:'„Die Brücke ist wieder sicher! Händler kommen sogar wieder aus dem Sumpf herüber.“'};
      return {text:'„Halt! Äh… ich meine: Willkommen an der Ostbrücke. Seit der Troll da ist, will keiner mehr rüber.“'};
    }}, ['brueckentroll']),
  giver({id:'kasimir', name:'Kasimir', x:154.5, y:192.6, look:{skin:'#c9a890', hair:'#3a3a3a', outfit:'#3a2030'},
    cond:() => !P.f.kasimirGemeldet && !questDone('deserteur'),
    talk() {
      if (questActive('deserteur')) return {text:'„Leise! Wenn mich eine Patrouille findet, hängen sie mich.“'};
      return {text:'Ein abgemagerter Mann in der zerrissenen Uniform Morvaths hebt abwehrend die Hände. „Bitte… ich bin kein Feind. Nicht mehr.“'};
    }}, ['deserteur']),
  giver({id:'hilda', name:'Runenmeisterin Hilda', x:S_ALD(113.5, 29.6)[0], y:S_ALD(113.5, 29.6)[1], look:{skin:'#dba27c', hair:'#e8d070', outfit:'#5a5a6a', longHair:true}, teach:{schmieden:10, bergbau:10},
    talk() { return {text:questDone('kristallherz') ? '„Die Runen singen wieder. Hörst du sie? Nein? Menschen.“' : '„Ich bin die letzte Runenmeisterin von Tiefgrund. Und ich bin schlecht gelaunt.“'}; }}, ['kristallherz']),
  {id:'geist', name:'Geist von Valdrin', x:S_ALD(27.5, 97.8)[0], y:S_ALD(27.5, 97.8)[1], ghost:true, look:{skin:'#c8f0ff', hair:'#e8f8ff', outfit:'#8ad0e8', beard:true, helm:true},
    cond:() => questActive('herkunft') && P.q.herkunft.s === 4,
    talk() { return {text:'Eine durchscheinende Gestalt in alter Rüstung blickt dich an. Ihre Stimme klingt wie Wind in Ruinen.'}; }}
);
// bestehende Figuren bekommen neue Aufträge
giver(NPC_DEFS.find(n => n.id === 'hilde'), ['herkunft']);
giver(NPC_DEFS.find(n => n.id === 'edda'), ['fest']);
giver(NPC_DEFS.find(n => n.id === 'bauer'), ['brief']);

// ---------- Neue Quests ----------
Object.assign(QUESTS, {
  brief:{name:'Ein Brief für Rosa', giver:'Bauer Jost', lvl:2, desc:'Bauer Jost aus Eichenrast ist seit Jahren in Wirtin Rosa verliebt. Er hat endlich einen Brief geschrieben – aber nicht den Mut, ihn selbst zu überbringen.', steps:[
    {t:'talk', npc:'bauer', txt:'Hol dir den Brief bei Bauer Jost in Eichenrast.', say:'„Hier. Bitte nicht reinschauen. Und… sag ihr nicht, dass ich drei Nächte daran geschrieben hab.“', onDone:() => addItem('liebesbrief', 1)},
    {t:'branch', txt:'Bring den Brief zu Wirtin Rosa in die Taverne von Aldenmark.', opts:[
      {npc:'rosa', need:'liebesbrief', label:'💌 Den Brief überreichen', say:'Rosa liest. Dann liest sie noch einmal. „Dieser alte Trottel… warum hat er das nicht früher gesagt?“ Sie dreht sich schnell weg, aber du siehst, dass sie lächelt.',
        fn:() => { removeItem('liebesbrief', 1); P.rep.karma += 3; P.f.briefEhrlich = true; }},
      {npc:'rosa', need:'liebesbrief', label:'😏 Den Brief vor allen Gästen vorlesen', say:'„…deine Augen sind wie zwei Krüge frisches Bier…“ Die Taverne brüllt vor Lachen. Rosa reißt dir den Brief aus der Hand. „Raus. RAUS!“',
        fn:() => { removeItem('liebesbrief', 1); P.rep.karma -= 6; P.rep.stadt -= 2; P.f.briefSpott = true; }}]},
    {t:'talk', npc:'bauer', txt:'Erzähl Jost, wie es gelaufen ist.', say:() => P.f.briefEhrlich ? '„Sie hat WAS gesagt? Sie will am Sonntag mit mir spazieren gehen?“ Jost hebt dich fast hoch vor Freude.' : '„Ganz Aldenmark lacht über mich…“ Jost starrt auf seine Stiefel. „Danke für nichts.“'}],
    reward:{xp:220, gold:25}, onDone:() => { if (P.f.briefEhrlich) { addItem('eintopf', 2); toast('💞 Rosa und Jost sind jetzt ein Paar.', 'gold'); } }},
  bruder:{name:'Der verschwundene Bruder', giver:'Elsa die Weberin', lvl:6, desc:'Elsas Bruder Tom ging vor zwei Wochen als Fallensteller in die Weite Heide im Südwesten. Seitdem: kein Wort. Elsa fürchtet das Schlimmste.', steps:[
    {t:'goto', region:'heide', txt:'Reise in die Weite Heide (Südwesten) und suche Tom.'},
    {t:'branch', txt:'Sprich mit Tom im Jägerlager der Weiten Heide.', opts:[
      {npc:'tom', label:'„Elsa wartet auf dich. Ich bring dich heim.“', say:'„Heim? Ich schulde den Banditen hier Geld. Sie lassen mich nicht gehen – sie bewachen das Lager. Wenn du sie verjagst… dann vielleicht.“'},
      {npc:'tom', label:'💰 „Wie viel ist dir mein Schweigen wert?“', say:'Tom zögert lange. „Hundert Gold. Alles, was ich habe. Sag Elsa, ich bin tot. Besser, sie trauert, als dass die Banditen auch sie holen.“',
        fn:() => { P.gold += 100; P.rep.karma -= 15; P.f.tomLuege = true; }, jump:3}]},
    {t:'kill', e:'bandit', n:4, txt:'Verjage die Banditen, die Tom bedrohen (Weite Heide).'},
    {t:'talk', npc:'elsa', txt:'Kehre zu Elsa nach Aldenmark zurück.', say:() => P.f.tomLuege ?
      '„Tot…?“ Elsa setzt sich langsam hin. „Danke, dass du es mir gesagt hast.“ Das Gold in deiner Tasche fühlt sich auf einmal sehr schwer an.' :
      '„TOM!“ Elsa fällt ihrem Bruder um den Hals, der hinter dir durch das Tor stolpert. „Wie kann ich dir das je danken?“'}],
    reward:{xp:450, gold:60}, onDone:() => { if (!P.f.tomLuege) { P.rep.stadt += 6; toast('🏰 Ansehen in Aldenmark +6'); } }},
  graupelz:{name:'Die Alte Graupelz', giver:'Jäger Ragnar', lvl:8, desc:'Eine riesige, uralte Wölfin führt die Rudel der Weiten Heide an. Sie hat Ragnars Hunde gerissen – und sie wird immer kühner.', steps:[
    {t:'kill', e:'graupelz', n:1, txt:'Stelle die Alte Graupelz in der westlichen Heide.'},
    {t:'talk', npc:'ragnar', txt:'Kehre zu Ragnar ins Jägerlager zurück.', say:'„Du hast sie wirklich erwischt? Dreißig Jahre jage ich hier, und keiner hat das geschafft.“ Er reicht dir ein Bündel. „Nimm das. Und wenn du Tiere zähmen willst – ich kann dir mehr beibringen als Wilma.“'}],
    reward:{xp:560, gold:120, items:[['leder', 4], ['tierlederpanzer', 1]]}},
  einsiedler:{name:'Der Einsiedler vom Dunkelforst', giver:'Einsiedler Oswin', lvl:7, desc:'Oswin lebt allein im Dunkelforst. Er braucht Kräuter und Pilze für einen Trank – und er weiß Dinge über die alte Zeit, die sonst niemand mehr weiß.', steps:[
    {t:'collect', item:'kraut', n:6, npc:'oswin', txt:'Bring Oswin 6 Heilkräuter.', say:'„Gut, gut. Jetzt die Pilze. Die roten, nicht die blauen. Die blauen sprechen mit dir.“'},
    {t:'collect', item:'pilz', n:4, npc:'oswin', txt:'Bring Oswin 4 Waldpilze.', say:'Oswin rührt im Kessel. „Weißt du, wer Malgor war, bevor er Schattenfürst wurde? Ein Hofmagier. Im Königreich Valdrin. Er hat seinen König verraten und die Stadt in Schutt gelegt. Die Ruinen westlich von Aldenmark – das war einmal eine Hauptstadt.“'}],
    reward:{xp:450, gold:30, prof:{sammeln:1}}},
  spaeher:{name:'Malgors Späher', giver:'Einsiedler Oswin', lvl:8, desc:'Oswin hat Goblins gesehen, die versiegelte Botschaften durch den Wald tragen. Jemand in Aldenmark empfängt Befehle aus Morvath.', steps:[
    {t:'collect', item:'geheimbrief', n:1, from:'goblin', p:0.4, txt:'Erbeute einen Geheimbrief von einem Goblin (Grünwald, Dunkelforst, Goblinlager).'},
    {t:'talk', npc:'roderich', txt:'Bring den Brief zu Hauptmann Roderich am Südtor von Aldenmark.', say:'Roderich bricht das Siegel und wird blass. „Das ist die Handschrift des Kämmerers… Malgor hat einen Verräter direkt am Hof! Kein Wort zu niemandem. Ich kümmere mich darum.“', onDone:() => removeItem('geheimbrief', 1)}],
    reward:{xp:650, gold:150, rep:8}},
  herkunft:{name:'Das Medaillon', giver:'Mutter Hilde', lvl:9, desc:'Mutter Hilde hat dir etwas verschwiegen. Etwas, das sie bei dir fand, als sie dich als Baby aus dem Rinnstein zog.', steps:[
    {t:'talk', npc:'hilde', txt:'Sprich mit Mutter Hilde in ihrer Hütte.', say:'Hilde holt eine Dose unter ihrem Bett hervor. Darin liegt ein angelaufenes Medaillon. „Das trugst du, als ich dich fand. Ich hab’s nie verkauft – nicht mal im schlimmsten Winter. Ich glaube, es gehört zu deiner Familie.“', onDone:() => addItem('medaillon', 1)},
    {t:'talk', npc:'anselm', txt:'Zeige das Medaillon Bruder Anselm im Tempel von Aldenmark.', say:'Anselm hält es ins Kerzenlicht. „Das ist das Wappen von Valdrin. Ein Königshaus, das vor zwanzig Jahren unterging. Wenn du Antworten suchst – sie liegen in den Ruinen westlich von hier. Aber dort wacht etwas.“'},
    {t:'goto', region:'ruinen', txt:'Reise zu den Ruinen von Valdrin im Westen.'},
    {t:'kill', e:'knochenkoenig', n:1, txt:'Besiege den Knochenkönig, der die Ruinen bewacht.'},
    {t:'talk', npc:'geist', txt:'Sprich mit der Gestalt, die in den Ruinen erschienen ist.', say:'„Das Medaillon… Du trägst das Blut von Valdrin.“ Der Geist neigt den Kopf. „Ich war Hauptmann der Königsgarde. Malgor ermordete den König und die Königin in einer einzigen Nacht. Ein Kind entkam – getragen von einer Amme durch die Abwasserkanäle bis nach Aldenmark. Du. Nimm diesen Ring. Er gehörte deiner Mutter.“', onDone:() => addItem('valdrinring', 1)},
    {t:'branch', txt:'Entscheide, wem du von deiner Herkunft erzählst.', opts:[
      {npc:'koenig', label:'👑 Dem König die Wahrheit sagen', say:'König Aldric schweigt lange. „Valdrins Erbe… in meinem Reich. Lebend.“ Dann steht er auf. „Malgor wird dich jagen, wenn er es erfährt. Aber ganz Aldenmark wird hinter dir stehen.“',
        fn:() => { P.f.valdrinErbe = true; P.title = 'Erbe von Valdrin'; P.rep.stadt += 15; toast('👑 Titel: Erbe von Valdrin', 'gold'); }},
      {npc:'hilde', label:'🤫 Es nur Hilde erzählen', say:'Hilde nimmt deine Hände. „Prinz oder Prinzessin, Kind… für mich bleibst du das hungrige Ding, das mir die Suppe weggegessen hat.“ Sie lacht, aber ihre Augen sind feucht. „Bewahr das Geheimnis. Es ist sicherer so.“',
        fn:() => { P.f.valdrinGeheim = true; P.rep.karma += 5; }}]}],
    reward:{xp:900, gold:150}},
  brueckentroll:{name:'Der Brückentroll', giver:'Zöllner Fritz', lvl:10, desc:'Ein Troll hat sich unter der Ostbrücke eingenistet und verlangt von jedem Reisenden „Zoll“ – meistens den ganzen Reisenden.', steps:[
    {t:'kill', e:'brueckentroll', n:1, txt:'Vertreibe den Brückentroll an der Ostbrücke (östlich von Aldenmark).'},
    {t:'talk', npc:'fritz', txt:'Melde Zöllner Fritz, dass die Brücke frei ist.', say:'„Endlich! Hier, der Zoll der letzten Wochen – den hat der Troll eh nicht gebraucht.“'}],
    reward:{xp:600, gold:220, rep:6, items:[['silberbarren', 1]]}},
  deserteur:{name:'Der Deserteur', giver:'Kasimir', lvl:10, desc:'Ein Soldat aus Morvath versteckt sich am Fluss bei der Grenzbrücke. Er sagt, er sei geflohen. Hilfst du ihm – oder lieferst du ihn aus?', steps:[
    {t:'branch', txt:'Hilf Kasimir an der Grenzbrücke – oder melde ihn Hauptmann Roderich in Aldenmark.', opts:[
      {npc:'kasimir', label:'🤝 „Ich helfe dir.“', say:'„Danke… Ich habe seit Tagen nichts gegessen. Drei Brote – dann sage ich dir etwas, das dir das Leben retten wird.“'},
      {npc:'roderich', label:'⚖️ Den Deserteur melden', say:'Roderich nickt grimmig. „Ein Soldat Morvaths, so nah an der Stadt. Meine Leute holen ihn. Gute Arbeit.“',
        fn:() => { P.f.kasimirGemeldet = true; P.rep.stadt += 10; P.gold += 150; P.rep.karma -= 5; }, jump:2}]},
    {t:'collect', item:'brot', n:3, npc:'kasimir', txt:'Bring Kasimir 3 Brote.', say:'Kasimir isst gierig. Dann senkt er die Stimme. „Malgor trinkt die Kraft der Schattenkristalle. Wenn du ihn angreifst, zerschlag zuerst die Kristallsäulen in seinem Saal – dann ist er verwundbar. Ich habe sie selbst bewacht.“', onDone:() => { P.f.kasimir = true; toast('🗡️ Du kennst jetzt Malgors Schwachstelle.', 'gold'); }}],
    reward:{xp:500}},
  fest:{name:'Das Fest von Eichenrast', giver:'Dorfälteste Edda', lvl:5, desc:'Eichenrast will die Befreiung von den Goblins feiern. Es fehlt nur noch guter Wein – und der Ehrengast.', steps:[
    {t:'collect', item:'wein', n:2, npc:'edda', txt:'Bring Edda 2 Flaschen Elfenwein (gibt es bei Baldur oder Wirtin Rosa).', say:'„Wunderbar! Heute Abend wird gefeiert – und du sitzt am Kopf der Tafel.“'}],
    reward:{xp:300, rep:5, items:[['festmahl', 1]]},
    onDone:() => { if (P.comp.lyra) P.comp.lyra.aff = Math.min(100, P.comp.lyra.aff + 10); showScene('🎉', 'Lampions hängen zwischen den Bäumen. Bauer Jost spielt erstaunlich schlecht auf der Fiedel, die Kinder tanzen um das Feuer, und Lyra zieht dich lachend in den Kreis.<br><br>Zum ersten Mal fühlt sich ein Ort wie Zuhause an.'); }},
  kristallherz:{name:'Das Kristallherz', giver:'Runenmeisterin Hilda', lvl:10, desc:'Die große Runenschmiede von Tiefgrund ist erloschen. Hilda braucht Magiekristalle, um sie wieder zu entfachen – und bringt dir dafür das Runenschmieden bei.', steps:[
    {t:'collect', item:'kristall', n:4, npc:'hilda', txt:'Bring Hilda 4 Magiekristalle (Kristallfelsen in den Bergen, Spitzhacke nötig).', say:'Hilda setzt die Kristalle in die Esse. Blaues Feuer schießt hoch. „Sie lebt! Komm her, ich zeig dir, wie man Runen in Stahl brennt.“'}],
    reward:{xp:500, items:[['silberbarren', 2]], prof:{schmieden:1}}}
});
// Empfohlene Stufen der bisherigen Quests
Object.entries({ratten:1, krumm:2, gilde:3, goblins:5, spuren:9, audienz:11, sumpf:13, krieg:16, pilze:2, eintopf:4, erz:3, erz2:5, woelfe:4, leder:5}).forEach(([k, v]) => { if (QUESTS[k]) QUESTS[k].lvl = v; });

// ---------- Figuren reagieren auf deine Taten ----------
react('rosa', [[() => P.f.briefEhrlich, '„Jost hat mich zum Tanz am Sonntag eingeladen. Was ziehe ich bloß an?“'], [() => P.f.briefSpott, '„Du. Bei dir zähle ich jeden Krug doppelt nach.“']]);
react('hilde', [[() => P.f.valdrinGeheim, '„Unser Geheimnis, Kind. Ich sag’s nicht mal der Katze.“'], [() => P.f.valdrinErbe, '„Ganz Aldenmark redet über dich. Ein Königskind aus meiner Hütte! Ich krieg mich gar nicht mehr ein.“']]);
react('koenig', [[() => P.f.valdrinErbe, '„Valdrins Erbe. Du erinnerst mich an deinen Vater – er hat auch nie gefragt, bevor er eine Tür eingetreten hat.“']]);
react('roderich', [[() => questDone('spaeher'), '„Der Kämmerer sitzt im Kerker. Ohne dich hätte Malgor uns von innen aufgefressen.“'], [() => P.f.kasimirGemeldet, '„Der Deserteur hat geredet. Seine Informationen waren… nützlich.“']]);
react('bauer', [[() => P.f.briefEhrlich, '„Sonntag! Spazieren! Mit Rosa!“ Jost strahlt wie ein Kind.']]);
react('edda', [[() => questDone('fest'), '„Die Kinder spielen immer noch „Held besiegt Goblinhäuptling“. Du bist immer der Held. Jost ist immer der Goblin.“']]);

// ---------- Neue Ereignisse unterwegs ----------
const BARD_SONGS = [
  '„♪ In Valdrin stand ein Turm aus Gold, ein König gut, ein Volk ihm hold – bis Malgor kam im Mondenschein und brach das Reich in Staub und Stein… ♪“',
  '„♪ Im Eisenzahn, wo Asche weht, ein Drache schläft, der nie vergeht. Wer seine Schuppe tragen will, der kehrt nicht heim – er bleibt dort still… ♪“',
  '„♪ Ein Kind aus Dreck und Rattenloch, das stahl sein Brot und lachte doch. Man sagt, es trägt ein Königsblut – doch wichtig ist nur: Es hat Mut! ♪“',
  '„♪ Die Hexe im Nebel, so grün wie das Moor, sie flüstert dir Rezepte ins Ohr. Doch sei auf der Hut, sei weise und klug – ein Trank zu viel ist ein Schluck zu viel genug… ♪“'
];
const STORY_EVENTS = [
  {w:2, fn() {
    const z = ZONES[regionAt(P.x, P.y)]; if (!z || z.neutral || !z.mobs.length) return;
    const foes = z.mobs.filter(m => !ENEMIES[m[0]].passive); if (!foes.length) return;
    const s = freeSpot(6, 9); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'opfer');
    const npc = {id:'opfer', name:'Bedrängter Händler', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e8c0a0', hair:'#5a3a1a', outfit:'#8a6a2a'},
      talk() {
        if (this.done) return {text:'„Danke nochmal! Ich trinke heute Abend auf dich.“'};
        if (G.enemies.some(e => !e.dead && !e.def.passive && dist(e.x, e.y, this.x, this.y) < 9)) return {text:'„Hilfe! Mach sie fertig, bevor sie mich zerreißen!“'};
        this.done = true; const g = Math.round(rint(40, 90) * Math.max(1, z.lv[0] / 3)); P.gold += g; P.rep.karma += 3; sfx('coin');
        return {text:'„Du hast mir das Leben gerettet! Hier – ' + g + ' Gold. Und erzähl jedem, dass Händler Bert seine Schulden bezahlt!“'};
      }};
    G.tmp.push(npc);
    const type = wpick(foes), n = rint(2, 3);
    let placed = 0;
    for (let k = 0; k < 40 && placed < n; k++) {
      const ang = Math.random() * TAU, r = rnd(1.5, 4.5), x = npc.x + Math.cos(ang) * r, y = npc.y + Math.sin(ang) * r;
      if (canStand(x, y, 0.3, true)) { spawnEnemy(type, x, y, {aggro:true, lvl:rint(z.lv[0], z.lv[1])}); placed++; }
    }
    if (!placed) { G.tmp = G.tmp.filter(t => t.id !== 'opfer'); return; }   // kein Platz – Ereignis fällt aus
    refreshNpcs(); toast('🆘 Ein Händler wird angegriffen!', 'quest');
  }},
  {w:1, fn() {
    const s = freeSpot(4, 7); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'barde');
    G.tmp.push({id:'barde', name:'Wanderbarde Lio', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#f0c8a8', hair:'#e8a040', outfit:'#7a3a8a'},
      talk() {
        if (this.done) return {text:'„Ich schreibe gerade ein Lied über dich. Es reimt sich noch nicht.“'};
        this.done = true; P.buffs.mut = 300; gainXp(25);
        return {text:'Der Barde stimmt seine Laute:<br><br><i>' + pick(BARD_SONGS) + '</i><br><br>Du fühlst dich beschwingt. (Angeheitert: Flirten fällt leichter)'};
      }});
    refreshNpcs(); toast('🎵 Irgendwo in der Nähe spielt jemand Laute…', 'quest');
  }}
];

// ---------- Kleidung & Aussehen der Figuren ----------
const LOOK_STYLE = {
  hilde:{style:'cloth', outfit:'#6b5a48', jewel:false}, krumm:{style:'leather', outfit:'#2e2e38'}, bettler:{style:'cloth', outfit:'#5a5040'},
  baldur:{style:'cloth', outfit:'#8a6a2a'}, gunnar:{style:'leather', outfit:'#5a4030'}, rosa:{style:'cloth', outfit:'#9a2a4a', gem:'#e8c040'},
  sera:{style:'leather', outfit:'#5a3a2a', gem:'#3a8ad0'}, roderich:{style:'plate', plume:'#c83a3a', helmCol:'#a8acb8', trim:'#3a5aa8'},
  ulrich:{style:'robe', outfit:'#2a4a3a', trim:'#c8a040'}, koenig:{style:'royal', outfit:'#7a1a2a', helmCol:'#e8c040'}, wache4:{style:'chain', outfit:'#7a1a2a', helmCol:'#c8a040'},
  varek:{style:'royal', outfit:'#4a1a3a', trim:'#a080c0'}, thalion:{style:'robe', outfit:'#3a2a7a', trim:'#e8c040'}, anselm:{style:'robe', outfit:'#e8e0c8', trim:'#c8a040'},
  edda:{style:'cloth', outfit:'#5a6a3a', jewel:false}, wilma:{style:'leather', outfit:'#4a5a2a', gem:'#7ae040'}, morla:{style:'robe', outfit:'#2a4a2a', trim:'#8ad070', gem:'#7ae040'},
  wache1:{style:'chain', outfit:'#3a5aa8', helmCol:'#9a9aa4'}, wache2:{style:'chain', outfit:'#3a5aa8', helmCol:'#9a9aa4'}, wache3:{style:'chain', outfit:'#3a5aa8', helmCol:'#9a9aa4'},
  buerger1:{style:'cloth', outfit:'#5a7a9a'}, buerger2:{style:'cloth', outfit:'#8a6a3a'}, buerger3:{style:'cloth', outfit:'#9a3a5a', gem:'#e8c040'}, bauer:{style:'cloth', outfit:'#6a7a3a'},
  elsa:{style:'cloth', outfit:'#6a8a5a'}, tom:{style:'cloth'}, tom_stadt:{style:'cloth'}, ragnar:{style:'leather'}, oswin:{style:'robe', outfit:'#4a5a3a', trim:'#8a7a4a'},
  fritz:{style:'chain', outfit:'#5a6a8a'}, kasimir:{style:'chain', outfit:'#3a2030'}, hilda:{style:'chain', outfit:'#8a2a2a', gem:'#3ac8f0'}, geist:{style:'plate', metal:'#c8f0ff', helmCol:'#c8f0ff', trim:'#e8ffff'},
  grimm:{style:'leather', outfit:'#5a4a3a'}, mira:{style:'robe', outfit:'#e8e0c8', trim:'#e8c040', gem:'#e8c040'}, kael:{style:'robe', outfit:'#3a3a8a', trim:'#c8a040'},
  lyra:{style:'leather', outfit:'#3f6a35', gem:'#7ae040'}, brann:{style:'chain', outfit:'#8a2a2a'}
};
for (const d of NPC_DEFS) if (LOOK_STYLE[d.id] && d.look) Object.assign(d.look, LOOK_STYLE[d.id]);
for (const id in COMPS) if (LOOK_STYLE[id]) Object.assign(COMPS[id].look, LOOK_STYLE[id]);
