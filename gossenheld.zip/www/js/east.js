'use strict';
// ================= DER OSTEN: FRONT, KAISERREICH MORVATH, DRACHENZINNEN, WÜSTE =================
// Seit 0.11 ist die Welt 400 Felder breit (vorher 256). Alles hier liegt bei x ≥ 250.
// Kapitel II der Hauptgeschichte: „Die Ewige Kaiserin“.

// ---------- Neue Kacheln ----------
Object.assign(TL, {NEST:50, CACTUS:51, DUNE:52, SANDSTONE:53, BONES:54, DPINE:55, FIELD:56});
[51, 53, 55].forEach(t => { BLOCK[t] = 1; PSOLID[t] = 1; }); TALL[55] = 1;
Object.assign(TILE_COLORS, {50:'#8a6a4a', 51:'#4a8a3a', 52:'#e0c070', 53:'#c8a070', 54:'#e8e0d0', 55:'#1e3a2e', 56:'#8a7040'});
HARVEST[50] = {verb:'Ei nehmen', item:'drachenei', n:[1, 1], prof:'sammeln', time:2.2, lvl:5, regrow:6};
HARVEST[51] = {verb:'Pflücken', item:'kaktusfrucht', n:[1, 2], prof:'sammeln', time:0.8, lvl:0, regrow:2};
HARVEST[53] = {verb:'Abbauen', item:'stein', n:[2, 3], tool:'spitzhacke', prof:'bergbau', time:1.2, lvl:0, regrow:4};
HARVEST[55] = {verb:'Fällen', item:'holz', n:[2, 3], tool:'axt', prof:'holz', time:1.2, lvl:0, regrow:2};

const _drawTileSouth = drawTile;
drawTile = function (t, v) {
  if (t < 50) return _drawTileSouth(t, v);
  const tall = t === TL.DPINE, c = mkCanvas(tall ? 20 : 16, tall ? 28 : 16), x = c.getContext('2d'), s = t * 100 + v * 7 + 11;
  const R = (a, b, w, h, col) => { x.fillStyle = col; x.fillRect(a, b, w, h); };
  switch (t) {
    case TL.NEST:
      speck(x, 16, 16, '#857b6c', ['#766c5e', '#978d7d'], 0.4, s);
      for (let k = 0; k < 14; k++) { const a = k / 14 * TAU; R(Math.round(8 + Math.cos(a) * 6) - 1, Math.round(9 + Math.sin(a) * 4), 3, 1, k % 2 ? '#6a4a2a' : '#8a6a3a'); }
      R(5, 7, 3, 4, '#e8dcc0'); R(5, 7, 1, 1, '#ffffff'); R(9, 6, 3, 4, ['#c84a3a', '#4a8ad0', '#4a9a4a', '#e8c040'][v]); R(9, 6, 1, 1, '#ffffff');
      addOutline(c, '#1a140e'); break;
    case TL.CACTUS:
      speck(x, 16, 16, '#d9c58a', ['#ccb679', '#e6d6a2'], 0.25, s);
      R(6, 2, 4, 13, '#3a7a2a'); R(7, 2, 1, 13, '#5aa040'); R(2, 6, 2, 5, '#3a7a2a'); R(2, 10, 4, 2, '#3a7a2a'); R(12, 4, 2, 5, '#3a7a2a'); R(10, 8, 4, 2, '#3a7a2a');
      for (const [a, b] of [[5, 4], [10, 7], [5, 10], [10, 12], [1, 7], [14, 5]]) R(a, b, 1, 1, '#e8e0b0');
      if (v % 2) { R(6, 1, 2, 2, '#e85a8a'); R(12, 3, 2, 1, '#e8c040'); }
      addOutline(c, '#1a140e'); break;
    case TL.DUNE:
      speck(x, 16, 16, '#e0c070', ['#d0b060', '#ecd088', '#c8a858'], 0.3, s);
      for (const row of [4, 9, 14]) { const o = (v * 3 + row) % 5; for (let a = 0; a < 16; a++) if ((a + o) % 8 < 5) R(a, row + (a % 8 < 3 ? 0 : 1), 1, 1, '#b8984a'); }
      break;
    case TL.SANDSTONE:
      R(0, 0, 16, 16, '#b88a5a'); R(1, 1, 14, 6, '#d8aa78'); R(1, 9, 6, 6, '#c89a68'); R(9, 9, 6, 6, '#d0a272');
      R(0, 7, 16, 2, '#8a6a42'); R(7, 9, 2, 7, '#8a6a42'); R(2, 2, 4, 1, '#ecc490');
      if (v === 2) { R(3, 3, 2, 2, '#8a6a42'); R(11, 11, 2, 1, '#8a6a42'); }
      break;
    case TL.BONES:
      x.clearRect(0, 0, 16, 16);
      R(3, 9, 6, 4, '#e8e0d0'); R(4, 10, 1, 1, '#3a2a2a'); R(7, 10, 1, 1, '#3a2a2a'); R(4, 12, 4, 1, '#c8c0b0');
      R(10, 11, 5, 1, '#e8e0d0'); R(9, 10, 1, 3, '#e8e0d0'); R(14, 10, 1, 3, '#e8e0d0');
      if (v > 1) { R(2, 4, 7, 1, '#d8d0c0'); R(1, 3, 1, 3, '#d8d0c0'); }
      addOutline(c, '#3a2a1a'); break;
    case TL.DPINE: {
      R(9, 21, 3, 7, '#3a2a1a');
      for (let k = 0; k < 4; k++) { const top = 2 + k * 5, hw = 3 + k * 2; for (let y = 0; y < 7; y++) { const w = Math.floor(hw * (y + 1) / 7); R(10 - w, top + y, w * 2 + 1, 1, '#1e3a2e'); R(10 - w, top + y, Math.max(1, w), 1, '#2c4e3c'); } }
      if (v === 3) { R(8, 9, 1, 1, '#a040f0'); R(13, 16, 1, 1, '#a040f0'); }
      addOutline(c, '#0e0a0a'); break; }
    case TL.FIELD:
      R(0, 0, 16, 16, '#7a5a32');
      for (let row = 1; row < 16; row += 4) { R(0, row, 16, 2, '#6a4a28'); for (let a = 1 + (v % 2); a < 16; a += 3) { R(a, row - 1, 1, 2, v === 3 ? '#c8a040' : '#5a9a3a'); R(a, row - 2, 1, 1, v === 3 ? '#e8c860' : '#7aba4a'); } }
      break;
  }
  return c;
};

// ---------- Regionen ----------
['drachenzinnen', 'wolkenhorst', 'front', 'loewenwacht', 'heerlager', 'kernland', 'rabenfurt', 'nachtkrone', 'grauwacht', 'grube', 'stollen', 'wueste', 'qarim', 'tiefwueste', 'sonnentempel']
  .forEach(r => { RIDX[r] = REGIONS.length; REGIONS.push(r); });
Object.assign(REGION_INFO, {
  drachenzinnen:{name:'Drachenzinnen', c:[340, 60], lv:[22, 28]},
  wolkenhorst:{name:'Kloster Wolkenhorst', c:[330, 31], safe:true},
  front:{name:'Die Brandmark (Front)', c:[272, 210], lv:[17, 21], dark:true},
  loewenwacht:{name:'Heerlager Löwenwacht', c:[266, 157], safe:true},
  heerlager:{name:'Kriegslager der Legion', c:[284, 129], lv:[19, 21], dark:true},
  kernland:{name:'Kaiserreich Morvath', c:[340, 135], lv:[19, 24], dark:true},
  rabenfurt:{name:'Rabenfurt', c:[312, 104], safe:true},
  nachtkrone:{name:'Nachtkrone (Hauptstadt)', c:[353, 150], safe:true},
  grauwacht:{name:'Grauwacht', c:[372, 220], safe:true},
  grube:{name:'Die Grube', c:[300, 202], lv:[20, 22], dark:true},
  stollen:{name:'Alte Stollen', c:[388, 213], lv:[20, 22]},
  wueste:{name:'Glutsand-Wüste', c:[286, 272], lv:[13, 17]},
  qarim:{name:'Oase Qarim', c:[300, 288], safe:true},
  tiefwueste:{name:'Tiefe Wüste', c:[360, 282], lv:[21, 25]},
  sonnentempel:{name:'Sonnentempel', c:[378, 293], lv:[23, 26]}
});
Object.assign(ZONES, {
  front:{lv:[17, 21], cap:8, pack:0.35, mobs:[['legionaer', 3], ['legion_armbrust', 2], ['kriegshund', 2], ['soldat', 1]]},
  heerlager:{lv:[19, 21], cap:7, hostile:true, mobs:[['legionaer', 3], ['legion_armbrust', 2], ['kriegsmagier', 1]]},
  kernland:{lv:[19, 24], cap:7, pack:0.3, mobs:[['legionaer', 2], ['legion_armbrust', 1], ['kriegsmagier', 1], ['kriegshund', 2], ['warg', 1], ['praetorianer', 1]]},
  grube:{lv:[20, 22], cap:6, hostile:true, mobs:[['aufseher', 3], ['legionaer', 1]]},
  stollen:{lv:[20, 22], cap:5, mobs:[['troll', 2]]},
  drachenzinnen:{lv:[22, 28], cap:6, pack:0.15, mobs:[['wyvern', 3], ['jungdrache', 2], ['frostdrache', 1], ['drachenjaeger', 2], ['baer', 1]]},
  wueste:{lv:[13, 17], cap:7, pack:0.2, mobs:[['skorpion', 3], ['sandechse', 2], ['dornechse', 1], ['wuestenraeuber', 2]]},
  tiefwueste:{lv:[21, 25], cap:7, mobs:[['skorpion', 2], ['mumie', 2], ['dornechse', 1], ['wuestenraeuber', 1]]},
  sonnentempel:{lv:[23, 26], cap:6, hostile:true, mobs:[['mumie', 3]]}
});
const EAST = {lager:[266, 168], raben:[312, 118], krone:[353, 173], grau:[372, 232], grube:[300, 211], heer:[284, 138], kloster:[330, 40], kroll:[302, 66], sturm:[382, 17], qarim:[300, 300], tempel:[378, 305]};
SOUTH_SAFE.push([266, 168, 14], [312, 118, 16], [353, 173, 24], [372, 232, 12], [330, 40, 10], [300, 300, 15]);
function kriverX(y) { return 318 + Math.sin(y / 11) * 4 + Math.sin(y / 4.7) * 1.3; }

// ---------- Gegenstände ----------
defI('passierschein', {name:'Passierschein von Morvath', icon:'📜', val:0, type:'quest', stack:true});
defI('legionssiegel', {name:'Legionssiegel', icon:'🔰', val:0, type:'quest', stack:true});
defI('sonnenherz', {name:'Das Sonnenherz', icon:'🌞', val:0, type:'quest', stack:true});
defI('adelsjuwel', {name:'Juwel der Gräfin Morwenna', icon:'💎', val:0, type:'quest', stack:true});
defI('drachenei', {name:'Drachenei', icon:'🥚', val:400, type:'tool', stack:true, desc:'Benutzen: ausbrüten – schlüpft ein junger Drache (Tierzähmung 8)'});
defI('kaktusfrucht', {name:'Kaktusfrucht', icon:'🌵', val:6, type:'food', heal:30, mana:10, stack:true});
defI('dattel', {name:'Datteln', icon:'🌴', val:5, type:'food', heal:18, stack:true, gift:true});
defI('skorpionstachel', {name:'Skorpionstachel', icon:'🦂', val:25, stack:true});
defI('jungschuppe', {name:'Jungdrachenschuppe', icon:'🐲', val:60, stack:true});
defI('gewuerzbraten', {name:'Gewürzbraten', icon:'🍖', val:70, type:'food', heal:200, buff:['satt', 300], stack:true});
defI('valdrinkrone', {name:'Krone von Valdrin', icon:'👑', type:'schmuck', bonus:{str:5, dex:5, int:5, vit:5, wis:5}, def:5, luck:0.1, val:0});
W('krummsaebel', 'Wüstenkrummsäbel', '🗡️', 'melee', 30, 950);
W('nachtklinge', 'Nachtklinge', '⚔️', 'melee', 37, 2200);
W('sonnenklinge', 'Sonnenklinge', '⚔️', 'melee', 50, 6000, {holy:true});
W('drachenbogen', 'Drachenbogen', '🏹', 'bow', 42, 5000);
A('wuestenrobe', 'Wüstenrobe', '🥻', 9, 900, {bonus:{dex:3, wis:2}});
A('drachenreiterruestung', 'Drachenreiter-Rüstung', '🐲', 28, 4800, {bonus:{str:3, vit:3}});
PG('echsensattel', 'Echsensattel', 'sattel', {speed:0.25, val:300, petCol:'#a8743c', minLvl:1});
PG('drachensattel', 'Drachensattel', 'sattel', {speed:0.45, def:6, val:2500, petCol:'#8a2a1a', minLvl:10});
Object.assign(ARMOR_COLOR, {wuestenrobe:'#d8c8a0', drachenreiterruestung:'#8a3a2a'});
Object.assign(ARMOR_STYLE, {wuestenrobe:['robe'], drachenreiterruestung:['plate', '#8a3a2a', '#e8a040']});
RECIPES.push(
  {out:'krummsaebel', req:{silberbarren:2, eisenbarren:2, leder:1}, prof:'schmieden', lvl:8},
  {out:'echsensattel', req:{leder:3, skorpionstachel:1}, prof:'schmieden', lvl:4},
  {out:'drachensattel', req:{jungschuppe:4, leder:4}, prof:'schmieden', lvl:10},
  {out:'drachenreiterruestung', req:{jungschuppe:8, mithrilbarren:3}, prof:'schmieden', lvl:11},
  {out:'gewuerzbraten', req:{fleisch:2, dattel:2}, prof:'kochen', lvl:6, st:'feuer'}
);
Object.assign(SHOPS, {
  bertram:['grheiltrank', 'heiltrank', 'manatrank', 'reparaturset', 'meisterset', 'pfeile', 'koecher_gross', 'plattenruestung', 'plattenhelm', 'beinschienen', 'plattenstiefel', 'langschwert', 'mithrilklinge', 'kampfsattel', 'tiersilberpanzer'],
  ilsa:['brot', 'bier', 'wein', 'eintopf', 'gebraten', 'grheiltrank'],
  ottilie:['arkanstab', 'sternenstab', 'magierrobe', 'mithrilruestung', 'mithrilhelm', 'koenigssattel', 'tiermithrilpanzer', 'dimensionsbeutel', 'elfenkoecher', 'mithrilbogen'],
  hedda:['mithrilbarren', 'silberbarren', 'eisenbarren', 'meisterset', 'mithrilklinge', 'mithrilhandschuhe', 'mithrilstiefel', 'mithrilhose', 'spitzhacke'],
  faruk:['krummsaebel', 'wuestenrobe', 'echsensattel', 'kaktusfrucht', 'dattel', 'grheiltrank', 'rum', 'packtasche', 'perle'],
  ysolde:['drachensattel', 'tiermithrilpanzer', 'grheiltrank', 'fleisch', 'kaktusfrucht']
});
RUMORS.push(
  '„Malgor war nur ein Statthalter, heißt es. Hinter der Brandmark herrscht die Ewige Kaiserin – seit dreihundert Jahren.“',
  '„Im Nordosten, in den Drachenzinnen, nisten junge Drachen. Die Mönche von Wolkenhorst sollen sie reiten können!“',
  '„Die Beduinen der Oase Qarim zähmen Sandechsen. Schneller als jedes Pferd – und sie brauchen kaum Wasser.“',
  '„In Nachtkrone kommt nur hinein, wer einen Passierschein hat. Oder eine sehr gute Fälscherin kennt.“'
);

// ---------- Gegner ----------
Object.assign(ENEMIES, {
  legionaer:{name:'Legionär', shape:'hum', col:'#c9a890', outfit:'#3a1a2a', helm:true, hair:'#3a3a44', hp:300, dmg:30, spd:2.6, xp:230, gold:[20, 50], drops:[['eisenbarren', 0.35], ['grheiltrank', 0.1], ['nachtklinge', 0.01]], lvl:19},
  legion_armbrust:{name:'Legions-Armbrustschütze', shape:'hum', col:'#c9a890', outfit:'#2a1a2a', helm:true, hair:'#4a4a54', hp:220, dmg:26, spd:2.5, xp:220, gold:[18, 45], drops:[['pfeile', 0.5]], lvl:19, ranged:true, proj:'arrow'},
  kriegsmagier:{name:'Kriegsmagierin', shape:'hum', col:'#e0c0b0', outfit:'#2a1030', hair:'#1a1a2a', hp:200, dmg:32, spd:2.4, xp:260, gold:[25, 60], drops:[['schattenkristall', 0.4], ['manatrank', 0.3]], lvl:20, ranged:true, proj:'shadow'},
  kriegshund:{name:'Kriegshund', shape:'quad', size:1.1, col:'#3a3038', hp:220, dmg:26, spd:3.5, xp:180, drops:[['fell', 0.8], ['fleisch', 0.6]], lvl:18, tame:{lvl:7, roles:['kampf']}},
  drogan:{name:'Kriegsherr Drogan', shape:'hum', size:1.6, col:'#c9a890', outfit:'#2a1a1a', helm:true, hair:'#1a1a1a', hp:2600, dmg:40, spd:2.5, xp:3000, gold:[400, 600], drops:[['nachtklinge', 1]], lvl:20, boss:true},
  aufseher:{name:'Grubenaufseher', shape:'hum', col:'#d8a880', outfit:'#3a2a2a', hair:'#2a1a1a', bald:true, hp:260, dmg:28, spd:2.6, xp:220, gold:[20, 50], drops:[['dietrich', 0.3], ['eisenerz', 0.5]], lvl:20},
  praetorianer:{name:'Prätorianer', shape:'hum', size:1.15, col:'#c9a890', outfit:'#2a2a3a', helm:true, hair:'#2a2a34', hp:420, dmg:38, spd:2.6, xp:400, gold:[40, 90], drops:[['mithrilerz', 0.4], ['nachtklinge', 0.03], ['legionssiegel', 0.2]], lvl:24},
  schattenklinge:{name:'Schattenklinge', shape:'hum', col:'#d8b8a8', outfit:'#1a1a24', hair:'#0a0a12', hp:260, dmg:36, spd:3.2, xp:330, gold:[30, 70], drops:[['dietrich', 0.5], ['grheiltrank', 0.2]], lvl:24},
  varn:{name:'General Varn', shape:'hum', size:1.7, col:'#c9a890', outfit:'#1a1a2a', helm:true, hair:'#1a1a1a', hp:4000, dmg:48, spd:2.5, xp:6000, gold:[800, 1200], drops:[['mithrilbarren', 1, 3]], lvl:26, boss:true},
  nyxara:{name:'Die Ewige Kaiserin Nyxara', shape:'hum', size:1.8, col:'#e8d0e0', outfit:'#2a0a3a', hair:'#e8e0f0', eye:'#c040f0', hp:7000, dmg:55, spd:2.6, xp:12000, gold:[3000, 4000], drops:[['schattenkristall', 1, 5]], lvl:28, boss:true, ranged:true, proj:'shadow'},
  grell:{name:'Steuervogt Grell', shape:'hum', size:1.3, col:'#e8c0a0', outfit:'#4a3a1a', hair:'#8a6a2a', hp:1400, dmg:30, spd:2.4, xp:1600, gold:[500, 700], drops:[], lvl:21, boss:true},
  champion:{name:'Arenachampion Kord', shape:'hum', size:1.5, col:'#c8946a', outfit:'#5a3a1a', helm:true, hair:'#2a1a1a', hp:3000, dmg:44, spd:2.8, xp:3500, gold:[600, 900], drops:[['mithrilbarren', 1, 2]], lvl:24, boss:true},
  drachenjaeger:{name:'Drachenjäger', shape:'hum', col:'#d8a880', outfit:'#4a4a2a', hair:'#5a3a1a', hp:300, dmg:30, spd:2.6, xp:260, gold:[25, 60], drops:[['pfeile', 0.5], ['jungschuppe', 0.25]], lvl:22, ranged:true, proj:'arrow'},
  kroll:{name:'Jagdmeister Kroll', shape:'hum', size:1.5, col:'#d8a880', outfit:'#5a3a1a', hair:'#c8c8c8', hp:3000, dmg:42, spd:2.6, xp:4000, gold:[500, 800], drops:[['jungschuppe', 1, 4]], lvl:24, boss:true, ranged:true, proj:'arrow'},
  wyvern:{name:'Wyvern', shape:'quad', size:1.3, col:'#4a7a3a', hp:380, dmg:34, spd:3.2, xp:320, drops:[['jungschuppe', 0.5], ['fleisch', 0.8]], lvl:22, tame:{lvl:9, roles:['kampf', 'reit'], speed:2.0}, fly:true, dragon:true},
  jungdrache:{name:'Jungdrache', shape:'quad', size:1.35, col:'#b83a2a', hp:420, dmg:36, spd:3.0, xp:360, drops:[['jungschuppe', 0.8]], lvl:23, tame:{lvl:10, roles:['kampf', 'reit'], speed:2.2}, fly:true, dragon:true, ranged:true, proj:'fire'},
  frostdrache:{name:'Frostdrache', shape:'quad', size:1.35, col:'#4a7ab8', hp:460, dmg:38, spd:3.0, xp:400, drops:[['jungschuppe', 0.8], ['kristall', 0.3]], lvl:24, tame:{lvl:11, roles:['kampf', 'reit'], speed:2.3}, fly:true, dragon:true},
  sturmschwinge:{name:'Sturmschwinge, die Uralte', shape:'quad', size:2.6, col:'#5a3a8a', hp:8000, dmg:60, spd:2.6, xp:12000, gold:[2000, 3000], drops:[['schuppe', 1, 4], ['jungschuppe', 1, 6]], lvl:28, boss:true, ranged:true, proj:'fire'},
  skorpion:{name:'Riesenskorpion', shape:'quad', size:1.0, col:'#8a5a2a', hp:140, dmg:18, spd:2.6, xp:120, drops:[['skorpionstachel', 0.5]], lvl:14},
  sandechse:{name:'Sandechse', shape:'quad', size:1.2, col:'#c8a060', hp:120, dmg:0, spd:3.9, xp:60, drops:[['leder', 0.6]], lvl:13, passive:true, tame:{lvl:4, roles:['reit'], speed:1.95, food:'kaktusfrucht'}},
  dornechse:{name:'Dornechse', shape:'quad', size:1.35, col:'#8a7a3a', hp:260, dmg:24, spd:3.0, xp:200, drops:[['leder', 0.8], ['fleisch', 0.5]], lvl:16, tame:{lvl:7, roles:['kampf', 'reit'], speed:1.7}},
  wuestenraeuber:{name:'Wüstenräuber', shape:'hum', col:'#c89060', outfit:'#c8a878', helm:true, hair:'#1a1a1a', hp:180, dmg:20, spd:2.8, xp:140, gold:[15, 40], drops:[['dattel', 0.4], ['krummsaebel', 0.02], ['schatzkarte', 0.03]], lvl:15},
  mumie:{name:'Tempelmumie', shape:'hum', col:'#d8cca8', outfit:'#c8b890', bald:true, eye:'#40f0a0', hp:320, dmg:32, spd:2.1, xp:280, gold:[20, 50], drops:[['buch', 0.1], ['kristall', 0.2]], lvl:22, undead:true},
  sandschlund:{name:'Der Sandschlund', shape:'quad', size:2.4, col:'#b8905a', hp:3200, dmg:44, spd:2.2, xp:5000, gold:[600, 900], drops:[['skorpionstachel', 1, 4], ['perle', 1, 3]], lvl:22, boss:true},
  sonnenwaechter:{name:'Der Sonnenwächter', shape:'hum', size:2.0, col:'#c8a040', outfit:'#8a6a2a', bald:true, eye:'#ffffff', hp:4200, dmg:46, spd:2.0, xp:6500, gold:[700, 1000], drops:[['kristall', 1, 3]], lvl:24, boss:true, ranged:true, proj:'fire'}
});
Object.assign(ENEMY_STYLE, {
  legionaer:{style:'plate', metal:'#4a3a4a', trim:'#8a1a2a', helmCol:'#4a3a4a'}, legion_armbrust:{style:'chain', outfit:'#3a1a2a', helmCol:'#5a4a5a'},
  kriegsmagier:{style:'robe', outfit:'#2a1030', trim:'#a040f0', female:true, longHair:true, gem:'#a040f0'},
  drogan:{style:'plate', metal:'#3a2a2a', trim:'#c83a1a', cape:'#5a0a0a', beard:true, helmCol:'#3a2a2a'},
  aufseher:{style:'leather', outfit:'#3a2a2a'}, praetorianer:{style:'plate', metal:'#2a2a3a', trim:'#e8c040', cape:'#4a0a2a', plume:'#c8a040', helmCol:'#2a2a3a'},
  schattenklinge:{style:'leather', outfit:'#1a1a24', female:true, longHair:true}, varn:{style:'plate', metal:'#1a1a2a', trim:'#e8c040', cape:'#6a0a1a', plume:'#e8c040', helmCol:'#1a1a2a', beard:true},
  nyxara:{style:'royal', outfit:'#2a0a3a', trim:'#c040f0', female:true, longHair:true, jewel:true, gem:'#c040f0', cape:'#1a0420'},
  grell:{style:'royal', outfit:'#4a3a1a', trim:'#c8a040'}, champion:{style:'plate', metal:'#8a6a3a', trim:'#c83a3a', helmCol:'#8a6a3a'},
  drachenjaeger:{style:'chain', outfit:'#4a4a2a'}, kroll:{style:'leather', outfit:'#5a3a1a', beard:true, cape:'#3a2a1a'},
  wuestenraeuber:{style:'cloth', outfit:'#c8a878', helmCol:'#e8dcc0'}, mumie:{style:'robe', outfit:'#c8b890', trim:'#a89870'},
  sonnenwaechter:{style:'plate', metal:'#c8a040', trim:'#ff8030'}
});
Object.assign(ANIMAL_DRAW, {
  drache(R, f, c, o) {
    const l = shade(c, 0.25), d = shade(c, -0.3), b = o.belly || shade(c, 0.45), w = shade(c, -0.15), wm = shade(c, 0.12), e = o.eye || '#ffd040';
    if (f) { R(3, 1, 2, 1, w); R(4, 2, 1, 6, w); R(5, 2, 1, 6, wm); R(6, 3, 1, 5, wm); R(7, 4, 1, 4, w); R(2, 0, 2, 1, d); }
    else { R(2, 6, 7, 1, w); R(3, 7, 6, 1, wm); R(4, 8, 4, 1, wm); R(1, 5, 2, 1, d); }
    R(0, 11, 2, 1, c); R(1, 10, 3, 2, c); R(0, 10, 1, 1, d);
    R(3, 9, 7, 4, c); R(4, 8, 5, 1, l); R(4, 12, 5, 1, b); R(5, 11, 3, 1, b);
    if (f) { R(4, 13, 1, 2, d); R(8, 13, 1, 1, d); R(9, 13, 1, 1, d); } else { R(5, 13, 1, 2, d); R(8, 13, 1, 2, d); }
    R(9, 6, 2, 4, c); R(10, 4, 4, 3, c); R(14, 5, 2, 2, c); R(13, 6, 2, 1, b); R(12, 4, 1, 1, e);
    R(10, 2, 1, 2, '#e8e0c8'); R(12, 3, 1, 1, '#e8e0c8'); R(6, 8, 1, 1, d); R(8, 8, 1, 1, d);
    if (o.spikes) { R(4, 7, 1, 1, '#e8e0c8'); R(7, 7, 1, 1, '#e8e0c8'); }
  },
  skorpion(R, f, c) {
    const l = shade(c, 0.25), d = shade(c, -0.3);
    for (let k = 0; k < 3; k++) { R(4 + k * 2 + (f ? 1 : 0), 13, 1, 2, d); R(5 + k * 2 - (f ? 1 : 0), 13, 1, 1, d); }
    R(4, 10, 7, 3, c); R(5, 10, 5, 1, l); R(11, 10, 2, 2, c); R(12, 9, 1, 1, '#111');
    R(13, 8, 2, 2, c); R(13, 12, 2, 2, c); R(15, 8, 1, 1, d); R(15, 13, 1, 1, d);
    R(3, 9, 2, 2, c); R(2, 7, 2, 2, c); R(2, 5, 2, 2, l); R(3, 3, 2, 2, c); R(5, 3, 2, 1, c); R(6, 4, 1, 2, '#2a1a1a'); R(7, 5, 1, 1, '#2a1a1a');
  },
  echse(R, f, c, o) {
    const l = shade(c, 0.3), d = shade(c, -0.35);
    R(0, 11, 3, 1, c); R(2, 10, 2, 2, c);
    R(3, 9, 8, 3, c); R(4, 8, 6, 1, l); R(3, 12, 8, 1, d); R(5, 10, 1, 1, d); R(8, 9, 1, 1, d);
    R(11, 8, 4, 3, c); R(15, 9, 1, 2, c); R(13, 8, 1, 1, o.eye || '#111'); R(11, 7, 3, 1, l);
    if (o.frill) { R(10, 5, 2, 4, '#c8603a'); R(9, 6, 1, 2, '#e8803a'); for (const a of [4, 6, 8]) R(a, 7, 1, 1, '#e8e0c8'); }
    if (f) { R(4, 12, 1, 3, d); R(9, 13, 1, 2, d); R(10, 12, 1, 1, d); } else { R(5, 12, 1, 3, d); R(9, 12, 1, 3, d); }
    if (o.spikes) { R(6, 8, 1, 1, '#e8e0c8'); R(9, 8, 1, 1, '#e8e0c8'); }
  },
  wurm(R, f, c) {
    const l = shade(c, 0.25), d = shade(c, -0.3);
    R(0, 13, 16, 3, '#c8a868'); R(1, 12, 5, 1, '#d8b878'); R(10, 12, 5, 1, '#d8b878');
    const up = f ? 1 : 0;
    R(2, 10, 3, 4, c); R(4, 7 - up, 3, 5, c); R(6, 5 - up, 3, 4, c); R(9, 3 - up, 4, 5, c);
    for (const [a, b] of [[3, 11], [5, 8], [7, 6], [10, 4]]) R(a, b - up, 2, 1, l);
    R(13, 4 - up, 3, 4, '#3a1a1a'); R(13, 4 - up, 1, 1, '#ffffff'); R(15, 4 - up, 1, 1, '#ffffff'); R(13, 7 - up, 1, 1, '#ffffff'); R(15, 7 - up, 1, 1, '#ffffff'); R(10, 3 - up, 1, 1, d);
  }
});
Object.assign(ANIMAL_LOOK, {
  kriegshund:['wolf', {spikes:true, eye:'#f06020'}], wyvern:['drache', {belly:'#a8c070'}], jungdrache:['drache', {}], frostdrache:['drache', {belly:'#e8f4ff', eye:'#a0f0ff'}],
  sturmschwinge:['drache', {belly:'#e8c0f0', eye:'#80f0ff', spikes:true}], skorpion:['skorpion', {}], sandechse:['echse', {}], dornechse:['echse', {frill:true}], sandschlund:['wurm', {}]
});
Object.assign(BOSS_POS, {drogan:[284.5, 137.6], grell:[326.5, 112.6], champion:[364.5, 182.6], sandschlund:[318.5, 318.6], sonnenwaechter:[378.5, 303.6], kroll:[302.5, 66.6], sturmschwinge:[382.5, 17.6], varn:[352.5, 166.6], nyxara:[0, 0]});

// ---------- Icons ----------
Object.assign(ICON_DRAW, {
  egg(R, o) { const c = o.c || '#e8dcc0'; R(5, 3, 6, 10, c); R(4, 5, 8, 7, c); R(5, 4, 2, 2, '#ffffff'); R(4, 11, 8, 2, shade(c, -0.25)); R(8, 6, 2, 2, o.s || '#c84a3a'); R(6, 9, 2, 1, o.s || '#c84a3a'); R(10, 9, 1, 2, o.s || '#c84a3a'); },
  cactusfruit(R) { R(4, 5, 8, 8, '#e04a7a'); R(5, 4, 6, 10, '#e04a7a'); R(5, 5, 2, 2, '#f8a0c0'); for (const [a, b] of [[7, 8], [9, 10], [6, 11], [10, 6]]) R(a, b, 1, 1, '#ffe0a0'); R(6, 2, 1, 2, '#4a8a3a'); R(8, 1, 1, 3, '#4a8a3a'); R(10, 2, 1, 2, '#4a8a3a'); },
  dates(R) { for (const [a, b] of [[3, 7], [7, 5], [9, 9], [5, 10]]) { R(a, b, 4, 3, '#7a3a1a'); R(a, b, 2, 1, '#a85a2a'); } R(7, 2, 1, 4, '#8a6a3a'); },
  stinger(R) { R(3, 11, 3, 3, '#8a5a2a'); R(5, 9, 2, 3, '#8a5a2a'); R(7, 6, 2, 4, '#9a6a3a'); R(9, 4, 2, 3, '#a8743c'); R(11, 2, 2, 3, '#2a1a1a'); R(12, 1, 1, 1, '#4a3a3a'); R(6, 10, 1, 1, '#c89a5a'); },
  crown(R) { R(2, 7, 12, 6, '#e8c040'); R(2, 4, 2, 3, '#e8c040'); R(7, 2, 2, 5, '#e8c040'); R(12, 4, 2, 3, '#e8c040'); R(2, 12, 12, 1, '#a8801a'); R(7, 9, 2, 2, '#c83a3a'); R(3, 9, 2, 2, '#3a8ad0'); R(11, 9, 2, 2, '#3a9a4a'); R(3, 7, 10, 1, '#fff0a0'); }
});
Object.assign(ICON_DEF, {
  passierschein:['letter', {seal:'#8a1a2a'}], legionssiegel:['amulet', {c:'#4a1a3a'}], sonnenherz:['gem', {c:'#ffd040'}], adelsjuwel:['gem', {c:'#e04a7a'}],
  drachenei:['egg'], kaktusfrucht:['cactusfruit'], dattel:['dates'], skorpionstachel:['stinger'], jungschuppe:['scale'], gewuerzbraten:['cooked'], valdrinkrone:['crown'],
  krummsaebel:['sabre', {c:'#e8e0c8', g:'#e8c040'}], nachtklinge:['sword', {len:9, guard:2, grip:2, fuller:true, c:'#7a6a9a', g:'#2a1a3a', gem:'#a040f0'}],
  sonnenklinge:['sword', {len:10, guard:3, grip:3, fuller:true, c:'#fff0a0', g:'#e8c040', gem:'#ff8030'}], drachenbogen:['bow', {c:'#8a2a1a', g:'#e8c040', gem:'#ff6030'}],
  wuestenrobe:['armor', {c:'#d8c8a0', t:'robe', a:'#8a5a2a'}], drachenreiterruestung:['armor', {c:'#8a3a2a', t:'dragon'}],
  echsensattel:['saddle', {c:'#a8743c'}], drachensattel:['saddle', {c:'#8a2a1a', g:'#e8c040'}]
});
for (const id of Object.keys(ICON_DEF)) if (ITEMS[id] && !ITEMS[id].emoji) { ITEMS[id].emoji = ITEMS[id].icon; ITEMS[id].icon = iconHTML(id); }

// Drachenei ausbrüten
ITEMS.drachenei.useLabel = '🥚 Ausbrüten';
ITEMS.drachenei.use = function () {
  if (!P.learned.zaehmen || P.prof.zaehmen.lvl < 8) { toast('Zum Ausbrüten brauchst du Tierzähmung Stufe 8.'); sfx('fail'); return; }
  if (P.pets.length >= 8) { toast('Du hast schon zu viele Tiere.'); return; }
  removeItem('drachenei', 1);
  const type = pick(['jungdrache', 'jungdrache', 'frostdrache', 'wyvern']);
  P.pets.push({type, name:'Drachenjunges', species:ENEMIES[type].name, lvl:1, xp:0, roles:ENEMIES[type].tame.roles.slice(), speed:ENEMIES[type].tame.speed, hp:null, gear:{}});
  sfx('tame'); burst(P.x, P.y - 0.5, '#ffb040', 24); syncAllies();
  showDialog('Ein Drache schlüpft!', 'Die Schale knackt, glüht – und ein kleiner ' + ENEMIES[type].name + ' blinzelt dich an. Er hält dich offensichtlich für seine Mutter.<br><br>Gib ihm unter <b>Gefährten → Tiere</b> einen Namen. Mit Stufe 8 und einem Sattel kannst du ihn reiten – und fliegen!', [{t:'Willkommen, Kleiner!'}]);
};
// Wilde Drachen lassen sich nur von Drachenfreunden zähmen
const _tryTameBase = tryTame;
tryTame = function (e) {
  if (e.def.dragon && !P.f.drachenfreund && P.prof.zaehmen.lvl < 12) { toast('🐉 Wilde Drachen vertrauen nur Drachenfreunden (Hauptquest in den Drachenzinnen) – oder Meistern der Tierzähmung (Stufe 12).'); return; }
  return _tryTameBase(e);
};
// Landen nur auf festem Boden
const _toggleRideBase = toggleRide;
toggleRide = function () {
  if (P.mounted && G.flying) { const t = tileAt(P.x, P.y); if (WG[idx(Math.floor(P.x), Math.floor(P.y))] === TL.WATER || t === TL.LAVA) { toast('🐉 Hier kannst du nicht landen – flieg erst an Land.'); return; } }
  return _toggleRideBase();
};

// ---------- Gebäudebilder: Zelte, Lehmhäuser, Pagode, dunkle Häuser ----------
const _houseCanvasSouth = houseCanvas, EAST_HOUSE = {};
houseCanvas = function (b) {
  if (!b.tent && !b.adobe && !b.pagoda && !b.dark) return _houseCanvasSouth(b);
  const key = [b.tent ? 't' : b.adobe ? 'a' : b.pagoda ? 'p' : 'd', b.w, b.h, b.v, b.col || '', b.wall ? 1 : 0, b.door].join(',');
  if (EAST_HOUSE[key]) return EAST_HOUSE[key];
  const W = b.w * 16, H = b.h * 16 + 8;
  let c;
  if (b.dark) {
    const base = _houseCanvasSouth(Object.assign({}, b, {dark:false}));
    c = mkCanvas(base.width, base.height); const x = c.getContext('2d'); x.drawImage(base, 0, 0);
    x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(34,12,48,0.38)'; x.fillRect(0, 0, c.width, c.height);
    if (b.wall) { x.globalCompositeOperation = 'source-over'; for (const bx of [c.width * 0.3, c.width * 0.7]) { const px = Math.round(bx) - 4; x.fillStyle = '#4a0a3a'; x.fillRect(px, 22, 8, 16); x.fillStyle = '#c040f0'; x.fillRect(px + 2, 27, 4, 4); } }
  } else {
    c = mkCanvas(W, H); const x = c.getContext('2d');
    const R = (a, y, w, h, col) => { x.fillStyle = col; x.fillRect(a, y, w, h); };
    if (b.tent) {
      const col = b.col || '#c8b08a', l = shade(col, 0.25), d = shade(col, -0.3), top = 6;
      for (let y = top; y < H - 2; y++) { const t = (y - top) / (H - 2 - top), hw = Math.round(3 + t * (W / 2 - 2)); for (let a = W / 2 - hw; a < W / 2 + hw; a++) R(a, y, 1, 1, Math.floor((a - W / 2 + 64) / 4) % 2 ? col : (b.stripe || l)); R(W / 2 + hw - 2, y, 2, 1, d); }
      R(W / 2 - 1, 1, 2, 6, '#5a3a1a'); R(W / 2 + 1, 1, 4, 3, b.flag || '#c83a3a');
      R(W / 2 - 4, H - 12, 8, 10, '#2a1a10'); R(W / 2 - 5, H - 13, 1, 11, d); R(W / 2 + 4, H - 13, 1, 11, d);
      R(1, H - 2, 2, 2, '#5a3a1a'); R(W - 3, H - 2, 2, 2, '#5a3a1a');
    } else if (b.adobe) {
      const wall = ['#d8b888', '#e0c49a', '#ccaa7a', '#d4b080'][b.v % 4], d = shade(wall, -0.25), top = H - 26;
      R(0, top, W, 26, wall); R(0, H - 4, W, 4, d); R(0, top, W, 3, shade(wall, 0.15)); R(0, top + 3, W, 1, d);
      for (let a = 6; a < W - 4; a += 14) { R(a, top + 1, 3, 3, '#7a5228'); }
      if (b.w >= 5) { const cx = W / 2; for (let y = 0; y < 12; y++) { const hw = Math.round(Math.sqrt(Math.max(0, 1 - ((11 - y) / 11) ** 2)) * 12); R(cx - hw, top - 12 + y, hw * 2, 1, y < 3 ? '#f0e0c0' : shade(wall, 0.08)); } R(cx - 1, top - 15, 2, 4, '#e8c040'); }
      for (let col = 0; col < b.w; col++) { const a = col * 16; if (a === b.door * 16) continue; R(a + 5, top + 8, 6, 6, '#3a2a1a'); R(a + 5, top + 8, 6, 1, '#6a4a2a'); R(a + 4, top + 14, 8, 1, d); }
      const dx = b.door * 16; R(dx + 3, H - 18, 10, 16, '#5a3a1a'); R(dx + 4, H - 20, 8, 2, '#5a3a1a'); R(dx + 4, H - 17, 8, 15, '#8a5a2a'); R(dx + 10, H - 10, 1, 2, '#e0b84a');
      R(dx + 2, H - 21, 12, 2, d);
      if (b.v % 2) { R(2, top + 18, 8, 2, '#c83a3a'); R(W - 10, top + 18, 8, 2, '#3a8ad0'); }
    } else if (b.pagoda) {
      const wall = '#8a2a1a', roof = '#2a5a5a', rl = '#3a7a6a', top2 = 6;
      R(4, H - 26, W - 8, 24, wall); for (let a = 6; a < W - 6; a += 12) R(a, H - 26, 2, 24, '#5a1a0a'); R(0, H - 3, W, 3, '#8d8d92');
      const roofRow = (y0, hw0, hw1, hgt) => { for (let y = 0; y < hgt; y++) { const t = y / (hgt - 1), hw = Math.round(hw0 + (hw1 - hw0) * t); R(W / 2 - hw, y0 + y, hw * 2, 1, y === hgt - 1 ? rl : roof); } R(W / 2 - hw1 - 2, y0 + hgt - 2, 3, 2, rl); R(W / 2 + hw1 - 1, y0 + hgt - 2, 3, 2, rl); };
      roofRow(H - 34, 10, W / 2, 9); R(10, H - 42, W - 20, 9, wall); roofRow(top2 + 2, 4, W / 2 - 8, 12); R(W / 2 - 1, 0, 2, top2 + 3, '#e8c040');
      const dx = b.door * 16; R(dx + 2, H - 20, 12, 18, '#3a1a0a'); R(dx + 3, H - 19, 10, 17, '#c83a1a'); R(dx + 7, H - 19, 1, 17, '#3a1a0a'); R(dx + 4, H - 24, 8, 3, '#e8c040');
      R(8, H - 18, 4, 6, '#e8d890'); R(W - 12, H - 18, 4, 6, '#e8d890');
    }
    addOutline(c, '#1a140e');
  }
  EAST_HOUSE[key] = c; return c;
};
function eastTent(x, y, w, h, col, extra) {
  BUILDINGS.push(Object.assign({x, y, w, h, v:3, tent:true, col, door:w >> 1}, extra || {}));
  for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (inb(xx, yy)) WT[idx(xx, yy)] = TL.BLOCKER;
}
function eastHouse(x0, y0, w, h, v, flag, type) { building(x0, y0, w, h, v, type); const b = BUILDINGS[BUILDINGS.length - 1]; b[flag] = true; return b; }

// ---------- Weltgenerierung des Ostens ----------
function eastGen() {
  const S = 9191;
  for (let y = 0; y < WORLD_H; y++) {
    const xs = 254 + Math.round(Math.sin(y / 13) * 3);
    for (let x = xs; x < MW; x++) {
      const i = idx(x, y), n = fbm(x, y, S), h = hash2(x, y, S + 9), h2 = hash2(x + 3, y + 7, S + 21), sy = seaY(x);
      let reg, g = TL.GRASS, o = -1;
      if (y < 92 + Math.sin(x / 10) * 4) {
        reg = 'drachenzinnen'; g = y < 40 + Math.sin(x / 7) * 3 ? TL.SNOW : TL.GRAVEL;
        if (n > 0.52) { o = TL.ROCK; if (h2 < 0.1) o = TL.IRON; else if (h2 < 0.16) o = TL.SILVER; else if (h2 < 0.21) o = TL.CRYSTAL; else if (h2 < 0.26) o = TL.MITHRIL; }
        else if (n < 0.2 && y > 45) g = TL.LAVA;
        else if (n > 0.44 && h < 0.3) o = TL.PINE; else if (h < 0.01) o = TL.NEST; else if (h < 0.018) o = TL.HERB;
      } else if (y < 258 + Math.sin(x / 12) * 4) {
        if (x < 288 + Math.sin(y / 9) * 3) {
          reg = 'front'; g = n > 0.56 ? TL.GRASS : h2 < 0.55 ? TL.ASH : TL.GRAVEL;
          if (n < 0.24) { g = TL.GRAVEL; if (h < 0.12) o = TL.ROCK; }
          else if (h < 0.03) o = TL.DEADTREE; else if (h < 0.042) o = TL.BONES; else if (h < 0.05) o = TL.FENCE; else if (h < 0.054) o = TL.ROCK;
        } else {
          reg = 'kernland'; g = TL.DARK;
          if (n > 0.62) o = TL.DPINE; else if (n < 0.24) g = TL.WATER;
          else if (h < 0.015) o = TL.ROCK; else if (h < 0.02) o = TL.IRON; else if (h < 0.03) o = TL.MUSHROOM; else if (h < 0.035) o = TL.BONES; else if (h < 0.045) o = TL.HERB;
          if (y > 95 && y < 246 && Math.abs(x - kriverX(y)) < 1.6) { g = TL.WATER; o = -1; }
        }
      } else {
        if (y >= sy) { reg = x < 335 ? 'wueste' : 'tiefwueste'; g = TL.WATER; }
        else {
          reg = x < 335 + Math.sin(y / 11) * 6 ? 'wueste' : 'tiefwueste';
          if (y >= sy - 3) { g = TL.SAND; if (h < 0.05) o = TL.SHELL; }
          else { g = n > 0.5 ? TL.DUNE : TL.SAND; if (h < 0.022) o = TL.CACTUS; else if (h < 0.03 || (reg === 'tiefwueste' && n > 0.74)) o = TL.SANDSTONE; else if (h < 0.034) o = TL.BONES; }
        }
      }
      if (x >= MW - 3 || y < 3 || y >= WORLD_H - 3) { g = TL.WATER; o = -1; }
      WR[i] = RIDX[reg]; WG[i] = g; WT[i] = o >= 0 ? o : g;
    }
  }
  const setT = (x, y, gt, ot) => { if (!inb(x, y)) return; const i = idx(x, y); if (gt != null) WG[i] = gt; WT[i] = ot != null ? ot : WG[i]; };
  const area = (cx, cy, r, reg, ground, sx) => { for (let y = Math.floor(cy - r); y <= cy + r; y++) for (let x = Math.floor(cx - r * (sx || 1)); x <= cx + r * (sx || 1); x++) {
    if (!inb(x, y) || Math.hypot((x - cx) / (sx || 1), y - cy) > r) continue; const i = idx(x, y); if (reg) WR[i] = RIDX[reg]; if (ground != null && WG[i] !== TL.WATER) { WG[i] = typeof ground === 'function' ? ground(x, y) : ground; WT[i] = WG[i]; } } };
  const ring = (cx, cy, r, t, gaps) => { for (let k = 0; k < 160; k++) { const a = k / 160 * TAU, x = Math.round(cx + Math.cos(a) * r), y = Math.round(cy + Math.sin(a) * r * 0.85);
    if (gaps.some(gp => Math.abs(((a - gp + TAU * 1.5) % TAU) - Math.PI) < 0.22)) continue; setT(x, y, null, t); } };
  // --- Heerlager Löwenwacht ---
  { const [cx, cy] = EAST.lager;
    area(cx, cy, 10, 'loewenwacht', (x, y) => hash2(x, y, 3) < 0.6 ? TL.GRASS : TL.PATH);
    ring(cx, cy, 9.4, TL.FENCE, [Math.PI, 0, Math.PI / 2]);
    eastTent(cx - 2, cy - 7, 5, 3, '#2a4a8a', {stripe:'#e8e0c8', flag:'#e8c040'});
    eastTent(cx - 7, cy - 3, 3, 2, '#3a5a9a'); eastTent(cx + 4, cy - 3, 3, 2, '#3a5a9a'); eastTent(cx - 7, cy + 3, 3, 2, '#e8e0c8', {stripe:'#c83a3a'}); eastTent(cx + 4, cy + 3, 3, 2, '#3a5a9a');
    setT(cx, cy, null, TL.HEARTH); setT(cx - 4, cy + 1, null, TL.ANVIL); setT(cx + 3, cy + 1, null, TL.BARREL); setT(cx + 3, cy, null, TL.BARREL); setT(cx - 4, cy - 1, null, TL.TABLE); }
  // --- Kriegslager der Legion ---
  { const [cx, cy] = EAST.heer;
    area(cx, cy, 8, 'heerlager', TL.ASH); ring(cx, cy, 7.6, TL.FENCE, [Math.PI, Math.PI / 2]);
    eastTent(cx - 5, cy - 5, 3, 2, '#3a1a2a', {flag:'#a040f0'}); eastTent(cx + 2, cy - 5, 3, 2, '#3a1a2a', {flag:'#a040f0'}); eastTent(cx + 2, cy + 2, 3, 2, '#2a1a1a', {flag:'#a040f0'});
    setT(cx - 3, cy + 2, null, TL.HEARTH); setT(cx + 5, cy, null, TL.BARREL);
    chestAt(cx - 5, cy + 3, {lock:4, gold:500, loot:[['grheiltrank', 2], ['mithrilbarren', 1]]}); }
  // --- Rabenfurt ---
  { const [cx, cy] = EAST.raben;
    area(cx, cy, 14, 'rabenfurt', (x, y) => Math.abs(y - cy - 3) <= 1 || Math.abs(x - cx + 4) <= 0 ? TL.PATH : (hash2(x, y, 4) < 0.2 ? TL.PATH : TL.GRASS), 1.15);
    for (let y = cy - 14; y <= cy + 14; y++) for (let x = cx - 16; x <= cx + 16; x++) if (inb(x, y) && Math.abs(x - kriverX(y)) < 1.6) setT(x, y, TL.WATER);
    eastHouse(cx - 12, cy - 9, 6, 3, 1, 'dark');                      // Gasthaus „Rabenkrug“ (Tür 297,111)
    eastHouse(cx - 4, cy - 10, 4, 3, 0, 'dark'); eastHouse(cx - 13, cy + 5, 4, 3, 2, 'dark'); eastHouse(cx - 6, cy + 6, 4, 3, 3, 'dark');
    eastHouse(cx + 9, cy - 8, 4, 3, 0, 'dark'); eastHouse(cx + 9, cy + 5, 5, 3, 2, 'dark');
    setT(cx - 3, cy, null, TL.HEARTH); setT(cx - 9, cy - 1, null, TL.BARREL); setT(cx + 12, cy, null, TL.ANVIL);
    for (let y = cy - 4; y <= cy + 1; y++) for (let x = cx + 20; x <= cx + 26; x++) if (inb(x, y) && WG[idx(x, y)] !== TL.WATER) setT(x, y, TL.FIELD);
    for (let y = cy + 15; y <= cy + 19; y++) for (let x = cx - 12; x <= cx - 4; x++) if (inb(x, y) && WG[idx(x, y)] !== TL.WATER) setT(x, y, TL.FIELD); }
  // --- Nachtkrone ---
  { const x0 = 334, x1 = 372, y0 = 154, y1 = 192;
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) { const i = idx(x, y); WR[i] = RIDX.nachtkrone; WG[i] = WT[i] = (x === x0 || x === x1 || y === y0 || y === y1) ? TL.WALL : (hash2(x, y, 8) < 0.12 ? TL.GRAVEL : TL.FLOOR); }
    for (let x = 351; x <= 355; x++) { setT(x, y1, TL.FLOOR); setT(x, y0, TL.FLOOR); } for (let y = 171; y <= 175; y++) { setT(x0, y, TL.FLOOR); setT(x1, y, TL.FLOOR); }
    for (let y = y0 - 1; y <= y1 + 1; y++) for (let x = x0 - 1; x <= x1 + 1; x++) if (inb(x, y)) WR[idx(x, y)] = RIDX.nachtkrone;
    eastHouse(346, 156, 13, 6, 0, 'dark', TL.WALL);           // Kaiserpalast (Tür 352,161)
    eastHouse(337, 163, 6, 3, 2, 'dark');                      // Große Bibliothek (Tür 340,165)
    eastHouse(362, 163, 6, 3, 1, 'dark');                      // Schwarzer Kelch
    eastHouse(362, 156, 6, 3, 3, 'dark');                      // Haus der Gräfin Morwenna
    eastHouse(337, 156, 6, 3, 0, 'dark'); eastHouse(337, 178, 5, 3, 0, 'dark'); eastHouse(343, 184, 5, 3, 3, 'dark'); eastHouse(337, 186, 4, 3, 1, 'dark');
    setT(352, 172, TL.WATER); setT(353, 172, TL.WATER); setT(352, 173, TL.WATER); setT(353, 173, TL.WATER);
    for (const [a, b] of [[349, 170], [356, 170], [349, 176], [356, 176]]) setT(a, b, null, TL.FLOWER);
    chestAt(368, 158, {lock:4, gold:400, loot:[['adelsjuwel', 1], ['ring', 1]]});
    const ax = 364, ay = 183; for (let y = ay - 5; y <= ay + 5; y++) for (let x = ax - 6; x <= ax + 6; x++) { const d = Math.hypot((x - ax) / 1.2, y - ay); if (d < 4.6) setT(x, y, TL.GRAVEL); else if (d < 5.4 && !(y > ay + 3 && Math.abs(x - ax) <= 1)) setT(x, y, TL.WALL); }
    setT(345, 181, null, TL.BARREL); setT(346, 181, null, TL.BARREL); setT(359, 168, null, TL.HEARTH); }
  // --- Grauwacht & Alte Stollen ---
  { const [cx, cy] = EAST.grau;
    area(cx, cy, 11, 'grauwacht', (x, y) => hash2(x, y, 6) < 0.35 ? TL.PATH : TL.GRAVEL);
    eastHouse(cx - 8, cy - 7, 5, 3, 1, 'dark'); eastHouse(cx + 2, cy - 7, 4, 3, 0, 'dark'); eastHouse(cx - 9, cy + 3, 4, 3, 2, 'dark'); eastHouse(cx + 3, cy + 3, 5, 3, 3, 'dark');
    setT(cx + 1, cy, null, TL.ANVIL); setT(cx - 2, cy, null, TL.HEARTH); setT(cx + 2, cy, null, TL.BARREL);
    area(351, 241, 6, null, TL.WATER);
    const [sx, sy2] = [388, 222]; area(sx, sy2, 7, 'stollen', TL.GRAVEL);
    for (let y = sy2 - 7; y <= sy2 + 7; y++) for (let x = sx - 8; x <= sx + 8; x++) { const d = Math.hypot(x - sx, y - sy2); if (d > 5 && d < 7 && !(x < sx && Math.abs(y - sy2) <= 1)) { const hh = hash2(x, y, 12); setT(x, y, null, hh < 0.3 ? TL.IRON : hh < 0.5 ? TL.SILVER : hh < 0.62 ? TL.MITHRIL : TL.ROCK); } } }
  // --- Die Grube ---
  { const [cx, cy] = EAST.grube; area(cx, cy, 8, 'grube', TL.GRAVEL); ring(cx, cy, 7.5, TL.FENCE, [Math.PI]);
    for (let k = 0; k < 10; k++) { const a = k * 0.7, x = Math.round(cx + Math.cos(a) * 4), y = Math.round(cy + Math.sin(a) * 3); setT(x, y, null, k % 3 ? TL.ROCK : TL.IRON); }
    eastTent(cx - 1, cy - 2, 3, 2, '#3a2a2a', {flag:'#a040f0'}); setT(cx + 2, cy + 3, null, TL.HEARTH); }
  // --- Kloster Wolkenhorst & Drachennester ---
  { const [cx, cy] = EAST.kloster; area(cx, cy, 8, 'wolkenhorst', (x, y) => hash2(x, y, 7) < 0.4 ? TL.PATH : TL.SNOW);
    eastHouse(cx - 3, cy - 6, 7, 4, 0, 'pagoda', TL.WALL); BUILDINGS[BUILDINGS.length - 1].wall = false;
    setT(cx - 4, cy + 1, null, TL.HEARTH); for (const [a, b] of [[cx + 5, cy + 3], [cx - 6, cy + 4], [cx + 6, cy - 2]]) setT(a, b, null, TL.NEST);
    const [kx, ky] = EAST.kroll; area(kx, ky, 6, null, TL.GRAVEL); eastTent(kx - 4, ky - 4, 3, 2, '#5a4a2a'); eastTent(kx + 1, ky - 4, 3, 2, '#5a4a2a');
    for (let x = kx - 4; x <= kx + 4; x++) if (Math.abs(x - kx) > 1) setT(x, ky + 4, null, TL.FENCE); setT(kx, ky + 1, null, TL.HEARTH);
    const [tx, ty] = EAST.sturm; area(tx, ty, 6, null, TL.GRAVEL); for (let k = 0; k < 6; k++) setT(Math.round(tx + Math.cos(k) * 4), Math.round(ty + Math.sin(k) * 3), null, TL.NEST); }
  // --- Oase Qarim ---
  { const [cx, cy] = EAST.qarim;
    area(cx, cy, 14, 'qarim', (x, y) => Math.hypot(x - cx, y - cy + 2) < 7 ? TL.GRASS : hash2(x, y, 9) < 0.25 ? TL.PATH : TL.SAND, 1.1);
    area(cx, cy - 2, 3.6, null, TL.WATER);
    for (let k = 0; k < 9; k++) { const a = k / 9 * TAU, x = Math.round(cx + Math.cos(a) * 5.5), y = Math.round(cy - 2 + Math.sin(a) * 4.6); setT(x, y, null, TL.PALM); }
    eastTent(cx - 11, cy - 8, 4, 3, '#c83a3a', {stripe:'#e8d8b0', flag:'#e8c040'}); eastTent(cx + 7, cy - 9, 4, 3, '#3a5a9a', {stripe:'#e8d8b0'}); eastTent(cx - 12, cy + 3, 3, 2, '#e8c040', {stripe:'#c8702a'});
    eastHouse(cx + 6, cy + 2, 5, 3, 1, 'adobe'); eastHouse(cx - 6, cy + 6, 4, 3, 0, 'adobe'); eastHouse(cx + 1, cy + 7, 4, 3, 2, 'adobe');
    setT(cx - 4, cy + 3, null, TL.HEARTH); setT(cx + 4, cy + 4, null, TL.BARREL); setT(cx + 5, cy + 5, null, TL.BARREL);
    const pt = Math.floor(seaY(cx + 2)) - 2; for (let y = pt; y < pt + 9; y++) { setT(cx + 2, y, TL.BRIDGE); setT(cx + 3, y, TL.BRIDGE); WR[idx(cx + 2, y)] = WR[idx(cx + 3, y)] = RIDX.qarim; }
    BUILDINGS.push({x:cx + 5, y:pt + 3, w:6, h:3, v:3, ship:true, door:0}); }
  // --- Sonnentempel ---
  { const [cx, cy] = EAST.tempel, x0 = cx - 9, x1 = cx + 9, y0 = cy - 9, y1 = cy + 9;
    area(cx, cy, 13, 'sonnentempel', null);
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) { const edge = x === x0 || x === x1 || y === y0 || y === y1; setT(x, y, TL.FLOOR, edge && !(y === y1 && Math.abs(x - cx) <= 1) ? TL.SANDSTONE : null); }
    for (let y = y0 + 3; y <= y1 - 3; y += 3) for (const x of [x0 + 3, x1 - 3]) setT(x, y, null, TL.SANDSTONE);
    for (let x = x0 + 3; x <= x1 - 3; x += 3) if (Math.abs(x - cx) > 1) setT(x, y0 + 3, null, TL.SANDSTONE);
    setT(cx - 1, cy - 6, null, TL.ALTAR); setT(cx, cy - 6, null, TL.ALTAR); setT(cx + 1, cy - 6, null, TL.ALTAR);
    for (let y = y1 + 1; y <= y1 + 6; y++) for (let x = cx - 2; x <= cx + 2; x++) setT(x, y, TL.SAND);   // freier Vorplatz
    chestAt(x0 + 1, y0 + 1, {lock:5, gold:900, loot:[['kristall', 3], ['perle', 2]]}); }
  // --- Straßen ---
  { const a = shiftOld(139, 129).map(Math.round); road(a[0], a[1], 256, 170); }
  road(276, 168, 333, 173); road(268, 158, 296, 122); road(296, 122, 300, 118); road(318, 130, 334, 171);
  road(312, 104, 330, 48); road(318, 86, 302, 71); road(302, 71, 302, 66); road(353, 193, 368, 224); road(266, 178, 278, 258); road(278, 258, 294, 293);
  road(184, 279, 240, 300); road(240, 300, 287, 300); road(314, 118, 324, 118);
}
const _worldExtrasSouth = worldExtras;
worldExtras = function () { eastGen(); _worldExtrasSouth(); };
function eastInteriors() {
  makeInterior('rabenkrug', 'Gasthaus „Rabenkrug“', 12, 8, [303, 111, 1], TL.WOOD, o => {
    for (let x = 1; x <= 4; x++) o(x, 3, TL.COUNTER); o(10, 2, TL.HEARTH); o(1, 2, TL.SHELF); [[7, 3], [7, 5], [10, 5]].forEach(p => o(p[0], p[1], TL.TABLE)); o(1, 6, TL.BARREL); o(10, 6, TL.BARREL); });
  makeInterior('bibliothek', 'Große Bibliothek von Nachtkrone', 12, 8, [340, 165, 1], TL.FLOOR, o => {
    for (let x = 1; x <= 10; x++) if (x !== 5 && x !== 6) o(x, 2, TL.SHELF); o(1, 4, TL.SHELF); o(10, 4, TL.SHELF); o(5, 4, TL.TABLE); o(6, 4, TL.TABLE); o(5, 6, TL.CARPET); o(6, 6, TL.CARPET); });
  makeInterior('palast', 'Thronsaal der Ewigen Kaiserin', 16, 10, [352, 161, 1], TL.FLOOR, o => {
    o(8, 2, TL.THRONE); for (let y = 3; y <= 8; y++) { o(7, y, TL.CARPET); o(8, y, TL.CARPET); o(9, y, TL.CARPET); }
    for (const x of [2, 13]) for (const y of [3, 6]) o(x, y, TL.ALTAR); o(1, 8, TL.TROPHY); o(14, 8, TL.TROPHY); });
  BOSS_POS.nyxara = ipos(['palast', 8.5, 4.6]);
}
const _southInteriorsBase = southInteriors;
southInteriors = function () { _southInteriorsBase(); eastInteriors(); };
// Reihenfolge der Innenräume merken (für alte Spielstände)
const INTERIOR_LOG = [];
const _makeInteriorBase = makeInterior;
makeInterior = function (id, name, w, h) { if (id === 'hilde') INTERIOR_LOG.length = 0; INTERIOR_LOG.push({id, w, h}); return _makeInteriorBase.apply(this, arguments); };
const EAST_INTERIORS = ['rabenkrug', 'bibliothek', 'palast'], SOUTH_INTERIORS = ['moewe', 'leuchtturm'];

// ---------- Alte Spielstände (256 Felder breit) übernehmen ----------
function remapSave(data) {
  const oMW = data.mw, oH = data.wh || 256;
  if (oMW !== 256 || MW === 256) return;
  const oMH = oH + 64, conv = k => { k = +k; const x = k % oMW, y = Math.floor(k / oMW); return y < oH && y < WORLD_H ? idx(x, y) : -1; };
  for (const key of ['mods', 'dyn']) { const src = data[key] || {}, out = {}; for (const k in src) { const n = conv(k); if (n >= 0) out[n] = src[k]; } data[key] = out; }
  try { const bits = unpackBits(data.ex, oMW * oMH), nb = new Uint8Array(MW * MH); for (let i = 0; i < oMW * oH; i++) if (bits[i]) nb[idx(i % oMW, Math.floor(i / oMW))] = 1; data.ex = packBits(nb); } catch (e) { data.ex = packBits(new Uint8Array(MW * MH)); }
  const p = data.P;
  if (p && p.y >= oH) {
    let IX = 2, IY = oH + 3, IROW = 0, found = null;
    for (const e of INTERIOR_LOG) {
      if (EAST_INTERIORS.includes(e.id) || (oH === 256 && SOUTH_INTERIORS.includes(e.id))) continue;
      if (IX + e.w > oMW - 2) { IX = 2; IY += IROW + 3; IROW = 0; }
      if (p.x >= IX && p.x < IX + e.w && p.y >= IY && p.y < IY + e.h) { found = {id:e.id, dx:p.x - IX, dy:p.y - IY}; break; }
      IX += e.w + 3; IROW = Math.max(IROW, e.h);
    }
    const I = found && INTERIORS[found.id];
    if (I) { p.x = I.x0 + found.dx; p.y = I.y0 + found.dy; } else { const q = ipos(['hilde', 3.6, 4.4]); p.x = q[0]; p.y = q[1]; }
  }
  data.mw = MW; data.wh = WORLD_H;
  setTimeout(() => toast('🗺️ Die Welt ist gewachsen: Im Osten liegen jetzt die Front, das Kaiserreich Morvath, die Drachenzinnen und die Glutsand-Wüste!', 'quest'), 1400);
}

// ---------- Laufende Effekte: Fliegen, Stadttor, Katapulte, Kaiserin ----------
function eastTick(dt) {
  if (!P || P.dead) return;
  const m = P.mounted && P.pets[P.mount];
  G.flying = !!(m && ENEMIES[m.type] && ENEMIES[m.type].fly);
  const reg = regionAt(P.x, P.y);
  // Nachtkrone nur mit Passierschein
  if (reg === 'nachtkrone' && !P.f.passierschein) {
    if (G.lastFree) teleport(G.lastFree[0], G.lastFree[1]);
    if (!(G.gateMsg > G.t)) { G.gateMsg = G.t + 4; showDialog('Torwache von Nachtkrone', '„Halt! Niemand betritt die Stadt der Kaiserin ohne Passierschein. Verschwinde, bevor ich dich in den Kerker werfe.“<br><br><i>(Einen Passierschein bekommst du in der Hauptgeschichte – oder bei der Schmugglerin Mara im Heerlager Löwenwacht.)</i>', [{t:'Zurückweichen'}]); }
    return;
  }
  if (!REGION_INFO[reg].inside) G.lastFree = [P.x, P.y];
  // Katapultbeschuss an der Front
  if (reg === 'front' || reg === 'heerlager') {
    G.shellT = (G.shellT || rnd(4, 8)) - dt;
    if (G.shellT <= 0) { G.shellT = rnd(5, 10); const a = Math.random() * TAU, r = rnd(1.5, 7); (G.shells = G.shells || []).push({x:P.x + Math.cos(a) * r, y:P.y + Math.sin(a) * r, t:1.3}); }
  }
  if (G.shells && G.shells.length) {
    for (const s of G.shells) {
      s.t -= dt; if (Math.floor(s.t * 8) % 2 === 0) ring(s.x, s.y, 1.4, '#ff6030');
      if (s.t <= 0) { burst(s.x, s.y, '#ff8030', 26); burst(s.x, s.y, '#5a4a4a', 14); G.shake = 0.35; sfx('boom'); if (dist(P.x, P.y, s.x, s.y) < 1.7) hurt(P, 20 + P.lvl); for (const e of G.enemies) if (!e.dead && dist(e.x, e.y, s.x, s.y) < 1.7) e.hp -= 30; }
    }
    G.shells = G.shells.filter(s => s.t > 0);
  }
  // Die Kaiserin wird vom Sonnenherz geschwächt
  for (const e of G.enemies) if (e.type === 'nyxara' && !e._sun && !e.dead) {
    e._sun = true;
    if (P.f.sonnenherz) { e.maxHp = Math.round(e.maxHp * 0.6); e.hp = Math.min(e.hp, e.maxHp); setTimeout(() => toast('🌞 Das Sonnenherz glüht auf! Nyxaras Unsterblichkeit bröckelt – sie ist verwundbar!', 'gold'), 900); }
  }
  // Quest-Schritt „Tier zähmen“
  G.petStepT = (G.petStepT || 0) - dt;
  if (G.petStepT <= 0) { G.petStepT = 1; for (const id of Object.keys(P.q)) { const st = curStep(id); if (st && st.t === 'pet' && P.pets.some(p => p.type === st.type)) advanceQuest(id); } }
}
function spawnAround(type, n, lvl, r) {
  let k = 0;
  for (let t = 0; t < 60 && k < n; t++) { const a = Math.random() * TAU, d = rnd(2.5, r || 5), x = P.x + Math.cos(a) * d, y = P.y + Math.sin(a) * d; if (canStand(x, y, 0.3, true)) { spawnEnemy(type, x, y, {aggro:true, lvl}); k++; } }
  return k;
}
const hildeGone = () => P && P.f.hildeEntfuehrt && !questDone('kaiserin');
{ const hd = NPC_DEFS.find(n => n.id === 'hilde'); const hc = hd.cond; hd.cond = () => (!hc || hc()) && !hildeGone(); }

// ---------- Figuren ----------
const L_ = (x, y) => ({x, y});
NPC_DEFS.push(
  {id:'hagen', name:'Feldmarschall Hagen', ...L_(266.5, 165.4), look:{skin:'#e0b090', hair:'#9a9a9a', outfit:'#2a4a8a', beard:true, style:'plate', metal:'#a8acb8', trim:'#e8c040', cape:'#2a4a8a', helmCol:'#a8acb8'},
    talk() { return {text:questDone('kaiserin') ? '„Der Krieg ist vorbei. Ich weiß gar nicht mehr, was ich mit meinen Händen anfangen soll. Vielleicht… Rosen züchten.“' : pick(['„Halt den Kopf unten, wenn die Katapulte feuern. Ich hab schon zu viele gute Leute begraben.“', '„Die Legion ist zäh. Aber wir sind zäher – oder dümmer. Das Ergebnis ist dasselbe.“'])}; }},
  {id:'bertram', name:'Quartiermeister Bertram', ...L_(261.5, 171.6), shop:'bertram', smith:true, look:{skin:'#e8b896', hair:'#6a4a2a', outfit:'#4a5a3a', beard:true, style:'leather'},
    talk() { return {text:'„Ausrüstung für die Front. Kein Rabatt, keine Rückgabe, kein Gejammer.“'}; }},
  {id:'mara', name:'Schmugglerin Mara', ...L_(271.5, 172.6), look:{skin:'#d8a880', hair:'#2a1a1a', outfit:'#3a3a3a', longHair:true, style:'leather', gem:'#c83a3a'},
    talk() {
      const r = {text:P.f.passierschein ? '„Pass auf, dass dir der Passierschein nicht nass wird. Die Tinte ist noch frisch.“' : '„Ich besorge Dinge. Briefe, Wein, Passierscheine… Für den richtigen Preis.“'};
      if (!P.f.passierschein && !questActive('schatten')) r.opts = [{t:'📜 Passierschein kaufen (1500 Gold)', f:() => { if (P.gold < 1500) return {text:'„Tausendfünfhundert. Fälschen ist Kunst, und Kunst ist teuer.“'}; P.gold -= 1500; P.f.passierschein = true; addItem('passierschein', 1); sfx('coin'); return {text:'„Bitte sehr. Mit Siegel und allem. Wenn dich jemand fragt: Du bist Weinhändler aus Rabenfurt.“'}; }}];
      return r;
    }},
  {id:'greet', name:'Feldscherin Greet', ...L_(262.5, 175.6), teach:{kochen:10}, look:{skin:'#f0c8a8', hair:'#c8702a', outfit:'#e8e0c8', longHair:true, style:'robe', trim:'#c83a3a'},
    talk() { return {text:'„Wenn du blutest, komm her. Wenn du nur jammerst, geh weiter.“'}; }},
  {id:'bors', name:'Wachtmeister Bors', ...L_(271.5, 164.6), look:{skin:'#c8946a', hair:'#3a2a1a', outfit:'#2a4a8a', beard:true, style:'chain', helmCol:'#8a8e9a'},
    talk() { return {text:'„Die Kriegshunde der Legion riechen Angst. Ich rieche nach Zwiebeln. Deshalb leb ich noch.“'}; }},
  {id:'leni', name:'Leni', ...L_(276.5, 205.6), look:{skin:'#f0d0b8', hair:'#e8d070', outfit:'#3a1a2a', longHair:true, style:'chain'},
    cond:() => !P.f.leniGemeldet && !questDone('deserteurin') && !(questActive('deserteurin') && P.q.deserteurin.s >= 1),
    talk() { return {text:'Ein Mädchen in viel zu großer Legionsrüstung kauert hinter einem Felsen. „Bitte… ich bin sechzehn. Sie haben mich aus meinem Dorf geholt. Ich will nur nach Hause.“'}; }},
  {id:'leni_rf', name:'Leni', ...L_(314.5, 126.6), wander:2, look:{skin:'#f0d0b8', hair:'#e8d070', outfit:'#6a8a5a', longHair:true, style:'cloth'},
    cond:() => questDone('deserteurin') && !P.f.leniGemeldet, talk() { return {text:'„Meine Mutter hat geweint, als sie mich gesehen hat. Ich auch. Danke… für alles.“'}; }},
  {id:'ilsa', name:'Wirtin Ilsa', at:['rabenkrug', 3.5, 2.6], shop:'ilsa', look:{skin:'#e8c0a0', hair:'#5a3a2a', outfit:'#4a2a3a', longHair:true, style:'cloth', gem:'#8a8a8a'},
    talk() { return {text:pick(['„Leise reden. Die Wände in Morvath haben Ohren – und manchmal auch Dolche.“', '„Ein Bier? Hier trinkt man auf die Kaiserin. Laut. Und denkt sich seinen Teil.“'])}; }},
  {id:'kraehe', name:'Mutter Krähe', ...L_(305.5, 113.6), look:{skin:'#d8b8a0', hair:'#2a2a2a', outfit:'#3a3a3a', longHair:true, style:'robe', trim:'#8a8a8a'},
    cond:() => !(questActive('sturm') || questActive('kaiserin')),
    talk() { return {text:questDone('kaiserin') ? (P.f.endeFrieden ? '„Ich bin zu alt zum Herrschen. Aber du hast mich nicht gefragt, ob ich will. Also tu ich’s.“' : '„Morvath ist frei. Was immer das am Ende bedeutet.“') : '„Eine Krähe sieht alles. Und vergisst nichts.“'}; }},
  {id:'kraehe_nk', name:'Mutter Krähe', ...L_(352.5, 164.6), look:{skin:'#d8b8a0', hair:'#2a2a2a', outfit:'#3a3a3a', longHair:true, style:'robe', trim:'#8a8a8a'},
    cond:() => questActive('sturm') && P.q.sturm.s >= 3 || questActive('kaiserin'),
    talk() { return {text:'„Der Palast steht offen. Hinter dieser Tür wartet sie. Dreihundert Jahre lang hat sie gewartet.“'}; }},
  {id:'enna', name:'Witwe Enna', ...L_(309.5, 124.6), wander:2, look:{skin:'#e0c0a0', hair:'#9a9a9a', outfit:'#4a4a3a', longHair:true, style:'cloth'},
    talk() { return {text:questDone('steuervogt') ? '„Grell ist weg! Die Kinder haben heute Abend Suppe. Richtige Suppe!“' : '„Der Vogt nimmt alles für den Krieg der Kaiserin. Erst die Männer, dann das Korn.“'}; }},
  {id:'rf_buerger', name:'Fährmann Udo', ...L_(320.5, 121.6), wander:2, look:{skin:'#d8a070', hair:'#5a3a1a', outfit:'#3a4a5a', beard:true, style:'cloth'},
    talk() { return {text:pick(['„Früher hieß dieser Ort Rabenfurt, weil hier Raben waren. Jetzt sind’s Legionäre. Die krächzen lauter.“', '„Aldenmark? Man sagt, dort darf man den König auslachen, ohne gehängt zu werden. Stimmt das?“'])}; }},
  {id:'corvin', name:'Archivar Corvin', at:['bibliothek', 5.5, 5.6], look:{skin:'#e8d0b8', hair:'#e8e8e8', outfit:'#2a2a4a', beard:true, style:'robe', trim:'#c8a040'},
    talk() { return {text:pick(['„Bücher sind gefährlicher als Schwerter. Deshalb verbrennt die Kaiserin sie lieber.“', '„Pst. Hier wird geflüstert. Oder verhaftet.“'])}; }},
  {id:'ottilie', name:'Händlerin Ottilie', ...L_(341.5, 183.6), shop:'ottilie', rich:3, look:{skin:'#f0d0c0', hair:'#8a1a2a', outfit:'#4a1a3a', longHair:true, style:'royal', trim:'#c8a040', gem:'#c040f0'},
    talk() { return {text:'„Nur das Feinste aus dem Kaiserreich. Zahlung in Gold. Schulden zahlt man in Nachtkrone mit Fingern.“'}; }},
  {id:'kurt', name:'Arenameister Kurt', ...L_(360.5, 190.4), look:{skin:'#c8946a', hair:'#2a2a2a', outfit:'#5a3a1a', bald:true, beard:true, style:'leather'},
    talk() { return {text:questDone('arena') ? '„Der neue Champion! Das Volk liebt dich. Die Kaiserin weniger.“' : '„Brot und Blut! Die Arena ist das Einzige, was die Leute hier noch zum Lachen bringt.“'}; }},
  {id:'fee', name:'Taschendiebin Fee', ...L_(348.5, 186.6), wander:2, look:{skin:'#f0d0b8', hair:'#c8702a', outfit:'#3a4a3a', longHair:true, style:'leather'},
    talk() { return {text:'„Ich klaue nur von Leuten, die’s verdient haben. Also von allen mit Hut.“'}; }},
  {id:'nk_wache1', name:'Torwache', ...L_(350.5, 190.4), look:{skin:'#c9a890', hair:'#3a3a44', outfit:'#3a1a2a', style:'plate', metal:'#4a3a4a', trim:'#8a1a2a', helmCol:'#4a3a4a'},
    talk() { return {text:'„Passierschein geprüft. Weitergehen. Und Ruhm der Kaiserin.“'}; }},
  {id:'nk_wache2', name:'Torwache', ...L_(356.5, 190.4), look:{skin:'#c9a890', hair:'#3a3a44', outfit:'#3a1a2a', style:'plate', metal:'#4a3a4a', trim:'#8a1a2a', helmCol:'#4a3a4a'},
    talk() { return {text:'„Ich hab dich im Auge, Fremder.“'}; }},
  {id:'nk_buerger1', name:'Bürgerin Vela', ...L_(347.5, 176.6), wander:3, look:{skin:'#e8c8b0', hair:'#2a1a2a', outfit:'#5a3a5a', longHair:true, style:'cloth'},
    talk() { return {text:pick(['„Die Kaiserin sieht seit dreihundert Jahren gleich aus. Sagt man. Niemand, der sie gesehen hat, redet darüber.“', '„Mein Bruder ist an der Front. Ich bete jeden Abend. Zu wem, sag ich lieber nicht.“'])}; }},
  {id:'nk_buerger2', name:'Gewürzhändler Barik', ...L_(358.5, 170.6), wander:2, look:{skin:'#b88a60', hair:'#1a1a1a', outfit:'#8a6a2a', beard:true, style:'cloth'},
    talk() { return {text:'„Zimt aus Qarim! Pfeffer aus dem Süden! Na gut, eigentlich nur Salz. Der Krieg, verstehst du.“'}; }},
  {id:'hilde_gefangen', name:'Mutter Hilde', at:['palast', 12.5, 7.6], look:{skin:'#e3b48f', hair:'#d4d4d4', outfit:'#6b5a48', longHair:true, style:'cloth'},
    cond:() => questActive('kaiserin') && P.q.kaiserin.s >= 1, talk() { return {text:'„Kind! Ich wusste, dass du kommst. Ich hab’s denen gesagt. Ich hab’s denen JEDEN TAG gesagt.“'}; }},
  {id:'brunhild', name:'Vorarbeiterin Brunhild', ...L_(368.5, 236.6), look:{skin:'#d8a070', hair:'#c8702a', outfit:'#5a4a3a', longHair:true, style:'leather'},
    talk() { return {text:questDone('grubenunglueck') ? '„Die Stollen sind wieder sicher. Na ja – so sicher, wie ein Loch im Berg eben sein kann.“' : '„Die Trolle sind in die alten Stollen eingefallen. Meine Leute sitzen fest!“'}; }},
  {id:'hedda', name:'Schmiedin Hedda', ...L_(375.5, 230.6), shop:'hedda', smith:true, teach:{schmieden:12}, look:{skin:'#e0b090', hair:'#2a2a2a', outfit:'#4a3a3a', longHair:true, style:'leather', gem:'#c83a3a'},
    talk() { return {text:'„Ich schmiede Schwerter für die Legion. Offiziell.“ Sie zwinkert.'}; }},
  {id:'gw_buerger', name:'Grubenarbeiter Jost', ...L_(370.5, 228.6), wander:2, look:{skin:'#c8946a', hair:'#3a3a3a', outfit:'#5a5a5a', beard:true, style:'cloth'},
    talk() { return {text:'„Wir graben Mithril für die Kaiserin und kriegen dafür Steine zum Abendessen.“'}; }},
  {id:'amira', name:'Scheicha Amira', ...L_(303.5, 293.6), look:{skin:'#b8845a', hair:'#1a1a1a', outfit:'#c83a3a', longHair:true, style:'royal', trim:'#e8c040', gem:'#3a8ad0'},
    talk() { return {text:P.f.qarimFeind ? '„Du hast genommen, was dir nicht gehörte. Der Sand wird es nicht vergessen.“' : questDone('sonnentempel') ? '„Möge die Sonne dein Schwert führen, Freund der Banu Qarim.“' : '„Die Wüste prüft jeden, der sie betritt. Wir auch.“'}; }},
  {id:'tarek', name:'Brunnenwart Tarek', ...L_(297.5, 303.6), look:{skin:'#a8744a', hair:'#e8e8e8', outfit:'#e8dcc0', beard:true, style:'robe', trim:'#3a8ad0'},
    talk() { return {text:'„Wasser ist Leben. Und Kaktusfrüchte sind Wasser, das stachelt.“'}; }},
  {id:'faruk', name:'Händler Faruk', ...L_(306.5, 303.6), shop:'faruk', rich:2, look:{skin:'#b8845a', hair:'#1a1a1a', outfit:'#3a5a9a', beard:true, style:'cloth', helmCol:'#e8dcc0'},
    talk() { return {text:'„Willkommen auf dem Basar! Alles echt, alles günstig, alles – na gut, das meiste – nicht gestohlen.“'}; }},
  {id:'layla', name:'Echsenzüchterin Layla', ...L_(294.5, 296.6), teach:{zaehmen:10}, look:{skin:'#c8946a', hair:'#3a1a1a', outfit:'#c8702a', longHair:true, style:'leather', gem:'#e8c040'},
    talk() { return {text:'„Eine Sandechse läuft dir davon, wenn du sie jagst. Biete ihr eine Kaktusfrucht an – dann läuft sie für dich.“'}; }},
  {id:'selim', name:'Weber Selim', ...L_(299.5, 307.6), look:{skin:'#a8744a', hair:'#3a3a3a', outfit:'#8a3a5a', beard:true, style:'cloth'},
    talk() { return {text:questDone('tochter') ? '„Nura webt jetzt Teppiche mit Skorpionen darauf. Ich glaube, sie verarbeitet etwas.“' : '„Meine Tochter Nura ist in die Tiefe Wüste gelaufen. Sie wollte die alten Ruinen sehen…“'}; }},
  {id:'nura', name:'Nura', ...L_(346.5, 276.6), look:{skin:'#c8946a', hair:'#1a1a1a', outfit:'#e8c040', longHair:true, style:'cloth'},
    cond:() => questActive('tochter') && P.q.tochter.s <= 1, talk() { return {text:'„Ich wollte nur die Ruinen sehen! Dann kamen die Skorpione… so viele…“'}; }},
  {id:'salma', name:'Kapitänin Salma', ...L_(116.5, 331.2), look:{skin:'#b8845a', hair:'#1a1a1a', outfit:'#3a5a9a', longHair:true, style:'leather', helmCol:'#e8dcc0', gem:'#e8c040'},
    talk() { return seaTalk('qarim'); }},
  {id:'salma_q', name:'Kapitänin Salma', ...L_(302.5, 329.4), look:{skin:'#b8845a', hair:'#1a1a1a', outfit:'#3a5a9a', longHair:true, style:'leather', helmCol:'#e8dcc0', gem:'#e8c040'},
    talk() { return seaTalk('hafen'); }},
  {id:'ysolde', name:'Drachenhüterin Ysolde', ...L_(330.5, 39.6), shop:'ysolde', teach:{zaehmen:12}, look:{skin:'#f0d0c0', hair:'#e8e8f0', outfit:'#2a5a5a', longHair:true, style:'robe', trim:'#e8c040', gem:'#c83a3a'},
    talk() { return {text:P.f.drachenfreund ? '„Die Drachen kennen deinen Geruch jetzt. Das ist eine Ehre. Und ein bisschen eklig.“' : '„Wolkenhorst hütet die Drachen seit tausend Jahren. Wer sie jagt, jagt uns.“'}; }},
  {id:'moench', name:'Bruder Kenji', ...L_(334.5, 42.6), wander:2, look:{skin:'#e8c8a0', hair:'#1a1a1a', outfit:'#c8702a', bald:true, style:'robe', trim:'#8a2a1a'},
    talk() { return {text:pick(['„Ein Drache vergisst nie. Weder Freundschaft noch Beleidigung. Sei also höflich.“', '„Drachenmilch? Nein, so etwas gibt es nicht. Frag nicht, woher ich das weiß.“'])}; }}
);
function seaTalk(to) {
  const dest = to === 'qarim' ? {n:'Oase Qarim (Wüstenküste)', p:[EAST.qarim[0] + 2.5, Math.floor(seaY(EAST.qarim[0] + 2)) - 3.4]} : {n:'Möwenhafen', p:[118.5, 328.6]};
  return {text:'„Die <i>Sandrose</i> segelt zwischen Möwenhafen und der Wüstenküste. Schneller als jede Karawane – und keine Skorpione an Bord. Meistens.“', opts:[
    {t:'⛵ Nach ' + dest.n + ' – 40 Gold', f:() => { if (P.gold < 40) return {text:'„Vierzig Gold. Wind ist umsonst, mein Schiff nicht.“'}; P.gold -= 40; sfx('coin'); setTimeout(() => { P.mounted = false; teleport(dest.p[0], dest.p[1]); syncAllies(); toast('⛵ Die Sandrose legt an: ' + dest.n + '.', 'quest'); }, 60); return 'close'; }},
    {t:'Tschüss'}]};
}
// Kutschen
KUTSCHE.push({id:'loewenwacht', name:'Heerlager Löwenwacht', pos:() => [271.5, 176.6]}, {id:'rabenfurt', name:'Rabenfurt', pos:() => [306.5, 126.6]}, {id:'qarim', name:'Oase Qarim', pos:() => [294.5, 307.6]});
for (const k of KUTSCHE.slice(-3)) { const p = k.pos(); NPC_DEFS.push({id:'kutsche_' + k.id, name:k.id === 'qarim' ? 'Karawanenführer' : 'Kutscher', x:p[0], y:p[1], look:{skin:k.id === 'qarim' ? '#a8744a' : '#e0b090', hair:'#3a2a1a', outfit:k.id === 'qarim' ? '#e8dcc0' : '#4a5a7a', beard:true, style:'leather', helmCol:'#3a3a2a'}, talk() { return kutscheTalk(k.id); }}); }
// Gefährten
COMPS.tamsin = {name:'Tamsin', title:'Rebellin der Grauen Hand', cls:'kampf', hp:115, dmg:15, home:[304.5, 117.6], cost:0, teach:{schloss:8},
  look:{skin:'#e8c8b0', hair:'#3a3a3a', outfit:'#4a4a4a', longHair:true, style:'leather', gem:'#8a8a8a'}, likes:['wein', 'buch', 'ring'],
  bio:'„Tamsin. Meine Mutter ist die Krähe, mein Vater hing am Galgen von Nachtkrone. Ich kämpfe, bis keiner mehr hängen muss.“',
  lines:['„Halt dich im Schatten. Wir sind hier nicht in Aldenmark.“', '„Du bist anders als die Ritter, von denen man erzählt. Besser.“', '„Wenn das vorbei ist… bleib. Hier. Bei mir.“'], recruit:() => questDone('graue_hand')};
COMPS.zahir = {name:'Zahir', title:'Beduinen-Späher', cls:'bogen', hp:95, dmg:16, home:[308.5, 297.6], cost:0,
  look:{skin:'#a8744a', hair:'#1a1a1a', outfit:'#e8dcc0', style:'leather', helmCol:'#3a5a9a'}, likes:['dattel', 'perle', 'wein'],
  bio:'„Zahir ibn Qarim. Ich lese den Sand wie du ein Buch. Nur dass der Sand nicht lügt.“',
  lines:['„Riechst du das? Sturm. Oder Kamel. Schwer zu sagen.“', '„Meine Schwester sagt, ich rede zu viel von dir. Sie hat recht.“', '„In der Wüste sagt man: Wer zusammen Wasser teilt, teilt auch das Leben.“'], recruit:() => questDone('wueste')};

// ---------- Hauptquest Kapitel II: Die Ewige Kaiserin ----------
QUESTS.krieg.next = 'nachhall';
const erbeText = () => P.f.valdrinErbe || P.f.valdrinGeheim ? '„Du weißt es also schon. Gut. Dann muss ich dir nicht erklären, warum du das Gesicht von Königin Elara trägst.“' : '„Du weißt es nicht, oder? Das Kind, das Valdrins Untergang überlebte… Die Amme trug es durch die Kanäle nach Aldenmark. In die Gosse. Zu einer Frau namens Hilde. Du bist der letzte Spross von Valdrin.“';
Object.assign(QUESTS, {
  nachhall:{name:'Ein Sieg mit bitterem Nachgeschmack', main:true, giver:'König Aldric', lvl:17, desc:'Malgor ist gefallen, Aldenmark feiert. Doch in der Nacht des Festes reitet ein Bote mit zerfetztem Banner in den Burghof.', steps:[
    {t:'talk', npc:'koenig', txt:'Sprich mit König Aldric beim Siegesfest im Thronsaal.', say:'Mitten im Fest stürzt ein Bote herein, blutverschmiert. „Majestät! Legionen mit dem Banner der Ewigen Kaiserin – sie haben die Grenze hinter Schwarzfels überschritten!“<br><br>Aldric wird blass. „Malgor war nicht der Herr von Morvath. Er war nur ihr Hund.“ Er wendet sich dir zu. „Feldmarschall Hagen hält die Front im Heerlager Löwenwacht. Er braucht dich.“'},
    {t:'goto', region:'loewenwacht', txt:'Reise ins Heerlager Löwenwacht (östlich der Festung Schwarzfels, an der Front).'},
    {t:'talk', npc:'hagen', txt:'Melde dich bei Feldmarschall Hagen.', say:'Hagen mustert dich von oben bis unten. „Das also ist der Held von Aldenmark. Ein Gossenkind mit Ritterschlag.“ Er spuckt aus. „Hier draußen zählt kein Titel. Hier zählt, wer morgen noch steht. Zeig mir, was du kannst.“'}],
    reward:{xp:2500, gold:300}, next:'front'},
  front:{name:'Die Brandmark', main:true, giver:'Feldmarschall Hagen', lvl:18, desc:'Die Legion drängt Tag für Tag gegen die Linien von Löwenwacht. Ihr Anführer, Kriegsherr Drogan, sitzt in einem befestigten Lager im Osten.', steps:[
    {t:'kill', e:'legionaer', n:8, txt:'Halte die Front: Besiege 8 Legionäre in der Brandmark. Achte auf Katapultbeschuss!'},
    {t:'goto', region:'heerlager', txt:'Stoße zum Kriegslager der Legion im Nordosten der Front vor.'},
    {t:'kill', e:'drogan', n:1, txt:'Besiege Kriegsherr Drogan.'},
    {t:'talk', npc:'hagen', txt:'Kehre zu Hagen nach Löwenwacht zurück.', say:'Hagen schweigt lange. Dann legt er dir die Hand auf die Schulter. „Ich habe mich geirrt. Du bist kein Ritter aus der Gosse. Du bist ein Soldat. Von heute an: Hauptmann der Löwenwacht.“'}],
    reward:{xp:4000, gold:600, rep:10, items:[['grheiltrank', 3]]}, onDone:() => { P.title = 'Hauptmann der Löwenwacht'; toast('🎖️ Titel: Hauptmann der Löwenwacht', 'gold'); }, next:'schatten'},
  schatten:{name:'Hinter feindlichen Linien', main:true, giver:'Feldmarschall Hagen', lvl:19, desc:'Hagen glaubt nicht an einen Sieg durch Gewalt allein. Im Kaiserreich soll es Menschen geben, die gegen Nyxara kämpfen. Jemand muss sie finden.', steps:[
    {t:'talk', npc:'hagen', txt:'Hör dir Hagens Plan an.', say:'„In Morvath gibt es eine Widerstandsbewegung. Die Graue Hand. Wenn wir sie finden, kämpfen wir nicht mehr allein. Die Schmugglerin Mara kann dir Papiere besorgen. Frag nicht, woher ich sie kenne.“'},
    {t:'collect', item:'legionssiegel', n:3, from:'legionaer', p:0.4, npc:'mara', txt:'Mara braucht 3 echte Legionssiegel zum Fälschen – erbeute sie von Legionären.', say:'Mara drückt die Siegel in warmes Wachs und malt mit ruhiger Hand. „Ein Passierschein der Kaiserin. Damit kommst du bis nach Nachtkrone. Frag in Rabenfurt im Gasthaus nach dem „Grauen Bier“.“',
      onDone:() => { P.f.passierschein = true; addItem('passierschein', 1); }},
    {t:'goto', region:'rabenfurt', txt:'Reise nach Rabenfurt im Kaiserreich (nordöstlich von Löwenwacht, am Fluss).'},
    {t:'talk', npc:'ilsa', txt:'Bestelle bei Wirtin Ilsa im Gasthaus „Rabenkrug“ ein „Graues Bier“.', say:'Ilsa erstarrt kurz. Dann stellt sie dir einen Krug hin – leer. „Graues Bier ist aus. Aber Mutter Krähe hat vielleicht noch welches. Hinterhof, links neben dem Gasthaus. Und jetzt trink, du wirst beobachtet.“'}],
    reward:{xp:4500, gold:200}, next:'graue_hand'},
  graue_hand:{name:'Die Graue Hand', main:true, giver:'Wirtin Ilsa', lvl:20, desc:'Mutter Krähe führt die Graue Hand. Sie vertraut niemandem – schon gar nicht einem Ritter aus Aldenmark.', steps:[
    {t:'talk', npc:'kraehe', txt:'Triff Mutter Krähe im Hinterhof von Rabenfurt.', say:'Eine alte Frau in grauem Umhang sieht dich mit stechenden Augen an. „Aldenmark schickt einen Spion. Wie rührend. Willst du mein Vertrauen? In der Grube südlich von hier schuften unsere Leute bis zum Tod. Befrei sie.“'},
    {t:'goto', region:'grube', txt:'Finde die Grube – ein Arbeitslager im Süden des Kaiserreichs.'},
    {t:'kill', e:'aufseher', n:5, txt:'Besiege 5 Grubenaufseher und befreie die Gefangenen.'},
    {t:'talk', npc:'kraehe', txt:'Kehre zu Mutter Krähe zurück.', say:() => 'Die befreiten Gefangenen kommen hinter dir in den Hof gestolpert. Krähe sieht dich lange an. Dann wird sie blass. „Dieses Gesicht… “<br><br>' + erbeText() + '<br><br>„Und deshalb, Kind, jagt dich die Kaiserin. Valdrins Blut kann den Urdrachen in den Zinnen wecken. Mit ihm würde sie die Welt verbrennen. Meine Tochter Tamsin wird dich begleiten, wenn du willst.“',
      onDone:() => { P.f.erbeBekannt = true; }}],
    reward:{xp:5000, gold:400}, next:'nachtkrone'},
  nachtkrone:{name:'Die Stadt der Kaiserin', main:true, giver:'Mutter Krähe', lvl:21, desc:'Wie besiegt man eine Herrscherin, die nicht sterben kann? Archivar Corvin in der Großen Bibliothek von Nachtkrone soll die Antwort kennen.', steps:[
    {t:'goto', region:'nachtkrone', txt:'Reise mit deinem Passierschein in die Hauptstadt Nachtkrone (Mitte des Kaiserreichs).'},
    {t:'talk', npc:'corvin', txt:'Finde Archivar Corvin in der Großen Bibliothek (links neben dem Palast).', say:'Corvin schließt die Tür hinter dir. „Nyxara lebt seit dreihundert Jahren, weil sie das Licht der Sonne in sich trägt – gestohlen aus dem Sonnentempel der Wüstenvölker. Nur das Sonnenherz selbst kann ihre Unsterblichkeit brechen. Es liegt noch im Tempel, bewacht von…“<br><br>Die Tür fliegt auf. Prätorianer! „Verrat!“, schreit einer.',
      onDone:() => setTimeout(() => { spawnAround('praetorianer', 4, 22, 4); toast('⚔️ Die Palastwache hat dich entdeckt!', 'warn'); }, 900)},
    {t:'kill', e:'praetorianer', n:4, txt:'Wehre dich gegen die Prätorianer!'},
    {t:'talk', npc:'corvin', txt:'Sprich mit Corvin, bevor Verstärkung kommt.', say:'Corvin zittert, aber er lebt. „Geh! In die Wüste im Süden. Die Banu Qarim in der Oase hüten den Weg zum Sonnentempel. Sag Scheicha Amira, dass der Mond nach der Sonne fragt. Sie wird verstehen.“'}],
    reward:{xp:5500, gold:300}, next:'wueste'},
  wueste:{name:'Das Volk des Sandes', main:true, giver:'Archivar Corvin', lvl:22, desc:'Die Banu Qarim leben seit Jahrhunderten in der Glutsand-Wüste. Fremden trauen sie nicht – zu oft brachten Fremde die Legion.', steps:[
    {t:'goto', region:'qarim', txt:'Reise zur Oase Qarim in der Glutsand-Wüste (Süden – auch per Schiff ab Möwenhafen).'},
    {t:'talk', npc:'amira', txt:'Sprich mit Scheicha Amira.', say:'„Der Mond fragt nach der Sonne…“ Amira verengt die Augen. „Corvin lebt also noch. Aber Worte sind Sand. Ein Ungeheuer, der Sandschlund, frisst unsere Karawanen. Töte es, und ich höre dir zu.“'},
    {t:'kill', e:'sandschlund', n:1, txt:'Töte den Sandschlund in der Wüste östlich der Oase.'},
    {t:'talk', npc:'amira', txt:'Kehre zu Amira zurück.', say:'Amira lässt Wasser vor dir auf den Sand gießen – die höchste Ehre ihres Volkes. „Du hast für uns geblutet. Der Sonnentempel liegt in der Tiefen Wüste, ganz im Osten. Mein Bruder Zahir wird dich begleiten, wenn du willst.“'}],
    reward:{xp:6000, gold:500, items:[['echsensattel', 1]]}, next:'sonnentempel'},
  sonnentempel:{name:'Das Herz der Sonne', main:true, giver:'Scheicha Amira', lvl:23, desc:'Im Sonnentempel ruht das Sonnenherz – bewacht von Toten, die nicht ruhen, und einem Wächter aus lebendigem Gold.', steps:[
    {t:'goto', region:'sonnentempel', txt:'Finde den Sonnentempel in der Tiefen Wüste (Südosten).'},
    {t:'kill', e:'mumie', n:6, txt:'Besiege 6 Tempelmumien.'},
    {t:'kill', e:'sonnenwaechter', n:1, txt:'Besiege den Sonnenwächter im Herzen des Tempels.', onDone:() => { addItem('sonnenherz', 1); toast('🌞 Das Sonnenherz pulsiert warm in deinen Händen.', 'gold'); }},
    {t:'branch', txt:'Bring das Sonnenherz zu Amira.', opts:[
      {npc:'amira', need:'sonnenherz', label:'🙏 „Es gehört deinem Volk. Leih es mir für diesen einen Kampf.“', say:'Amira legt ihre Hände über deine. „Kein Fremder hat je gefragt. Alle haben genommen.“ Sie reicht dir eine Klinge, die wie Morgenlicht schimmert. „Die Sonnenklinge. Bring uns das Herz zurück, wenn es vorbei ist.“',
        fn:() => { P.f.sonnenherz = true; P.rep.karma += 10; addItem('sonnenklinge', 1); }},
      {npc:'amira', need:'sonnenherz', label:'✊ „Ich brauche es. Ob ihr wollt oder nicht.“', say:'Amiras Krieger ziehen ihre Säbel – sie hebt die Hand. „Geh. Nimm es. Aber komm nie wieder nach Qarim.“',
        fn:() => { P.f.sonnenherz = true; P.f.qarimFeind = true; P.rep.karma -= 15; }}]}],
    reward:{xp:6500, gold:400}, next:'drachen'},
  drachen:{name:'Flügel aus Feuer', main:true, giver:'Scheicha Amira', lvl:24, desc:'Nyxara schickt Drachenjäger in die Zinnen. Sie will die jungen Drachen brechen – und den Urdrachen finden, bevor du es tust.', steps:[
    {t:'goto', region:'wolkenhorst', txt:'Reise zum Kloster Wolkenhorst in den Drachenzinnen (Nordosten).'},
    {t:'talk', npc:'ysolde', txt:'Sprich mit der Drachenhüterin Ysolde.', say:'„Valdrins Blut…“ Ysolde spürt es, bevor du etwas sagst. „Die Jäger der Kaiserin fangen unsere Jungdrachen mit Netzen und Ketten. Ihr Lager liegt im Westen der Zinnen. Hilf uns – und die Drachen werden dir helfen.“'},
    {t:'kill', e:'drachenjaeger', n:6, txt:'Vertreibe 6 Drachenjäger aus den Zinnen.'},
    {t:'kill', e:'kroll', n:1, txt:'Besiege Jagdmeister Kroll in seinem Lager.'},
    {t:'talk', npc:'ysolde', txt:'Kehre zu Ysolde zurück.', say:'Ysolde führt dich zu einem Nest. Ein junger Drache schnuppert an deiner Hand – und legt den Kopf hinein. „Er hat dich gewählt. Von heute an bist du ein Drachenfreund. Nimm dieses Ei und diesen Sattel. Und lerne zu fliegen.“'}],
    reward:{xp:7000, gold:500, items:[['drachenei', 1], ['drachensattel', 1]]}, onDone:() => { P.f.drachenfreund = true; P.title = 'Drachenfreund'; toast('🐉 Titel: Drachenfreund – du kannst jetzt wilde Drachen zähmen!', 'gold'); }, next:'verrat'},
  verrat:{name:'Schatten über der Gosse', main:true, giver:'Drachenhüterin Ysolde', lvl:25, desc:'Ysolde hat eine Vision: Schatten fallen auf den Ort, an dem alles begann.', steps:[
    {t:'talk', npc:'ysolde', txt:'Lass dir von Ysolde ihre Vision erzählen.', say:'Ysoldes Augen werden milchig. „Ich sehe… ein Viertel aus Holz und Dreck. Ratten. Eine alte Frau, die Suppe kocht. Und Schatten mit Dolchen.“ Sie packt deinen Arm. „Die Kaiserin weiß, wer dich großgezogen hat. Flieg!“'},
    {t:'goto', region:'gosse', txt:'Eile zurück ins Rattenviertel von Aldenmark!', onDone:() => { P.f.hildeEntfuehrt = true; setTimeout(() => { spawnAround('schattenklinge', 4, 24, 5); toast('🗡️ Schattenklingen! Sie warten schon auf dich!', 'warn'); }, 700); }},
    {t:'kill', e:'schattenklinge', n:4, txt:'Besiege die Schattenklingen im Rattenviertel.'},
    {t:'talk', npc:'bettler', txt:'Frag den Alten Bettler, was passiert ist.', say:'Der Bettler zittert. „Sie kamen in der Nacht. Haben Hilde aus ihrer Hütte gezerrt. Sie hat sich gewehrt – mit der Suppenkelle, stell dir vor. Einer sagte: „Die Kaiserin will das Pflegekind. Es wird kommen.“ Sie haben sie nach Nachtkrone gebracht.“'}],
    reward:{xp:7000}, next:'sturm'},
  sturm:{name:'Der Sturm auf Nachtkrone', main:true, giver:'Feldmarschall Hagen', lvl:26, desc:'Es ist eine Falle. Natürlich ist es eine Falle. Aber Hilde ist dort – und ganz Aldenmark marschiert mit dir.', steps:[
    {t:'talk', npc:'hagen', txt:'Bitte Feldmarschall Hagen in Löwenwacht um das Heer.', say:'Hagen hört zu, ohne dich zu unterbrechen. Dann ruft er: „Trompeter! Alle Banner auf!“ Zu dir sagt er leise: „Die Graue Hand öffnet uns die Tore. Du gehst zuerst rein. Wie immer.“'},
    {t:'goto', region:'nachtkrone', txt:'Stürme Nachtkrone – das Heer folgt dir!', onDone:() => setTimeout(() => { spawnAround('praetorianer', 6, 25, 6); toast('⚔️ Die Prätorianer stellen sich dir entgegen!', 'warn'); G.shake = 0.6; }, 700)},
    {t:'kill', e:'praetorianer', n:6, txt:'Kämpfe dich durch die Prätorianer.'},
    {t:'kill', e:'varn', n:1, txt:'Besiege General Varn vor dem Palast.'},
    {t:'talk', npc:'kraehe_nk', txt:'Triff Mutter Krähe vor dem Palasttor.', say:'Krähe steht vor dem Tor, das Schwert in der Hand, das Gesicht voller Ruß. „Die Stadt gehört uns. Nur der Palast nicht.“ Sie öffnet die Tür. „Geh. Hol deine Mutter zurück.“'}],
    reward:{xp:9000, gold:1000}, next:'kaiserin'},
  kaiserin:{name:'Die Ewige Kaiserin', main:true, giver:'Mutter Krähe', lvl:28, desc:'Dreihundert Jahre Herrschaft. Ein gestohlenes Licht. Und ein Kind aus der Gosse, das nicht weiß, wann es aufhören soll.', steps:[
    {t:'kill', e:'nyxara', n:1, txt:'Betritt den Palast und stelle dich der Ewigen Kaiserin Nyxara.'},
    {t:'talk', npc:'hilde_gefangen', txt:'Befreie Mutter Hilde im Thronsaal.', say:'Hilde fällt dir um den Hals und hält dich so fest, dass dir die Luft wegbleibt. „Mein Kind. Mein dummes, mutiges Kind.“ Dann schiebt sie dich ein Stück weg und wischt dir mit dem Ärmel den Ruß aus dem Gesicht. „So. Jetzt siehst du wieder ordentlich aus.“'},
    {t:'branch', txt:'Draußen wartet ein Reich ohne Herrscherin. Entscheide vor dem Palast, was aus Morvath wird.', opts:[
      {npc:'kraehe_nk', label:'👑 „Ich nehme die Krone von Valdrin. Beide Reiche werden eins.“', say:'Krähe nickt langsam. „Ein Kind von Valdrin auf dem Thron von Morvath. Die Geschichte hat Sinn für Humor.“ Sie kniet. Und hinter ihr kniet die ganze Stadt.', fn:() => { P.f.endeKrone = true; addItem('valdrinkrone', 1); P.title = P.gender === 'w' ? 'Königin von Valdrin' : 'König von Valdrin'; P.rep.stadt += 20; }},
      {npc:'kraehe_nk', label:'🕊️ „Morvath gehört seinem Volk. Führe du es, Krähe.“', say:'Krähe starrt dich an. Dann lacht sie – zum ersten Mal, seit du sie kennst. „Ein Held, der eine Krone ablehnt. Die Barden werden es nicht glauben.“', fn:() => { P.f.endeFrieden = true; P.rep.karma += 20; P.title = 'Friedensbringer'; }},
      {npc:'kraehe_nk', label:'🗝️ „Ich nehme das Gold der Kaiserin und verschwinde.“', say:'Krähe zieht eine Augenbraue hoch. „Du hast die Kaiserin getötet, um sie zu bestehlen?“ Sie zuckt mit den Schultern. „Nimm dir, was du tragen kannst. Morvath regelt den Rest selbst.“', fn:() => { P.f.endeDieb = true; P.gold += 20000; P.rep.diebe += 30; P.title = 'Legende der Gosse'; }}]}],
    reward:{xp:15000, gold:3000},
    onDone:() => { playMusic('victory'); G.musicHold = G.t + 40;
      const end = P.f.endeKrone ? 'Auf den Türmen von Nachtkrone weht das alte Banner von Valdrin. Das Kind aus der Gosse trägt eine Krone – und Hilde besteht darauf, dass es trotzdem jeden Sonntag zum Suppeessen kommt.' :
        P.f.endeFrieden ? 'Mutter Krähe führt Morvath in eine unsichere, aber freie Zukunft. Zwischen Aldenmark und Morvath wird Frieden geschlossen – unterschrieben von einem Kind aus der Gosse, das keine Krone wollte.' :
        'Niemand weiß genau, wohin das Gold der Kaiserin verschwunden ist. Aber im Rattenviertel gibt es seitdem jeden Abend Braten, und Krummfinger nennt dich „Chef“.';
      showStory('🌅 Das Ende der Ewigen Kaiserin', 'Nyxara ist gefallen. Das gestohlene Licht kehrt zur Sonne zurück.<br><br>' + end + '<br><br>Die Welt bleibt offen: Sturmschwinge, die Uralte, kreist noch über den Zinnen, deine Drachen wollen fliegen – und irgendwo wartet immer noch ein Abenteuer.'); }}
});

// ---------- Nebenquests ----------
Object.assign(QUEST_REQ, {verwundete:() => true, kriegshunde:() => true, deserteurin:() => true, hunger:() => true, steuervogt:() => true, grubenunglueck:() => true, rebellenwaffen:() => true,
  arena:() => true, buecher:() => true, juwel:() => true, wasser:() => true, karawane:() => true, echsenreiter:() => true, tochter:() => true, dracheneier:() => true, sturmschwinge:() => questDone('drachen') || P.lvl >= 26});
Object.assign(QUESTS, {
  verwundete:{name:'Verbandszeug für die Front', giver:'Feldscherin Greet', lvl:17, desc:'Im Lazarett von Löwenwacht sterben Soldaten, weil die Heiltränke ausgehen.', steps:[
    {t:'collect', item:'heiltrank', n:6, npc:'greet', txt:'Bring Feldscherin Greet 6 Heiltränke.', say:'Greet verteilt die Tränke, ohne aufzusehen. Erst später, als der letzte Verwundete schläft, sagt sie leise: „Heute ist keiner gestorben. Das ist dein Verdienst.“'}],
    reward:{xp:1800, gold:150, prof:{kochen:1}}},
  kriegshunde:{name:'Die Meute', giver:'Wachtmeister Bors', lvl:18, desc:'Die Kriegshunde der Legion reißen jede Nacht Wachen von den Posten.', steps:[
    {t:'kill', e:'kriegshund', n:6, txt:'Erlege 6 Kriegshunde in der Brandmark.'},
    {t:'talk', npc:'bors', txt:'Melde dich bei Wachtmeister Bors.', say:'„Sechs? Hah! Heute Nacht schlafen meine Jungs wieder. Na ja, so gut man eben schläft, wenn Felsbrocken vom Himmel fallen.“'}],
    reward:{xp:2400, gold:250, items:[['kampfsattel', 1]]}},
  deserteurin:{name:'Ein Kind in Rüstung', giver:'Leni', lvl:18, desc:'Eine junge Zwangsrekrutin der Legion versteckt sich in der Brandmark. Sie will nach Hause – nach Rabenfurt.', steps:[
    {t:'branch', txt:'Hilf Leni, nach Rabenfurt zu kommen – oder melde sie Feldmarschall Hagen.', opts:[
      {npc:'leni', label:'🤝 „Ich bringe dich nach Hause.“', say:'Leni wirft die Legionsrüstung in einen Graben. „Meine Mutter heißt Ilsa. Sie hat das Gasthaus in Rabenfurt. Sag ihr, dass ich komme.“'},
      {npc:'hagen', label:'⚖️ Die Deserteurin melden', say:'Hagen seufzt. „Ein Kind. Natürlich ist es ein Kind.“ Er gibt einem Soldaten einen Wink. „Sie kommt ins Gefangenenlager. Gut aufgepasst, Hauptmann.“', fn:() => { P.f.leniGemeldet = true; P.gold += 300; P.rep.karma -= 10; P.rep.stadt += 3; }, jump:2}]},
    {t:'talk', npc:'ilsa', txt:'Bring Wirtin Ilsa in Rabenfurt die Nachricht von ihrer Tochter.', say:'Ilsa lässt einen Krug fallen. Dann noch einen. „Leni lebt? LENI LEBT?“ Sie umarmt dich über den Tresen hinweg. „Hier trinkst du nie wieder für Geld.“'}],
    reward:{xp:2600, gold:100}, onDone:() => { if (!P.f.leniGemeldet) P.rep.karma += 10; }},
  hunger:{name:'Brot für Rabenfurt', giver:'Witwe Enna', lvl:19, desc:'Der Steuervogt hat das letzte Korn für die Legion beschlagnahmt. Die Kinder von Rabenfurt hungern.', steps:[
    {t:'collect', item:'brot', n:8, npc:'enna', txt:'Bring Witwe Enna 8 Brote für die hungernden Familien.', say:'Enna teilt das Brot in winzige Stücke, damit es für alle reicht. Ein kleiner Junge sieht dich an, als wärst du ein Gott. „Bist du der Held aus Aldenmark?“, flüstert er.'}],
    reward:{xp:2200, gold:50}, onDone:() => { P.rep.karma += 8; }},
  steuervogt:{name:'Der Steuervogt', giver:'Witwe Enna', lvl:21, desc:'Steuervogt Grell presst Rabenfurt aus und lässt jeden auspeitschen, der nicht zahlt. Er wohnt auf der anderen Seite des Flusses.', steps:[
    {t:'kill', e:'grell', n:1, txt:'Stelle Steuervogt Grell östlich des Flusses von Rabenfurt.'},
    {t:'talk', npc:'enna', txt:'Erzähl Enna, dass der Vogt keine Steuern mehr eintreibt.', say:'„Er ist weg? Wirklich weg?“ Enna lacht und weint zugleich. Am Abend bringt das halbe Dorf dir Geschenke: einen Laib Brot, ein selbstgeschnitztes Holzpferd, eine Flasche sehr fragwürdigen Schnaps.'}],
    reward:{xp:3200, gold:400, items:[['grheiltrank', 2]]}, onDone:() => { P.rep.karma += 6; }},
  grubenunglueck:{name:'Verschüttet', giver:'Vorarbeiterin Brunhild', lvl:21, desc:'Trolle sind in die Alten Stollen östlich von Grauwacht eingefallen. Zwölf Bergleute sitzen fest.', steps:[
    {t:'kill', e:'troll', n:4, txt:'Besiege 4 Trolle in den Alten Stollen östlich von Grauwacht.'},
    {t:'talk', npc:'brunhild', txt:'Kehre zu Brunhild zurück.', say:'Einer nach dem anderen kriechen die Bergleute ans Licht. Brunhild zählt laut mit. Bei „zwölf“ setzt sie sich auf einen Stein und atmet zum ersten Mal seit Tagen richtig aus.'}],
    reward:{xp:3200, gold:350, prof:{bergbau:1}}},
  rebellenwaffen:{name:'Schwerter für die Graue Hand', giver:'Schmiedin Hedda', lvl:21, desc:'Hedda schmiedet heimlich Waffen für den Widerstand. Ihr geht das Eisen aus.', steps:[
    {t:'collect', item:'eisenbarren', n:8, npc:'hedda', txt:'Bring Hedda 8 Eisenbarren.', say:'„Das reicht für zwanzig Klingen.“ Hedda grinst. „Und eine für dich – nimm die Nachtklinge. Und ich zeig dir, wie man Stahl so faltet, dass er Legionsrüstungen durchschlägt.“'}],
    reward:{xp:2800, items:[['nachtklinge', 1]], prof:{schmieden:1}}},
  arena:{name:'Blut und Sand', giver:'Arenameister Kurt', lvl:24, desc:'Arenachampion Kord hat noch nie verloren. Die Leute von Nachtkrone würden alles geben, um ihn fallen zu sehen.', steps:[
    {t:'kill', e:'champion', n:1, txt:'Besiege Arenachampion Kord in der Arena von Nachtkrone.'},
    {t:'talk', npc:'kurt', txt:'Hol dir deinen Preis bei Arenameister Kurt.', say:'Die Menge brüllt deinen Namen – deinen echten, nicht den auf dem Passierschein. Kurt schiebt dir einen schweren Beutel zu. „Lauf, bevor die Prätorianer sich fragen, wer du eigentlich bist.“'}],
    reward:{xp:4500, gold:1500}, onDone:() => toast('🏟️ Titel-Ruhm: Champion von Nachtkrone', 'gold')},
  buecher:{name:'Verbotene Bücher', giver:'Archivar Corvin', lvl:21, desc:'Die Kaiserin lässt alle Bücher über die alte Zeit verbrennen. Corvin will retten, was zu retten ist.', steps:[
    {t:'collect', item:'buch', n:4, npc:'corvin', txt:'Bring Corvin 4 alte Bücher (Ruinen, Skelette, Händler).', say:'Corvin streicht über die Einbände wie über ein schlafendes Kind. „Valdrins Chroniken… Das Lied von Aurelion… Danke. Jemand muss sich erinnern, wenn sie fort ist.“'}],
    reward:{xp:2600, gold:200, items:[['sternenstab', 1]]}},
  juwel:{name:'Das Juwel der Gräfin', giver:'Taschendiebin Fee', lvl:22, desc:'Gräfin Morwenna hat Fees Familie von ihrem Land vertrieben. Ihr Lieblingsjuwel liegt in einer Truhe in ihrem Haus.', steps:[
    {t:'collect', item:'adelsjuwel', n:1, npc:'fee', txt:'Knacke die Truhe am Haus der Gräfin (Nordosten der Stadt) und bring Fee das Juwel.', say:'Fee hält das Juwel gegen das Licht. „Weißt du, was das ist? Das ist das Land meines Vaters. In Stein gepresst.“ Sie steckt es ein. „Die Diebe von Nachtkrone schulden dir was.“'}],
    reward:{xp:2600, gold:800}, onDone:() => { P.rep.diebe += 10; }},
  wasser:{name:'Süßes Wasser', giver:'Brunnenwart Tarek', lvl:14, desc:'Der Oasenteich sinkt jedes Jahr. Bis die Regenzeit kommt, müssen Kaktusfrüchte die Kinder versorgen.', steps:[
    {t:'collect', item:'kaktusfrucht', n:8, npc:'tarek', txt:'Bring Tarek 8 Kaktusfrüchte (Kakteen in der Wüste pflücken).', say:'„Gut gepflückt, ohne dich zu stechen? Nein? Dann hast du aus der Wüste gelernt.“ Tarek lacht und reicht dir einen Becher kühles Wasser – das kostbarste Geschenk in Qarim.'}],
    reward:{xp:1300, gold:120, prof:{sammeln:1}}},
  karawane:{name:'Die Karawanenstraße', giver:'Händler Faruk', lvl:15, desc:'Wüstenräuber überfallen jede Karawane zwischen Qarim und den Aschelanden.', steps:[
    {t:'kill', e:'wuestenraeuber', n:8, txt:'Vertreibe 8 Wüstenräuber.'},
    {t:'talk', npc:'faruk', txt:'Kehre zu Händler Faruk zurück.', say:'„Acht! Bei den Sternen! Hier, nimm das – und den Rabatt. Nein, warte, den Rabatt nicht. Doch, gut, ein kleiner Rabatt.“'}],
    reward:{xp:1800, gold:400, items:[['krummsaebel', 1]]}},
  echsenreiter:{name:'Der Echsenreiter', giver:'Echsenzüchterin Layla', lvl:13, desc:'Wer in der Wüste überleben will, braucht eine Sandechse. Layla zeigt dir, wie man eine zähmt.', steps:[
    {t:'pet', type:'sandechse', txt:'Zähme eine Sandechse (Glutsand-Wüste; Tierzähmung 4, eine Kaktusfrucht als Futter).'},
    {t:'talk', npc:'layla', txt:'Zeig Layla deine neue Sandechse.', say:'Layla krault deine Echse am Kinn, und das Tier schnurrt – ja, wirklich. „Du hast ein gutes Händchen. Hier, ein Echsensattel. Und denk dran: Nie von hinten aufsteigen.“'}],
    reward:{xp:1200, items:[['echsensattel', 1]], prof:{zaehmen:1}}},
  tochter:{name:'Nura und die Ruinen', giver:'Weber Selim', lvl:22, desc:'Selims Tochter Nura ist in die Tiefe Wüste gelaufen, um die alten Ruinen zu sehen.', steps:[
    {t:'talk', npc:'nura', txt:'Finde Nura in der Tiefen Wüste (östlich der Oase).', say:'„Du bist von Papa geschickt? Pass auf – die Skorpione!“'},
    {t:'kill', e:'skorpion', n:5, txt:'Verscheuche die Riesenskorpione um Nura (5).'},
    {t:'talk', npc:'selim', txt:'Bring Selim die Nachricht, dass Nura auf dem Heimweg ist.', say:'Selim fällt auf die Knie und dankt den Sternen, dem Sand und dir – in dieser Reihenfolge. „Nimm diese Robe. Ich habe sie für ihre Hochzeit gewebt. Aber sie ist erst neun, ich webe eine neue.“'}],
    reward:{xp:3000, gold:200, items:[['wuestenrobe', 1]]}},
  dracheneier:{name:'Gestohlene Eier', giver:'Drachenhüterin Ysolde', lvl:22, desc:'Die Jäger haben Nester geplündert. Ysolde will verwaiste Eier ins Kloster holen, bevor sie erkalten.', steps:[
    {t:'collect', item:'drachenei', n:3, npc:'ysolde', txt:'Sammle 3 Dracheneier aus Nestern in den Drachenzinnen (Sammeln Stufe 5).', say:'Ysolde legt die Eier in warme Asche. „Sie werden schlüpfen. Und eines Tages werden sie sich an dich erinnern.“ Sie reicht dir einen glänzenden Tierpanzer. „Für deinen eigenen Drachen.“'}],
    reward:{xp:3500, items:[['tiermithrilpanzer', 1]], prof:{zaehmen:1}}},
  sturmschwinge:{name:'Sturmschwinge, die Uralte', giver:'Drachenhüterin Ysolde', lvl:28, desc:'Ein uralter Drache, wahnsinnig geworden durch Nyxaras Magie, kreist über dem höchsten Gipfel der Zinnen.', steps:[
    {t:'kill', e:'sturmschwinge', n:1, txt:'Stelle Sturmschwinge auf dem höchsten Gipfel im Nordosten der Drachenzinnen.'},
    {t:'talk', npc:'ysolde', txt:'Kehre zu Ysolde zurück.', say:'Ysolde schweigt lange. „Sie war die Mutter vieler unserer Drachen. Jetzt hat sie Frieden.“ Sie reicht dir einen Bogen aus schwarzem Drachenhorn. „Sie hätte gewollt, dass du ihn trägst.“'}],
    reward:{xp:12000, gold:2000, items:[['drachenbogen', 1]]}, onDone:() => { P.title = 'Drachenbezwinger'; toast('🐉 Titel: Drachenbezwinger', 'gold'); }}
});
giver(NPC_DEFS.find(n => n.id === 'greet'), ['verwundete']);
giver(NPC_DEFS.find(n => n.id === 'bors'), ['kriegshunde']);
giver(NPC_DEFS.find(n => n.id === 'leni'), ['deserteurin']);
giver(NPC_DEFS.find(n => n.id === 'enna'), ['hunger', 'steuervogt']);
giver(NPC_DEFS.find(n => n.id === 'brunhild'), ['grubenunglueck']);
giver(NPC_DEFS.find(n => n.id === 'hedda'), ['rebellenwaffen']);
giver(NPC_DEFS.find(n => n.id === 'kurt'), ['arena']);
giver(NPC_DEFS.find(n => n.id === 'corvin'), ['buecher']);
giver(NPC_DEFS.find(n => n.id === 'fee'), ['juwel']);
giver(NPC_DEFS.find(n => n.id === 'tarek'), ['wasser']);
giver(NPC_DEFS.find(n => n.id === 'faruk'), ['karawane']);
giver(NPC_DEFS.find(n => n.id === 'layla'), ['echsenreiter']);
giver(NPC_DEFS.find(n => n.id === 'selim'), ['tochter']);
giver(NPC_DEFS.find(n => n.id === 'ysolde'), ['dracheneier', 'sturmschwinge']);
react('koenig', [[() => questDone('front'), '„Hagen schreibt, du hättest Drogan erschlagen. Hagen lobt nie jemanden. Ich mache mir fast Sorgen um ihn.“'], [() => questDone('kaiserin'), '„Die Ewige Kaiserin… gefallen durch ein Kind, das ich einst für einen Dieb hielt. Die Götter haben Humor.“']]);
react('hilde', [[() => questDone('kaiserin'), '„Ich hab der Kaiserin gesagt, dass sie sich warm anziehen soll. Hat sie nicht gehört. Typisch Adel.“']]);
react('sera', [[() => questDone('front'), '„Hauptmann der Löwenwacht? Ich hab immer gesagt, aus dir wird was. Na gut, ich hab’s gedacht. Leise.“']]);

// ---------- Ereignisse im Osten ----------
STORY_EVENTS.push(
  {w:2, fn() {
    if (regionAt(P.x, P.y) !== 'front') return; const s = freeSpot(3, 6); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'verwundet');
    G.tmp.push({id:'verwundet', name:'Verwundeter Soldat', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e0b090', hair:'#6a4a2a', outfit:'#2a4a8a', style:'chain', helmCol:'#8a8e9a'},
      talk() {
        if (this.done) return {text:'„Ich schaff’s zurück ins Lager. Dank dir.“'};
        return {text:'„Hauptmann… mein Trupp ist gefallen. Hast du einen Heiltrank?“', opts:[
          {t:'🧪 Großen Heiltrank geben', f:() => { if (!countItem('grheiltrank')) return {text:'Du hast keinen Großen Heiltrank.'}; removeItem('grheiltrank', 1); this.done = true; P.rep.karma += 5; P.rep.stadt += 2; gainXp(300); return {text:'Er trinkt und Farbe kehrt in sein Gesicht zurück. „Ich werde Hagen sagen, wer mir das Leben gerettet hat.“'}; }},
          {t:'Weitergehen', f:() => { P.rep.karma -= 2; this.done = true; return 'close'; }}]};
      }});
    refreshNpcs(); toast('🆘 Ein verwundeter Soldat ruft nach dir!', 'quest');
  }},
  {w:2, fn() {
    const r = regionAt(P.x, P.y); if (r !== 'wueste' && r !== 'tiefwueste') return; const s = freeSpot(4, 7); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'karawane');
    G.tmp.push({id:'karawane', name:'Wandernde Karawane', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, shop:'faruk', look:{skin:'#a8744a', hair:'#1a1a1a', outfit:'#c83a3a', beard:true, style:'cloth', helmCol:'#e8dcc0'},
      talk() { return {text:'„Salam, Reisender! Unsere Kamele sind müde, aber unsere Waren sind frisch. Na ja – frisch für Wüstenverhältnisse.“'}; }});
    refreshNpcs(); toast('🐪 Eine Karawane zieht durch die Dünen!', 'quest');
  }},
  {w:1, fn() {
    if (regionAt(P.x, P.y) !== 'kernland') return; const s = freeSpot(3, 6); if (!s) return;
    G.tmp = G.tmp.filter(t => t.id !== 'fluechtling');
    G.tmp.push({id:'fluechtling', name:'Flüchtlingsfamilie', x:s[0] + 0.5, y:s[1] + 0.6, tmpNpc:true, expires:G.day + 1, look:{skin:'#e0c0a0', hair:'#5a3a2a', outfit:'#5a5040', longHair:true, style:'cloth'},
      talk() {
        if (this.done) return {text:'„Möge dich das Licht beschützen.“'};
        return {text:'„Die Legion hat unser Dorf niedergebrannt, weil wir nicht genug Korn hatten. Wir wollen nach Grauwacht. Hast du etwas zu essen?“', opts:[
          {t:'🍞 3 Brote geben', f:() => { if (countItem('brot') < 3) return {text:'Du hast nicht genug Brot.'}; removeItem('brot', 3); this.done = true; P.rep.karma += 6; gainXp(200); return {text:'Die Kinder essen gierig. Die Mutter drückt dir einen kleinen Holzanhänger in die Hand – ein Rabe. „Das Zeichen der Grauen Hand. Zeig ihn, und man wird dir helfen.“'}; }},
          {t:'Weitergehen', f:() => { this.done = true; return 'close'; }}]};
      }});
    refreshNpcs(); toast('👣 Am Wegesrand kauert eine Familie…', 'quest');
  }},
  {w:1, fn() {
    if (regionAt(P.x, P.y) !== 'drachenzinnen') return; const s = freeSpot(8, 11); if (!s) return;
    spawnEnemy(chance(0.5) ? 'jungdrache' : 'frostdrache', s[0] + 0.5, s[1] + 0.5, {aggro:true, lvl:rint(23, 26)});
    G.shake = 0.4; toast('🐉 Ein Schatten fällt vom Himmel – ein junger Drache stürzt herab!', 'warn');
  }}
);
