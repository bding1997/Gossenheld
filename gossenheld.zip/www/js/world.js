'use strict';
// ---------- Welt & Kartengenerierung ----------
const MW = 160, MH = 160;
const TL = {GRASS:0,WATER:1,SAND:2,TREE:3,ROCK:4,IRON:5,PATH:6,ROOF:7,WALL:8,SWAMP:9,DARK:10,SNOW:11,HERB:12,MUSHROOM:13,BRIDGE:14,ANVIL:15,HEARTH:16,CHEST:17,FLOWER:18,SILVER:19,MITHRIL:20,DEADTREE:21,FLOOR:22,CRYSTAL:23,DOOR:24,FENCE:25,GRAVEL:26,PINE:27};
const BLOCK = new Uint8Array(32); [1,3,4,5,7,8,15,16,17,19,20,21,23,24,25,27].forEach(t => BLOCK[t] = 1);
const PSOLID = new Uint8Array(32); [3,4,5,7,8,15,16,17,19,20,21,23,24,27].forEach(t => PSOLID[t] = 1);
const TALL = new Uint8Array(32); [3,21,27].forEach(t => TALL[t] = 1);
const TILE_COLORS = ['#5b9b3d','#3576bd','#d9c58a','#2f6a26','#8d8d92','#a0704a','#a98457','#9c3b2b','#6b6b74','#4b5a33','#3b3142','#e6edf3','#4f9a3f','#7a5a3a','#8b5a2b','#4a4a52','#d06a2a','#e0b040','#c86a9a','#c8d0d8','#3ac8f0','#5a4a3a','#8c867a','#6ae0f0','#6b4422','#8a6236','#857b6c','#2c5e3c'];
const REGIONS = ['wiese','wald','berge','sumpf','morvath','stadt','gosse','dorf','ruinen','lager','goblinlager','mine','hexe','festung','hort'];
const RIDX = {}; REGIONS.forEach((r, i) => RIDX[r] = i);
const REGION_INFO = {
  wiese:{name:'Goldwiesen',c:[45,122]}, wald:{name:'Grünwald',c:[42,42]}, berge:{name:'Eisenzahn-Berge',c:[110,22]},
  sumpf:{name:'Nebelsumpf',c:[125,78]}, morvath:{name:'Reich Morvath',c:[122,128]}, stadt:{name:'Aldenmark',c:[80,99],safe:true},
  gosse:{name:'Rattenviertel',c:[59,115]}, dorf:{name:'Eichenrast',c:[34,56],safe:true}, ruinen:{name:'Ruinen von Valdrin',c:[28,96]},
  lager:{name:'Banditenlager',c:[24,136]}, goblinlager:{name:'Goblinlager',c:[20,28]}, mine:{name:'Zwergenmine Tiefgrund',c:[116,28]},
  hexe:{name:'Hexenhütte',c:[130,86]}, festung:{name:'Festung Schwarzfels',c:[139,142]}, hort:{name:'Drachenhort',c:[142,12]}
};
// Abbaubare Felder
const HARVEST = {
  3:{verb:'Fällen',item:'holz',n:[2,3],tool:'axt',prof:'holz',time:1.1,lvl:0,regrow:2},
  27:{verb:'Fällen',item:'holz',n:[2,3],tool:'axt',prof:'holz',time:1.1,lvl:0,regrow:2},
  21:{verb:'Fällen',item:'holz',n:[1,2],tool:'axt',prof:'holz',time:0.9,lvl:0,regrow:3},
  4:{verb:'Abbauen',item:'stein',n:[1,3],tool:'spitzhacke',prof:'bergbau',time:1.1,lvl:0,regrow:3},
  5:{verb:'Abbauen',item:'eisenerz',n:[1,2],tool:'spitzhacke',prof:'bergbau',time:1.3,lvl:0,regrow:4},
  19:{verb:'Abbauen',item:'silbererz',n:[1,2],tool:'spitzhacke',prof:'bergbau',time:1.6,lvl:3,regrow:5},
  20:{verb:'Abbauen',item:'mithrilerz',n:[1,2],tool:'spitzhacke',prof:'bergbau',time:2.0,lvl:6,regrow:7},
  23:{verb:'Abbauen',item:'kristall',n:[1,2],tool:'spitzhacke',prof:'bergbau',time:1.8,lvl:4,regrow:6},
  12:{verb:'Sammeln',item:'kraut',n:[1,2],prof:'sammeln',time:0.6,lvl:0,regrow:1},
  13:{verb:'Sammeln',item:'pilz',n:[1,2],prof:'sammeln',time:0.6,lvl:0,regrow:1},
  18:{verb:'Pflücken',item:'blume',n:[1,2],prof:'sammeln',time:0.5,lvl:0,regrow:1}
};
let WT, WT0, WG, WR, WV;
const idx = (x, y) => y * MW + x;
const inb = (x, y) => x >= 0 && y >= 0 && x < MW && y < MH;
function riverX(y) { return 100 + Math.sin(y / 13) * 4 + Math.sin(y / 5.3) * 1.5; }
function baseRegion(x, y) {
  if (x > riverX(y) + 1) { if (y > 112) return 'morvath'; if (y < 52) return 'berge'; return 'sumpf'; }
  if (y < 46 && x > 68) return 'berge';
  if (x < 72 && y < 88) return 'wald';
  return 'wiese';
}
function specialRegion(x, y) {
  const d = (a, b) => Math.hypot(x - a, y - b);
  if (x >= 66 && x <= 94 && y >= 88 && y <= 110) return 'stadt';
  if (x >= 52 && x <= 65 && y >= 108 && y <= 122) return 'gosse';
  if (d(34, 56) < 9) return 'dorf';
  if (d(20, 28) < 7.5) return 'goblinlager';
  if (d(28, 96) < 8) return 'ruinen';
  if (d(24, 136) < 7) return 'lager';
  if (d(116, 28) < 7) return 'mine';
  if (d(130, 85) < 6) return 'hexe';
  if (x >= 128 && x <= 150 && y >= 132 && y <= 152) return 'festung';
  if (d(142, 12) < 8) return 'hort';
  return null;
}
function setG(x, y, t) { if (!inb(x, y)) return; const i = idx(x, y); WT[i] = t; WG[i] = t; }
function setO(x, y, t) { if (!inb(x, y)) return; WT[idx(x, y)] = t; }
function rectG(x0, y0, x1, y1, t) { for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) setG(x, y, t); }
function circG(cx, cy, r, t) { for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if (Math.hypot(x - cx, y - cy) <= r) setG(x, y, t); }
function building(x0, y0, w, h, v, type) {
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) { setG(x, y, type || TL.ROOF); WV[idx(x, y)] = v; }
  setG(x0 + (w >> 1), y0 + h - 1, TL.DOOR);
}
function chestAt(x, y, def) { setO(x, y, TL.CHEST); G.chests[idx(x, y)] = def; }
function pathAt(x, y) {
  if (!inb(x, y)) return;
  const i = idx(x, y), t = WT[i];
  if ([TL.WALL,TL.ROOF,TL.DOOR,TL.FENCE,TL.CHEST,TL.FLOOR,TL.ANVIL,TL.HEARTH].includes(t)) return;
  if (WG[i] === TL.WATER) { WT[i] = WG[i] = TL.BRIDGE; }
  else if (WG[i] !== TL.BRIDGE) { WT[i] = WG[i] = TL.PATH; }
}
function road(x0, y0, x1, y1) {
  let dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) {
    pathAt(x0, y0); pathAt(x0 + 1, y0); pathAt(x0, y0 + 1);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}
function genWorld(seed) {
  const N = MW * MH;
  WT = new Uint8Array(N); WG = new Uint8Array(N); WR = new Uint8Array(N); WV = new Uint8Array(N).fill(255);
  G.chests = {};
  for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
    const i = idx(x, y), br = baseRegion(x, y), sr = specialRegion(x, y) || br;
    WR[i] = RIDX[sr];
    const n = fbm(x, y, seed), h = hash2(x, y, seed + 9), h2 = hash2(x + 3, y + 7, seed + 21);
    let g = TL.GRASS, o = -1;
    switch (br) {
      case 'wald':
        if (n > 0.5) o = TL.TREE; else if (h < 0.025) o = TL.HERB; else if (h < 0.05) o = TL.MUSHROOM; else if (h < 0.06) o = TL.FLOWER; else if (h < 0.068) o = TL.ROCK;
        break;
      case 'wiese':
        if (n < 0.2) g = TL.WATER; else if (n < 0.24) g = TL.SAND;
        else { if (n > 0.7) o = TL.TREE; else if (h < 0.012) o = TL.ROCK; else if (h < 0.03) o = TL.FLOWER; else if (h < 0.04) o = TL.HERB; else if (h < 0.044) o = TL.IRON; }
        break;
      case 'berge':
        g = y < 22 ? TL.SNOW : TL.GRAVEL;
        if (n > 0.52) { o = TL.ROCK; if (h2 < 0.13) o = TL.IRON; else if (h2 < 0.18) o = TL.SILVER; else if (h2 < 0.2) o = TL.CRYSTAL; else if (y < 24 && h2 < 0.24) o = TL.MITHRIL; }
        else if (n > 0.44 && h < 0.35) o = TL.PINE; else if (h < 0.01) o = TL.HERB;
        break;
      case 'sumpf':
        if (n < 0.3) g = TL.WATER; else { g = TL.SWAMP; if (n > 0.62) o = TL.DEADTREE; else if (h < 0.05) o = TL.MUSHROOM; else if (h < 0.08) o = TL.HERB; }
        break;
      case 'morvath':
        g = TL.DARK;
        if (n > 0.62) o = TL.DEADTREE; else if (n < 0.22) { o = TL.ROCK; if (h2 < 0.08) o = TL.MITHRIL; else if (h2 < 0.2) o = TL.IRON; else if (h2 < 0.25) o = TL.CRYSTAL; }
        break;
    }
    if (Math.abs(x - riverX(y)) < 1.8) { g = TL.WATER; o = -1; }
    if (x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) { g = TL.WATER; o = -1; }
    WG[i] = g; WT[i] = o >= 0 ? o : g;
  }
  // --- Aldenmark ---
  rectG(66, 88, 94, 110, TL.FLOOR);
  for (let x = 66; x <= 94; x++) { setG(x, 88, TL.WALL); setG(x, 110, TL.WALL); }
  for (let y = 88; y <= 110; y++) { setG(66, y, TL.WALL); setG(94, y, TL.WALL); }
  [[90,88],[91,88],[79,110],[80,110],[81,110],[66,99],[66,100],[66,101],[94,99],[94,100],[94,101]].forEach(p => setG(p[0], p[1], TL.FLOOR));
  building(76, 89, 9, 5, 0, TL.WALL);        // Burg
  building(68, 94, 5, 3, 0);                 // Händler
  building(87, 94, 5, 3, 1);                 // Schmiede
  building(68, 103, 6, 3, 0);                // Taverne
  building(76, 103, 5, 3, 1);                // Tempel
  building(84, 103, 6, 3, 3);                // Gilde
  rectG(79, 98, 80, 99, TL.WATER);           // Brunnen
  setO(92, 97, TL.ANVIL); setO(74, 104, TL.HEARTH);
  chestAt(73, 95, {lock:1, gold:40, loot:[], owner:'baldur', refill:true});
  for (const p of [[67,90],[93,90],[67,108],[93,108],[75,100],[86,100]]) setO(p[0], p[1], TL.FLOWER);
  // --- Rattenviertel ---
  rectG(52, 108, 65, 122, TL.PATH);
  for (let y = 108; y <= 122; y++) for (let x = 52; x <= 65; x++) if (hash2(x, y, 77) < 0.35) setG(x, y, TL.GRASS);
  building(54, 109, 3, 2, 3); building(58, 110, 3, 2, 0); building(53, 118, 3, 2, 3); building(61, 119, 3, 2, 0); building(57, 119, 2, 2, 3);
  setO(56, 115, TL.HEARTH);
  // --- Eichenrast ---
  circG(34, 56, 8.5, TL.GRASS);
  for (let y = 46; y <= 66; y++) for (let x = 24; x <= 44; x++) {
    const dx = x - 34, dy = y - 56, d = Math.hypot(dx, dy);
    if (d > 7.4 && d < 8.4 && Math.abs(dx) > 1 && Math.abs(dy) > 1) setO(x, y, TL.FENCE);
  }
  building(28, 49, 4, 3, 0); building(37, 49, 4, 3, 1); building(27, 59, 4, 3, 2); building(38, 59, 4, 3, 0);
  setO(36, 57, TL.HEARTH); setO(33, 52, TL.FLOWER); setO(35, 52, TL.FLOWER);
  // --- Goblinlager ---
  circG(20, 28, 6.5, TL.PATH);
  building(15, 24, 3, 2, 0); building(22, 23, 3, 2, 0); building(15, 31, 3, 2, 0);
  chestAt(24, 30, {lock:1, gold:30, loot:[['heiltrank',2]]});
  // --- Ruinen ---
  circG(28, 96, 7.5, TL.GRASS);
  for (let y = 88; y <= 104; y++) for (let x = 20; x <= 36; x++) {
    const d = Math.hypot(x - 28, y - 96);
    if (d < 3) setG(x, y, TL.FLOOR); else if (d < 6.5 && d > 3.5 && hash2(x, y, 5) < 0.35) setG(x, y, TL.WALL);
  }
  chestAt(28, 95, {lock:2, gold:80, loot:[['buch',1],['kristall',1]]});
  chestAt(25, 99, {lock:3, gold:120, loot:[['grheiltrank',1],['silberbarren',2]]});
  // --- Banditenlager ---
  circG(24, 136, 6.5, TL.PATH);
  building(19, 131, 3, 2, 3); building(26, 131, 3, 2, 3);
  chestAt(24, 138, {lock:3, gold:200, loot:[['rucksack',1],['dietrich',3]]});
  // --- Zwergenmine ---
  circG(116, 28, 6.5, TL.GRAVEL);
  for (let y = 20; y <= 36; y++) for (let x = 108; x <= 124; x++) {
    const dx = x - 116, dy = y - 28, d = Math.hypot(dx, dy);
    if (d > 5 && d < 6.6 && !(dy > 3 && Math.abs(dx) <= 2)) { const h = hash2(x, y, 3); setO(x, y, h < 0.45 ? TL.IRON : h < 0.7 ? TL.SILVER : TL.ROCK); }
  }
  building(114, 21, 5, 3, 0, TL.WALL); setO(119, 26, TL.ANVIL); setO(113, 27, TL.HEARTH);
  // --- Hexenhütte ---
  circG(130, 86, 4.5, TL.SWAMP);
  building(128, 82, 4, 3, 2);
  // --- Festung Schwarzfels ---
  rectG(128, 132, 150, 152, TL.DARK);
  for (let x = 128; x <= 150; x++) { setG(x, 132, TL.WALL); setG(x, 152, TL.WALL); }
  for (let y = 132; y <= 152; y++) { setG(128, y, TL.WALL); setG(150, y, TL.WALL); }
  for (let x = 138; x <= 140; x++) setG(x, 132, TL.DARK);
  rectG(133, 137, 134, 138, TL.WALL); rectG(144, 137, 145, 138, TL.WALL); rectG(133, 146, 134, 147, TL.WALL); rectG(144, 146, 145, 147, TL.WALL);
  chestAt(130, 150, {lock:4, gold:500, loot:[['mithrilbarren',2]]});
  chestAt(148, 150, {lock:4, gold:400, loot:[['kristall',3],['grheiltrank',2]]});
  // --- Drachenhort ---
  circG(142, 12, 7.5, TL.GRAVEL);
  for (let y = 3; y <= 21; y++) for (let x = 133; x <= 151; x++) {
    const dx = x - 142, dy = y - 12, d = Math.hypot(dx, dy);
    if (d > 5.6 && d < 7.2 && !(dy > 3 && Math.abs(dx) <= 2)) { const h = hash2(x, y, 9); setO(x, y, h < 0.3 ? TL.MITHRIL : h < 0.5 ? TL.CRYSTAL : TL.ROCK); }
  }
  chestAt(142, 8, {lock:5, gold:3000, loot:[['schuppe',2],['mithrilbarren',3]]});
  // --- Straßen ---
  road(80, 111, 80, 114); road(80, 114, 64, 114);
  road(65, 100, 45, 100); road(45, 100, 34, 65);
  road(34, 47, 21, 34);
  road(90, 87, 90, 62); road(90, 62, 116, 35);
  road(95, 100, 126, 88);
  road(80, 114, 92, 124); road(92, 124, 139, 131);
  road(45, 100, 34, 98);
  road(60, 122, 30, 134);
  WT0 = WT.slice();
}
